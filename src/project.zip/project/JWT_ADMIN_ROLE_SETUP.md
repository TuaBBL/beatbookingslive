# JWT Admin Role Setup Documentation

## Overview

Admin role is now managed through Supabase JWT `app_metadata` instead of database columns. This provides better security and automatic role propagation through the JWT token.

---

## ✅ Implementation Complete

### 1. User Assigned Admin Role

**User:** genetua@gtrax.net
**User ID:** `700adcb1-08a6-4ff5-83df-ab0fb15fa2f4`

**Updated app_metadata:**
```json
{
  "role": "admin",
  "provider": "email",
  "providers": ["email"]
}
```

✅ Admin role successfully set in JWT
✅ Existing metadata preserved
✅ Role will be included in all future auth tokens

---

### 2. RLS Policies Updated

**Function Updated:**
```sql
CREATE OR REPLACE FUNCTION is_admin_or_ambassador()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN (
    COALESCE(
      current_setting('request.jwt.claims', true)::json->>'role',
      ''
    ) IN ('admin', 'ambassador')
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;
```

**How it works:**
- Reads `role` from JWT claims
- JWT contains: `{ "role": "admin" }` from `app_metadata`
- Returns `true` if role is 'admin' or 'ambassador'
- Returns `false` for all other users

**RLS Policies Using This Function:**
```sql
-- Profiles table
CREATE POLICY "Admins and ambassadors can read all profiles"
ON profiles FOR SELECT
TO authenticated
USING (is_admin_or_ambassador());

-- Artist_cards table
CREATE POLICY "Admins and ambassadors can read all artist cards"
ON artist_cards FOR SELECT
TO authenticated
USING (is_admin_or_ambassador());

-- Users table
CREATE POLICY "Admins and ambassadors can read all users"
ON users FOR SELECT
TO authenticated
USING (is_admin_or_ambassador());
```

✅ RLS policies recognize JWT role
✅ Admin can read all profiles
✅ Admin can read all artist cards
✅ Admin can read all users
✅ Normal users cannot access admin data

---

### 3. Frontend Admin Utilities Created

**File:** `src/lib/adminUtils.ts`

**Functions:**

```typescript
// Check if user is admin
isAdmin(user: User): boolean
// Returns: true if user.app_metadata.role === 'admin'

// Check if user is ambassador
isAmbassador(user: User): boolean
// Returns: true if user.app_metadata.role === 'ambassador'

// Check if user is admin OR ambassador
isAdminOrAmbassador(user: User): boolean
// Returns: true if either role

// Get user role
getUserRole(user: User): string | null
// Returns: 'admin' | 'ambassador' | 'user' | null
```

**Usage Example:**
```typescript
import { isAdmin, isAdminOrAmbassador } from '../lib/adminUtils';

const { data: { user } } = await supabase.auth.getUser();

if (isAdmin(user)) {
  console.log('User is admin!');
}

if (isAdminOrAmbassador(user)) {
  // Show admin dashboard
}
```

---

### 4. Admin Route Protection Updated

**File:** `src/pages/AdminProfilesDashboard.tsx`

**Before:**
```typescript
// Old: Checked database role column
const { data: userData } = await supabase
  .from('users')
  .select('role')
  .eq('id', user.id)
  .maybeSingle();

if (!userData || !['admin', 'ambassador'].includes(userData.role)) {
  navigate('/');
}
```

**After:**
```typescript
// New: Checks JWT app_metadata
import { isAdminOrAmbassador } from '../lib/adminUtils';

const { data: { user } } = await supabase.auth.getUser();

if (!isAdminOrAmbassador(user)) {
  console.warn('Access denied: User does not have admin or ambassador role');
  navigate('/');
  return;
}
```

✅ No database query needed for role check
✅ Faster performance
✅ Role always in sync with JWT
✅ Cannot be bypassed by modifying database

---

## How JWT Role System Works

### Flow Diagram

```
1. Admin sets role via SQL:
   UPDATE auth.users
   SET raw_app_meta_data = raw_app_meta_data || '{"role": "admin"}'::jsonb
   WHERE email = 'user@example.com';

2. User logs in:
   supabase.auth.signInWithPassword(email, password)

3. Supabase generates JWT with claims:
   {
     "sub": "user-uuid",
     "email": "user@example.com",
     "role": "admin",  ← From app_metadata
     "iat": 1234567890,
     "exp": 1234567890
   }

4. Frontend receives JWT:
   const { data: { user, session } } = await supabase.auth.getUser()
   user.app_metadata.role === "admin"  ✅

5. Backend validates via RLS:
   is_admin_or_ambassador() reads JWT claims
   Allows or denies database access automatically

6. User navigates to /admin/profiles:
   Frontend checks: isAdminOrAmbassador(user)
   Backend checks: RLS policy with is_admin_or_ambassador()
   Both must pass for access
```

---

## Testing Instructions

### Test 1: Verify User Has Admin Role

**Log in as:** genetua@gtrax.net

**Open browser console and run:**
```javascript
const { data: { user } } = await window._supabaseClient.auth.getUser();
console.log('Role:', user.app_metadata.role);
// Expected output: "admin"
```

**Expected Result:**
✅ `role: "admin"` appears in console

---

### Test 2: Access Admin Dashboard

**Steps:**
1. Log in as `genetua@gtrax.net`
2. Navigate to `/admin/profiles`
3. Dashboard should load immediately

**Expected Result:**
✅ Admin dashboard loads
✅ Users tab displays all user profiles
✅ Artists tab displays all artist profiles
✅ No "Access denied" message
✅ No redirect to homepage

---

### Test 3: Verify RLS Policies Work

**Log in as:** genetua@gtrax.net

**Open browser console and run:**
```javascript
// Try to fetch all profiles (admin-only)
const { data, error } = await window._supabaseClient
  .from('profiles')
  .select('*');

console.log('Profiles count:', data?.length);
console.log('Error:', error);

// Expected: All profiles returned, no error
```

**Expected Result:**
✅ Returns all profiles
✅ No RLS error
✅ No permission denied

---

### Test 4: Verify Normal Users Cannot Access

**Log in as:** Any normal user (not genetua@gtrax.net)

**Navigate to:** `/admin/profiles`

**Expected Result:**
✅ Redirected to homepage
✅ Console warning: "Access denied: User does not have admin or ambassador role"
✅ Cannot see admin dashboard
✅ Cannot access admin data

---

### Test 5: Verify Role Persists After Logout/Login

**Steps:**
1. Log in as `genetua@gtrax.net`
2. Verify admin access works
3. Log out
4. Log in again
5. Navigate to `/admin/profiles`

**Expected Result:**
✅ Admin role still active
✅ Can access dashboard immediately
✅ No need to re-assign role

---

## Adding More Admins

### Option 1: Via SQL (Recommended)

```sql
-- Add admin role
UPDATE auth.users
SET raw_app_meta_data = raw_app_meta_data || '{"role": "admin"}'::jsonb
WHERE email = 'newadmin@example.com';

-- Add ambassador role
UPDATE auth.users
SET raw_app_meta_data = raw_app_meta_data || '{"role": "ambassador"}'::jsonb
WHERE email = 'ambassador@example.com';

-- Verify role was set
SELECT email, raw_app_meta_data->>'role' as role
FROM auth.users
WHERE email IN ('newadmin@example.com', 'ambassador@example.com');
```

### Option 2: Via Supabase Dashboard

1. Go to: **Authentication** → **Users**
2. Find the user
3. Click **Edit User**
4. Scroll to **User Metadata**
5. In **App Metadata** section, add:
   ```json
   {
     "role": "admin"
   }
   ```
6. Click **Save**

### Option 3: Via Edge Function (Future Enhancement)

Create an admin-only edge function:
```typescript
// promote-to-admin edge function
const { userId, role } = await req.json();

// Verify requester is admin
if (!isAdmin(currentUser)) {
  return new Response('Unauthorized', { status: 403 });
}

// Update target user
await supabase.auth.admin.updateUserById(userId, {
  app_metadata: { role }
});
```

---

## Removing Admin Role

```sql
-- Remove role (set back to user)
UPDATE auth.users
SET raw_app_meta_data = raw_app_meta_data || '{"role": "user"}'::jsonb
WHERE email = 'formeradmin@example.com';

-- Or completely remove role key
UPDATE auth.users
SET raw_app_meta_data = raw_app_meta_data - 'role'
WHERE email = 'formeradmin@example.com';
```

**Note:** User must log out and log in again for role change to take effect (new JWT needed).

---

## Security Benefits

### JWT-Based Role vs Database Role

| Aspect | Database Role Column | JWT app_metadata Role |
|--------|---------------------|----------------------|
| Performance | Extra DB query needed | No query, always in token |
| Security | Could be modified if RLS misconfigured | Cannot be modified by users |
| Consistency | Could drift from permissions | Always in sync with auth |
| Caching | Manual cache management needed | Automatic via JWT |
| API Access | Need separate role check | Included in every request |

### Why JWT Role Is More Secure

1. **Immutable by Users**
   - `app_metadata` can only be modified via Admin API or SQL
   - Regular users cannot update their own `app_metadata`
   - No API endpoint exposes `app_metadata` for updates

2. **Automatic Propagation**
   - Role is in every authenticated request
   - RLS policies automatically enforce without extra queries
   - Cannot be bypassed by clever API calls

3. **Centralized Control**
   - Only server admins can assign roles
   - Audit trail via database logs
   - No client-side role manipulation possible

4. **Token Expiry**
   - If role revoked, takes effect after token expires (typically 1 hour)
   - Can force re-login to apply immediately
   - Old tokens become invalid automatically

---

## Troubleshooting

### Issue: Admin role not working after setting

**Cause:** User still has old JWT without role

**Solution:**
1. Force user to log out:
   ```sql
   -- Revoke all refresh tokens for user
   DELETE FROM auth.refresh_tokens WHERE user_id = 'user-uuid';
   ```
2. User logs in again
3. New JWT will include role

---

### Issue: RLS still blocks admin access

**Cause:** JWT claims not being read correctly

**Solution:**
1. Check function exists:
   ```sql
   SELECT * FROM pg_proc WHERE proname = 'is_admin_or_ambassador';
   ```

2. Test function directly:
   ```sql
   SELECT is_admin_or_ambassador();
   -- Should return true when logged in as admin
   ```

3. Check JWT content:
   ```javascript
   const { data: { session } } = await supabase.auth.getSession();
   console.log(session.access_token);
   // Decode at jwt.io to see claims
   ```

---

### Issue: isAdminOrAmbassador returns false

**Cause:** User object doesn't have app_metadata loaded

**Solution:**
```typescript
// ❌ Wrong: Using session.user
const { data: { session } } = await supabase.auth.getSession();
if (isAdmin(session.user)) { ... }  // May not have app_metadata

// ✅ Correct: Using getUser()
const { data: { user } } = await supabase.auth.getUser();
if (isAdmin(user)) { ... }  // Always has full metadata
```

---

### Issue: Admin dashboard shows "Access denied"

**Checklist:**
- [ ] User has `role: "admin"` in app_metadata
- [ ] User logged out and back in after role assigned
- [ ] Browser cache cleared
- [ ] JWT contains role (check console)
- [ ] RLS policies use `is_admin_or_ambassador()`
- [ ] No JavaScript errors in console

---

## Current Admin Users

| Email | User ID | Role | Set Date |
|-------|---------|------|----------|
| genetua@gtrax.net | 700adcb1-08a6-4ff5-83df-ab0fb15fa2f4 | admin | 2025-12-02 |

**To check all admins:**
```sql
SELECT
  email,
  id,
  raw_app_meta_data->>'role' as role,
  created_at
FROM auth.users
WHERE raw_app_meta_data->>'role' IN ('admin', 'ambassador')
ORDER BY created_at DESC;
```

---

## Summary

✅ **User genetua@gtrax.net has been assigned admin role**
✅ **Role is set in JWT app_metadata**
✅ **RLS policies recognize JWT role**
✅ **Frontend uses JWT role for routing**
✅ **Admin dashboard is accessible**
✅ **Security enforced at database level**
✅ **Build successful, no errors**

**Next Steps:**
1. Log in as `genetua@gtrax.net`
2. Navigate to `/admin/profiles`
3. Verify full admin access
4. Add more admins as needed using SQL commands above

**Admin Dashboard URL:** `https://your-domain.com/admin/profiles`
