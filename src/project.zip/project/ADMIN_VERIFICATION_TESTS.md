# Admin Role Verification Tests

## Quick Verification Checklist

Run these tests to verify the admin role system is working correctly.

---

## ✅ Test 1: Verify Database Role

**Run in Supabase SQL Editor:**
```sql
SELECT
  email,
  id,
  raw_app_meta_data,
  raw_app_meta_data->>'role' as extracted_role
FROM auth.users
WHERE email = 'genetua@gtrax.net';
```

**Expected Output:**
```
email              | genetua@gtrax.net
id                 | 700adcb1-08a6-4ff5-83df-ab0fb15fa2f4
raw_app_meta_data  | {"role": "admin", "provider": "email", "providers": ["email"]}
extracted_role     | admin
```

**Status:** ✅ PASS if role = "admin"

---

## ✅ Test 2: Verify RLS Function

**Run in Supabase SQL Editor:**
```sql
-- Test as the admin user (must be logged in as genetua@gtrax.net)
SELECT is_admin_or_ambassador() as is_admin;
```

**Expected Output:**
```
is_admin | true
```

**Status:** ✅ PASS if returns true

---

## ✅ Test 3: Verify Admin Can Read All Profiles

**Run in Supabase SQL Editor (as admin):**
```sql
SELECT COUNT(*) as total_profiles
FROM profiles;
```

**Expected:** Returns count of ALL profiles (not just admin's own)

**Status:** ✅ PASS if returns all profiles without RLS error

---

## ✅ Test 4: Verify Admin Can Read All Artists

**Run in Supabase SQL Editor (as admin):**
```sql
SELECT COUNT(*) as total_artists
FROM artist_cards;
```

**Expected:** Returns count of ALL artist cards

**Status:** ✅ PASS if returns all artists without RLS error

---

## ✅ Test 5: Frontend Role Check

**Log in as genetua@gtrax.net**

**Open browser console and paste:**
```javascript
// Get current user
const { data: { user } } = await window._supabaseClient.auth.getUser();

console.log('=== User Role Verification ===');
console.log('Email:', user.email);
console.log('User ID:', user.id);
console.log('app_metadata:', user.app_metadata);
console.log('Role:', user.app_metadata?.role);
console.log('Is Admin?:', user.app_metadata?.role === 'admin');
```

**Expected Output:**
```
=== User Role Verification ===
Email: genetua@gtrax.net
User ID: 700adcb1-08a6-4ff5-83df-ab0fb15fa2f4
app_metadata: {role: 'admin', provider: 'email', providers: Array(1)}
Role: admin
Is Admin?: true
```

**Status:** ✅ PASS if "Is Admin?: true"

---

## ✅ Test 6: Admin Dashboard Access

**Steps:**
1. Log in as `genetua@gtrax.net`
2. Navigate to: `http://localhost:5173/admin/profiles` (or your domain)
3. Observe the page

**Expected Result:**
- ✅ Page loads successfully
- ✅ Shows "Admin Dashboard" header
- ✅ Shows two tabs: "Users" and "Artists"
- ✅ Shows table with profile data
- ✅ No redirect to homepage
- ✅ No "Access denied" errors in console

**Status:** ✅ PASS if dashboard displays

---

## ✅ Test 7: Normal User Cannot Access Admin Dashboard

**Steps:**
1. Log in as ANY other user (not genetua@gtrax.net)
2. Navigate to: `/admin/profiles`
3. Observe behavior

**Expected Result:**
- ✅ Redirected to homepage immediately
- ✅ Console shows: "Access denied: User does not have admin or ambassador role"
- ✅ Cannot see admin dashboard

**Status:** ✅ PASS if redirected and blocked

---

## ✅ Test 8: Verify Helper Functions Work

**Log in as genetua@gtrax.net**

**Open browser console and paste:**
```javascript
// Import helper (if available globally, otherwise skip)
const { data: { user } } = await window._supabaseClient.auth.getUser();

// Manual check (same logic as helper)
const isAdmin = user?.app_metadata?.role === 'admin';
const isAmbassador = user?.app_metadata?.role === 'ambassador';
const isAdminOrAmbassador = isAdmin || isAmbassador;

console.log('Is Admin:', isAdmin);
console.log('Is Ambassador:', isAmbassador);
console.log('Is Admin or Ambassador:', isAdminOrAmbassador);
```

**Expected Output:**
```
Is Admin: true
Is Ambassador: false
Is Admin or Ambassador: true
```

**Status:** ✅ PASS if "Is Admin: true"

---

## ✅ Test 9: JWT Contains Role

**Log in as genetua@gtrax.net**

**Open browser console and paste:**
```javascript
const { data: { session } } = await window._supabaseClient.auth.getSession();

console.log('=== JWT Token Analysis ===');
console.log('Access Token:', session.access_token);

// Decode JWT (base64 decode the middle part)
const payload = session.access_token.split('.')[1];
const decoded = JSON.parse(atob(payload));

console.log('JWT Claims:', decoded);
console.log('Role in JWT:', decoded.role);
```

**Expected Output:**
```
=== JWT Token Analysis ===
Access Token: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
JWT Claims: {
  sub: "700adcb1-08a6-4ff5-83df-ab0fb15fa2f4",
  email: "genetua@gtrax.net",
  role: "admin",   ← THIS IS THE KEY PART
  ...
}
Role in JWT: admin
```

**Status:** ✅ PASS if JWT contains `"role": "admin"`

---

## ✅ Test 10: Role Persists After Logout/Login

**Steps:**
1. Log in as `genetua@gtrax.net`
2. Verify admin access works (`/admin/profiles`)
3. Log out completely
4. Close browser
5. Re-open browser
6. Log in again as `genetua@gtrax.net`
7. Navigate to `/admin/profiles` again

**Expected Result:**
- ✅ Admin access still works
- ✅ Can access dashboard immediately
- ✅ Role still in JWT
- ✅ No need to reassign role

**Status:** ✅ PASS if admin access persists

---

## 🔍 Debugging Failed Tests

### If Test 1 Fails (Database role not set)

```sql
-- Re-run the role assignment
UPDATE auth.users
SET raw_app_meta_data = raw_app_meta_data || '{"role": "admin"}'::jsonb
WHERE email = 'genetua@gtrax.net';

-- Verify
SELECT raw_app_meta_data->>'role' FROM auth.users WHERE email = 'genetua@gtrax.net';
```

---

### If Test 2 Fails (RLS function returns false)

```sql
-- Check if function exists
SELECT proname, prosrc FROM pg_proc WHERE proname = 'is_admin_or_ambassador';

-- If missing, re-run migration:
-- (Copy the function creation SQL from JWT_ADMIN_ROLE_SETUP.md)
```

---

### If Test 5/9 Fails (JWT doesn't contain role)

**Cause:** Old JWT cached, role not in token yet

**Solution:**
```javascript
// Force logout
await window._supabaseClient.auth.signOut();

// Clear all storage
localStorage.clear();
sessionStorage.clear();

// Reload page
location.reload();

// Log in again - new JWT will contain role
```

---

### If Test 6 Fails (Dashboard redirects)

**Check browser console for:**
- "Access denied: User does not have admin or ambassador role"
- Any JavaScript errors
- Network errors

**Verify:**
```javascript
// Check if helper function works
const { data: { user } } = await window._supabaseClient.auth.getUser();
console.log('app_metadata:', user.app_metadata);
console.log('role:', user.app_metadata?.role);
```

---

## 📊 Test Results Summary

| Test # | Test Name | Status | Notes |
|--------|-----------|--------|-------|
| 1 | Database role set | ⬜ | Check app_metadata in auth.users |
| 2 | RLS function works | ⬜ | Returns true for admin |
| 3 | Admin can read profiles | ⬜ | No RLS errors |
| 4 | Admin can read artists | ⬜ | No RLS errors |
| 5 | Frontend role check | ⬜ | app_metadata.role === 'admin' |
| 6 | Dashboard access | ⬜ | Page loads for admin |
| 7 | Normal user blocked | ⬜ | Redirected away |
| 8 | Helper functions | ⬜ | isAdmin returns true |
| 9 | JWT contains role | ⬜ | Decoded token has role |
| 10 | Role persists | ⬜ | Survives logout/login |

**Legend:**
- ⬜ Not tested
- ✅ Pass
- ❌ Fail

---

## 🚀 Quick Start Verification (30 seconds)

**Fastest way to verify everything works:**

1. **Open Supabase SQL Editor:**
   ```sql
   SELECT email, raw_app_meta_data->>'role' as role
   FROM auth.users
   WHERE email = 'genetua@gtrax.net';
   ```
   Expected: `role | admin`

2. **Log in as genetua@gtrax.net**

3. **Go to:** `/admin/profiles`

4. **Result:** Dashboard loads = ✅ SUCCESS

If steps 1-4 work, the system is fully operational!

---

## Support

If any test fails, refer to:
- `JWT_ADMIN_ROLE_SETUP.md` - Complete setup documentation
- `ADMIN_DASHBOARD_DOCUMENTATION.md` - Dashboard usage guide
- Troubleshooting section in JWT_ADMIN_ROLE_SETUP.md

All tests should pass for `genetua@gtrax.net` with admin role.
