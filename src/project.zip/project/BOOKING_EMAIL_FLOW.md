# Booking Request Email & SMS Flow

## What Happens When a User Submits a Booking Request

### Step 1: User Submits Booking Form
When a user fills out and submits the booking request form in `BookingRequestModal.tsx`, the following happens:

1. **Database Insert**: The booking is saved to the `bookings` table with status `'pending'`
2. **Email Trigger**: Immediately after successful database insert, the `sendEmailNotification()` function is called
3. **SMS Trigger**: If the artist has a phone number, the `sendSMSNotification()` function is called

### Step 2: Email Notification Process

The system calls the `send-booking-request-notification` edge function with this data:

```javascript
{
  artistEmail: "artist@example.com",
  artistName: "DJ Jane",
  userName: "John Planner",
  userEmail: "planner@example.com",
  userPhone: "+44 555-1234",
  eventType: "Wedding Reception",
  requestedDate: "2024-06-15",
  timeFrom: "8:00 PM",
  timeTo: "12:00 AM",
  location: "Grand Hotel Ballroom",
  comments: "Looking for house music DJ"
}
```

### Step 3: Two Emails Sent Simultaneously

The edge function sends **TWO emails in parallel**:

#### Email 1: Admin Notification
**To:** `process.env.EMAIL` (info@beatbookings.com)
**Subject:** "New Booking: [Artist Name] - [Event Date]"
**Contains:**
- Artist Information (name, email)
- Client Information (name, email, phone)
- Complete Event Details (type, date, time, location, comments)
- Confirmation that artist has been notified

#### Email 2: User Confirmation
**To:** User's email address
**Subject:** "Booking Request Confirmed - [Artist Name]"
**Contains:**
- Confirmation of receipt
- Booking summary
- What happens next (artist will review, user can track in dashboard)
- Link to user dashboard to view booking status

### Step 4: SMS Notification (If Artist Has Phone Number)

The system checks if the artist has a phone number in their profile:

1. **Query Database**: Fetch artist's phone number from `Artist Cards` table
2. **If Phone Exists**: Call `send-booking-sms` edge function
3. **If No Phone**: Skip SMS notification gracefully

#### SMS Message Format:
```
🎵 BeatBookingsLive Alert!

New booking request from [User Name]

Event: [Event Type]
Date: [Date]

Check your dashboard to view details and respond: beatbookingslive.com

- BeatBookingsLive Team
```

**Features:**
- Auto-formats phone numbers (UK +44, US +1)
- Concise message with key info
- Link to dashboard for full details
- Gracefully handles missing Twilio credentials

### Step 5: Success Feedback

The modal shows:
- ✅ Success message "Booking request submitted successfully"
- Confirmation that emails have been sent
- Option to close modal or submit another request

### Code Flow

```
User fills form → handleSubmit() called
                      ↓
            Insert into bookings table
                      ↓
            Create bookingData object
                      ↓
        ┌─────────────┴──────────────┐
        ↓                            ↓
  sendEmailNotification()    sendSMSNotification()
        ↓                            ↓
 send-booking-request-      Query artist phone
    notification                    ↓
        ↓                    If phone exists
  Two emails sent:                  ↓
        ↓                    send-booking-sms
  ┌─────┴─────┐                     ↓
  ↓           ↓              SMS sent to artist
Admin      User
Email    Confirmation
  ↓           ↓
  └─────┬─────┘
        ↓
  Show success message
```

## Error Handling

- If database insert fails: No emails/SMS sent, error shown to user
- If email sending fails: Booking still saved, error logged but not shown to user
- If email service not configured: Booking saved, graceful fallback with warning
- If SMS sending fails: Booking and emails still work, SMS silently skipped
- If no artist phone: SMS step skipped gracefully
- If Twilio not configured: SMS disabled, booking and emails still work

## Email Templates

Both emails use the branded BeatBookingsLive template with:
- Neon green and black theme
- Professional formatting
- Clear info boxes for structured data
- Mobile responsive design
- Call-to-action buttons

## Testing

To test the email flow:

1. Submit a booking request through the UI
2. Check the browser console for email sending logs
3. Check Supabase Edge Function logs for the `send-booking-request-notification` function
4. Verify emails arrive at both addresses

## Environment Setup

Required environment variables in Supabase:
```bash
EMAIL=info@beatbookings.com
RESEND_API_KEY=your_resend_api_key
APP_URL=https://beatbookingslive.com
```

## Integration Points

The booking email system is integrated at:
- **File**: `src/components/BookingRequestModal.tsx`
- **Function**: Line 183 `handleSubmit()`
- **Email Call**: Line 227 `sendEmailNotification()`
- **Edge Function**: `supabase/functions/send-booking-request-notification/index.ts`

## Current Status

✅ **ACTIVE** - System is fully configured and ready to send emails on every booking request submission.

The email notification is automatic and requires no additional action from the user or admin.
