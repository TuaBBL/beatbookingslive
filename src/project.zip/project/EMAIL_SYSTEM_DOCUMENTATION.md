# BeatBookingsLive Email & SMS Notification System

## Overview

Complete notification system for BeatBookingsLive using:
- **Email**: Supabase Edge Functions + Resend API
- **SMS**: Supabase Edge Functions + Twilio API

## Setup Requirements

### Environment Variables

Add these to your Supabase project environment variables:

```bash
# Email Configuration (Required)
EMAIL=info@beatbookings.com
RESEND_API_KEY=your_resend_api_key_here
APP_URL=https://beatbookingslive.com

# SMS Configuration (Optional - for text message notifications)
TWILIO_ACCOUNT_SID=your_twilio_account_sid
TWILIO_AUTH_TOKEN=your_twilio_auth_token
TWILIO_PHONE_NUMBER=+1234567890
```

### Getting a Resend API Key

1. Sign up at [resend.com](https://resend.com)
2. Verify your sending domain (info@beatbookings.com)
3. Generate an API key from the dashboard
4. Add the API key to Supabase environment variables

### Getting Twilio SMS Credentials (Optional)

1. Sign up at [twilio.com](https://www.twilio.com)
2. Purchase or get a free trial phone number
3. Find your Account SID and Auth Token in the Twilio Console
4. Add all three values to Supabase environment variables
5. Note: SMS notifications will gracefully skip if not configured

## Email Functions Available

### 1. Contact Form Emails

**Function:** `send-contact-form`

**Purpose:** Sends contact form submissions to admin

**Usage:**
```javascript
const response = await fetch(`${supabaseUrl}/functions/v1/send-contact-form`, {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${supabaseAnonKey}`,
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    name: 'John Doe',
    email: 'john@example.com',
    message: 'I need help with...'
  })
});
```

---

### 2. Artist Signup Notifications

**Function:** `send-artist-signup-notification`

**Purpose:** Sends welcome email to artist + notification to admin

**Usage:**
```javascript
const response = await fetch(`${supabaseUrl}/functions/v1/send-artist-signup-notification`, {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${supabaseAnonKey}`,
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    name: 'Jane Smith',
    stageName: 'DJ Jane',
    email: 'jane@example.com',
    category: 'DJ',
    genre: 'House',
    location: 'Los Angeles, CA',
    phone: '555-123-4567',
    about: 'Professional DJ with 10 years experience...'
  })
});
```

**Sends:**
- Admin notification with all artist details
- Welcome email to artist with next steps

---

### 3. Booking Request Notifications

**Function:** `send-booking-request-notification`

**Purpose:** Notifies admin and sends confirmation to user

**Usage:**
```javascript
const response = await fetch(`${supabaseUrl}/functions/v1/send-booking-request-notification`, {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${supabaseAnonKey}`,
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    artistName: 'DJ Jane',
    artistEmail: 'jane@example.com',
    userName: 'John Planner',
    userEmail: 'planner@example.com',
    userPhone: '555-987-6543',
    eventType: 'Wedding Reception',
    requestedDate: '2024-06-15',
    timeFrom: '8:00 PM',
    timeTo: '12:00 AM',
    location: 'Grand Hotel Ballroom, Los Angeles',
    comments: 'Looking for house music DJ for wedding'
  })
});
```

**Sends:**
- Admin notification with booking details
- Confirmation email to user/event planner

---

### 4. Artist Approval Emails

**Function:** `send-artist-approval`

**Purpose:** Notifies artist their profile is approved and live

**Usage:**
```javascript
const response = await fetch(`${supabaseUrl}/functions/v1/send-artist-approval`, {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${supabaseAnonKey}`,
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    artistName: 'Jane Smith',
    artistEmail: 'jane@example.com',
    stageName: 'DJ Jane',
    category: 'DJ',
    profileUrl: 'https://beatbookingslive.com/artist/123'
  })
});
```

**Sends:**
- Approval email with profile link and next steps
- Includes premium upgrade information

---

### 5. New User Welcome Emails

**Function:** `send-welcome-email`

**Purpose:** Sends customized welcome email to new users

**Usage:**
```javascript
const response = await fetch(`${supabaseUrl}/functions/v1/send-welcome-email`, {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${supabaseAnonKey}`,
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    email: 'newuser@example.com',
    name: 'John Doe',
    userType: 'planner' // 'artist', 'planner', or 'user'
  })
});
```

**User Types:**
- `artist` - Welcome for artists with profile setup instructions
- `planner` - Welcome for event planners with browsing instructions
- `user` - Generic welcome for general users

---

### 6. Booking SMS Notifications

**Function:** `send-booking-sms`

**Purpose:** Sends text message to artist when they have a phone number

**Usage:**
```javascript
const response = await fetch(`${supabaseUrl}/functions/v1/send-booking-sms`, {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${supabaseAnonKey}`,
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    artistPhone: '+447123456789',
    artistName: 'DJ Jane',
    userName: 'John Planner',
    eventType: 'Wedding Reception',
    requestedDate: '2024-06-15'
  })
});
```

**Sends:**
- Text message alert to artist's phone
- Includes booking requester name, event type, and date
- Link to dashboard to view full details

**Phone Number Formatting:**
- Automatically formats UK numbers (+44)
- Supports US numbers (+1)
- Handles various input formats

**Note:** This function is automatically called when a booking request is submitted and the artist has a phone number in their profile.

---

## Integration Examples

### Example 1: Call on User Signup

```javascript
// After user signs up
const { data: { user } } = await supabase.auth.signUp({
  email: 'user@example.com',
  password: 'password'
});

if (user) {
  // Send welcome email
  await fetch(`${supabaseUrl}/functions/v1/send-welcome-email`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${supabaseAnonKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      email: user.email,
      name: user.user_metadata.name,
      userType: 'user'
    })
  });
}
```

### Example 2: Call on Artist Profile Creation

```javascript
// After artist creates profile
const { data: artistCard, error } = await supabase
  .from('Artist Cards')
  .insert({
    name: 'Jane Smith',
    stage_name: 'DJ Jane',
    // ... other fields
  })
  .select()
  .single();

if (artistCard) {
  // Send artist signup notification
  await fetch(`${supabaseUrl}/functions/v1/send-artist-signup-notification`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${supabaseAnonKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      name: artistCard.name,
      stageName: artistCard.stage_name,
      email: user.email,
      category: artistCard.category,
      genre: artistCard.genre,
      location: artistCard.location,
      about: artistCard.about
    })
  });
}
```

### Example 3: Call on Booking Request

```javascript
// After booking is submitted
const { data: booking, error } = await supabase
  .from('bookings')
  .insert({
    artist_id: artistId,
    user_name: userName,
    // ... other fields
  })
  .select()
  .single();

if (booking) {
  // Send booking notification
  await fetch(`${supabaseUrl}/functions/v1/send-booking-request-notification`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${supabaseAnonKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      artistName: artist.stage_name || artist.name,
      artistEmail: artist.email,
      userName: booking.user_name,
      userEmail: booking.user_email,
      userPhone: booking.user_phone,
      eventType: booking.event_type,
      requestedDate: booking.requested_date,
      timeFrom: booking.time_from,
      timeTo: booking.time_to,
      location: booking.location,
      comments: booking.comments
    })
  });
}
```

## Email Template Customization

All emails use a shared template located in:
`supabase/functions/_shared/email.ts`

### Template Features:
- Consistent BeatBookingsLive branding
- Neon green and black theme matching the app
- Mobile responsive
- Info boxes for structured content
- Call-to-action buttons
- Professional footer with copyright

### Customizing Templates:

Edit the `createEmailTemplate()` function in `_shared/email.ts` to modify:
- Colors and styling
- Logo and branding
- Footer content
- Overall layout

## Error Handling

All functions include:
- Input validation
- Safety guards for missing environment variables
- Detailed error logging
- Graceful error responses

Example error response:
```json
{
  "error": "Email is required"
}
```

Example success response:
```json
{
  "success": true,
  "adminEmailSent": true,
  "welcomeEmailSent": true
}
```

## Testing

### Test with curl:

```bash
curl -X POST \
  'https://your-project.supabase.co/functions/v1/send-contact-form' \
  -H 'Authorization: Bearer YOUR_ANON_KEY' \
  -H 'Content-Type: application/json' \
  -d '{
    "name": "Test User",
    "email": "test@example.com",
    "message": "This is a test message"
  }'
```

### Monitor Function Logs:

View logs in Supabase Dashboard:
1. Go to Edge Functions
2. Select your function
3. Click "Logs" tab

## Deployment

All functions are automatically deployed using the Supabase MCP tools.

To manually deploy a function:
```bash
# Not needed - handled automatically by the system
```

## Security Notes

- All functions use CORS headers for browser access
- API keys are stored securely in environment variables
- Functions validate all input data
- Email addresses are validated by Resend
- Rate limiting handled by Supabase Edge Functions

## Support

For issues or questions:
- Check function logs in Supabase Dashboard
- Verify environment variables are set correctly
- Ensure Resend domain is verified
- Test with simple payloads first

## Future Enhancements

Potential additions:
- Email templates for booking confirmations
- Email reminders before events
- Monthly newsletter system
- Review request emails
- Payment receipt emails
