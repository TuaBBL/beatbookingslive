# Email Verification Setup

## Overview
Email verification has been implemented for both user and artist signups. Users must verify their email addresses before they can sign in to the application.

## Implementation Details

### What Was Added
1. **Email verification during signup**: When users or artists sign up, they receive a verification email
2. **Verification check on login**: Users cannot log in until they verify their email
3. **Clear messaging**: Users see appropriate messages about needing to verify their email

### Modified Files
- `src/components/AuthModal.tsx` - User signup and login with email verification
- `src/components/ArtistAuthModal.tsx` - Artist signup and login with email verification
- `src/components/auth/LoginForm.tsx` - Login form with verification check
- `src/components/auth/SignupForm.tsx` - Signup form with verification messages

## Supabase Configuration Required

**IMPORTANT**: Email verification must be enabled in your Supabase project settings.

### How to Enable Email Confirmation in Supabase:

1. Go to your Supabase project dashboard
2. Navigate to **Authentication** → **Settings**
3. Scroll down to **Email Auth** section
4. Toggle **Enable email confirmations** to ON
5. Save changes

### Email Templates (Optional)
You can customize the email templates in:
- **Authentication** → **Email Templates** → **Confirm signup**

The default template includes a link to verify the email address.

## User Flow

### Signup Flow
1. User fills out signup form
2. User submits form
3. Account is created but not verified
4. User receives email with verification link
5. User sees message: "Account created! Please check your email to verify your account before signing in."
6. User clicks link in email
7. Email is verified
8. User can now sign in

### Login Flow (Before Verification)
1. User tries to sign in
2. System checks `email_confirmed_at` field
3. If not verified, shows error: "Please verify your email before signing in. Check your inbox for the verification link."
4. User cannot proceed until email is verified

### Login Flow (After Verification)
1. User signs in with verified email
2. Login succeeds
3. User is directed to their dashboard

## Technical Details

### Verification Check
The verification status is checked using the `email_confirmed_at` field on the user object:

```typescript
if (!data.user.email_confirmed_at) {
  setError('Please verify your email before signing in...');
  return;
}
```

### Email Redirect
After clicking the verification link in the email, users are redirected to:
```
${window.location.origin}/
```

This is configured in the `emailRedirectTo` option during signup.

## Testing

To test email verification:

1. **Enable email confirmation** in Supabase settings
2. Sign up a new user
3. Check the email inbox for verification link
4. Try to log in before clicking the link (should fail)
5. Click the verification link
6. Try to log in again (should succeed)

## Notes

- Email verification is required for both regular users and artists
- Existing users who signed up before this feature may not have verified emails
- The system handles duplicate signup attempts gracefully
- Users can request a new verification email if needed (functionality can be added if required)
