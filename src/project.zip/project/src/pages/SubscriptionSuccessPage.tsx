import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, Crown, ArrowRight } from 'lucide-react';
import { SupportChatModal } from '../components/SupportChatModal';
import { FloatingSupportButton } from '../components/FloatingSupportButton';
import { useAuth } from '../hooks/useAuth';

export function SubscriptionSuccessPage() {
  const [countdown, setCountdown] = useState(5);
  const [supportChatOpen, setSupportChatOpen] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          window.location.href = '/';
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center py-12 px-4">
      <div className="max-w-md w-full">
        <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
          <div className="mb-6">
            <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900 mb-2">
              Subscription Activated!
            </h1>
            <p className="text-gray-600">
              Welcome to BeatBookingsLive! Your subscription has been successfully activated.
            </p>
          </div>

          <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-lg p-6 mb-6">
            <div className="flex items-center justify-center mb-3">
              <Crown className="w-6 h-6 text-yellow-500 mr-2" />
              <h3 className="font-semibold text-gray-900">You're all set!</h3>
            </div>
            <p className="text-sm text-gray-600 mb-4">
              Your artist profile is now active and ready to be discovered by event planners across Australia & NZ.
            </p>
            <div className="space-y-2 text-sm text-gray-700">
              <div className="flex items-center justify-center">
                <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                <span>Profile listing activated</span>
              </div>
              <div className="flex items-center justify-center">
                <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                <span>Searchable by event planners</span>
              </div>
              <div className="flex items-center justify-center">
                <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                <span>Media gallery enabled</span>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            <Link
              to="/"
              className="w-full bg-indigo-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-indigo-700 transition-colors flex items-center justify-center"
            >
              Get Started
              <ArrowRight className="w-4 h-4 ml-2" />
            </Link>
            
            <p className="text-sm text-gray-500">
              Redirecting automatically in {countdown} seconds...
            </p>
          </div>

          <div className="mt-6 pt-6 border-t border-gray-200">
            <Link
              to="/terms"
              className="text-sm text-gray-600 hover:text-gray-900 underline"
            >
              Terms & Conditions
            </Link>
          </div>
        </div>
      </div>

      <FloatingSupportButton onClick={() => setSupportChatOpen(true)} />

      <SupportChatModal
        isOpen={supportChatOpen}
        onClose={() => setSupportChatOpen(false)}
        userId={user?.id}
      />
    </div>
  );
}