import { useState, useEffect } from 'react';
import { X, MapPin, Music2, Star, LogOut, Youtube, Instagram, Facebook, Music, Radio, Headphones, Send, Plus, CreditCard as Edit, Trash2, Calendar, Clock, MessageCircle, Heart, Shield, Bell, User, Mail } from 'lucide-react';
import { supabase, Artist, Review } from '../lib/supabase';
import { getThemeClasses } from '../lib/themeUtils';
import { ArtistFilters, FilterState } from '../components/ArtistFilters';
import { ArtistProfileModal } from '../components/ArtistProfileModal';
import { EditProfileModal } from '../components/EditProfileModal';
import { EditUserProfileModal } from '../components/EditUserProfileModal';
import { UserProfileView } from '../components/UserProfileView';
import { BookingRequestModal } from '../components/BookingRequestModal';
import { EditBookingModal } from '../components/EditBookingModal';
import { BookingMessagesModal } from '../components/BookingMessagesModal';
import { NotificationBell } from '../components/NotificationBell';
import { SupportChatModal } from '../components/SupportChatModal';
import { FloatingSupportButton } from '../components/FloatingSupportButton';
import { ArtistCardStats } from '../components/ArtistCardStats';
import { showToast } from '../components/Toast';
import { Link, useNavigate } from 'react-router-dom';
import { isAdmin } from '../lib/adminUtils';
import { AdminMessagesInbox } from '../components/AdminMessagesInbox';
import { MessageAdminButton } from '../components/MessageAdminButton';

interface Booking {
  id: string;
  artist_id: number;
  user_name: string;
  user_email: string;
  user_phone: string | null;
  event_type: string;
  requested_date: string;
  time_from: string;
  time_to: string;
  location: string;
  comments: string | null;
  status: string;
  created_at: string;
  artist?: Artist;
}

interface UserDashboardProps {
  user: any;
  onSignOut: () => void;
}

export function UserDashboard({ user, onSignOut }: UserDashboardProps) {
  const navigate = useNavigate();
  const [selectedArtist, setSelectedArtist] = useState<Artist | null>(null);
  const [artists, setArtists] = useState<Artist[]>([]);
  const [filteredArtists, setFilteredArtists] = useState<Artist[]>([]);
  const [loading, setLoading] = useState(true);
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loadingReviews, setLoadingReviews] = useState(false);
  const [newReview, setNewReview] = useState({ rating: 5, comment: '' });
  const [submittingReview, setSubmittingReview] = useState(false);
  const [isArtist, setIsArtist] = useState(false);
  const [hasArtistProfile, setHasArtistProfile] = useState(false);
  const [createProfileModalOpen, setCreateProfileModalOpen] = useState(false);
  const [editProfileModalOpen, setEditProfileModalOpen] = useState(false);
  const [userArtistCard, setUserArtistCard] = useState<Artist | null>(null);
  const [userArtistProfile, setUserArtistProfile] = useState<any>(null);
  const [filters, setFilters] = useState<FilterState>({
    searchQuery: '',
    location: '',
    states: [],
    category: '',
    hasSoundcloud: false,
    hasYoutube: false,
    hasSpotify: false
  });
  const [bookingModalOpen, setBookingModalOpen] = useState(false);
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [incomingBookings, setIncomingBookings] = useState<Booking[]>([]);
  const [loadingBookings, setLoadingBookings] = useState(false);
  const [editingBooking, setEditingBooking] = useState<Booking | null>(null);
  const [showMyBookings, setShowMyBookings] = useState(false);
  const [showIncomingBookings, setShowIncomingBookings] = useState(false);
  const [selectedBookingForMessage, setSelectedBookingForMessage] = useState<Booking | null>(null);
  const [messageModalOpen, setMessageModalOpen] = useState(false);
  const [supportChatOpen, setSupportChatOpen] = useState(false);
  const [rebookingData, setRebookingData] = useState<Booking | null>(null);
  const [userProfileData, setUserProfileData] = useState<any>(null);
  const [editUserProfileModalOpen, setEditUserProfileModalOpen] = useState(false);
  const [userFavorites, setUserFavorites] = useState<Set<number>>(new Set());
  const [showProfileView, setShowProfileView] = useState(false);
  const [adminInboxOpen, setAdminInboxOpen] = useState(false);

  useEffect(() => {
    fetchArtists();
    checkUserArtistStatus();
    fetchBookings();
    fetchUserProfile();
    fetchUserFavorites();
  }, []);

  useEffect(() => {
    if (userArtistCard) {
      fetchIncomingBookings();
    }
  }, [userArtistCard]);

  async function fetchUserProfile() {
    try {
      const { data: userData } = await supabase
        .from('users')
        .select('id, created_at')
        .eq('id', user.id)
        .maybeSingle();

      let profileData = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user.id)
        .maybeSingle();

      if (!profileData.data) {
        const { data: newProfile } = await supabase
          .from('profiles')
          .insert({
            id: user.id,
            full_name: null,
            location: null,
            state_territory: null,
            phone_number: null,
            profile_image_url: null
          })
          .select()
          .single();

        profileData.data = newProfile;
      }

      if (profileData.data) {
        setUserProfileData({
          id: user.id,
          email: user.email,
          created_at: userData?.created_at || new Date().toISOString(),
          ...profileData.data
        });
      }
    } catch (error) {
      console.error('Error fetching user profile:', error);
    }
  }

  async function fetchUserFavorites() {
    console.log('fetchUserFavorites called with user.id:', user.id);
    try {
      const { data, error } = await supabase
        .from('user_favorites')
        .select('artist_id')
        .eq('user_id', user.id);

      console.log('Favorites fetch result:', { data, error });

      if (error) throw error;

      const favoriteIds = new Set(data?.map(fav => fav.artist_id) || []);
      console.log('Favorite IDs:', Array.from(favoriteIds));
      setUserFavorites(favoriteIds);
    } catch (error) {
      console.error('Error fetching favorites:', error);
    }
  }

  async function toggleFavorite(artistId: number) {
    console.log('=== toggleFavorite START ===');
    console.log('Input artistId:', artistId, '(type:', typeof artistId, ')');
    console.log('User ID:', user.id, '(type:', typeof user.id, ')');
    console.log('User object:', user);

    try {
      if (userFavorites.has(artistId)) {
        console.log('Action: REMOVING favorite');
        console.log('DELETE from user_favorites WHERE user_id =', user.id, 'AND artist_id =', artistId);

        const { error } = await supabase
          .from('user_favorites')
          .delete()
          .eq('user_id', user.id)
          .eq('artist_id', artistId);

        if (error) {
          console.error('❌ DELETE ERROR:', error);
          throw error;
        }

        setUserFavorites(prev => {
          const newSet = new Set(prev);
          newSet.delete(artistId);
          return newSet;
        });

        console.log('✅ Favorite removed successfully');
        showToast('Removed from Favorites', 'Artist has been removed from your favorites');
      } else {
        console.log('Action: ADDING favorite');
        const insertData = {
          user_id: user.id,
          artist_id: artistId,
        };
        console.log('INSERT data:', JSON.stringify(insertData, null, 2));
        console.log('Data types:', {
          user_id: typeof insertData.user_id,
          artist_id: typeof insertData.artist_id
        });

        const { data, error } = await supabase
          .from('user_favorites')
          .insert(insertData)
          .select();

        console.log('INSERT response data:', data);
        console.log('INSERT response error:', error);

        if (error) {
          console.error('❌ INSERT ERROR:', error);
          console.error('Error message:', error.message);
          console.error('Error code:', error.code);
          console.error('Error details:', error.details);
          console.error('Error hint:', error.hint);
          throw error;
        }

        setUserFavorites(prev => new Set([...prev, artistId]));

        console.log('✅ Favorite added successfully');
        console.log('Inserted record:', data);
        showToast('Added to Favorites!', 'Artist has been added to your favorites library');
      }
    } catch (error: any) {
      console.error('❌ EXCEPTION in toggleFavorite:', error);
      console.error('Full error object:', JSON.stringify(error, null, 2));
      showToast('Error', error.message || 'Failed to update favorites');
    }
    console.log('=== toggleFavorite END ===');
  }

  async function checkUserArtistStatus() {
    try {
      const { data: userData } = await supabase
        .from('users')
        .select('user_type')
        .eq('id', user.id)
        .maybeSingle();

      const isArtistUser = userData?.user_type === 'artist';
      setIsArtist(isArtistUser);

      if (isArtistUser) {
        const { data: profileData } = await supabase
          .from('artist_profiles')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle();

        setUserArtistProfile(profileData);

        if (profileData?.artist_card_id) {
          const { data: cardData } = await supabase
            .from('artist_cards')
            .select('*')
            .eq('id', profileData.artist_card_id)
            .maybeSingle();

          setUserArtistCard(cardData);

          // Check if required fields are filled
          const hasRequiredFields = cardData &&
            cardData.name &&
            cardData.category &&
            cardData.genre &&
            (cardData.state_territories && cardData.state_territories.length > 0) &&
            (cardData.locations && cardData.locations.length > 0);

          setHasArtistProfile(!!profileData?.profile_completed && !!hasRequiredFields);
        } else {
          setHasArtistProfile(false);
        }
      }
    } catch (error) {
      console.error('Error checking artist status:', error);
    }
  }

  useEffect(() => {
    applyFilters();
  }, [artists, filters]);

  async function fetchArtists() {
    try {
      const { data, error } = await supabase
        .from('artist_cards')
        .select('*')
        .order('featured_priority', { ascending: true, nullsLast: true })
        .order('created_at', { ascending: true });

      if (error) throw error;
      setArtists(data || []);
    } catch (error) {
      console.error('Error fetching artists:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchBookings() {
    setLoadingBookings(true);
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const bookingsWithArtists = await Promise.all(
        (data || []).map(async (booking) => {
          const { data: artist } = await supabase
            .from('artist_cards')
            .select('*')
            .eq('id', booking.artist_id)
            .maybeSingle();

          return {
            ...booking,
            artist: artist
          };
        })
      );

      setBookings(bookingsWithArtists);
    } catch (error) {
      console.error('Error fetching bookings:', error);
    } finally {
      setLoadingBookings(false);
    }
  }

  async function fetchIncomingBookings() {
    if (!userArtistCard) return;

    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('artist_id', userArtistCard.id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const bookingsWithUsers = await Promise.all(
        (data || []).map(async (booking) => {
          const { data: profile } = await supabase
            .from('profiles')
            .select('*')
            .eq('id', booking.user_id)
            .maybeSingle();

          return {
            ...booking,
            userProfile: profile
          };
        })
      );

      setIncomingBookings(bookingsWithUsers);
    } catch (error) {
      console.error('Error fetching incoming bookings:', error);
    }
  }

  async function deleteBooking(bookingId: string) {
    if (!confirm('Are you sure you want to delete this booking request?')) return;

    try {
      const { error } = await supabase
        .from('bookings')
        .delete()
        .eq('id', bookingId);

      if (error) throw error;

      await fetchBookings();
      await fetchIncomingBookings();
    } catch (error: any) {
      alert(error.message || 'Error deleting booking');
    }
  }

  function applyFilters() {
    let filtered = [...artists];

    if (filters.searchQuery) {
      const query = filters.searchQuery.toLowerCase();
      filtered = filtered.filter(artist =>
        (artist.stage_name || artist.name).toLowerCase().includes(query)
      );
    }

    if (filters.states && filters.states.length > 0) {
      filtered = filtered.filter(artist => {
        if (!artist.state_territories || artist.state_territories.length === 0) {
          return false;
        }
        return filters.states.some(state => artist.state_territories?.includes(state));
      });
    }

    if (filters.location) {
      filtered = filtered.filter(artist => artist.location === filters.location);
    }

    if (filters.category) {
      filtered = filtered.filter(artist => artist.category === filters.category);
    }

    if (filters.genre) {
      filtered = filtered.filter(artist => artist.genre && artist.genre.toLowerCase().includes(filters.genre.toLowerCase()));
    }

    if (filters.hasYoutube) {
      filtered = filtered.filter(artist => artist.youtube_link && artist.youtube_link.trim() !== '');
    }

    if (filters.hasSoundcloud) {
      filtered = filtered.filter(artist => artist.soundcloud_link && artist.soundcloud_link.trim() !== '');
    }

    if (filters.hasSpotify) {
      filtered = filtered.filter(artist => artist.spotify_link && artist.spotify_link.trim() !== '');
    }

    setFilteredArtists(filtered);
  }

  const handleFilterChange = (newFilters: FilterState) => {
    setFilters(newFilters);
  };

  const renderStars = (rating: number | string, size = 'w-4 h-4') => {
    const ratingNum = typeof rating === 'number' ? rating : parseFloat(rating) || 0;
    return (
      <div className="flex items-center gap-1">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            className={`${size} ${
              i < ratingNum
                ? 'fill-[#39ff14] text-[#39ff14]'
                : 'text-gray-600'
            }`}
          />
        ))}
      </div>
    );
  };

  async function fetchReviews(artistId: number) {
    setLoadingReviews(true);
    try {
      const { data, error } = await supabase
        .from('reviews')
        .select('*')
        .eq('artist_id', artistId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setReviews(data || []);
    } catch (error) {
      console.error('Error fetching reviews:', error);
    } finally {
      setLoadingReviews(false);
    }
  }

  async function submitReview() {
    if (!selectedArtist || !user) return;

    setSubmittingReview(true);
    try {
      const { error } = await supabase
        .from('reviews')
        .insert({
          artist_id: selectedArtist.id,
          user_id: user.id,
          rating: newReview.rating,
          comment: newReview.comment
        });

      if (error) throw error;

      setNewReview({ rating: 5, comment: '' });
      await fetchReviews(selectedArtist.id);
      await fetchArtists();
    } catch (error: any) {
      alert(error.message || 'Error submitting review');
    } finally {
      setSubmittingReview(false);
    }
  }

  async function handleDeleteProfile() {
    if (!userArtistCard || !confirm('Are you sure you want to delete your artist profile? This action cannot be undone.')) return;

    try {
      const { error: cardError } = await supabase
        .from('artist_cards')
        .delete()
        .eq('id', userArtistCard.id);

      if (cardError) throw cardError;

      const { error: profileError } = await supabase
        .from('artist_profiles')
        .delete()
        .eq('user_id', user.id);

      if (profileError) throw profileError;

      setSelectedArtist(null);
      await checkUserArtistStatus();
      await fetchArtists();
      onArtistDeleteSuccess();
      alert('Profile deleted successfully');
    } catch (error: any) {
      alert(error.message || 'Error deleting profile');
    }
  }

  const handleEditSuccess = () => {
    setEditProfileModalOpen(false);
    checkUserArtistStatus();
    fetchArtists();
  };

  const isOwnProfile = selectedArtist && userArtistCard && selectedArtist.id === userArtistCard.id;

  useEffect(() => {
    if (selectedArtist) {
      fetchReviews(selectedArtist.id);
      setNewReview({ rating: 5, comment: '' });
    }
  }, [selectedArtist]);

  useEffect(() => {
    if (isArtist && !hasArtistProfile && !loading) {
      // If they have a card (existing profile with missing fields), open edit modal
      // Otherwise, open create modal (no profile at all)
      if (userArtistCard) {
        setEditProfileModalOpen(true);
      } else {
        setCreateProfileModalOpen(true);
      }
    }
  }, [isArtist, hasArtistProfile, loading, userArtistCard]);

  useEffect(() => {
    // For regular users (non-artists), check if profile fields are incomplete
    if (!isArtist && userProfileData && !loading) {
      const hasIncompleteProfile = !userProfileData.full_name ||
                                    !userProfileData.location ||
                                    !userProfileData.state_territory;

      if (hasIncompleteProfile) {
        setEditUserProfileModalOpen(true);
      }
    }
  }, [isArtist, userProfileData, loading]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white relative overflow-y-auto overflow-x-hidden" style={{ WebkitOverflowScrolling: 'touch' }}>
      <div className="fixed inset-0 opacity-50 pointer-events-none">
        <div className="absolute left-10 top-20 w-4 h-32 bg-gradient-to-b from-red-500 via-red-600 to-transparent rounded-full" style={{ filter: 'blur(2px)', animation: 'wave 2.5s ease-in-out infinite' }}></div>
        <div className="absolute left-20 top-32 w-4 h-40 bg-gradient-to-b from-red-600 via-red-700 to-transparent rounded-full" style={{ filter: 'blur(2px)', animation: 'wave-intense 2.8s ease-in-out infinite 0.2s' }}></div>
        <div className="absolute left-32 top-24 w-4 h-36 bg-gradient-to-b from-red-500 via-orange-600 to-transparent rounded-full" style={{ filter: 'blur(2px)', animation: 'wave-smooth 3.2s ease-in-out infinite 0.5s' }}></div>
        <div className="absolute left-44 top-28 w-5 h-44 bg-gradient-to-b from-red-600 via-red-700 to-transparent rounded-full" style={{ filter: 'blur(2px)', animation: 'wave 2.3s ease-in-out infinite 0.8s' }}></div>
        <div className="absolute left-56 top-20 w-4 h-38 bg-gradient-to-b from-red-500 via-red-600 to-transparent rounded-full" style={{ filter: 'blur(2px)', animation: 'wave-intense 2.9s ease-in-out infinite 1s' }}></div>
        <div className="absolute left-68 top-26 w-4 h-42 bg-gradient-to-b from-red-700 via-red-800 to-transparent rounded-full" style={{ filter: 'blur(2px)', animation: 'wave-smooth 2.6s ease-in-out infinite 0.3s' }}></div>
        <div className="absolute left-80 top-30 w-5 h-48 bg-gradient-to-b from-red-500 via-orange-600 to-transparent rounded-full" style={{ filter: 'blur(2px)', animation: 'wave 2.7s ease-in-out infinite 0.6s' }}></div>
        <div className="absolute left-96 top-22 w-4 h-34 bg-gradient-to-b from-red-600 via-red-700 to-transparent rounded-full" style={{ filter: 'blur(2px)', animation: 'wave-intense 3.1s ease-in-out infinite 1.2s' }}></div>

        <div className="absolute right-10 top-40 w-4 h-32 bg-gradient-to-b from-red-500 via-red-600 to-transparent rounded-full" style={{ filter: 'blur(2px)', animation: 'wave-smooth 2.6s ease-in-out infinite 0.4s' }}></div>
        <div className="absolute right-24 top-28 w-5 h-40 bg-gradient-to-b from-red-600 via-red-700 to-transparent rounded-full" style={{ filter: 'blur(2px)', animation: 'wave 2.4s ease-in-out infinite 0.7s' }}></div>
        <div className="absolute right-40 top-36 w-4 h-36 bg-gradient-to-b from-red-500 via-orange-600 to-transparent rounded-full" style={{ filter: 'blur(2px)', animation: 'wave-intense 3s ease-in-out infinite 0.9s' }}></div>
        <div className="absolute right-56 top-32 w-5 h-44 bg-gradient-to-b from-red-600 via-red-700 to-transparent rounded-full" style={{ filter: 'blur(2px)', animation: 'wave-smooth 2.8s ease-in-out infinite 1.1s' }}></div>
        <div className="absolute right-72 top-24 w-4 h-38 bg-gradient-to-b from-red-500 via-red-600 to-transparent rounded-full" style={{ filter: 'blur(2px)', animation: 'wave 2.5s ease-in-out infinite 0.5s' }}></div>
        <div className="absolute right-88 top-30 w-4 h-42 bg-gradient-to-b from-red-700 via-red-800 to-transparent rounded-full" style={{ filter: 'blur(2px)', animation: 'wave-intense 2.9s ease-in-out infinite 0.2s' }}></div>
        <div className="absolute right-104 top-26 w-5 h-46 bg-gradient-to-b from-red-500 via-orange-600 to-transparent rounded-full" style={{ filter: 'blur(2px)', animation: 'wave-smooth 3.1s ease-in-out infinite 0.8s' }}></div>
        <div className="absolute right-120 top-34 w-4 h-40 bg-gradient-to-b from-red-600 via-red-700 to-transparent rounded-full" style={{ filter: 'blur(2px)', animation: 'wave 2.7s ease-in-out infinite 1.3s' }}></div>
      </div>

      <header className="fixed top-0 left-0 right-0 z-50 bg-black border-b-2 border-red-500 shadow-lg overflow-visible">
        <div className="container mx-auto px-2 sm:px-4 py-3 sm:py-6 flex flex-col lg:flex-row justify-between items-center gap-2 sm:gap-4 overflow-visible">
          <button
            onClick={async () => {
              await onSignOut();
              window.location.href = '/';
            }}
            className="flex items-center gap-2 sm:gap-3 flex-shrink-0 hover:opacity-80 transition-opacity cursor-pointer"
          >
            <div className="relative">
              <svg width="35" height="28" viewBox="0 0 50 40" fill="none" xmlns="http://www.w3.org/2000/svg" className="sm:w-[50px] sm:h-[40px]">
                <rect x="2" y="12" width="3" height="16" rx="1.5" fill="#39ff14" style={{ filter: 'drop-shadow(0 0 6px #ff0000)' }} />
                <rect x="8" y="8" width="3" height="24" rx="1.5" fill="#39ff14" style={{ filter: 'drop-shadow(0 0 6px #ff0000)' }} />
                <rect x="14" y="4" width="3" height="32" rx="1.5" fill="#39ff14" style={{ filter: 'drop-shadow(0 0 6px #ff0000)' }} />
                <path d="M24 8L42 20L24 32V8Z" fill="#39ff14" style={{ filter: 'drop-shadow(0 0 6px #ff0000)' }} />
              </svg>
            </div>
            <div className="flex flex-col leading-none">
              <div>
                <span className="text-base sm:text-2xl font-bold text-[#39ff14]" style={{ textShadow: '0 0 8px #ff0000' }}>Beat</span>
              </div>
              <div>
                <span className="text-base sm:text-2xl font-bold text-[#39ff14]" style={{ textShadow: '0 0 8px #ff0000' }}>Bookings</span>
              </div>
              <div>
                <span className="text-xs sm:text-base font-bold text-red-500" style={{ textShadow: '0 0 8px #ff0000' }}>LIVE</span>
              </div>
            </div>
          </button>

          <div className="text-base sm:text-xl lg:text-2xl font-bold text-fluro-green">
            Artist Directory
          </div>

          <div className="flex items-center gap-2 sm:gap-4 flex-wrap sm:flex-nowrap">
            {userProfileData && (
              <button
                onClick={() => setShowProfileView(true)}
                className="flex items-center gap-2 hover:opacity-80 transition-opacity"
              >
                {userProfileData.profile_image_url ? (
                  <img
                    src={userProfileData.profile_image_url}
                    alt={userProfileData.full_name}
                    className="w-8 h-8 sm:w-10 sm:h-10 rounded-full object-cover border-2 border-[#39ff14]"
                  />
                ) : (
                  <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-gray-700 border-2 border-[#39ff14] flex items-center justify-center">
                    <span className="text-[#39ff14] font-bold text-sm sm:text-base">
                      {userProfileData.full_name?.charAt(0).toUpperCase() || 'U'}
                    </span>
                  </div>
                )}
                <div className="text-fluro-green-subtle text-xs sm:text-sm hidden lg:block text-left">
                  <div className="font-semibold">{userProfileData.full_name}</div>
                  <div className="text-xs opacity-70">{user?.email}</div>
                </div>
              </button>
            )}
            <button
              onClick={() => setAdminInboxOpen(true)}
              className="flex items-center gap-1 sm:gap-2 px-2 sm:px-4 py-1.5 sm:py-2 bg-transparent border-2 border-blue-500 text-blue-500 rounded-lg text-xs sm:text-base font-semibold hover:bg-blue-500 hover:text-white transition-all duration-300"
              title="Admin Messages"
            >
              <Mail className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden sm:inline">ADMIN</span>
            </button>
            <NotificationBell />
            {isAdmin(user) && (
              <button
                onClick={() => navigate('/admin/profiles')}
                className="flex items-center gap-1 sm:gap-2 px-2 sm:px-4 py-1.5 sm:py-2 bg-transparent border-2 border-[#39ff14] text-[#39ff14] rounded-lg text-xs sm:text-base font-semibold hover:bg-[#39ff14] hover:text-black transition-all duration-300"
                title="Admin Dashboard"
              >
                <Shield className="w-3 h-3 sm:w-4 sm:h-4" />
                <span className="hidden sm:inline">Admin</span>
              </button>
            )}
            <button
              onClick={onSignOut}
              className="flex items-center gap-1 sm:gap-2 px-2 sm:px-4 py-1.5 sm:py-2 bg-transparent border-2 border-red-500 text-red-500 rounded-lg text-xs sm:text-base font-semibold hover:bg-red-500 hover:text-white transition-all duration-300"
            >
              <LogOut className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden sm:inline">Sign Out</span>
            </button>
          </div>
        </div>
      </header>

      <main className="relative z-10 container mx-auto px-4 py-12">
        <section className="mb-8">
          <div className="flex flex-col gap-4">
            <div>
              <h2 className="text-4xl font-bold text-fluro-green mb-2">
                Welcome to Your Dashboard
              </h2>
              <p className="text-fluro-green-subtle text-lg">
                Browse and book amazing artists for your events
              </p>
            </div>
            <div className="flex items-center gap-3 flex-wrap justify-start">
              <button
                onClick={() => setShowMyBookings(!showMyBookings)}
                className="flex items-center gap-2 px-4 sm:px-6 py-2 sm:py-3 bg-transparent border-2 border-[#39ff14] text-[#39ff14] rounded-lg font-bold hover:bg-[#39ff14] hover:text-black transition-all duration-300 whitespace-nowrap text-sm sm:text-base"
              >
                <Calendar className="w-4 h-4 sm:w-5 sm:h-5" />
                My Bookings {bookings.length > 0 && `(${bookings.length})`}
              </button>
              {hasArtistProfile && (
                <button
                  onClick={() => setShowIncomingBookings(!showIncomingBookings)}
                  className="flex items-center gap-2 px-4 sm:px-6 py-2 sm:py-3 bg-transparent border-2 border-blue-500 text-blue-500 rounded-lg font-bold hover:bg-blue-500 hover:text-white transition-all duration-300 whitespace-nowrap text-sm sm:text-base"
                >
                  <Bell className="w-4 h-4 sm:w-5 sm:h-5" />
                  Incoming Requests {incomingBookings.length > 0 && `(${incomingBookings.length})`}
                </button>
              )}
              {isArtist && !hasArtistProfile && (
                <button
                  onClick={() => setCreateProfileModalOpen(true)}
                  className="flex items-center gap-2 px-4 sm:px-6 py-2 sm:py-3 bg-[#39ff14] text-black rounded-lg font-bold hover:glow-red-strong transition-all duration-300 transform hover:scale-105 whitespace-nowrap text-sm sm:text-base"
                >
                  <Plus className="w-4 h-4 sm:w-5 sm:h-5" />
                  Create Artist Profile
                </button>
              )}
            </div>
          </div>
        </section>

        {showMyBookings && (
          <section className="mb-12">
            <div className="bg-gray-900 rounded-lg border-2 border-[#39ff14] p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-fluro-green">My Booking Requests</h3>
                <button
                  onClick={() => setShowMyBookings(false)}
                  className="text-fluro-green-subtle hover:text-fluro-green transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {loadingBookings ? (
                <div className="text-center py-8">
                  <p className="text-fluro-green-subtle">Loading bookings...</p>
                </div>
              ) : bookings.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-fluro-green-subtle">You haven't made any booking requests yet.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {bookings.map((booking) => (
                    <div
                      key={booking.id}
                      className="bg-gray-800 rounded-lg border border-red-500 border-opacity-30 p-6 hover:border-opacity-60 transition-all duration-300"
                    >
                      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-3">
                            {booking.artist?.image_url && (
                              <img
                                src={booking.artist.image_url}
                                alt={booking.artist.name}
                                className="w-16 h-16 rounded-lg object-cover border-2 border-red-500"
                              />
                            )}
                            <div>
                              <h4 className="text-xl font-bold text-fluro-green">
                                {booking.artist?.stage_name || booking.artist?.name || 'Artist'}
                              </h4>
                              <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold ${
                                booking.status === 'pending' ? 'bg-yellow-500 bg-opacity-20 text-yellow-400 border border-yellow-500' :
                                booking.status === 'confirmed' ? 'bg-green-500 bg-opacity-20 text-green-400 border border-green-500' :
                                booking.status === 'cancelled' ? 'bg-red-500 bg-opacity-20 text-red-400 border border-red-500' :
                                'bg-gray-500 bg-opacity-20 text-gray-400 border border-gray-500'
                              }`}>
                                {booking.status.toUpperCase()}
                              </span>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-fluro-green-subtle">
                            <div className="flex items-center gap-2">
                              <Music2 className="w-4 h-4" />
                              <span className="font-semibold">{booking.event_type}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Calendar className="w-4 h-4" />
                              <span>{new Date(booking.requested_date).toLocaleDateString()}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Clock className="w-4 h-4" />
                              <span>{booking.time_from} - {booking.time_to}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <MapPin className="w-4 h-4" />
                              <span className="text-sm">{booking.location}</span>
                            </div>
                          </div>

                          {booking.comments && (
                            <div className="mt-3 pt-3 border-t border-gray-700">
                              <p className="text-fluro-green-subtle text-sm">{booking.comments}</p>
                            </div>
                          )}
                        </div>

                        <div className="flex flex-col gap-2 w-full lg:w-auto">
                          <button
                            onClick={() => {
                              setSelectedBookingForMessage(booking);
                              setMessageModalOpen(true);
                            }}
                            className="flex items-center justify-center gap-2 px-4 py-2 bg-transparent border-2 border-[#39ff14] text-[#39ff14] rounded-lg font-semibold hover:bg-[#39ff14] hover:text-black transition-all duration-300 whitespace-nowrap"
                          >
                            <MessageCircle className="w-4 h-4" />
                            Message
                          </button>
                          {booking.status === 'cancelled' ? (
                            <button
                              onClick={() => {
                                if (booking.artist) {
                                  setSelectedArtist(booking.artist);
                                  setRebookingData(booking);
                                  setBookingModalOpen(true);
                                }
                              }}
                              className="flex items-center justify-center gap-2 px-4 py-2 bg-[#39ff14] border-2 border-[#39ff14] text-black rounded-lg font-semibold hover:glow-red-strong transition-all duration-300 whitespace-nowrap"
                            >
                              <Calendar className="w-4 h-4" />
                              Rebook
                            </button>
                          ) : (
                            <button
                              onClick={() => setEditingBooking(booking)}
                              className="flex items-center justify-center gap-2 px-4 py-2 bg-[#39ff14] bg-opacity-20 border-2 border-[#39ff14] text-[#39ff14] rounded-lg font-semibold hover:bg-[#39ff14] hover:text-black transition-all duration-300 whitespace-nowrap"
                            >
                              <Edit className="w-4 h-4" />
                              Edit
                            </button>
                          )}
                          <button
                            onClick={() => deleteBooking(booking.id)}
                            className="flex items-center justify-center gap-2 px-4 py-2 bg-red-500 bg-opacity-20 border-2 border-red-500 text-red-500 rounded-lg font-semibold hover:bg-red-500 hover:text-white transition-all duration-300 whitespace-nowrap"
                          >
                            <Trash2 className="w-4 h-4" />
                            Delete
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>
        )}

        {showIncomingBookings && hasArtistProfile && (
          <section className="mb-12">
            <div className="bg-gray-900 rounded-lg border-2 border-blue-500 p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-2xl font-bold text-blue-400">Incoming Booking Requests</h3>
                <button
                  onClick={() => setShowIncomingBookings(false)}
                  className="text-blue-400 hover:text-blue-300 transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              {incomingBookings.length === 0 ? (
                <div className="text-center py-8">
                  <p className="text-gray-400">No incoming booking requests yet.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {incomingBookings.map((booking) => (
                    <div
                      key={booking.id}
                      className="bg-gray-800 rounded-lg border border-blue-500 border-opacity-30 p-6 hover:border-opacity-60 transition-all duration-300"
                    >
                      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-3">
                            {booking.user_profile_image_url && (
                              <img
                                src={booking.user_profile_image_url}
                                alt={booking.user_name}
                                className="w-16 h-16 rounded-lg object-cover border-2 border-blue-500"
                              />
                            )}
                            {!booking.user_profile_image_url && (
                              <div className="w-16 h-16 rounded-lg bg-gray-700 border-2 border-blue-500 flex items-center justify-center">
                                <User className="w-8 h-8 text-blue-400" />
                              </div>
                            )}
                            <div>
                              <h4 className="text-xl font-bold text-blue-400">
                                {booking.user_name}
                              </h4>
                              <p className="text-sm text-gray-400">{booking.user_email}</p>
                              <span className={`inline-block px-3 py-1 rounded-full text-xs font-semibold mt-1 ${
                                booking.status === 'pending' ? 'bg-yellow-500 bg-opacity-20 text-yellow-400 border border-yellow-500' :
                                booking.status === 'confirmed' ? 'bg-green-500 bg-opacity-20 text-green-400 border border-green-500' :
                                booking.status === 'cancelled' ? 'bg-red-500 bg-opacity-20 text-red-400 border border-red-500' :
                                'bg-gray-500 bg-opacity-20 text-gray-400 border border-gray-500'
                              }`}>
                                {booking.status.toUpperCase()}
                              </span>
                            </div>
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-gray-300">
                            <div className="flex items-center gap-2">
                              <Music2 className="w-4 h-4 text-blue-400" />
                              <span className="font-semibold">{booking.event_type}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Calendar className="w-4 h-4 text-blue-400" />
                              <span>{new Date(booking.requested_date).toLocaleDateString()}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <Clock className="w-4 h-4 text-blue-400" />
                              <span>{booking.time_from} - {booking.time_to}</span>
                            </div>
                            <div className="flex items-center gap-2">
                              <MapPin className="w-4 h-4 text-blue-400" />
                              <span className="text-sm">{booking.location}</span>
                            </div>
                            {booking.user_phone && (
                              <div className="flex items-center gap-2">
                                <MessageCircle className="w-4 h-4 text-blue-400" />
                                <span className="text-sm">{booking.user_phone}</span>
                              </div>
                            )}
                          </div>

                          {booking.comments && (
                            <div className="mt-3 pt-3 border-t border-gray-700">
                              <p className="text-gray-300 text-sm">{booking.comments}</p>
                            </div>
                          )}
                        </div>

                        <div className="flex flex-col gap-2 w-full lg:w-auto">
                          <button
                            onClick={() => {
                              setSelectedBookingForMessage(booking);
                              setMessageModalOpen(true);
                            }}
                            className="flex items-center justify-center gap-2 px-4 py-2 bg-transparent border-2 border-blue-500 text-blue-500 rounded-lg font-semibold hover:bg-blue-500 hover:text-white transition-all duration-300 whitespace-nowrap"
                          >
                            <MessageCircle className="w-4 h-4" />
                            Message
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </section>
        )}

        <ArtistFilters onFilterChange={handleFilterChange} />

        {filteredArtists.some(a => a.is_premium) && (
          <section className="mb-12">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-3xl font-bold text-fluro-green">
                Featured Artists
              </h3>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6 mb-12">
              {filteredArtists
                .filter(a => a.is_premium)
                .map((artist) => (
                  <div
                    key={artist.id}
                    onClick={() => setSelectedArtist(artist)}
                    className="bg-gray-900 rounded-lg overflow-hidden border-2 border-yellow-500 glow-yellow hover:glow-yellow-strong transition-all duration-300 transform hover:scale-105 cursor-pointer group relative"
                  >
                    <div className="absolute top-3 right-3 z-10 flex gap-2">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleFavorite(artist.id);
                        }}
                        className={`${
                          userFavorites.has(artist.id)
                            ? 'bg-red-500 text-white'
                            : 'bg-gray-900 bg-opacity-70 text-gray-400 hover:text-red-500'
                        } rounded-full p-2 hover:scale-110 transition-all duration-300 shadow-lg`}
                        title={userFavorites.has(artist.id) ? 'Remove from favorites' : 'Add to favorites'}
                      >
                        <Heart className={`w-5 h-5 ${userFavorites.has(artist.id) ? 'fill-white' : ''}`} />
                      </button>
                      <div className="bg-yellow-500 rounded-full p-2">
                        <Star className="w-5 h-5 fill-black text-black" />
                      </div>
                    </div>
                    <div className="relative overflow-hidden h-64">
                      <img
                        src={artist.image_url}
                        alt={artist.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-70"></div>
                      <ArtistCardStats artistId={artist.id} />
                    </div>
                    <div className="p-6">
                      <h4 className="text-2xl font-bold text-fluro-green-subtle mb-2">{artist.stage_name || artist.name}</h4>
                      <p className="text-fluro-green-subtle text-sm mb-1">{artist.category}</p>
                      {artist.genre && (
                        <p className="text-fluro-green-subtle text-xs mb-1 opacity-70">{artist.genre}</p>
                      )}
                      <p className="text-fluro-green-subtle text-sm opacity-80 mb-3">{artist.location}</p>
                      <div className="flex items-center gap-2 mb-3">
                        {renderStars(artist.rating)}
                        <span className="text-fluro-green-subtle text-sm">
                          ({typeof artist.rating === 'number' ? artist.rating.toFixed(1) : parseFloat(artist.rating || '0').toFixed(1)})
                        </span>
                      </div>
                      <div className="flex gap-2 flex-wrap">
                        {artist.youtube_link && (
                          <a
                            href={artist.youtube_link}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => e.stopPropagation()}
                            className="text-red-500 hover:text-red-400 transition-colors"
                            title="YouTube"
                          >
                            <Youtube className="w-4 h-4" />
                          </a>
                        )}
                        {artist.instagram_link && (
                          <a
                            href={artist.instagram_link}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => e.stopPropagation()}
                            className="text-pink-500 hover:text-pink-400 transition-colors"
                            title="Instagram"
                          >
                            <Instagram className="w-4 h-4" />
                          </a>
                        )}
                        {artist.facebook_link && (
                          <a
                            href={artist.facebook_link}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => e.stopPropagation()}
                            className="text-blue-500 hover:text-blue-400 transition-colors"
                            title="Facebook"
                          >
                            <Facebook className="w-4 h-4" />
                          </a>
                        )}
                        {artist.soundcloud_link && (
                          <a
                            href={artist.soundcloud_link}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => e.stopPropagation()}
                            className="text-orange-500 hover:text-orange-400 transition-colors"
                            title="SoundCloud"
                          >
                            <Music className="w-4 h-4" />
                          </a>
                        )}
                        {artist.mixcloud_link && (
                          <a
                            href={artist.mixcloud_link}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => e.stopPropagation()}
                            className="text-teal-500 hover:text-teal-400 transition-colors"
                            title="Mixcloud"
                          >
                            <Radio className="w-4 h-4" />
                          </a>
                        )}
                        {artist.spotify_link && (
                          <a
                            href={artist.spotify_link}
                            target="_blank"
                            rel="noopener noreferrer"
                            onClick={(e) => e.stopPropagation()}
                            className="text-green-500 hover:text-green-400 transition-colors"
                            title="Spotify"
                          >
                            <Headphones className="w-4 h-4" />
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          </section>
        )}

        <section className="mb-16">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-3xl font-bold text-fluro-green-subtle">
              All Artists
            </h3>
          </div>
          {loading ? (
            <div className="text-center py-12">
              <p className="text-fluro-green-subtle text-lg">Loading artists...</p>
            </div>
          ) : filteredArtists.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-fluro-green-subtle text-lg">No artists found matching your filters</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-6">
              {filteredArtists.map((artist) => (
                <div
                  key={artist.id}
                  onClick={() => setSelectedArtist(artist)}
                  className={`bg-gray-900 rounded-lg overflow-hidden border-2 ${artist.is_premium ? 'border-yellow-500 glow-yellow hover:glow-yellow-strong' : 'border-red-500 glow-red hover:glow-red-strong'} transition-all duration-300 transform hover:scale-105 cursor-pointer group relative`}
                >
                  <div className="absolute top-3 right-3 z-10 flex gap-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFavorite(artist.id);
                      }}
                      className={`${
                        userFavorites.has(artist.id)
                          ? 'bg-red-500 text-white'
                          : 'bg-gray-900 bg-opacity-70 text-gray-400 hover:text-red-500'
                      } rounded-full p-2 hover:scale-110 transition-all duration-300 shadow-lg`}
                      title={userFavorites.has(artist.id) ? 'Remove from favorites' : 'Add to favorites'}
                    >
                      <Heart className={`w-5 h-5 ${userFavorites.has(artist.id) ? 'fill-white' : ''}`} />
                    </button>
                    {artist.is_premium && (
                      <div className="bg-yellow-500 rounded-full p-2">
                        <Star className="w-5 h-5 fill-black text-black" />
                      </div>
                    )}
                  </div>
                  <div className="relative overflow-hidden h-64">
                    <img
                      src={artist.image_url}
                      alt={artist.name}
                      className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-70"></div>
                    <ArtistCardStats artistId={artist.id} />
                  </div>
                  <div className="p-6">
                    <h4 className="text-2xl font-bold text-fluro-green-subtle mb-2">{artist.stage_name || artist.name}</h4>
                    <p className="text-fluro-green-subtle text-sm mb-1">{artist.category}</p>
                    {artist.genre && (
                      <p className="text-fluro-green-subtle text-xs mb-1 opacity-70">{artist.genre}</p>
                    )}
                    <p className="text-fluro-green-subtle text-sm opacity-80 mb-3">{artist.location}</p>
                    <div className="flex items-center gap-2 mb-3">
                      {renderStars(artist.rating)}
                      <span className="text-fluro-green-subtle text-sm">
                        ({typeof artist.rating === 'number' ? artist.rating.toFixed(1) : parseFloat(artist.rating || '0').toFixed(1)})
                      </span>
                    </div>
                    <div className="flex gap-2 flex-wrap">
                      {artist.youtube_link && (
                        <a
                          href={artist.youtube_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="text-red-500 hover:text-red-400 transition-colors"
                          title="YouTube"
                        >
                          <Youtube className="w-4 h-4" />
                        </a>
                      )}
                      {artist.instagram_link && (
                        <a
                          href={artist.instagram_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="text-pink-500 hover:text-pink-400 transition-colors"
                          title="Instagram"
                        >
                          <Instagram className="w-4 h-4" />
                        </a>
                      )}
                      {artist.facebook_link && (
                        <a
                          href={artist.facebook_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="text-blue-500 hover:text-blue-400 transition-colors"
                          title="Facebook"
                        >
                          <Facebook className="w-4 h-4" />
                        </a>
                      )}
                      {artist.soundcloud_link && (
                        <a
                          href={artist.soundcloud_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="text-orange-500 hover:text-orange-400 transition-colors"
                          title="SoundCloud"
                        >
                          <Music className="w-4 h-4" />
                        </a>
                      )}
                      {artist.mixcloud_link && (
                        <a
                          href={artist.mixcloud_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="text-teal-500 hover:text-teal-400 transition-colors"
                          title="Mixcloud"
                        >
                          <Radio className="w-4 h-4" />
                        </a>
                      )}
                      {artist.spotify_link && (
                        <a
                          href={artist.spotify_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="text-green-500 hover:text-green-400 transition-colors"
                          title="Spotify"
                        >
                          <Headphones className="w-4 h-4" />
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </section>
      </main>

      <footer className="relative z-10 container mx-auto px-4 py-8 text-center border-t border-red-500 border-opacity-30">
        <div className="flex flex-col items-center gap-3">
          <Link
            to="/terms"
            className="text-fluro-green-subtle text-sm hover:text-[#39ff14] transition-colors underline"
          >
            Terms & Conditions
          </Link>
          <p className="text-fluro-green-subtle text-sm">
            © 2025 Beat Bookings Live. All rights reserved.
          </p>
        </div>
      </footer>

      {selectedArtist && (() => {
        const artistTheme = getThemeClasses(selectedArtist.profile_theme);
        return (
        <div className="fixed inset-0 bg-black bg-opacity-80 backdrop-blur-sm z-50 overflow-y-auto" onClick={() => setSelectedArtist(null)}>
          <div className={`bg-gray-900 rounded-2xl ${artistTheme.border} ${artistTheme.glowStrong} max-w-4xl w-full my-4 mx-auto`} onClick={(e) => e.stopPropagation()} style={{ maxHeight: 'calc(100vh - 32px)' }}>
            <div className="relative">
              <div className="absolute top-2 right-2 md:top-4 md:right-4 z-20 flex items-center gap-2">
                {!isOwnProfile && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleFavorite(selectedArtist.id);
                    }}
                    className={`${
                      userFavorites.has(selectedArtist.id)
                        ? 'bg-red-500 border-red-500 text-white'
                        : 'bg-gray-900 bg-opacity-50 border-gray-700 text-gray-400'
                    } border-2 rounded-full p-2 hover:scale-110 transition-all duration-300 shadow-lg`}
                    title={userFavorites.has(selectedArtist.id) ? 'Remove from favorites' : 'Add to favorites'}
                    style={{ minWidth: '44px', minHeight: '44px' }}
                  >
                    <Heart
                      className="w-5 h-5"
                      fill={userFavorites.has(selectedArtist.id) ? 'currentColor' : 'none'}
                    />
                  </button>
                )}
                {isOwnProfile && (
                  <>
                    <button
                      onClick={() => setEditProfileModalOpen(true)}
                      className="bg-[#39ff14] bg-opacity-20 border-2 border-[#39ff14] rounded-full p-2 text-[#39ff14] hover:bg-opacity-30 transition-all duration-300 shadow-lg"
                      title="Edit Profile"
                      style={{ minWidth: '44px', minHeight: '44px' }}
                    >
                      <Edit className="w-5 h-5" />
                    </button>
                    <button
                      onClick={handleDeleteProfile}
                      className="bg-red-500 bg-opacity-20 border-2 border-red-500 rounded-full p-2 text-red-500 hover:bg-opacity-30 transition-all duration-300 shadow-lg"
                      title="Delete Profile"
                      style={{ minWidth: '44px', minHeight: '44px' }}
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </>
                )}
                <button
                  onClick={() => setSelectedArtist(null)}
                  className="bg-black bg-opacity-90 rounded-full p-2 md:p-3 text-fluro-green-subtle hover:text-fluro-green hover:bg-opacity-100 transition-all duration-300 shadow-lg"
                  style={{ minWidth: '44px', minHeight: '44px' }}
                >
                  <X className="w-5 h-5 md:w-6 md:h-6" />
                </button>
              </div>

              <div className="relative h-48 sm:h-64 md:h-80 lg:h-96 overflow-hidden">
                <img
                  src={selectedArtist.image_url}
                  alt={selectedArtist.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-gray-900/50 to-transparent"></div>
                <div className="absolute bottom-8 left-8 right-8">
                  <h2 className="text-5xl font-bold text-fluro-green mb-3">{selectedArtist.stage_name || selectedArtist.name}</h2>
                  <div className="flex items-center gap-4 text-fluro-green-subtle">
                    <div className="flex items-center gap-2">
                      <Music2 className="w-5 h-5" />
                      <span className="text-lg">{selectedArtist.category}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-5 h-5" />
                      <span className="text-lg">{selectedArtist.location}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {renderStars(selectedArtist.rating)}
                      <span className="text-lg">({selectedArtist.rating || '0'})</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="p-8">
                <div className="mb-6">
                  <div className="inline-block px-4 py-2 rounded-full border-2 mb-4" style={{
                    borderColor: selectedArtist.availability === 'available' ? '#39ff14' : '#ff0000',
                    backgroundColor: selectedArtist.availability === 'available' ? 'rgba(57, 255, 20, 0.1)' : 'rgba(255, 0, 0, 0.1)'
                  }}>
                    <span className={`font-bold ${selectedArtist.availability === 'available' ? 'text-[#39ff14]' : 'text-red-500'}`}>
                      {selectedArtist.availability === 'available' ? 'Available for Booking' : 'Currently Booked'}
                    </span>
                  </div>
                </div>

                <div className={`bg-black bg-opacity-50 border ${artistTheme.borderStrong.replace('border-2 ', '')} border-opacity-30 rounded-lg p-6 mb-6`}>
                  <h3 className="text-xl font-bold text-fluro-green-subtle mb-4">About</h3>
                  <p className="text-fluro-green-subtle leading-relaxed">
                    {selectedArtist.about}
                  </p>
                </div>

                {(selectedArtist.youtube_link || selectedArtist.instagram_link || selectedArtist.facebook_link ||
                  selectedArtist.soundcloud_link || selectedArtist.mixcloud_link || selectedArtist.spotify_link ||
                  selectedArtist.tiktok_link) && (
                  <div className={`bg-black bg-opacity-50 border ${artistTheme.borderStrong.replace('border-2 ', '')} border-opacity-30 rounded-lg p-6 mb-6`}>
                    <h3 className="text-xl font-bold text-fluro-green-subtle mb-4">Connect</h3>
                    <div className="flex flex-wrap gap-3">
                      {selectedArtist.youtube_link && (
                        <a
                          href={selectedArtist.youtube_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 px-4 py-2 bg-red-600 bg-opacity-20 border-2 border-red-600 text-red-500 rounded-lg font-semibold hover:bg-red-600 hover:text-white transition-all duration-300"
                        >
                          <Youtube className="w-5 h-5" />
                          YouTube
                        </a>
                      )}
                      {selectedArtist.instagram_link && (
                        <a
                          href={selectedArtist.instagram_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 px-4 py-2 bg-pink-600 bg-opacity-20 border-2 border-pink-600 text-pink-500 rounded-lg font-semibold hover:bg-pink-600 hover:text-white transition-all duration-300"
                        >
                          <Instagram className="w-5 h-5" />
                          Instagram
                        </a>
                      )}
                      {selectedArtist.facebook_link && (
                        <a
                          href={selectedArtist.facebook_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 px-4 py-2 bg-blue-600 bg-opacity-20 border-2 border-blue-600 text-blue-500 rounded-lg font-semibold hover:bg-blue-600 hover:text-white transition-all duration-300"
                        >
                          <Facebook className="w-5 h-5" />
                          Facebook
                        </a>
                      )}
                      {selectedArtist.soundcloud_link && (
                        <a
                          href={selectedArtist.soundcloud_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 px-4 py-2 bg-orange-600 bg-opacity-20 border-2 border-orange-600 text-orange-500 rounded-lg font-semibold hover:bg-orange-600 hover:text-white transition-all duration-300"
                        >
                          <Music className="w-5 h-5" />
                          SoundCloud
                        </a>
                      )}
                      {selectedArtist.mixcloud_link && (
                        <a
                          href={selectedArtist.mixcloud_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 px-4 py-2 bg-teal-600 bg-opacity-20 border-2 border-teal-600 text-teal-500 rounded-lg font-semibold hover:bg-teal-600 hover:text-white transition-all duration-300"
                        >
                          <Radio className="w-5 h-5" />
                          Mixcloud
                        </a>
                      )}
                      {selectedArtist.spotify_link && (
                        <a
                          href={selectedArtist.spotify_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 px-4 py-2 bg-green-600 bg-opacity-20 border-2 border-green-600 text-green-500 rounded-lg font-semibold hover:bg-green-600 hover:text-white transition-all duration-300"
                        >
                          <Headphones className="w-5 h-5" />
                          Spotify
                        </a>
                      )}
                      {selectedArtist.tiktok_link && (
                        <a
                          href={selectedArtist.tiktok_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center gap-2 px-4 py-2 bg-gray-700 bg-opacity-20 border-2 border-gray-400 text-gray-300 rounded-lg font-semibold hover:bg-gray-700 hover:text-white transition-all duration-300"
                        >
                          <Music2 className="w-5 h-5" />
                          TikTok
                        </a>
                      )}
                    </div>
                  </div>
                )}

                {!isOwnProfile && (
                  <div className={`bg-black bg-opacity-50 border ${artistTheme.borderStrong.replace('border-2 ', '')} border-opacity-30 rounded-lg p-6 mb-6`}>
                    <h3 className="text-xl font-bold text-fluro-green-subtle mb-4">Reviews</h3>

                    <div className="mb-6">
                      <h4 className="text-lg font-semibold text-fluro-green-subtle mb-3">Write a Review</h4>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">Rating</label>
                        <div className="flex gap-2">
                          {[1, 2, 3, 4, 5].map((star) => (
                            <button
                              key={star}
                              onClick={() => setNewReview({ ...newReview, rating: star })}
                              className="transition-transform hover:scale-110"
                            >
                              <Star
                                className={`w-8 h-8 cursor-pointer ${
                                  star <= newReview.rating
                                    ? 'fill-[#39ff14] text-[#39ff14]'
                                    : 'text-gray-600 hover:text-[#39ff14]'
                                }`}
                              />
                            </button>
                          ))}
                        </div>
                      </div>
                      <div>
                        <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">Comment</label>
                        <textarea
                          value={newReview.comment}
                          onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                          className="w-full px-4 py-3 bg-gray-800 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] placeholder-[#39ff14] placeholder-opacity-40 focus:outline-none focus:border-opacity-100 transition-all duration-300 min-h-[100px]"
                          placeholder="Share your experience with this artist..."
                        />
                      </div>
                      <button
                        onClick={submitReview}
                        disabled={submittingReview}
                        className={`flex items-center gap-2 px-6 py-3 bg-[#39ff14] text-black rounded-lg font-bold ${artistTheme.hoverGlow} transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed`}
                      >
                        <Send className="w-5 h-5" />
                        {submittingReview ? 'Submitting...' : 'Submit Review'}
                      </button>
                    </div>
                  </div>

                  <div className={`border-t ${artistTheme.borderStrong.replace('border-2 ', '')} border-opacity-30 pt-6`}>
                    {loadingReviews ? (
                      <p className="text-fluro-green-subtle text-center">Loading reviews...</p>
                    ) : reviews.length === 0 ? (
                      <p className="text-fluro-green-subtle text-center">No reviews yet. Be the first to review!</p>
                    ) : (
                      <div className="space-y-4">
                        {reviews.map((review) => (
                          <div key={review.id} className={`bg-gray-800 bg-opacity-50 rounded-lg p-4 border ${artistTheme.borderStrong.replace('border-2 ', '')} border-opacity-20`}>
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center gap-2">
                                {renderStars(review.rating, 'w-4 h-4')}
                              </div>
                              <span className="text-fluro-green-subtle text-xs">
                                {new Date(review.created_at).toLocaleDateString()}
                              </span>
                            </div>
                            {review.comment && (
                              <p className="text-fluro-green-subtle text-sm">{review.comment}</p>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                )}

                {!isOwnProfile && selectedArtist.availability === 'available' && (
                  <div className="flex justify-center">
                    <button
                      onClick={() => setBookingModalOpen(true)}
                      className={`px-8 py-4 bg-[#39ff14] text-black rounded-lg font-bold ${artistTheme.hoverGlow} transition-all duration-300 transform hover:scale-105`}
                    >
                      Request Booking
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
        );
      })()}

      <ArtistProfileModal
        isOpen={createProfileModalOpen}
        userId={user.id}
        userEmail={user.email}
        onClose={() => setCreateProfileModalOpen(false)}
        onComplete={() => {
          setCreateProfileModalOpen(false);
          checkUserArtistStatus();
          fetchArtists();
        }}
      />

      <EditProfileModal
        isOpen={editProfileModalOpen}
        artistCard={userArtistCard}
        artistProfile={userArtistProfile}
        userId={user.id}
        onClose={() => setEditProfileModalOpen(false)}
        onSuccess={handleEditSuccess}
      />

      {userProfileData && (
        <EditUserProfileModal
          isOpen={editUserProfileModalOpen}
          onClose={() => setEditUserProfileModalOpen(false)}
          user={userProfileData}
          onSuccess={() => {
            setEditUserProfileModalOpen(false);
            fetchUserProfile();
            setShowProfileView(true);
          }}
        />
      )}

      {selectedArtist && (
        <BookingRequestModal
          isOpen={bookingModalOpen}
          onClose={() => {
            setBookingModalOpen(false);
            setRebookingData(null);
          }}
          artistId={selectedArtist.id}
          artistName={selectedArtist.stage_name || selectedArtist.name}
          artistEmail={selectedArtist.email}
          onSuccess={() => fetchBookings()}
          previousBooking={rebookingData}
        />
      )}

      <EditBookingModal
        isOpen={!!editingBooking}
        onClose={() => setEditingBooking(null)}
        booking={editingBooking}
        onSuccess={() => {
          setEditingBooking(null);
          fetchBookings();
        }}
      />

      {messageModalOpen && selectedBookingForMessage && (
        <BookingMessagesModal
          isOpen={messageModalOpen}
          onClose={() => {
            setMessageModalOpen(false);
            setSelectedBookingForMessage(null);
          }}
          booking={selectedBookingForMessage}
          currentUserId={user.id}
          isArtist={false}
        />
      )}

      <FloatingSupportButton onClick={() => setSupportChatOpen(true)} />

      <MessageAdminButton
        userId={user.id}
        userEmail={user.email}
        variant="floating"
      />

      <SupportChatModal
        isOpen={supportChatOpen}
        onClose={() => setSupportChatOpen(false)}
        userId={user.id}
      />

      {showProfileView && userProfileData && (
        <div className="fixed inset-0 bg-black bg-opacity-80 backdrop-blur-sm z-50 overflow-y-auto p-4">
          <div className="max-w-6xl mx-auto my-8">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-3xl font-bold text-[#39ff14]">My Profile</h2>
              <div className="flex gap-2">
                <button
                  onClick={() => {
                    setShowProfileView(false);
                    setEditUserProfileModalOpen(true);
                  }}
                  className="px-4 py-2 bg-[#39ff14] text-black rounded-lg font-semibold hover:bg-[#2acc00] transition-colors flex items-center gap-2"
                >
                  <Edit className="w-4 h-4" />
                  Edit Profile
                </button>
                <button
                  onClick={() => setShowProfileView(false)}
                  className="px-4 py-2 bg-gray-800 text-fluro-green-subtle rounded-lg font-semibold hover:bg-gray-700 transition-colors flex items-center gap-2"
                >
                  <X className="w-4 h-4" />
                  Close
                </button>
              </div>
            </div>
            <UserProfileView
              user={userProfileData}
              onSelectArtist={(artist) => {
                setSelectedArtist(artist);
                setShowProfileView(false);
              }}
            />
          </div>
        </div>
      )}

      <AdminMessagesInbox
        isOpen={adminInboxOpen}
        onClose={() => setAdminInboxOpen(false)}
        userId={user.id}
        userEmail={user.email || ''}
      />
    </div>
  );
}
