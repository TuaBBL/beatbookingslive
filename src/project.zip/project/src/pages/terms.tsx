import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
      <div className="max-w-3xl mx-auto px-6 py-12 text-white">
        <Link
          to="/"
          className="inline-flex items-center text-[#39ff14] hover:text-[#2ee000] mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Link>

        <div className="space-y-8">
          <div>
            <h1 className="text-4xl font-bold text-[#39ff14] mb-2">
              TERMS & CONDITIONS — BeatBookingsLive
            </h1>
            <p className="text-gray-400 text-sm">
              Last Updated: 26 Nov 25
            </p>
          </div>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              1. Introduction
            </h2>
            <p className="text-gray-300 leading-relaxed mb-3">
              BeatBookingsLive ("the Platform") is an online directory for Artists (DJs, performers, musicians) to showcase their profiles.
              Clients, planners, and venues ("Users") can browse profiles and communicate with Artists using the Platform's messaging box.
            </p>
            <p className="text-gray-300 leading-relaxed mb-3">
              BeatBookingsLive does NOT handle bookings, payments, deposits, or contracts.
            </p>
            <p className="text-gray-300 leading-relaxed">
              All arrangements are handled privately between Users.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              2. Nature of Service
            </h2>
            <p className="text-gray-300 leading-relaxed mb-3">
              BeatBookingsLive provides:
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-300 mb-4 ml-4">
              <li>Artist profiles</li>
              <li>Search tools</li>
              <li>Media display</li>
              <li>A messaging box for communication</li>
            </ul>
            <p className="text-gray-300 leading-relaxed mb-3">
              BeatBookingsLive does NOT:
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-300 mb-4 ml-4">
              <li>Act as a booking agent</li>
              <li>Process payments</li>
              <li>Guarantee event outcomes</li>
              <li>Verify artists</li>
              <li>Handle contracts</li>
              <li>Manage disputes</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              3. Messaging Feature
            </h2>
            <p className="text-gray-300 leading-relaxed mb-3">
              The Platform includes a messaging box that allows Artists and Clients to communicate.
            </p>
            <p className="text-gray-300 leading-relaxed mb-3">
              By using this feature, you agree:
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-300 mb-4 ml-4">
              <li>To communicate respectfully</li>
              <li>Not to send harassment, threats, or spam</li>
              <li>Not to share illegal content</li>
              <li>Not to attempt scams, fraud, or solicitation</li>
              <li>Not to exchange sensitive data (banking, IDs) unless you choose to do so privately</li>
              <li>All agreements made in messages are your responsibility</li>
            </ul>
            <p className="text-gray-300 leading-relaxed mb-3">
              BeatBookingsLive is not responsible for:
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-300 mb-4 ml-4">
              <li>Conversations</li>
              <li>Miscommunication</li>
              <li>Agreements made via messaging</li>
              <li>Harassment (though we may suspend offenders)</li>
              <li>Damages or losses resulting from messages</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              4. User Accounts
            </h2>
            <p className="text-gray-300 leading-relaxed mb-3">
              Users must:
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-300 mb-3 ml-4">
              <li>Provide accurate information</li>
              <li>Not impersonate others</li>
              <li>Not upload copyrighted content without rights</li>
              <li>Keep login details secure</li>
            </ul>
            <p className="text-gray-300 leading-relaxed">
              Account violations may result in suspension.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              3. ARTIST GUIDELINES — BeatBookingsLive
            </h2>
            <p className="text-gray-300 leading-relaxed mb-3">
              Artists agree to:
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-300 mb-4 ml-4">
              <li>Provide accurate profile content</li>
              <li>Respond respectfully using the messaging box</li>
              <li>Not use messaging for harassment or spam</li>
              <li>Manage all pricing, contracts & payments privately off-platform</li>
              <li>Not rely on BeatBookingsLive to handle disputes or guarantees</li>
              <li>Not upload copyrighted content without permission</li>
            </ul>
            <p className="text-gray-300 leading-relaxed mb-3">
              BeatBookingsLive is not liable for:
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-300 mb-4 ml-4">
              <li>Artist conduct</li>
              <li>Payment issues</li>
              <li>Performance quality</li>
              <li>Miscommunication in messages</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              4. CLIENT GUIDELINES — BeatBookingsLive
            </h2>
            <p className="text-gray-300 leading-relaxed mb-3">
              Clients agree to:
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-300 mb-4 ml-4">
              <li>Use the messaging box respectfully</li>
              <li>Confirm bookings privately with Artists</li>
              <li>Handle payments independently</li>
              <li>Verify artist suitability before booking</li>
              <li>Not rely on BeatBookingsLive for dispute resolution</li>
            </ul>
            <p className="text-gray-300 leading-relaxed mb-3">
              BeatBookingsLive is not liable for:
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-300 mb-4 ml-4">
              <li>No-shows</li>
              <li>Payment disputes</li>
              <li>Miscommunication in messages</li>
              <li>Artist behaviour or event outcomes</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              5. SAFETY & CONDUCT — BeatBookingsLive
            </h2>
            <p className="text-gray-300 leading-relaxed mb-3">
              Users must not:
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-300 mb-4 ml-4">
              <li>Harass or threaten others</li>
              <li>Use messaging for spam or scams</li>
              <li>Share illegal content</li>
              <li>Impersonate others</li>
              <li>Engage in discriminatory behaviour</li>
            </ul>
            <p className="text-gray-300 leading-relaxed mb-3">
              BeatBookingsLive may suspend accounts violating these rules.
            </p>
            <p className="text-gray-300 leading-relaxed mb-3">
              BeatBookingsLive is not responsible for:
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-300 mb-4 ml-4">
              <li>Off-platform interactions</li>
              <li>In-person behaviour</li>
              <li>Event safety</li>
              <li>Any agreements made privately</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              6. User Content
            </h2>
            <p className="text-gray-300 leading-relaxed mb-3">
              Users grant BeatBookingsLive permission to display:
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-300 mb-3 ml-4">
              <li>Photos</li>
              <li>Videos</li>
              <li>Mixes</li>
              <li>Descriptions</li>
            </ul>
            <p className="text-gray-300 leading-relaxed">
              Users must not upload illegal or harmful content.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              7. Limitation of Liability
            </h2>
            <p className="text-gray-300 leading-relaxed mb-3">
              BeatBookingsLive is not liable for:
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-300 mb-3 ml-4">
              <li>Artist/Client behaviour</li>
              <li>Event outcomes</li>
              <li>Cancellations or no-shows</li>
              <li>Miscommunication via messages</li>
              <li>Payment disputes</li>
              <li>Damages or injuries</li>
              <li>Personal arrangements between Users</li>
            </ul>
            <p className="text-gray-300 leading-relaxed">
              You use the Platform at your own risk.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              8. Termination
            </h2>
            <p className="text-gray-300 leading-relaxed mb-3">
              We may remove accounts for:
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-300 ml-4">
              <li>Abuse</li>
              <li>Harassment</li>
              <li>Fraud</li>
              <li>Illegal activity</li>
              <li>Violations of these Terms</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              9. Changes to Terms
            </h2>
            <p className="text-gray-300 leading-relaxed">
              We may update the Terms at any time.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              10. Contact
            </h2>
            <p className="text-gray-300 leading-relaxed">
              info@beatbookingslive.com
            </p>
          </section>

          <div className="mt-8 text-center">
            <Link
              to="/"
              className="inline-flex items-center justify-center px-8 py-3 bg-[#39ff14] text-black font-semibold rounded-lg hover:bg-[#2ee000] transition-colors shadow-lg"
            >
              Back to Home
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
