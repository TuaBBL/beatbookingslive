import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Lock, Eye, EyeOff } from 'lucide-react';

export function ResetPasswordPage() {
  const navigate = useNavigate();
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isValidToken, setIsValidToken] = useState(false);

 useEffect(() => {
  const hashParams = new URLSearchParams(window.location.hash.substring(1));
  const queryParams = new URLSearchParams(window.location.search);

  const token =
    hashParams.get('access_token') ||
    queryParams.get('access_token') ||
    hashParams.get('token') ||
    queryParams.get('token');

  const type =
    hashParams.get('type') ||
    queryParams.get('type');

  const refreshToken =
    hashParams.get('refresh_token') ||
    queryParams.get('refresh_token') ||
    token;

  console.log("Reset Debug:", { token, refreshToken, type });

  if (!token || type !== 'recovery') {
    setMessage({
      type: 'error',
      text: 'Invalid or expired password reset link',
    });
    return;
  }

  setIsValidToken(true);

  supabase.auth.setSession({
    access_token: token,
    refresh_token: refreshToken,
  }).then(({ error }) => {
    if (error) {
      console.error("Session error:", error);
      setMessage({
        type: 'error',
        text: 'Auth session missing or expired. Refresh your email link.',
      });
      setIsValidToken(false);
    }
  });
}, []);

  const handleSubmit = async (e: React.FormEvent) => {
  e.preventDefault();
  setLoading(true);
  setMessage(null);

  if (password !== confirmPassword) {
    setMessage({ type: 'error', text: 'Passwords do not match' });
    setLoading(false);
    return;
  }

  if (password.length < 6) {
    setMessage({ type: 'error', text: 'Password must be at least 6 characters long' });
    setLoading(false);
    return;
  }

  try {
    const { error } = await supabase.auth.updateUser({
      password: password,
    });

    if (error) throw error;

    setMessage({
      type: 'success',
      text: 'Password updated successfully! Redirecting to login...',
    });

    // Hard redirect because React Router context can be lost after recovery session
    setTimeout(() => {
      window.location.href = '/login';
    }, 1500);

  } catch (error: any) {
    setMessage({ type: 'error', text: error.message || 'Failed to update password' });
  } finally {
    setLoading(false);
  }
};

  if (!isValidToken && !message) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="text-center">
          <p className="text-gray-600">Validating reset link...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <h1 className="text-center text-3xl font-extrabold text-gray-900 mb-2">
          Reset Your Password
        </h1>
        <p className="text-center text-sm text-gray-600 mb-8">
          Enter your new password below
        </p>

        {message && (
          <div className={`mb-4 p-3 rounded-md ${
            message.type === 'error'
              ? 'bg-red-50 text-red-700 border border-red-200'
              : 'bg-green-50 text-green-700 border border-green-200'
          }`}>
            {message.text}
          </div>
        )}

        {isValidToken && (
          <div className="bg-white rounded-lg shadow-md p-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-1">
                  New Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    required
                    minLength={6}
                    className="w-full pl-10 pr-10 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    placeholder="Enter your new password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <div>
                <label htmlFor="confirmPassword" className="block text-sm font-medium text-gray-700 mb-1">
                  Confirm New Password
                </label>
                <div className="relative">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    id="confirmPassword"
                    type={showConfirmPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    required
                    minLength={6}
                    className="w-full pl-10 pr-10 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    placeholder="Confirm your new password"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute inset-y-0 right-0 pr-3 flex items-center text-gray-400 hover:text-gray-600"
                  >
                    {showConfirmPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full bg-indigo-600 text-white py-2 px-4 rounded-md hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
              >
                {loading ? 'Updating password...' : 'Update Password'}
              </button>
            </form>
          </div>
        )}

        {!isValidToken && (
          <div className="mt-6 text-center">
            <button
              onClick={() => navigate('/login')}
              className="text-sm text-indigo-600 hover:text-indigo-500 font-medium"
            >
              Return to Login
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
