import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { LoginForm } from '../components/auth/LoginForm';
import { SupportChatModal } from '../components/SupportChatModal';
import { FloatingSupportButton } from '../components/FloatingSupportButton';
import { UserProfileSetupModal } from '../components/UserProfileSetupModal';

export function LoginPage() {
  const navigate = useNavigate();
  const [supportChatOpen, setSupportChatOpen] = useState(false);
  const [userProfileSetupModalOpen, setUserProfileSetupModalOpen] = useState(false);
  const [setupUserId, setSetupUserId] = useState('');
  const [setupUserEmail, setSetupUserEmail] = useState('');

  const handleLoginSuccess = () => {
    navigate('/');
  };

  const handleUserNeedsProfileSetup = (userId: string, email: string) => {
    setSetupUserId(userId);
    setSetupUserEmail(email);
    setUserProfileSetupModalOpen(true);
  };

  const handleUserProfileSetupComplete = () => {
    setUserProfileSetupModalOpen(false);
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <h1 className="text-center text-3xl font-extrabold text-gray-900 mb-8">
          BeatBookingsLive
        </h1>
        <LoginForm
          onSuccess={handleLoginSuccess}
          onUserNeedsProfileSetup={handleUserNeedsProfileSetup}
        />
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-600">
            Don't have an account?{' '}
            <Link to="/signup" className="font-medium text-indigo-600 hover:text-indigo-500">
              Sign up here
            </Link>
          </p>
        </div>
      </div>

      <div className="mt-8 text-center">
        <Link
          to="/terms"
          className="text-sm text-gray-600 hover:text-gray-900 underline"
        >
          Terms & Conditions
        </Link>
      </div>

      <FloatingSupportButton onClick={() => setSupportChatOpen(true)} />

      <SupportChatModal
        isOpen={supportChatOpen}
        onClose={() => setSupportChatOpen(false)}
      />

      <UserProfileSetupModal
        isOpen={userProfileSetupModalOpen}
        userId={setupUserId}
        userEmail={setupUserEmail}
        onClose={() => setUserProfileSetupModalOpen(false)}
        onComplete={handleUserProfileSetupComplete}
      />
    </div>
  );
}