import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export default function PrivacyPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-3xl mx-auto px-6 py-12">
        <Link
          to="/"
          className="inline-flex items-center text-blue-600 hover:text-blue-700 mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Link>

        <div className="bg-white rounded-lg shadow-sm p-8 lg:p-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Privacy Policy
          </h1>
          <p className="text-gray-600 mb-8">
            Last Updated: 26 Nov 25
          </p>

          <div className="prose prose-gray max-w-none space-y-8">
            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                1. Introduction
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                BeatBookingsLive ("we", "us", "our") respects your privacy and is committed to protecting your personal information.
                This Privacy Policy explains how we collect, use, store, and protect your data when you use our website or create an account.
              </p>
              <p className="text-gray-700 leading-relaxed">
                By using BeatBookingsLive, you consent to the practices described in this Privacy Policy.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                2. Information We Collect
              </h2>

              <h3 className="text-xl font-semibold text-gray-900 mb-3 mt-6">
                a. Account Information
              </h3>
              <p className="text-gray-700 leading-relaxed mb-3">
                When you create an account, we collect:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-700 ml-4 mb-6">
                <li>Full name</li>
                <li>Email address</li>
                <li>Password (encrypted)</li>
                <li>Phone number (optional)</li>
                <li>City/State/Region</li>
              </ul>

              <h3 className="text-xl font-semibold text-gray-900 mb-3 mt-6">
                b. Artist Information
              </h3>
              <p className="text-gray-700 leading-relaxed mb-3">
                If you are an Artist, we may also collect:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-700 ml-4 mb-6">
                <li>Profile photos</li>
                <li>Music links</li>
                <li>Videos</li>
                <li>Pricing</li>
                <li>Availability</li>
                <li>Travel radius</li>
                <li>Equipment requirements</li>
              </ul>

              <h3 className="text-xl font-semibold text-gray-900 mb-3 mt-6">
                c. Usage Data
              </h3>
              <p className="text-gray-700 leading-relaxed mb-3">
                We may collect usage information such as:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-700 ml-4">
                <li>IP address</li>
                <li>Device type</li>
                <li>Browser</li>
                <li>Pages visited</li>
                <li>Actions taken on the platform</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                3. How We Use Your Information
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                We may use your information to:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-700 ml-4 mb-4">
                <li>Create and manage your account</li>
                <li>Connect Artists and Clients for directory purposes</li>
                <li>Communicate with you about events, updates, or account issues</li>
                <li>Improve our Platform and fix technical problems</li>
                <li>Verify identity and reduce fraud</li>
                <li>Send promotional or service-related messages</li>
              </ul>
              <p className="text-gray-700 leading-relaxed font-semibold">
                We do NOT sell your personal information.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                4. Sharing Your Information
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                We may share your information with:
              </p>

              <h3 className="text-xl font-semibold text-gray-900 mb-3 mt-6">
                a. Artists & Clients
              </h3>
              <p className="text-gray-700 leading-relaxed mb-4">
                Only when you contact an artist or engage with their profile.
              </p>

              <h3 className="text-xl font-semibold text-gray-900 mb-3 mt-6">
                b. Service Providers
              </h3>
              <p className="text-gray-700 leading-relaxed mb-4">
                Such as email services, analytics tools, or hosting providers.
              </p>

              <h3 className="text-xl font-semibold text-gray-900 mb-3 mt-6">
                c. Legal Requirements
              </h3>
              <p className="text-gray-700 leading-relaxed">
                If required by law, we may disclose information to authorities.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                5. Cookies
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                We use cookies for:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-700 ml-4 mb-4">
                <li>Login sessions</li>
                <li>Security</li>
                <li>Traffic analytics</li>
                <li>Website functionality</li>
              </ul>
              <p className="text-gray-700 leading-relaxed">
                You may disable cookies through your browser settings, but some functions may stop working.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                6. Data Retention
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                We retain information for as long as your account is active, or as needed to provide services, or comply with legal obligations.
              </p>
              <p className="text-gray-700 leading-relaxed">
                You may request deletion of your account at any time.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                7. Security
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                We take reasonable measures to protect your data, including:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-700 ml-4 mb-4">
                <li>Encrypted passwords</li>
                <li>HTTPS security</li>
                <li>Secure database storage</li>
              </ul>
              <p className="text-gray-700 leading-relaxed">
                However, no method of digital transmission is 100% secure.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                8. Your Rights
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Depending on your region, you may have the right to:
              </p>
              <ul className="list-disc list-inside space-y-2 text-gray-700 ml-4 mb-4">
                <li>Access your personal information</li>
                <li>Edit or update your details</li>
                <li>Request deletion of your data</li>
                <li>Request a copy of your data</li>
                <li>Opt-out of marketing communications</li>
              </ul>
              <p className="text-gray-700 leading-relaxed">
                To make these requests, contact: <span className="font-semibold">support@beatbookingslive.com</span>
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                9. Children
              </h2>
              <p className="text-gray-700 leading-relaxed">
                BeatBookingsLive is not intended for anyone under 16.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                10. Changes to This Policy
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                We may update this Privacy Policy at any time. Changes will be published on this page with a new "Last Updated" date.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                11. Contact Us
              </h2>
              <p className="text-gray-700 leading-relaxed">
                For privacy questions or concerns: <span className="font-semibold">info@beatbookingslive.com</span>
              </p>
            </section>
          </div>

          <div className="mt-8 text-center">
            <Link
              to="/"
              className="inline-flex items-center justify-center px-8 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors shadow-md hover:shadow-lg"
            >
              Back to Home
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
