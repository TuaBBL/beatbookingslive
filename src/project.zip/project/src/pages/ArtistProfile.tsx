import { LogOut, CreditCard as Edit, Eye, Plus, Calendar, Clock, MapPin, User, Mail, Phone, MessageCircle, Check, X, Trash2, Shield } from 'lucide-react';
import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { EditProfileModal } from '../components/EditProfileModal';
import { ArtistProfileModal } from '../components/ArtistProfileModal';
import { ArtistDetailView } from '../components/ArtistDetailView';
import { SubscriptionModal } from '../components/SubscriptionModal';
import { SubscriptionStatus } from '../components/SubscriptionStatus';
import { BookingMessagesModal } from '../components/BookingMessagesModal';
import { NotificationBell } from '../components/NotificationBell';
import { SupportChatModal } from '../components/SupportChatModal';
import { FloatingSupportButton } from '../components/FloatingSupportButton';
import { PremiumAnalyticsDashboard } from '../components/PremiumAnalyticsDashboard';
import { AdminMessagesInbox } from '../components/AdminMessagesInbox';
import { MessageAdminButton } from '../components/MessageAdminButton';
import { Link, useNavigate } from 'react-router-dom';
import { isAdmin } from '../lib/adminUtils';

interface ArtistProfileProps {
  user: any;
  onSignOut: () => void;
  onArtistDeleteSuccess: () => void;
}

export function ArtistProfile({ user, onSignOut, onArtistDeleteSuccess }: ArtistProfileProps) {
  const navigate = useNavigate();
  const [artistProfile, setArtistProfile] = useState<any>(null);
  const [artistCard, setArtistCard] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [createProfileModalOpen, setCreateProfileModalOpen] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [subscriptionModalOpen, setSubscriptionModalOpen] = useState(false);
  const [reviews, setReviews] = useState<any[]>([]);
  const [bookings, setBookings] = useState<any[]>([]);
  const [selectedBooking, setSelectedBooking] = useState<any>(null);
  const [messageModalOpen, setMessageModalOpen] = useState(false);
  const [supportChatOpen, setSupportChatOpen] = useState(false);
  const [adminMessagesOpen, setAdminMessagesOpen] = useState(false);

  useEffect(() => {
    fetchArtistProfile();
  }, [user]);

  async function fetchArtistProfile() {
    try {
      const { data: profile, error: profileError } = await supabase
        .from('artist_profiles')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (profileError) throw profileError;
      setArtistProfile(profile);

      if (profile?.artist_card_id) {
        const { data: card, error: cardError } = await supabase
          .from('artist_cards')
          .select('*')
          .eq('id', profile.artist_card_id)
          .maybeSingle();

        if (cardError) throw cardError;
        setArtistCard(card);

        // Check if required fields are incomplete
        const hasIncompleteFields = !card ||
          !card.name ||
          !card.category ||
          !card.genre ||
          !card.state_territories || card.state_territories.length === 0 ||
          !card.locations || card.locations.length === 0;

        // Auto-open edit modal if profile exists but has incomplete fields
        if (hasIncompleteFields && card) {
          setEditModalOpen(true);
        }

        const { data: reviewsData } = await supabase
          .from('reviews')
          .select('*')
          .eq('artist_id', card.id)
          .order('created_at', { ascending: false });

        setReviews(reviewsData || []);

        const { data: bookingsData } = await supabase
          .from('bookings')
          .select('*')
          .eq('artist_id', card.id)
          .order('created_at', { ascending: false });

        setBookings(bookingsData || []);
      } else {
        // No profile at all - auto-open create modal
        setCreateProfileModalOpen(true);
      }
    } catch (error) {
      console.error('Error fetching artist profile:', error);
    } finally {
      setLoading(false);
    }
  }

  const handleEditSuccess = async () => {
    await fetchArtistProfile();
    // Check if profile is now complete after the update
    const card = artistCard;
    if (card && card.name && card.category && card.genre &&
        card.state_territories && card.state_territories.length > 0 &&
        card.locations && card.locations.length > 0) {
      setEditModalOpen(false);
    }
  };

  const handleProfileComplete = async () => {
    await fetchArtistProfile();
    // Profile creation complete, close modal
    setCreateProfileModalOpen(false);
  };

  const handleModalClose = () => {
    // Check if profile has required fields before allowing close
    if (artistCard) {
      const hasRequiredFields = artistCard.name &&
        artistCard.category &&
        artistCard.genre &&
        artistCard.state_territories && artistCard.state_territories.length > 0 &&
        artistCard.locations && artistCard.locations.length > 0;

      if (hasRequiredFields) {
        setEditModalOpen(false);
        setCreateProfileModalOpen(false);
      } else {
        alert('Please complete all required fields (Name, Category, Genre, State/Territory, Location) before continuing.');
      }
    } else {
      alert('Please create your artist profile to access the dashboard.');
    }
  };

  const handleSubscribe = () => {
    setCreateProfileModalOpen(false);
    setSubscriptionModalOpen(true);
  };


  const handleBookingStatusUpdate = async (bookingId: string, status: 'confirmed' | 'cancelled') => {
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ status })
        .eq('id', bookingId);

      if (error) throw error;

      setBookings(bookings.map(b =>
        b.id === bookingId ? { ...b, status } : b
      ));
    } catch (error) {
      console.error('Error updating booking status:', error);
    }
  };

  const deleteBooking = async (bookingId: string) => {
    if (!confirm('Are you sure you want to delete this booking request?')) return;

    try {
      const { error } = await supabase
        .from('bookings')
        .delete()
        .eq('id', bookingId);

      if (error) throw error;

      setBookings(bookings.filter(b => b.id !== bookingId));
    } catch (error) {
      console.error('Error deleting booking:', error);
    }
  };

  const handleOpenMessages = (booking: any) => {
    setSelectedBooking(booking);
    setMessageModalOpen(true);
  };

  if (loading) {
    return (
    <div className="min-h-screen w-full overflow-y-auto overflow-x-hidden bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white flex items-center justify-center">
        <p className="text-fluro-green-subtle text-lg">Loading your profile...</p>
      </div>
    );
  }

  console.log('ArtistProfile - artistCard:', artistCard);
  console.log('ArtistProfile - artistProfile:', artistProfile);

  return (
  <div className="min-h-screen w-full overflow-y-auto overflow-x-hidden bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white relative" style={{ WebkitOverflowScrolling: 'touch' }}>
    {/* Background Lights */}
    <div className="fixed inset-0 opacity-50 pointer-events-none">
      <div
        className="absolute left-10 top-24 w-32 h-40 bg-gradient-to-b from-red-500 via-red-600 to-transparent rounded-full"
        style={{ filter: 'blur(2px)', animation: 'wave 2.5s ease-in-out infinite 0.2s' }}
      />
      <div
        className="absolute left-20 top-32 w-44 h-40 bg-gradient-to-b from-red-600 via-red-700 to-transparent rounded-full"
        style={{ filter: 'blur(2px)', animation: 'wave-intense 2.8s ease-in-out infinite 0.2s' }}
      />
      <div
        className="absolute right-10 top-40 w-48 h-32 bg-gradient-to-b from-red-500 via-red-600 to-transparent rounded-full"
        style={{ filter: 'blur(2px)', animation: 'wave-smooth 2.6s ease-in-out infinite 0.4s' }}
      />
    </div>

    {/* FIXED HEADER */}
    <header className="fixed top-0 left-0 right-0 z-50 bg-black border-b-2 border-red-500 shadow-lg overflow-visible">
      <div className="container mx-auto px-3 py-3 sm:py-6 flex flex-row justify-between items-center gap-3 overflow-visible">

        {/* LOGO & TITLE */}
        <button
          onClick={async () => {
            await onSignOut();
            window.location.href = '/';
          }}
          className="flex items-center gap-2 flex-shrink-0 hover:opacity-80 transition-opacity cursor-pointer"
        >
          <svg width="35" height="28" viewBox="0 0 35 28" xmlns="http://www.w3.org/2000/svg" className="sm:w-[50px] sm:h-[40px]">
            <rect x="2" y="12" width="3" height="16" rx="1.5" fill="#39FF14" style={{ filter: 'drop-shadow(0 0 6px #ff0000)' }} />
            <rect x="9" y="8" width="3" height="20" rx="1.5" fill="#39FF14" style={{ filter: 'drop-shadow(0 0 6px #ff0000)' }} />
            <rect x="17" y="4" width="3" height="24" rx="1.5" fill="#39FF14" style={{ filter: 'drop-shadow(0 0 6px #ff0000)' }} />
            <rect x="24" y="12" width="3" height="16" rx="1.5" fill="#39FF14" style={{ filter: 'drop-shadow(0 0 6px #ff0000)' }} />
          </svg>
          <div className="flex flex-col leading-none">
            <span className="text-base sm:text-2xl font-bold text-[#39ff14]" style={{ textShadow: '0 0 8px #ff0000' }}>Beat</span>
            <span className="text-base sm:text-2xl font-bold text-[#39ff14]" style={{ textShadow: '0 0 8px #ff0000' }}>Bookings</span>
            <span className="text-xs sm:text-base font-bold text-red-500" style={{ textShadow: '0 0 8px #ff0000' }}>LIVE</span>
          </div>
        </button>

        <div className="text-base sm:text-xl lg:text-2xl font-bold text-fluro-green">
          Artist Dashboard
        </div>

        {/* USER INFO + NOTIFICATIONS + SIGN OUT */}
        <div className="flex items-center gap-2 sm:gap-4 flex-shrink-0">
          <div className="text-fluro-green-subtle text-xs sm:text-sm hidden lg:block">
            {user?.email}
          </div>

          <NotificationBell />

          <button
            onClick={() => setAdminMessagesOpen(true)}
            className="flex items-center gap-1 sm:gap-2 px-3 py-1.5 sm:px-4 sm:py-2 bg-transparent border-2 border-blue-500 text-blue-500 rounded-lg text-xs sm:text-base font-semibold hover:bg-blue-500 hover:text-white transition-all duration-300"
            title="Admin Messages"
          >
            <Mail className="w-3 h-3 sm:w-4 sm:h-4" />
            <span className="hidden sm:inline">ADMIN</span>
          </button>

          {isAdmin(user) && (
            <button
              onClick={() => navigate('/admin/profiles')}
              className="flex items-center gap-1 sm:gap-2 px-3 py-1.5 sm:px-4 sm:py-2 bg-transparent border-2 border-[#39ff14] text-[#39ff14] rounded-lg text-xs sm:text-base font-semibold hover:bg-[#39ff14] hover:text-black transition-all duration-300"
              title="Admin Dashboard"
            >
              <Shield className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden sm:inline">Admin</span>
            </button>
          )}

          <button
            onClick={onSignOut}
            className="flex items-center gap-1 sm:gap-2 px-3 py-1.5 sm:px-4 sm:py-2 bg-transparent border-2 border-red-500 text-red-500 rounded-lg text-xs sm:text-base font-semibold hover:bg-red-500 hover:text-white transition-all duration-300"
          >
            <LogOut className="w-3 h-3 sm:w-4 sm:h-4" />
            <span className="hidden sm:inline">Sign Out</span>
          </button>
        </div>

      </div>
    </header>

    {/* SPACE BELOW FIXED HEADER */}
    <div className="h-24 sm:h-32"></div>

{/* MAIN CONTENT WRAPPER */}
<main className="relative z-10 container mx-auto px-4 py-8 sm:py-12">

  <section className="mb-8 flex flex-col md:flex-row md:items-center md:justify-between gap-4">

    <div>
      {/* Welcome Text */}
      <h2 className="text-4xl font-bold text-fluro-green mb-2">
        Welcome back, {artistCard?.stage_name || artistCard?.name || 'Artist'}
      </h2>

      <p className="text-fluro-green-subtle text-lg">
        {artistCard ? (
          <>Manage your profile and bookings</>
        ) : (
          <>Get started by creating your artist profile</>
        )}
      </p>
    </div>

    {/* EDIT / PREVIEW BUTTONS */}
    {artistCard && (
      <div className="flex gap-3 flex-wrap">

        <button
          onClick={() => setEditModalOpen(true)}
          className="flex items-center gap-2 px-6 py-3 bg-[#39ff14] text-black rounded-lg font-bold hover:opacity-80 transition"
        >
          <Edit className="w-5 h-5" />
          Edit Profile
        </button>

        <button
          onClick={() => setPreviewOpen(true)}
          className="flex items-center gap-2 px-6 py-3 bg-transparent border-2 border-[#39ff14] text-[#39ff14] rounded-lg font-bold hover:bg-[#39ff14] hover:text-black transition"
        >
          <Eye className="w-5 h-5" />
          Preview
        </button>

      </div>
    )}
  </section>
</main>
        {artistCard && (
  <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-10 px-4">

    {/* LEFT: ARTIST IMAGE */}
    <div className="lg:col-span-1 bg-gray-900 rounded-lg border-2 border-red-500 glow-red p-4">
      <img
        src={artistCard.image_url}
        alt={artistCard.name}
        className="w-full h-auto max-h-72 object-cover rounded-md"
      />
    </div>

    {/* MIDDLE: ARTIST DETAILS */}
    <div className="flex flex-col gap-3 bg-gray-900 rounded-lg border-2 border-red-500 glow-red p-6">

      <h3 className="text-2xl font-bold text-fluro-green mb-2">
        {artistCard.stage_name || artistCard.name}
      </h3>

      <p className="text-fluro-green-subtle text-sm">
        {artistCard.category}
      </p>

      <p className="text-fluro-green-subtle text-sm">
        {artistCard.location}
      </p>

      {/* Subscription */}
      <div className="mt-4">
        <SubscriptionStatus
          userId={user.id}
          artistCard={artistCard}
          onUpgrade={() => setSubscriptionModalOpen(true)}
        />
      </div>
    </div>

    {/* RIGHT: PROFILE STATUS */}
    <div className="lg:col-span-1 bg-gray-900 rounded-lg border-2 border-red-500 glow-red p-6">
      <h3 className="text-xl font-bold text-fluro-green mb-4">Profile Status</h3>

      <div className="space-y-4">

        {/* Completed */}
        <div className="flex items-center justify-between">
          <span className="text-fluro-green-subtle">Profile Completed</span>
          <span className="px-3 py-1 rounded-full text-sm font-semibold 
            bg-[#39ff14] text-black border border-[#39ff14]">
            {artistCard.profile_completed ? 'Yes' : 'No'}
          </span>
        </div>

        {/* Availability */}
        <div className="flex items-center justify-between">
          <span className="text-fluro-green-subtle">Availability</span>
          <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
            artistCard.availability === 'available'
              ? 'bg-[#39ff14] text-black border border-[#39ff14]'
              : 'bg-red-500 text-white border border-red-500'
          }`}>
            {artistCard.availability === 'available' ? 'Available' : 'Booked'}
          </span>
        </div>

        {/* Rating */}
        <div className="flex items-center justify-between">
          <span className="text-fluro-green-subtle">Rating</span>
          <span className="text-fluro-green font-semibold">
            {typeof artistCard.rating === 'number'
              ? artistCard.rating.toFixed(1)
              : 'N/A'}
          </span>
        </div>

      </div>
    </div>

    {/* ABOUT SECTION */}
    <div className="lg:col-span-3 bg-gray-900 rounded-lg border-2 border-red-500 glow-red p-6 mt-4">
      <h3 className="text-xl font-bold text-fluro-green mb-4">About</h3>
      <p className="text-fluro-green-subtle leading-relaxed">
        {artistCard.about}
      </p>
    </div>

    {/* ANALYTICS SECTION */}
    <div className="lg:col-span-3 mt-4">
      <PremiumAnalyticsDashboard
        artistId={artistCard.id}
        isPremium={artistCard.is_premium || false}
      />
    </div>

  </section>
)}
      {artistCard && bookings.length > 0 && (
  <div className="mt-10 px-4">
    <h2 className="text-2xl sm:text-3xl font-bold text-fluro-green mb-6">
      Booking Requests
    </h2>

    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {bookings.map((booking) => (
        <div
          key={booking.id}
          className="bg-gray-900 rounded-lg border-2 border-red-500 glow-red p-6 flex flex-col gap-4"
        >

          {/* DATE + STATUS */}
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-[#39ff14]" />
              <span className="text-fluro-green font-semibold">
                {new Date(booking.requested_date).toLocaleDateString('en-US', {
                  weekday: 'short',
                  month: 'short',
                  day: 'numeric',
                  year: 'numeric',
                })}
              </span>
            </div>

            <span
              className={`px-3 py-1 rounded-full text-xs font-semibold ${
                booking.status === 'pending'
                  ? 'bg-yellow-500 text-black border border-yellow-500'
                  : booking.status === 'confirmed'
                  ? 'bg-[#39ff14] text-black border border-[#39ff14]'
                  : 'bg-red-500 text-white border border-red-500'
              }`}
            >
              {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
            </span>
          </div>

          {/* TIME */}
          <div className="flex items-center gap-2 text-fluro-green-subtle">
            <Clock className="w-4 h-4" />
            <span className="text-sm">
              {booking.time_from} – {booking.time_to}
            </span>
          </div>

          {/* LOCATION */}
          <div className="flex items-center gap-2 text-fluro-green-subtle">
            <MapPin className="w-4 h-4" />
            <span className="text-sm line-clamp-1">{booking.location}</span>
          </div>

          {/* MESSAGE */}
          {booking.message && (
            <p className="text-fluro-green-subtle text-sm leading-relaxed">
              {booking.message}
            </p>
          )}

          {/* CLIENT INFO */}
          <div className="border-t border-gray-700 pt-4 mt-3">
            <p className="text-fluro-green font-semibold mb-3">Client Information:</p>

            <div className="flex items-start gap-3">
              {/* User Profile Image */}
              <div className="flex-shrink-0">
                {booking.user_profile_image_url ? (
                  <img
                    src={booking.user_profile_image_url}
                    alt={booking.user_name}
                    className="w-16 h-16 rounded-full object-cover border-2 border-fluro-green"
                  />
                ) : (
                  <div className="w-16 h-16 rounded-full bg-gray-700 border-2 border-fluro-green flex items-center justify-center">
                    <User className="w-8 h-8 text-fluro-green-subtle" />
                  </div>
                )}
              </div>

              {/* User Details */}
              <div className="flex-1 space-y-2">
                <div className="flex items-center gap-2 text-fluro-green-subtle text-sm">
                  <User className="w-4 h-4" />
                  <span>{booking.user_name}</span>
                </div>

                <div className="flex items-center gap-2 text-fluro-green-subtle text-sm">
                  <Mail className="w-4 h-4" />
                  <a
                    href={`mailto:${booking.user_email}`}
                    className="hover:text-[#39ff14] transition-colors"
                  >
                    {booking.user_email}
                  </a>
                </div>

                {booking.user_phone && (
                  <div className="flex items-center gap-2 text-fluro-green-subtle text-sm">
                    <Phone className="w-4 h-4" />
                    <a
                      href={`tel:${booking.user_phone}`}
                      className="hover:text-[#39ff14] transition-colors"
                    >
                      {booking.user_phone}
                    </a>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* COMMENTS */}
          {booking.comments && (
            <div className="border-t border-gray-700 pt-3 mt-3">
              <p className="text-fluro-green-subtle text-sm font-semibold mb-1">
                Comments:
              </p>
              <p className="text-fluro-green-subtle text-sm">{booking.comments}</p>
            </div>
          )}

          {/* CREATED AT */}
          <div className="text-fluro-green-subtle text-xs mt-3">
            Requested:{' '}
            {new Date(booking.created_at).toLocaleDateString('en-US', {
              month: 'short',
              day: 'numeric',
              year: 'numeric',
              hour: '2-digit',
              minute: '2-digit',
            })}
          </div>

          {/* BUTTONS */}
          <div className="booking-buttons mt-4 pt-4 border-t border-gray-700">
            <button
              onClick={() => handleOpenMessages(booking)}
              className="flex items-center justify-center gap-2 px-3 sm:px-4 py-2 bg-transparent border border-fluro-green text-fluro-green rounded-md hover:text-black hover:bg-fluro-green transition-all duration-300"
            >
              <MessageCircle className="w-4 h-4" />
              <span className="hidden sm:inline">Message</span>
            </button>

            {booking.status === 'pending' && (
              <>
                <button
                  onClick={() => handleBookingStatusUpdate(booking.id, 'confirmed')}
                  className="flex items-center justify-center gap-2 px-3 sm:px-4 py-2 bg-green-500 text-black rounded-md hover:bg-green-600"
                >
                  <Check className="w-4 h-4" />
                  <span className="hidden sm:inline">Accept</span>
                </button>

                <button
                  onClick={() => handleBookingStatusUpdate(booking.id, 'cancelled')}
                  className="flex items-center justify-center gap-2 px-3 sm:px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600"
                >
                  <X className="w-4 h-4" />
                  <span className="hidden sm:inline">Decline</span>
                </button>
              </>
            )}

            {(booking.status === 'confirmed' || booking.status === 'cancelled') && (
              <button
                onClick={() => deleteBooking(booking.id)}
                className="flex items-center justify-center gap-2 px-3 sm:px-4 py-2 bg-red-500 text-white rounded-md hover:bg-red-600 transition-all duration-300"
              >
                <Trash2 className="w-4 h-4" />
                <span className="hidden sm:inline">Delete</span>
              </button>
            )}
          </div>
        </div>
      ))}
    </div>
  </div>
)}

{!artistCard && (
  <div className="bg-gray-900 rounded-lg border-2 border-red-500 glow-red p-12 text-center mt-10 mx-4">
    <div className="max-w-2xl mx-auto">
      <div className="mb-6">
        <div className="inline-flex items-center justify-center w-20 h-20 bg-[#39ff14] bg-opacity-10 rounded-full mx-auto">
          <Plus className="w-10 h-10 text-[#39ff14]" />
        </div>
      </div>

      <h3 className="text-3xl font-bold text-fluro-green mb-4">
        Create Your Artist Profile
      </h3>

      <p className="text-fluro-green-subtle text-lg mb-8">
        Get started by creating your artist profile and showcase your talent to potential clients.
      </p>

      <button
        onClick={() => setCreateProfileModalOpen(true)}
        className="inline-flex items-center gap-3 px-8 py-4 bg-[#39ff14] text-black rounded-lg hover:text-black transition-all duration-300"
      >
        <Plus className="w-6 h-6" />
        Create Profile Now
      </button>
    </div>
  </div>
)}

<footer className="relative z-10 container mx-auto px-4 py-8 text-center border-t mt-10">
  <div className="flex flex-col items-center gap-3">
    <Link to="/terms" className="text-fluro-green-subtle text-sm hover:text-[#39ff14]">
      Terms & Conditions
    </Link>

    <p className="text-fluro-green-subtle text-sm">
      © 2025 Beat Bookings Live. All rights reserved.
    </p>
  </div>
</footer>

<EditProfileModal
  isOpen={editModalOpen}
  artistCard={artistCard}
  artistProfile={artistProfile}
  userId={user.id}
  onClose={handleModalClose}
  onSuccess={handleEditSuccess}
/>

<ArtistProfileModal
  isOpen={createProfileModalOpen}
  userId={user.id}
  userEmail={user.email}
  onClose={handleModalClose}
  onComplete={handleProfileComplete}
  onSubscribe={handleSubscribe}
/>

<SubscriptionModal
  isOpen={subscriptionModalOpen}
  onClose={() => setSubscriptionModalOpen(false)}
/>

{previewOpen && (
  <ArtistDetailView
    artist={artistCard}
    onClose={() => setPreviewOpen(false)}
    reviews={reviews}
  />
)}

<BookingMessagesModal
  isOpen={messageModalOpen}
  booking={selectedBooking}
  onClose={() => setMessageModalOpen(false)}
  currentUserId={user.id}
  isArtist={true}
  artistName={artistProfile?.stage_name || artistCard?.stage_name}
/>

<SupportChatModal
  isOpen={supportChatOpen}
  onClose={() => setSupportChatOpen(false)}
/>

<AdminMessagesInbox
  isOpen={adminMessagesOpen}
  onClose={() => setAdminMessagesOpen(false)}
  userId={user.id}
  userEmail={user.email}
/>

<FloatingSupportButton onClick={() => setSupportChatOpen(true)} />

      <MessageAdminButton
        userId={user.id}
        userEmail={user.email}
        variant="floating"
      />
  </div>
);
}

export default ArtistProfile;
