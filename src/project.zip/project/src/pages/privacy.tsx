import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export default function PrivacyPolicyPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
      <div className="max-w-3xl mx-auto px-6 py-12 text-white">
        <Link
          to="/"
          className="inline-flex items-center text-[#39ff14] hover:text-[#2ee000] mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Link>

        <div className="space-y-8">
          <div>
            <h1 className="text-4xl font-bold text-[#39ff14] mb-2">
              PRIVACY POLICY — BeatBookingsLive
            </h1>
            <p className="text-gray-400 text-sm">
              Last Updated: 26 Nov 25
            </p>
          </div>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              1. Introduction
            </h2>
            <p className="text-gray-300 leading-relaxed mb-3">
              BeatBookingsLive is a directory and messaging platform.
            </p>
            <p className="text-gray-300 leading-relaxed font-semibold">
              We do NOT collect payment details or booking data.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              2. Information We Collect
            </h2>

            <h3 className="text-xl font-semibold text-white mb-2 mt-4">
              Account Info
            </h3>
            <ul className="list-disc list-inside space-y-1 text-gray-300 mb-4 ml-4">
              <li>Name</li>
              <li>Email</li>
              <li>Password (encrypted)</li>
            </ul>

            <h3 className="text-xl font-semibold text-white mb-2 mt-4">
              Artist Profile Data
            </h3>
            <ul className="list-disc list-inside space-y-1 text-gray-300 mb-4 ml-4">
              <li>Photos</li>
              <li>Videos</li>
              <li>Mixes</li>
              <li>Bio</li>
              <li>Social links</li>
              <li>Location (general)</li>
            </ul>

            <h3 className="text-xl font-semibold text-white mb-2 mt-4">
              Messaging Data
            </h3>
            <p className="text-gray-300 leading-relaxed mb-2">
              We store:
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-300 mb-3 ml-4">
              <li>Messages sent & received</li>
              <li>Timestamps</li>
            </ul>
            <p className="text-gray-300 leading-relaxed mb-4">
              We do not read or monitor messages unless needed for investigation after a report.
            </p>

            <h3 className="text-xl font-semibold text-white mb-2 mt-4">
              Usage Data
            </h3>
            <ul className="list-disc list-inside space-y-1 text-gray-300 ml-4">
              <li>IP</li>
              <li>Device</li>
              <li>Browser</li>
              <li>Pages visited</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              3. What We Do NOT Collect
            </h2>
            <p className="text-gray-300 leading-relaxed mb-3">
              BeatBookingsLive does NOT collect:
            </p>
            <ul className="list-none space-y-1 text-gray-300 mb-3 ml-4">
              <li>❌ Payment info</li>
              <li>❌ Bank details</li>
              <li>❌ Contracts</li>
              <li>❌ Pricing info</li>
              <li>❌ Booking details</li>
              <li>❌ Sensitive IDs</li>
            </ul>
            <p className="text-gray-300 leading-relaxed">
              Because all bookings are handled off-platform.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              4. How We Use Your Data
            </h2>
            <ul className="list-disc list-inside space-y-1 text-gray-300 mb-3 ml-4">
              <li>Display Artist profiles</li>
              <li>Enable messaging between Users</li>
              <li>Improve platform functionality</li>
              <li>Maintain security</li>
              <li>Investigate reported abuse</li>
            </ul>
            <p className="text-gray-300 leading-relaxed font-semibold">
              We do NOT sell or trade personal data.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              5. Sharing Information
            </h2>
            <p className="text-gray-300 leading-relaxed mb-3">
              We only share data with:
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-300 mb-3 ml-4">
              <li>Hosting/tech providers</li>
              <li>Email services</li>
              <li>Analytics tools</li>
            </ul>
            <p className="text-gray-300 leading-relaxed font-semibold">
              We do NOT share data with advertisers or third parties for marketing.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              6. User Rights
            </h2>
            <p className="text-gray-300 leading-relaxed mb-3">
              You may:
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-300 mb-3 ml-4">
              <li>Edit your profile</li>
              <li>Delete content</li>
              <li>Request account removal</li>
              <li>Request data removal</li>
            </ul>
            <p className="text-gray-300 leading-relaxed">
              Email: <span className="font-semibold text-[#39ff14]">support@beatbookingslive.com</span>
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              7. Security
            </h2>
            <p className="text-gray-300 leading-relaxed mb-3">
              We use:
            </p>
            <ul className="list-disc list-inside space-y-1 text-gray-300 mb-3 ml-4">
              <li>Encrypted passwords</li>
              <li>Secure hosting</li>
              <li>Limited admin access</li>
            </ul>
            <p className="text-gray-300 leading-relaxed">
              But no platform is 100% secure.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              8. External Links
            </h2>
            <p className="text-gray-300 leading-relaxed mb-3">
              Artist profiles may include outside links (Spotify, YouTube, etc.).
            </p>
            <p className="text-gray-300 leading-relaxed">
              We are not responsible for external site privacy practices.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              9. Underage Users
            </h2>
            <p className="text-gray-300 leading-relaxed">
              Platform is for 16+ only.
            </p>
          </section>

          <section>
            <h2 className="text-2xl font-semibold text-[#39ff14] mb-3">
              10. Updates
            </h2>
            <p className="text-gray-300 leading-relaxed">
              Policy may be updated periodically.
            </p>
          </section>

          <div className="mt-8 text-center">
            <Link
              to="/"
              className="inline-flex items-center justify-center px-8 py-3 bg-[#39ff14] text-black font-semibold rounded-lg hover:bg-[#2ee000] transition-colors shadow-lg"
            >
              Back to Home
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
