import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { Loader2 } from 'lucide-react';

export function AuthCallbackPage() {
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const handleAuthCallback = async () => {
      try {
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();

        if (sessionError) throw sessionError;

        if (session) {
          // Redirect to homepage immediately
          // The useAuth hook will show profile setup modal if needed
          navigate('/');
        } else {
          setError('Authentication failed. Please try again.');
          setTimeout(() => {
            navigate('/login');
          }, 3000);
        }
      } catch (err: any) {
        console.error('Auth callback error:', err);
        setError(err.message || 'An error occurred during authentication');
        setTimeout(() => {
          navigate('/login');
        }, 3000);
      }
    };

    handleAuthCallback();
  }, [navigate]);

  return (
    <div className="min-h-screen bg-black flex items-center justify-center p-4">
      <div className="bg-gray-900 rounded-2xl border-2 border-[#39ff14] p-8 max-w-md w-full text-center">
        {error ? (
          <>
            <div className="mb-4">
              <X className="w-16 h-16 text-red-500 mx-auto" />
            </div>
            <h2 className="text-2xl font-bold text-red-500 mb-4">Authentication Failed</h2>
            <p className="text-fluro-green-subtle mb-4">{error}</p>
            <p className="text-fluro-green-subtle text-sm">Redirecting to login page...</p>
          </>
        ) : (
          <>
            <div className="mb-4">
              <Loader2 className="w-16 h-16 text-[#39ff14] mx-auto animate-spin" />
            </div>
            <h2 className="text-2xl font-bold text-[#39ff14] mb-4">Signing In...</h2>
            <p className="text-fluro-green-subtle">Redirecting to homepage...</p>
          </>
        )}
      </div>
    </div>
  );
}

function X({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      fill="none"
      stroke="currentColor"
      viewBox="0 0 24 24"
    >
      <path
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeWidth={2}
        d="M6 18L18 6M6 6l12 12"
      />
    </svg>
  );
}
