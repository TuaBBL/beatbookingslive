import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { ArtistProfileModal } from '../components/ArtistProfileModal';
import { SubscriptionModal } from '../components/SubscriptionModal';
import { Loader2 } from 'lucide-react';
import { useAuth } from '../hooks/useAuth';

export function CreateArtistPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [hasSubscription, setHasSubscription] = useState(false);
  const [showSubscriptionModal, setShowSubscriptionModal] = useState(false);
  const [existingArtistCard, setExistingArtistCard] = useState<any>(null);

  useEffect(() => {
    if (!user) {
      navigate('/login');
      return;
    }

    checkSubscriptionAndProfile();
  }, [user, navigate]);

  const checkSubscriptionAndProfile = async (retryCount = 0) => {
    if (!user) return;

    try {
      console.log(`[CreateArtistPage] Checking subscription (attempt ${retryCount + 1}/3)...`);
      setLoading(true);

      // Check subscription status in profiles table
      const { data: profileData, error: subError } = await supabase
        .from('profiles')
        .select('is_free_forever, subscription_tier, subscription_active')
        .eq('id', user.id)
        .maybeSingle();

      console.log('[CreateArtistPage] Profile query result:', { profileData, error: subError });

      // User is fully subscribed if ANY of these are true:
      // 1. is_free_forever === true
      // 2. subscription_tier === 'premium'
      // 3. subscription_tier === 'standard'
      const hasActiveSub = profileData && (
        profileData.is_free_forever === true ||
        profileData.subscription_tier === 'premium' ||
        profileData.subscription_tier === 'standard'
      );

      if (!hasActiveSub) {
        // If no subscription found and we haven't exceeded retry limit, retry after delay
        if (retryCount < 2) {
          console.log('[CreateArtistPage] No subscription found, retrying in 2 seconds...');
          await new Promise(resolve => setTimeout(resolve, 2000));
          return checkSubscriptionAndProfile(retryCount + 1);
        }

        console.log('[CreateArtistPage] No active subscription found after retries');
        setHasSubscription(false);
        setShowSubscriptionModal(true);
        setLoading(false);
        return;
      }

      console.log('[CreateArtistPage] Active subscription found:', profileData);

      setHasSubscription(true);

      console.log('[CreateArtistPage] Checking for existing artist card...');
      const { data: artistCard, error: cardError } = await supabase
        .from('artist_cards')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      console.log('[CreateArtistPage] Artist card query result:', { artistCard, error: cardError });

      if (artistCard) {
        const requiredFields = [
          artistCard.name,
          artistCard.stage_name,
          artistCard.category,
          artistCard.genre,
          artistCard.phone,
        ];

        const hasEmptyField = requiredFields.some(
          field => !field || field.trim() === ''
        );

        const missingLocations = !artistCard.locations || artistCard.locations.length === 0;
        const missingStates = !artistCard.state_territories || artistCard.state_territories.length === 0;

        if (!hasEmptyField && !missingLocations && !missingStates) {
          console.log('[CreateArtistPage] Artist profile complete, redirecting to home');
          navigate('/');
          return;
        }

        console.log('[CreateArtistPage] Artist profile incomplete, showing profile modal');
        setExistingArtistCard(artistCard);
      } else {
        console.log('[CreateArtistPage] No existing artist card found');
      }

      setLoading(false);
    } catch (error) {
      console.error('[CreateArtistPage] Error checking subscription and profile:', error);
      setLoading(false);
    }
  };

  const handleProfileComplete = () => {
    navigate('/');
  };


  if (!user) {
    return null;
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-[#39ff14] mx-auto mb-4" />
          <p className="text-[#39ff14]">Loading...</p>
        </div>
      </div>
    );
  }

  if (showSubscriptionModal) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
        <SubscriptionModal
          isOpen={true}
          onClose={() => navigate('/')}
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
      <ArtistProfileModal
        isOpen={true}
        userId={user.id}
        userEmail={user.email || ''}
        onClose={() => {}}
        onComplete={handleProfileComplete}
        onSubscribe={() => {}}
        existingData={existingArtistCard}
      />
    </div>
  );
}
