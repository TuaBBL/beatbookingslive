import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-3xl mx-auto px-6 py-12">
        <Link
          to="/"
          className="inline-flex items-center text-blue-600 hover:text-blue-700 mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Home
        </Link>

        <div className="bg-white rounded-lg shadow-sm p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Terms & Conditions — BeatBookingsLive
          </h1>
          <p className="text-gray-600 mb-8">
            Last Updated: 26 Nov 25
          </p>

          <div className="space-y-8">
            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-3">
                1. Introduction
              </h2>
              <p className="text-gray-700 leading-relaxed mb-3">
                BeatBookingsLive ("the Platform") is an online directory for DJs, artists, and entertainers to showcase their profiles. Clients, event planners, and venues ("Users") may browse profiles and contact Artists directly.
              </p>
              <p className="text-gray-700 leading-relaxed mb-3">
                BeatBookingsLive does NOT handle bookings, payments, contracts, or negotiations.
              </p>
              <p className="text-gray-700 leading-relaxed">
                By using the Platform, you accept these Terms & Conditions.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-3">
                2. Nature of Our Service (Directory Only)
              </h2>
              <p className="text-gray-700 leading-relaxed mb-3">
                BeatBookingsLive provides:
              </p>
              <ul className="list-disc list-inside space-y-1 text-gray-700 mb-4 ml-4">
                <li>Profile listings</li>
                <li>Artist showcase pages</li>
                <li>Search & discovery tools</li>
                <li>Contact or enquiry options</li>
              </ul>
              <p className="text-gray-700 leading-relaxed mb-3">
                BeatBookingsLive does NOT:
              </p>
              <ul className="list-disc list-inside space-y-1 text-gray-700 mb-4 ml-4">
                <li>Collect or process payments</li>
                <li>Charge booking fees</li>
                <li>Guarantee artist availability</li>
                <li>Act as a booking agent</li>
                <li>Participate in agreements</li>
                <li>Verify identity or performance quality</li>
                <li>Get involved in disputes</li>
              </ul>
              <p className="text-gray-700 leading-relaxed">
                All arrangements occur outside the platform, directly between Artist and Client.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-3">
                3. Artist Guidelines
              </h2>
              <p className="text-sm text-gray-500 italic mb-3">(no bookings, no payments)</p>
              <p className="text-gray-700 leading-relaxed mb-3">
                Artists agree to:
              </p>
              <ul className="list-disc list-inside space-y-1 text-gray-700 mb-4 ml-4">
                <li>Provide accurate profile content</li>
                <li>Upload only owned/licensed media</li>
                <li>Communicate professionally</li>
                <li>Manage all bookings privately off-platform</li>
                <li>Handle their own payments, contracts, and pricing</li>
                <li>Respect clients and event hosts</li>
              </ul>
              <p className="text-gray-700 leading-relaxed">
                Artists understand BeatBookingsLive is not responsible for bookings, payment disputes, or performance issues.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-3">
                4. Client Guidelines
              </h2>
              <p className="text-sm text-gray-500 italic mb-3">(Directory-Only)</p>
              <p className="text-gray-700 leading-relaxed mb-3">
                Clients agree to:
              </p>
              <ul className="list-disc list-inside space-y-1 text-gray-700 mb-4 ml-4">
                <li>Contact Artists respectfully</li>
                <li>Handle bookings privately (off-platform)</li>
                <li>Verify Artist suitability and availability independently</li>
                <li>Manage payments, deposits, and contracts directly with Artists</li>
                <li>Ensure event safety and readiness for performers</li>
                <li>Respect Artist content, time, and boundaries</li>
              </ul>
              <p className="text-gray-700 leading-relaxed mb-3">
                BeatBookingsLive is not responsible for:
              </p>
              <ul className="list-disc list-inside space-y-1 text-gray-700 mb-2 ml-4">
                <li>Event outcomes</li>
                <li>Payment disputes</li>
                <li>No-shows</li>
                <li>Artist behaviour</li>
                <li>Contract terms</li>
                <li>Damages or losses</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-3">
                5. User Accounts
              </h2>
              <p className="text-gray-700 leading-relaxed mb-3">
                Users must:
              </p>
              <ul className="list-disc list-inside space-y-1 text-gray-700 mb-3 ml-4">
                <li>Provide correct information</li>
                <li>Not impersonate others</li>
                <li>Not upload harmful content</li>
                <li>Use the Platform respectfully</li>
                <li>Keep login credentials secure</li>
              </ul>
              <p className="text-gray-700 leading-relaxed">
                BeatBookingsLive may suspend accounts for misuse.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-3">
                6. User Content
              </h2>
              <p className="text-gray-700 leading-relaxed mb-3">
                Users may upload:
              </p>
              <ul className="list-disc list-inside space-y-1 text-gray-700 mb-3 ml-4">
                <li>Photos</li>
                <li>Videos</li>
                <li>Mixes</li>
                <li>Descriptions</li>
              </ul>
              <p className="text-gray-700 leading-relaxed mb-3">
                You grant BeatBookingsLive a license to display this content.
              </p>
              <p className="text-gray-700 leading-relaxed">
                You are responsible for ensuring your content does not violate copyright laws.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-3">
                7. Limitation of Liability
              </h2>
              <p className="text-gray-700 leading-relaxed mb-3">
                BeatBookingsLive is not liable for:
              </p>
              <ul className="list-disc list-inside space-y-1 text-gray-700 mb-3 ml-4">
                <li>Interactions between Users</li>
                <li>Any damages or injuries</li>
                <li>Failed events</li>
                <li>Misconduct</li>
                <li>Loss of income</li>
                <li>Technical issues</li>
                <li>External links or third-party content</li>
              </ul>
              <p className="text-gray-700 leading-relaxed">
                Use the Platform at your own risk.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-3">
                8. Termination
              </h2>
              <p className="text-gray-700 leading-relaxed mb-3">
                BeatBookingsLive may remove or suspend accounts for:
              </p>
              <ul className="list-disc list-inside space-y-1 text-gray-700 ml-4">
                <li>Abuse</li>
                <li>Illegal or harmful content</li>
                <li>Fraud</li>
                <li>Repeated complaints</li>
              </ul>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-3">
                9. Changes to Terms
              </h2>
              <p className="text-gray-700 leading-relaxed mb-2">
                We may update these Terms at any time.
              </p>
              <p className="text-gray-700 leading-relaxed">
                Continued use = acceptance of updated Terms.
              </p>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 mb-3">
                10. Contact Us
              </h2>
              <p className="text-gray-700 leading-relaxed">
                info@beatbookingslive.com
              </p>
            </section>
          </div>

          <div className="mt-8 text-center">
            <Link
              to="/"
              className="inline-flex items-center justify-center px-8 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors shadow-md hover:shadow-lg"
            >
              Back to Home
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
