import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { SignupForm } from '../components/auth/SignupForm';
import { ArtistProfileModal } from '../components/ArtistProfileModal';
import { SubscriptionModal } from '../components/SubscriptionModal';
import { SupportChatModal } from '../components/SupportChatModal';
import { FloatingSupportButton } from '../components/FloatingSupportButton';

export function SignupPage() {
  const navigate = useNavigate();
  const [artistProfileModalOpen, setArtistProfileModalOpen] = useState(false);
  const [subscriptionModalOpen, setSubscriptionModalOpen] = useState(false);
  const [artistUserId, setArtistUserId] = useState('');
  const [artistEmail, setArtistEmail] = useState('');
  const [supportChatOpen, setSupportChatOpen] = useState(false);

  const handleSignupSuccess = () => {
    navigate('/login');
  };

  const handleArtistSignup = (userId: string, email: string) => {
    setArtistUserId(userId);
    setArtistEmail(email);
    setArtistProfileModalOpen(true);
  };

  const handleProfileComplete = () => {
    setArtistProfileModalOpen(false);
  };

  const handleSubscribe = () => {
    setArtistProfileModalOpen(false);
    setSubscriptionModalOpen(true);
  };


  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <h1 className="text-center text-3xl font-extrabold text-gray-900 mb-8">
          BeatBookingsLive
        </h1>
        <SignupForm
          onSuccess={handleSignupSuccess}
          onArtistSignup={handleArtistSignup}
        />
        <div className="mt-6 text-center">
          <p className="text-sm text-gray-600">
            Already have an account?{' '}
            <Link to="/login" className="font-medium text-indigo-600 hover:text-indigo-500">
              Sign in here
            </Link>
          </p>
        </div>
      </div>

      <div className="mt-8 text-center">
        <Link
          to="/terms"
          className="text-sm text-gray-600 hover:text-gray-900 underline"
        >
          Terms & Conditions
        </Link>
      </div>

      <ArtistProfileModal
        isOpen={artistProfileModalOpen}
        userId={artistUserId}
        userEmail={artistEmail}
        onClose={() => setArtistProfileModalOpen(false)}
        onComplete={handleProfileComplete}
        onSubscribe={handleSubscribe}
      />

      <SubscriptionModal
        isOpen={subscriptionModalOpen}
        onClose={() => setSubscriptionModalOpen(false)}
      />

      <FloatingSupportButton onClick={() => setSupportChatOpen(true)} />

      <SupportChatModal
        isOpen={supportChatOpen}
        onClose={() => setSupportChatOpen(false)}
      />
    </div>
  );
}