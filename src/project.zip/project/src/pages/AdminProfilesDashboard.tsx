import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { ProfileStatusIndicator } from '../components/ProfileStatusIndicator';
import { CompletionBar } from '../components/CompletionBar';
import { calculateUserProfileCompleteness, calculateArtistProfileCompleteness } from '../lib/profileCompleteness';
import { isAdminOrAmbassador } from '../lib/adminUtils';
import { Search, Filter, Eye, Edit, MessageCircle, CheckCircle, X, LogOut, Mail, Wrench, ChevronDown, ChevronUp, Phone, MapPin, Calendar, DollarSign, Star } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { AdminMessageModal } from '../components/AdminMessageModal';

interface UserProfile {
  id: string;
  email: string;
  full_name: string;
  location: string;
  state_territory: string;
  phone_number: string;
  profile_image_url: string;
  created_at: string;
  updated_at: string;
  profile_completed: boolean;
}

interface ArtistProfile {
  id: number;
  user_id: string;
  email: string;
  stage_name: string;
  name: string;
  category: string;
  genre: string;
  state_territories: string[];
  locations: string[];
  image_url: string;
  is_verified: boolean;
  phone: string;
  cost: number;
  cost_type: string;
  about: string;
  is_premium: boolean;
  subscription_type: string;
  profile_status: string;
  created_at: string;
  updated_at: string;
  availability: string;
  rating: number;
}

export function AdminProfilesDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState<'users' | 'artists'>('users');
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [artists, setArtists] = useState<ArtistProfile[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [stateFilter, setStateFilter] = useState('');
  const [genreFilter, setGenreFilter] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [incompleteOnly, setIncompleteOnly] = useState(false);
  const [sortBy, setSortBy] = useState<'name' | 'completion' | 'state' | 'created'>('name');
  const [isAdmin, setIsAdmin] = useState(false);
  const [messageModalOpen, setMessageModalOpen] = useState(false);
  const [selectedRecipientEmail, setSelectedRecipientEmail] = useState('');
  const [selectedRecipientName, setSelectedRecipientName] = useState('');
  const [cleanupRunning, setCleanupRunning] = useState(false);
  const [cleanupResult, setCleanupResult] = useState<any>(null);
  const [expandedUserRows, setExpandedUserRows] = useState<Set<string>>(new Set());
  const [expandedArtistRows, setExpandedArtistRows] = useState<Set<number>>(new Set());

  useEffect(() => {
    checkAdminAccess();
  }, []);

  useEffect(() => {
    if (isAdmin) {
      if (activeTab === 'users') {
        fetchUsers();
      } else {
        fetchArtists();
      }
    }
  }, [activeTab, isAdmin]);

  async function checkAdminAccess() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        navigate('/');
        return;
      }

      // Check JWT app_metadata for admin/ambassador role
      if (!isAdminOrAmbassador(user)) {
        console.warn('Access denied: User does not have admin or ambassador role');
        navigate('/');
        return;
      }

      setIsAdmin(true);
    } catch (error) {
      console.error('Error checking admin access:', error);
      navigate('/');
    }
  }

  async function fetchUsers() {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;

      setUsers((data || []) as UserProfile[]);
    } catch (error) {
      console.error('Error fetching users:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchArtists() {
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('artist_cards')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching artists:', error);
        throw error;
      }

      console.log('Fetched artists:', data?.length || 0);

      // Email is already in artist_cards table, no need to fetch from auth
      setArtists((data || []) as ArtistProfile[]);
    } catch (error) {
      console.error('Error fetching artists:', error);
    } finally {
      setLoading(false);
    }
  }

  const filteredUsers = users.filter((user) => {
    const completeness = calculateUserProfileCompleteness(user);

    if (incompleteOnly && completeness.status === 'green') return false;
    if (stateFilter && user.state_territory !== stateFilter) return false;
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      if (
        !user.full_name?.toLowerCase().includes(query) &&
        !user.email?.toLowerCase().includes(query) &&
        !user.location?.toLowerCase().includes(query)
      ) {
        return false;
      }
    }
    return true;
  });

  const filteredArtists = artists.filter((artist) => {
    const completeness = calculateArtistProfileCompleteness(artist);

    if (incompleteOnly && completeness.status === 'green') return false;
    if (stateFilter && (!artist.state_territories || !artist.state_territories.includes(stateFilter))) return false;
    if (genreFilter && artist.genre !== genreFilter) return false;
    if (categoryFilter && artist.category !== categoryFilter) return false;
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      if (
        !artist.stage_name?.toLowerCase().includes(query) &&
        !artist.name?.toLowerCase().includes(query) &&
        !artist.email?.toLowerCase().includes(query)
      ) {
        return false;
      }
    }
    return true;
  });

  const sortedUsers = [...filteredUsers].sort((a, b) => {
    const aComp = calculateUserProfileCompleteness(a);
    const bComp = calculateUserProfileCompleteness(b);

    switch (sortBy) {
      case 'completion':
        return bComp.percentage - aComp.percentage;
      case 'name':
        return (a.full_name || '').localeCompare(b.full_name || '');
      case 'state':
        return (a.state_territory || '').localeCompare(b.state_territory || '');
      default:
        return 0;
    }
  });

  const sortedArtists = [...filteredArtists].sort((a, b) => {
    const aComp = calculateArtistProfileCompleteness(a);
    const bComp = calculateArtistProfileCompleteness(b);

    switch (sortBy) {
      case 'completion':
        return bComp.percentage - aComp.percentage;
      case 'name':
        return (a.stage_name || a.name || '').localeCompare(b.stage_name || b.name || '');
      case 'state':
        return (a.state_territories?.[0] || '').localeCompare(b.state_territories?.[0] || '');
      default:
        return 0;
    }
  });

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate('/');
  };

  const handleOpenMessage = (email: string, name: string) => {
    setSelectedRecipientEmail(email);
    setSelectedRecipientName(name);
    setMessageModalOpen(true);
  };

  const handleCloseMessage = () => {
    setMessageModalOpen(false);
    setSelectedRecipientEmail('');
    setSelectedRecipientName('');
  };

  const toggleUserRow = (userId: string) => {
    const newExpanded = new Set(expandedUserRows);
    if (newExpanded.has(userId)) {
      newExpanded.delete(userId);
    } else {
      newExpanded.add(userId);
    }
    setExpandedUserRows(newExpanded);
  };

  const toggleArtistRow = (artistId: number) => {
    const newExpanded = new Set(expandedArtistRows);
    if (newExpanded.has(artistId)) {
      newExpanded.delete(artistId);
    } else {
      newExpanded.add(artistId);
    }
    setExpandedArtistRows(newExpanded);
  };

  const handleAutoCleanup = async () => {
    if (!confirm('This will perform a FULL cleanup of all user and artist data:\n\n• Fix artist profiles\n• Fix user profiles\n• Remove orphaned data\n• Repair metadata\n• Clean corrupt entries\n\nThis operation cannot be undone. Continue?')) {
      return;
    }

    setCleanupRunning(true);
    setCleanupResult(null);

    try {
      const { data: { session } } = await supabase.auth.getSession();

      if (!session) {
        alert('Not authenticated');
        return;
      }

      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/full-auto-clean`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${session.access_token}`,
            'Content-Type': 'application/json',
          },
        }
      );

      const result = await response.json();

      if (result.success) {
        setCleanupResult(result.summary);
        alert('✅ Full cleanup completed successfully!\n\nCheck the detailed results below.');
        await fetchProfiles();
      } else {
        alert(`❌ Cleanup failed: ${result.error}`);
      }
    } catch (error) {
      console.error('Error running cleanup:', error);
      alert('Failed to run cleanup action');
    } finally {
      setCleanupRunning(false);
    }
  };

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center">
        <div className="text-[#39ff14] text-xl">Checking permissions...</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 text-white">
      {/* Header */}
      <header className="bg-black border-b-2 border-red-500 shadow-lg">
        <div className="container mx-auto px-4 py-6 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-[#39ff14]" style={{ textShadow: '0 0 8px #ff0000' }}>
              Admin Dashboard
            </h1>
            <p className="text-gray-400 text-sm mt-1">Profile Management & Monitoring</p>
          </div>
          <div className="flex gap-4 items-center">
            <button
              onClick={handleAutoCleanup}
              disabled={cleanupRunning}
              className="px-4 py-2 bg-transparent border-2 border-[#39ff14] text-[#39ff14] rounded-lg font-semibold hover:bg-[#39ff14] hover:text-black transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
              title="Full database cleanup - Fix all user and artist profiles"
            >
              {cleanupRunning ? (
                <>
                  <svg className="animate-spin h-4 w-4" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Running Full Cleanup...
                </>
              ) : (
                <>
                  <Wrench className="w-4 h-4" />
                  Full Auto-Clean
                </>
              )}
            </button>
            <button
              onClick={() => navigate('/')}
              className="px-4 py-2 bg-transparent border-2 border-[#39ff14] text-[#39ff14] rounded-lg font-semibold hover:bg-[#39ff14] hover:text-black transition-all duration-300"
            >
              <Eye className="w-4 h-4 inline mr-2" />
              View Site
            </button>
            <button
              onClick={handleSignOut}
              className="flex items-center gap-2 px-4 py-2 bg-transparent border-2 border-red-500 text-red-500 rounded-lg font-semibold hover:bg-red-500 hover:text-white transition-all duration-300"
            >
              <LogOut className="w-4 h-4" />
              Sign Out
            </button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {/* Cleanup Results */}
        {cleanupResult && (
          <div className="bg-gray-800 rounded-lg p-6 mb-8 border border-[#39ff14] shadow-lg">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-2xl font-bold text-[#39ff14]">Full Auto-Cleanup Results</h2>
              <button
                onClick={() => setCleanupResult(null)}
                className="text-gray-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-3 gap-4 mb-6 p-4 bg-gray-900 rounded-lg border border-gray-700">
              <div className="text-center">
                <div className="text-[#39ff14] text-3xl font-bold">{cleanupResult.total_auth_users || 0}</div>
                <div className="text-gray-400 text-sm mt-1">Total Auth Users</div>
              </div>
              <div className="text-center">
                <div className="text-blue-400 text-3xl font-bold">{cleanupResult.total_artists || 0}</div>
                <div className="text-gray-400 text-sm mt-1">Total Artists</div>
              </div>
              <div className="text-center">
                <div className="text-purple-400 text-3xl font-bold">{cleanupResult.total_regular_users || 0}</div>
                <div className="text-gray-400 text-sm mt-1">Regular Users</div>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-gray-900 p-4 rounded-lg border border-[#39ff14]/20">
                <div className="text-[#39ff14] text-2xl font-bold">{cleanupResult.artists_fixed || 0}</div>
                <div className="text-gray-400 text-sm">Artists Fixed</div>
              </div>
              <div className="bg-gray-900 p-4 rounded-lg border border-blue-500/20">
                <div className="text-blue-400 text-2xl font-bold">{cleanupResult.new_artist_profiles_created || 0}</div>
                <div className="text-gray-400 text-sm">Artist Profiles Created</div>
              </div>
              <div className="bg-gray-900 p-4 rounded-lg border border-blue-500/20">
                <div className="text-blue-400 text-2xl font-bold">{cleanupResult.missing_user_rows_created || 0}</div>
                <div className="text-gray-400 text-sm">User Rows Created</div>
              </div>
              <div className="bg-gray-900 p-4 rounded-lg border border-red-500/20">
                <div className="text-red-400 text-2xl font-bold">{cleanupResult.incorrect_user_rows_deleted || 0}</div>
                <div className="text-gray-400 text-sm">Incorrect Rows Deleted</div>
              </div>
              <div className="bg-gray-900 p-4 rounded-lg border border-red-500/20">
                <div className="text-red-400 text-2xl font-bold">{cleanupResult.orphan_user_rows_removed || 0}</div>
                <div className="text-gray-400 text-sm">Orphan Users Removed</div>
              </div>
              <div className="bg-gray-900 p-4 rounded-lg border border-red-500/20">
                <div className="text-red-400 text-2xl font-bold">{cleanupResult.orphan_artist_profiles_removed || 0}</div>
                <div className="text-gray-400 text-sm">Orphan Artists Removed</div>
              </div>
              <div className="bg-gray-900 p-4 rounded-lg border border-purple-500/20">
                <div className="text-purple-400 text-2xl font-bold">{cleanupResult.metadata_roles_fixed || 0}</div>
                <div className="text-gray-400 text-sm">Metadata Roles Fixed</div>
              </div>
              <div className="bg-gray-900 p-4 rounded-lg border border-[#39ff14]/20">
                <div className="text-[#39ff14] text-2xl font-bold">
                  {(cleanupResult.artists_fixed || 0) + (cleanupResult.missing_user_rows_created || 0) +
                   (cleanupResult.incorrect_user_rows_deleted || 0) + (cleanupResult.orphan_user_rows_removed || 0) +
                   (cleanupResult.orphan_artist_profiles_removed || 0) + (cleanupResult.metadata_roles_fixed || 0)}
                </div>
                <div className="text-gray-400 text-sm">Total Actions</div>
              </div>
            </div>

            <div className="mt-6">
              <details className="bg-gray-900 p-4 rounded-lg border border-gray-700">
                <summary className="text-gray-400 cursor-pointer hover:text-white transition-colors font-semibold">
                  View Raw JSON Summary
                </summary>
                <pre className="mt-4 text-xs text-gray-300 overflow-x-auto">
                  {JSON.stringify(cleanupResult, null, 2)}
                </pre>
              </details>
            </div>
          </div>
        )}

        {/* Tabs */}
        <div className="flex gap-4 mb-8 border-b border-gray-700">
          <button
            onClick={() => setActiveTab('users')}
            className={`px-6 py-3 font-semibold transition-all duration-300 ${
              activeTab === 'users'
                ? 'text-[#39ff14] border-b-2 border-[#39ff14]'
                : 'text-gray-400 hover:text-[#39ff14]'
            }`}
          >
            Users ({users.length})
          </button>
          <button
            onClick={() => setActiveTab('artists')}
            className={`px-6 py-3 font-semibold transition-all duration-300 ${
              activeTab === 'artists'
                ? 'text-[#39ff14] border-b-2 border-[#39ff14]'
                : 'text-gray-400 hover:text-[#39ff14]'
            }`}
          >
            Artists ({artists.length})
          </button>
        </div>

        {/* Filters */}
        <div className="bg-gray-800 rounded-lg p-6 mb-8 border border-gray-700">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search by name or email..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white focus:border-[#39ff14] focus:outline-none"
              />
            </div>

            {/* Sort By */}
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white focus:border-[#39ff14] focus:outline-none"
            >
              <option value="name">Sort by Name</option>
              <option value="completion">Sort by Completion</option>
              <option value="state">Sort by State</option>
            </select>

            {/* State Filter */}
            <input
              type="text"
              placeholder="Filter by state..."
              value={stateFilter}
              onChange={(e) => setStateFilter(e.target.value)}
              className="px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white focus:border-[#39ff14] focus:outline-none"
            />

            {/* Incomplete Only */}
            <label className="flex items-center gap-3 px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg cursor-pointer hover:border-[#39ff14] transition-colors">
              <input
                type="checkbox"
                checked={incompleteOnly}
                onChange={(e) => setIncompleteOnly(e.target.checked)}
                className="w-4 h-4"
              />
              <span className="text-white">Incomplete Only</span>
            </label>
          </div>

          {activeTab === 'artists' && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              <input
                type="text"
                placeholder="Filter by genre..."
                value={genreFilter}
                onChange={(e) => setGenreFilter(e.target.value)}
                className="px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white focus:border-[#39ff14] focus:outline-none"
              />
              <input
                type="text"
                placeholder="Filter by category..."
                value={categoryFilter}
                onChange={(e) => setCategoryFilter(e.target.value)}
                className="px-4 py-2 bg-gray-900 border border-gray-700 rounded-lg text-white focus:border-[#39ff14] focus:outline-none"
              />
            </div>
          )}
        </div>

        {/* Table */}
        {loading ? (
          <div className="text-center py-12">
            <div className="text-[#39ff14] text-lg">Loading...</div>
          </div>
        ) : activeTab === 'users' ? (
          <div className="bg-gray-800 rounded-lg overflow-hidden border border-gray-700">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-900">
                  <tr>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-[#39ff14]"></th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-[#39ff14]">Name</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-[#39ff14]">Email</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-[#39ff14]">Phone</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-[#39ff14]">State</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-[#39ff14]">Location</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-[#39ff14]">Status</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-[#39ff14]">Completion</th>
                    <th className="px-6 py-4 text-center text-sm font-semibold text-[#39ff14]">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedUsers.map((user) => {
                    const completeness = calculateUserProfileCompleteness(user);
                    const isExpanded = expandedUserRows.has(user.id);
                    return (
                      <>
                        <tr key={user.id} className="border-t border-gray-700 hover:bg-gray-750 transition-colors">
                          <td className="px-6 py-4">
                            <button
                              onClick={() => toggleUserRow(user.id)}
                              className="text-[#39ff14] hover:text-[#39ff14]/80 transition-colors"
                            >
                              {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                            </button>
                          </td>
                          <td className="px-6 py-4 text-white">{user.full_name || <span className="text-gray-500">N/A</span>}</td>
                          <td className="px-6 py-4 text-gray-400 text-sm">{user.email}</td>
                          <td className="px-6 py-4 text-white">{user.phone_number || <span className="text-gray-500">N/A</span>}</td>
                          <td className="px-6 py-4 text-white">{user.state_territory || <span className="text-gray-500">N/A</span>}</td>
                          <td className="px-6 py-4 text-white">{user.location || <span className="text-gray-500">N/A</span>}</td>
                          <td className="px-6 py-4">
                            <ProfileStatusIndicator
                              status={completeness.status}
                              percentage={completeness.percentage}
                              missingFields={completeness.missingFields}
                              showLabel={true}
                            />
                          </td>
                          <td className="px-6 py-4">
                            <CompletionBar percentage={completeness.percentage} status={completeness.status} />
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex justify-center">
                              <button
                                onClick={() => handleOpenMessage(user.email, user.full_name || 'User')}
                                className="flex items-center gap-2 px-3 py-1.5 bg-[#39ff14] bg-opacity-20 border border-[#39ff14] text-[#39ff14] rounded-lg text-sm font-semibold hover:bg-[#39ff14] hover:text-black transition-all duration-300"
                                title="Send message to user"
                              >
                                <Mail className="w-4 h-4" />
                                Message
                              </button>
                            </div>
                          </td>
                        </tr>
                        {isExpanded && (
                          <tr key={`${user.id}-details`} className="border-t border-gray-700 bg-gray-800/50">
                            <td colSpan={9} className="px-6 py-4">
                              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <div className="space-y-2">
                                  <h4 className="text-[#39ff14] font-semibold mb-2">Profile Details</h4>
                                  <div className="flex items-center gap-2 text-sm">
                                    <Calendar className="w-4 h-4 text-gray-400" />
                                    <span className="text-gray-400">Created:</span>
                                    <span className="text-white">{new Date(user.created_at).toLocaleDateString()}</span>
                                  </div>
                                  <div className="flex items-center gap-2 text-sm">
                                    <Calendar className="w-4 h-4 text-gray-400" />
                                    <span className="text-gray-400">Updated:</span>
                                    <span className="text-white">{new Date(user.updated_at).toLocaleDateString()}</span>
                                  </div>
                                  <div className="flex items-center gap-2 text-sm">
                                    <CheckCircle className="w-4 h-4 text-gray-400" />
                                    <span className="text-gray-400">Profile Completed:</span>
                                    <span className="text-white">{user.profile_completed ? 'Yes' : 'No'}</span>
                                  </div>
                                </div>
                                <div className="space-y-2">
                                  <h4 className="text-[#39ff14] font-semibold mb-2">Missing Fields</h4>
                                  {completeness.missingFields.length > 0 ? (
                                    <ul className="text-sm space-y-1">
                                      {completeness.missingFields.map((field, idx) => (
                                        <li key={idx} className="text-yellow-400">• {field}</li>
                                      ))}
                                    </ul>
                                  ) : (
                                    <p className="text-sm text-green-400">All required fields complete</p>
                                  )}
                                </div>
                                <div className="space-y-2">
                                  <h4 className="text-[#39ff14] font-semibold mb-2">Profile Image</h4>
                                  {user.profile_image_url ? (
                                    <img src={user.profile_image_url} alt={user.full_name} className="w-24 h-24 rounded-lg object-cover border border-gray-700" />
                                  ) : (
                                    <div className="w-24 h-24 bg-gray-700 rounded-lg flex items-center justify-center text-gray-500 text-xs">No image</div>
                                  )}
                                </div>
                              </div>
                            </td>
                          </tr>
                        )}
                      </>
                    );
                  })}
                </tbody>
              </table>
            </div>
            {sortedUsers.length === 0 && (
              <div className="text-center py-12 text-gray-400">
                No users found matching your filters.
              </div>
            )}
          </div>
        ) : (
          <div className="bg-gray-800 rounded-lg overflow-hidden border border-gray-700">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-900">
                  <tr>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-[#39ff14]"></th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-[#39ff14]">Stage Name</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-[#39ff14]">Email</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-[#39ff14]">Phone</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-[#39ff14]">Category</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-[#39ff14]">Genre</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-[#39ff14]">Premium</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-[#39ff14]">Status</th>
                    <th className="px-6 py-4 text-left text-sm font-semibold text-[#39ff14]">Verified</th>
                    <th className="px-6 py-4 text-center text-sm font-semibold text-[#39ff14]">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {sortedArtists.map((artist) => {
                    const completeness = calculateArtistProfileCompleteness(artist);
                    const isExpanded = expandedArtistRows.has(artist.id);
                    return (
                      <>
                        <tr key={artist.id} className="border-t border-gray-700 hover:bg-gray-750 transition-colors">
                          <td className="px-6 py-4">
                            <button
                              onClick={() => toggleArtistRow(artist.id)}
                              className="text-[#39ff14] hover:text-[#39ff14]/80 transition-colors"
                            >
                              {isExpanded ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                            </button>
                          </td>
                          <td className="px-6 py-4 text-white">{artist.stage_name || artist.name || <span className="text-gray-500">N/A</span>}</td>
                          <td className="px-6 py-4 text-gray-400 text-sm">{artist.email}</td>
                          <td className="px-6 py-4 text-white">{artist.phone || <span className="text-gray-500">N/A</span>}</td>
                          <td className="px-6 py-4 text-white">{artist.category || <span className="text-gray-500">N/A</span>}</td>
                          <td className="px-6 py-4 text-white">{artist.genre || <span className="text-gray-500">N/A</span>}</td>
                          <td className="px-6 py-4">
                            {artist.is_premium ? (
                              <span className="px-2 py-1 bg-yellow-500/20 border border-yellow-500 text-yellow-500 rounded text-xs font-semibold">Premium</span>
                            ) : (
                              <span className="px-2 py-1 bg-gray-700 text-gray-400 rounded text-xs">Standard</span>
                            )}
                          </td>
                          <td className="px-6 py-4">
                            <ProfileStatusIndicator
                              status={completeness.status}
                              percentage={completeness.percentage}
                              missingFields={completeness.missingFields}
                              showLabel={true}
                            />
                          </td>
                          <td className="px-6 py-4">
                            {artist.is_verified ? (
                              <CheckCircle className="w-5 h-5 text-blue-500" />
                            ) : (
                              <X className="w-5 h-5 text-gray-500" />
                            )}
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex justify-center">
                              <button
                                onClick={() => handleOpenMessage(artist.email, artist.stage_name || artist.name || 'Artist')}
                                className="flex items-center gap-2 px-3 py-1.5 bg-[#39ff14] bg-opacity-20 border border-[#39ff14] text-[#39ff14] rounded-lg text-sm font-semibold hover:bg-[#39ff14] hover:text-black transition-all duration-300"
                                title="Send message to artist"
                              >
                                <Mail className="w-4 h-4" />
                                Message
                              </button>
                            </div>
                          </td>
                        </tr>
                        {isExpanded && (
                          <tr key={`${artist.id}-details`} className="border-t border-gray-700 bg-gray-800/50">
                            <td colSpan={10} className="px-6 py-4">
                              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                                <div className="space-y-2">
                                  <h4 className="text-[#39ff14] font-semibold mb-2">Basic Info</h4>
                                  <div className="text-sm space-y-1">
                                    <div><span className="text-gray-400">Full Name:</span> <span className="text-white">{artist.name || 'N/A'}</span></div>
                                    <div><span className="text-gray-400">Rating:</span> <span className="text-white flex items-center gap-1"><Star className="w-3 h-3 text-yellow-500" />{artist.rating || 0}</span></div>
                                    <div><span className="text-gray-400">Availability:</span> <span className="text-white">{artist.availability || 'N/A'}</span></div>
                                    <div><span className="text-gray-400">Profile Status:</span> <span className="text-white">{artist.profile_status || 'N/A'}</span></div>
                                  </div>
                                </div>
                                <div className="space-y-2">
                                  <h4 className="text-[#39ff14] font-semibold mb-2">Location & Cost</h4>
                                  <div className="text-sm space-y-1">
                                    <div><span className="text-gray-400">States:</span> <span className="text-white">{artist.state_territories?.join(', ') || 'N/A'}</span></div>
                                    <div><span className="text-gray-400">Locations:</span> <span className="text-white">{artist.locations?.join(', ') || 'N/A'}</span></div>
                                    <div><span className="text-gray-400">Cost:</span> <span className="text-white">${artist.cost || 0} {artist.cost_type || ''}</span></div>
                                  </div>
                                </div>
                                <div className="space-y-2">
                                  <h4 className="text-[#39ff14] font-semibold mb-2">Subscription</h4>
                                  <div className="text-sm space-y-1">
                                    <div><span className="text-gray-400">Type:</span> <span className="text-white">{artist.subscription_type || 'standard'}</span></div>
                                    <div><span className="text-gray-400">Premium:</span> <span className="text-white">{artist.is_premium ? 'Yes' : 'No'}</span></div>
                                    <div className="flex items-center gap-2">
                                      <Calendar className="w-3 h-3 text-gray-400" />
                                      <span className="text-gray-400">Created:</span>
                                      <span className="text-white text-xs">{new Date(artist.created_at).toLocaleDateString()}</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                      <Calendar className="w-3 h-3 text-gray-400" />
                                      <span className="text-gray-400">Updated:</span>
                                      <span className="text-white text-xs">{new Date(artist.updated_at).toLocaleDateString()}</span>
                                    </div>
                                  </div>
                                </div>
                                <div className="space-y-2">
                                  <h4 className="text-[#39ff14] font-semibold mb-2">Profile Image</h4>
                                  {artist.image_url ? (
                                    <img src={artist.image_url} alt={artist.stage_name || artist.name} className="w-24 h-24 rounded-lg object-cover border border-gray-700" />
                                  ) : (
                                    <div className="w-24 h-24 bg-gray-700 rounded-lg flex items-center justify-center text-gray-500 text-xs">No image</div>
                                  )}
                                </div>
                              </div>
                              <div className="mt-4 pt-4 border-t border-gray-700">
                                <h4 className="text-[#39ff14] font-semibold mb-2">About</h4>
                                <p className="text-sm text-gray-300">{artist.about || 'No description provided'}</p>
                              </div>
                              <div className="mt-4">
                                <h4 className="text-[#39ff14] font-semibold mb-2">Completion Status</h4>
                                <div className="flex items-center gap-4">
                                  <CompletionBar percentage={completeness.percentage} status={completeness.status} />
                                  <span className="text-sm text-gray-400">{completeness.percentage}% complete</span>
                                </div>
                                {completeness.missingFields.length > 0 && (
                                  <div className="mt-2">
                                    <p className="text-sm text-yellow-400 mb-1">Missing fields:</p>
                                    <ul className="text-sm space-y-1">
                                      {completeness.missingFields.map((field, idx) => (
                                        <li key={idx} className="text-yellow-400">• {field}</li>
                                      ))}
                                    </ul>
                                  </div>
                                )}
                              </div>
                            </td>
                          </tr>
                        )}
                      </>
                    );
                  })}
                </tbody>
              </table>
            </div>
            {sortedArtists.length === 0 && (
              <div className="text-center py-12 text-gray-400">
                No artists found matching your filters.
              </div>
            )}
          </div>
        )}
      </main>

      <AdminMessageModal
        isOpen={messageModalOpen}
        onClose={handleCloseMessage}
        recipientEmail={selectedRecipientEmail}
        recipientName={selectedRecipientName}
      />
    </div>
  );
}
