import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { SubscriptionPlans } from '../components/subscription/SubscriptionPlans';
import { SubscriptionStatus } from '../components/subscription/SubscriptionStatus';
import { useAuth } from '../hooks/useAuth';
import { SupportChatModal } from '../components/SupportChatModal';
import { FloatingSupportButton } from '../components/FloatingSupportButton';

export function SubscriptionPage() {
  const { user } = useAuth();
  const [supportChatOpen, setSupportChatOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto py-8 px-4">
        {user && (
          <div className="mb-8">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Current Subscription</h2>
            <SubscriptionStatus />
          </div>
        )}
        
        <SubscriptionPlans />

        <div className="mt-8 text-center pb-8">
          <Link
            to="/terms"
            className="text-sm text-gray-600 hover:text-gray-900 underline"
          >
            Terms & Conditions
          </Link>
        </div>
      </div>

      <FloatingSupportButton onClick={() => setSupportChatOpen(true)} />

      <SupportChatModal
        isOpen={supportChatOpen}
        onClose={() => setSupportChatOpen(false)}
        userId={user?.id}
      />
    </div>
  );
}