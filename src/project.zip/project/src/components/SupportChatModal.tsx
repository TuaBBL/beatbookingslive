import { X, Send, Bot, User, Loader2, HelpCircle, ChevronDown, ChevronUp, Mail } from 'lucide-react';
import { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';
import { EmailSupportModal } from './EmailSupportModal';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface SupportChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId?: string;
}

interface FAQ {
  question: string;
  answer: string;
}

const faqs: FAQ[] = [
  {
    question: "What is BeatBookingsLive?",
    answer: "BeatBookingsLive is an online directory where DJs, artists, and performers can showcase their profiles. Clients, planners, and venues can browse artists, view media, and communicate through the built-in messaging box. BeatBookingsLive does not act as a booking agent."
  },
  {
    question: "Do you handle bookings or payments?",
    answer: "No. BeatBookingsLive does not handle bookings, deposits, payments, invoices, contracts, or refunds. All agreements between Artists and Clients happen privately outside the platform."
  },
  {
    question: "How do I contact an Artist or Planner?",
    answer: "Once you log in and request a booking, messaging becomes available. You can message them directly through our built-in messaging box. Use it to ask questions, discuss event details, share links, and confirm availability. Contact details are also available on their profile. BeatBookingsLive does not get involved in these conversations."
  },
  {
    question: "Is BeatBookingsLive responsible for what users say in messages?",
    answer: "No. We provide the messaging tool, but we are not responsible for what users say, agreements made in messages, misunderstandings, harassment or inappropriate behaviour, or cancellations. Users can report abuse, and we may suspend accounts that violate our conduct rules."
  },
  {
    question: "Does BeatBookingsLive take commissions or fees?",
    answer: "No. We do not take booking fees, percentages, commissions, or payment cuts. BeatBookingsLive is a free directory platform unless future optional premium features are released."
  },
  {
    question: "How do I create an Artist profile?",
    answer: "Create an account, subscribe to a plan, add your profile photo, upload mixes, videos, or media, add your bio and details, add your contact links, then publish your profile. Your profile will appear in search results."
  },
  {
    question: "How do Clients find Artists?",
    answer: "Users can search by location, genres, tags, artist name, and profile keywords. Then they can click your profile and send you a message."
  },
  {
    question: "What if I have a problem or dispute with another user?",
    answer: "Since bookings happen off-platform, BeatBookingsLive cannot mediate disputes, enforce agreements, issue refunds, or intervene in personal contracts. You must resolve disputes directly with the other party."
  },
  {
    question: "Can I update my artist profile?",
    answer: "Yes. Log in and go to your Profile Settings to update photos, mixes, videos, bio, links, and details. Changes update immediately."
  },
  {
    question: "How do I delete my artist profile?",
    answer: "Go to Edit Profile and select Delete Profile."
  },
  {
    question: "Can I upload copyrighted songs or images?",
    answer: "Only if you own the rights or have permission. BeatBookingsLive may remove content that violates copyright."
  },
  {
    question: "Is my information safe?",
    answer: "Yes — we only store minimal account information and message history. We do not collect payment details or financial data. See our Privacy Policy for more info."
  },
  {
    question: "Why does messaging exist if you don't handle bookings?",
    answer: "Messaging is provided as a communication tool only. It helps Artists and Clients connect before organising things privately. The platform itself is not involved in bookings."
  },
  {
    question: "Can I share personal contact info in messages?",
    answer: "Yes — but at your own risk. Do not share passwords, banking details, sensitive ID, or private documents. BeatBookingsLive is not liable for what you share voluntarily."
  },
  {
    question: "Does BeatBookingsLive promote Artists?",
    answer: "We may feature Artists on home page highlights, trending sections, promotional content, and social media, but it's not guaranteed."
  },
  {
    question: "Does BeatBookingsLive guarantee that Artists will respond?",
    answer: "No. Artists manage their own inbox and decide if/when they reply."
  },
  {
    question: "What are the subscription packages for artists?",
    answer: "Artists can choose from two subscription packages: $25 Standard or $35 Premium. Note: The first 50 artists are free forever."
  },
  {
    question: "What's the difference between the two subscription packages?",
    answer: "Standard ($25/month): Your profile is listed in search, you can add photos, videos, and external links, you can receive messages and booking requests, and you get basic visibility. Premium ($35/month): Everything in Standard PLUS featured on the homepage, higher search ranking, premium badge, and increased overall visibility. In simple terms: Standard = get listed. Premium = get boosted."
  },
  {
    question: "How does the Planner/Artist messaging system work?",
    answer: "When you request a booking, it appears as a notification in the artist's profile. The artist will then accept or decline it. Whether accepted or declined, the messaging portal opens so you can communicate directly. If declined, the artist will explain why they're unable to fulfill the request through the messaging portal."
  },
  {
    question: "What happens when I request a booking?",
    answer: "Your booking request appears as a notification and request in the artist's profile. The artist will then accept or decline it. If accepted, the messaging portal opens up so you can communicate. If declined, it means they are unable to fulfill your request and you will receive a message from the artist explaining why."
  },
  {
    question: "Is BeatBookingsLive free?",
    answer: "Yes, as a user or planner it is free. Artists have two subscription packages to choose from to be listed: $25 Standard or $35 Premium."
  },
  {
    question: "Can I report a user for inappropriate behaviour?",
    answer: "Yes. Email info@beatbookingslive.com with details of the issue."
  }
];

export function SupportChatModal({ isOpen, onClose, userId }: SupportChatModalProps) {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [conversationId, setConversationId] = useState<string | null>(null);
  const [sessionId] = useState(() => `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`);
  const [showFAQ, setShowFAQ] = useState(true);
  const [expandedFAQ, setExpandedFAQ] = useState<number | null>(null);
  const [emailModalOpen, setEmailModalOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen && messages.length === 0) {
      setMessages([
        {
          role: 'assistant',
          content: "Hi! I'm your Beat Bookings Live assistant. Check out the FAQs below or ask me anything!",
          timestamp: new Date(),
        },
      ]);
    }
  }, [isOpen]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;

    const userMessage: Message = {
      role: 'user',
      content: input.trim(),
      timestamp: new Date(),
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/ai-support-chat`;

      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({
          conversationId: conversationId,
          message: userMessage.content,
          userId: userId,
          sessionId: sessionId,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to get response');
      }

      const data = await response.json();

      if (!conversationId) {
        setConversationId(data.conversationId);
      }

      const assistantMessage: Message = {
        role: 'assistant',
        content: data.message,
        timestamp: new Date(),
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error sending message:', error);
      setMessages(prev => [
        ...prev,
        {
          role: 'assistant',
          content: "I'm sorry, I'm having trouble connecting right now. Please try again or contact support directly at info@beatbookingslive.com",
          timestamp: new Date(),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 rounded-lg border-2 border-red-500 glow-red w-full max-w-2xl flex flex-col" style={{ height: '600px' }}>
        <div className="flex items-center justify-between p-4 border-b border-red-500 border-opacity-30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-[#39ff14] to-red-500 flex items-center justify-center">
              <Bot className="w-6 h-6 text-black" />
            </div>
            <div>
              <h2 className="text-xl font-bold text-fluro-green">AI Support</h2>
              <p className="text-xs text-fluro-green-subtle">Ask me anything about Beat Bookings Live</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-fluro-green-subtle hover:text-fluro-green transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {showFAQ && (
            <div className="bg-gray-800 border border-[#39ff14] border-opacity-30 rounded-lg p-4 mb-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-2">
                  <HelpCircle className="w-5 h-5 text-[#39ff14]" />
                  <h3 className="font-bold text-fluro-green">Frequently Asked Questions</h3>
                </div>
                <button
                  onClick={() => setShowFAQ(false)}
                  className="text-fluro-green-subtle hover:text-fluro-green text-sm transition-colors"
                >
                  Hide
                </button>
              </div>
              <div className="space-y-2">
                {faqs.map((faq, idx) => (
                  <div key={idx} className="border border-red-500 border-opacity-30 rounded-lg overflow-hidden">
                    <button
                      onClick={() => setExpandedFAQ(expandedFAQ === idx ? null : idx)}
                      className="w-full flex items-center justify-between p-3 hover:bg-gray-700 hover:bg-opacity-30 transition-colors text-left"
                    >
                      <span className="text-fluro-green text-sm font-medium">{faq.question}</span>
                      {expandedFAQ === idx ? (
                        <ChevronUp className="w-4 h-4 text-fluro-green flex-shrink-0" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-fluro-green flex-shrink-0" />
                      )}
                    </button>
                    {expandedFAQ === idx && (
                      <div className="p-3 pt-0 border-t border-red-500 border-opacity-20">
                        <p className="text-fluro-green-subtle text-sm leading-relaxed">{faq.answer}</p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
          {!showFAQ && (
            <button
              onClick={() => setShowFAQ(true)}
              className="w-full text-center text-sm text-fluro-green-subtle hover:text-fluro-green transition-colors mb-4"
            >
              Show FAQs
            </button>
          )}
          {messages.map((msg, idx) => (
            <div
              key={idx}
              className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}
            >
              <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 ${
                msg.role === 'user'
                  ? 'bg-red-500'
                  : 'bg-gradient-to-br from-[#39ff14] to-red-500'
              }`}>
                {msg.role === 'user' ? (
                  <User className="w-5 h-5 text-white" />
                ) : (
                  <Bot className="w-5 h-5 text-black" />
                )}
              </div>
              <div
                className={`max-w-[75%] rounded-lg p-3 ${
                  msg.role === 'user'
                    ? 'bg-red-500 bg-opacity-20 border border-red-500'
                    : 'bg-gray-800 border border-[#39ff14] border-opacity-30'
                }`}
              >
                <p className="text-fluro-green text-sm whitespace-pre-wrap">{msg.content}</p>
                <p className="text-xs text-fluro-green-subtle mt-1">
                  {msg.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#39ff14] to-red-500 flex items-center justify-center flex-shrink-0">
                <Bot className="w-5 h-5 text-black" />
              </div>
              <div className="bg-gray-800 border border-[#39ff14] border-opacity-30 rounded-lg p-3">
                <Loader2 className="w-5 h-5 text-fluro-green animate-spin" />
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        <div className="p-4 border-t border-red-500 border-opacity-30">
          <div className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Type your message..."
              disabled={loading}
              className="flex-1 bg-gray-800 border border-red-500 border-opacity-50 rounded-lg px-4 py-2 text-fluro-green placeholder-fluro-green-subtle focus:outline-none focus:border-[#39ff14] transition-colors disabled:opacity-50"
            />
            <button
              onClick={sendMessage}
              disabled={!input.trim() || loading}
              className="px-4 py-2 bg-gradient-to-r from-[#39ff14] to-red-500 text-black rounded-lg font-bold hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
          <div className="flex items-center justify-between mt-2">
            <p className="text-xs text-fluro-green-subtle">
              AI responses are for guidance only.
            </p>
            <button
              onClick={() => setEmailModalOpen(true)}
              className="flex items-center gap-1 text-xs text-[#39ff14] hover:text-[#2dd90f] transition-colors font-semibold"
            >
              <Mail className="w-3 h-3" />
              Email Support
            </button>
          </div>
        </div>
      </div>

      <EmailSupportModal
        isOpen={emailModalOpen}
        onClose={() => setEmailModalOpen(false)}
      />
    </div>
  );
}
