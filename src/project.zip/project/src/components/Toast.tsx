import { useEffect, useState } from 'react';
import { X } from 'lucide-react';

interface ToastProps {
  title: string;
  message: string;
  duration?: number;
  onClose: () => void;
}

export function Toast({ title, message, duration = 3000, onClose }: ToastProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    setTimeout(() => setIsVisible(true), 10);

    const hideTimer = setTimeout(() => {
      setIsExiting(true);
      setTimeout(() => {
        onClose();
      }, 300);
    }, duration);

    return () => clearTimeout(hideTimer);
  }, [duration, onClose]);

  return (
    <div
      className={`fixed top-4 left-1/2 transform -translate-x-1/2 z-[9999] transition-all duration-300 ${
        isVisible && !isExiting ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-4'
      }`}
      style={{
        background: 'rgba(10, 10, 10, 0.85)',
        backdropFilter: 'blur(10px)',
        border: '2px solid #39ff14',
        boxShadow: '0 0 10px #39ff14, 0 0 20px rgba(57, 255, 20, 0.5)',
        borderRadius: '12px',
        padding: '12px 20px',
        minWidth: '300px',
        maxWidth: '90vw',
      }}
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex-1">
          <h4
            className="font-bold text-[#39ff14] mb-1"
            style={{ textShadow: '0 0 8px #39ff14' }}
          >
            {title}
          </h4>
          <p className="text-white text-sm">{message}</p>
        </div>
        <button
          onClick={() => {
            setIsExiting(true);
            setTimeout(onClose, 300);
          }}
          className="text-[#39ff14] hover:text-white transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

export function ToastContainer() {
  const [toasts, setToasts] = useState<Array<{ id: string; title: string; message: string }>>([]);

  useEffect(() => {
    const handleShowToast = (event: CustomEvent) => {
      const { title, message } = event.detail;
      const id = Date.now().toString();
      setToasts((prev) => [...prev, { id, title, message }]);
    };

    window.addEventListener('showToast' as any, handleShowToast);
    return () => window.removeEventListener('showToast' as any, handleShowToast);
  }, []);

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((toast) => toast.id !== id));
  };

  return (
    <>
      {toasts.map((toast) => (
        <Toast
          key={toast.id}
          title={toast.title}
          message={toast.message}
          onClose={() => removeToast(toast.id)}
        />
      ))}
    </>
  );
}

export function showToast(title: string, message: string) {
  const event = new CustomEvent('showToast', {
    detail: { title, message },
  });
  window.dispatchEvent(event);
}
