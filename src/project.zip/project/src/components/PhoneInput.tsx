import { useState } from 'react';

interface PhoneInputProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  className?: string;
  disabled?: boolean;
}

const countryCodes = [
  { code: '+1', country: 'US/CA', flag: '🇺🇸' },
  { code: '+44', country: 'UK', flag: '🇬🇧' },
  { code: '+61', country: 'AU', flag: '🇦🇺' },
  { code: '+49', country: 'DE', flag: '🇩🇪' },
  { code: '+33', country: 'FR', flag: '🇫🇷' },
  { code: '+34', country: 'ES', flag: '🇪🇸' },
  { code: '+39', country: 'IT', flag: '🇮🇹' },
  { code: '+31', country: 'NL', flag: '🇳🇱' },
  { code: '+32', country: 'BE', flag: '🇧🇪' },
  { code: '+41', country: 'CH', flag: '🇨🇭' },
  { code: '+46', country: 'SE', flag: '🇸🇪' },
  { code: '+47', country: 'NO', flag: '🇳🇴' },
  { code: '+45', country: 'DK', flag: '🇩🇰' },
  { code: '+358', country: 'FI', flag: '🇫🇮' },
  { code: '+353', country: 'IE', flag: '🇮🇪' },
  { code: '+351', country: 'PT', flag: '🇵🇹' },
  { code: '+30', country: 'GR', flag: '🇬🇷' },
  { code: '+48', country: 'PL', flag: '🇵🇱' },
  { code: '+420', country: 'CZ', flag: '🇨🇿' },
  { code: '+36', country: 'HU', flag: '🇭🇺' },
  { code: '+40', country: 'RO', flag: '🇷🇴' },
  { code: '+81', country: 'JP', flag: '🇯🇵' },
  { code: '+82', country: 'KR', flag: '🇰🇷' },
  { code: '+86', country: 'CN', flag: '🇨🇳' },
  { code: '+91', country: 'IN', flag: '🇮🇳' },
  { code: '+65', country: 'SG', flag: '🇸🇬' },
  { code: '+60', country: 'MY', flag: '🇲🇾' },
  { code: '+66', country: 'TH', flag: '🇹🇭' },
  { code: '+63', country: 'PH', flag: '🇵🇭' },
  { code: '+64', country: 'NZ', flag: '🇳🇿' },
  { code: '+27', country: 'ZA', flag: '🇿🇦' },
  { code: '+20', country: 'EG', flag: '🇪🇬' },
  { code: '+971', country: 'AE', flag: '🇦🇪' },
  { code: '+966', country: 'SA', flag: '🇸🇦' },
  { code: '+52', country: 'MX', flag: '🇲🇽' },
  { code: '+55', country: 'BR', flag: '🇧🇷' },
  { code: '+54', country: 'AR', flag: '🇦🇷' },
  { code: '+56', country: 'CL', flag: '🇨🇱' },
  { code: '+57', country: 'CO', flag: '🇨🇴' },
];

export function PhoneInput({ value, onChange, placeholder, className, disabled }: PhoneInputProps) {
  const parsePhone = (fullNumber: string) => {
    if (!fullNumber) return { code: '+1', number: '' };

    for (const { code } of countryCodes) {
      if (fullNumber.startsWith(code)) {
        return {
          code,
          number: fullNumber.slice(code.length),
        };
      }
    }

    return { code: '+1', number: fullNumber };
  };

  const { code: initialCode, number: initialNumber } = parsePhone(value);
  const [countryCode, setCountryCode] = useState(initialCode);
  const [phoneNumber, setPhoneNumber] = useState(initialNumber);

  const handleCodeChange = (newCode: string) => {
    setCountryCode(newCode);
    onChange(phoneNumber ? `${newCode}${phoneNumber}` : '');
  };

  const handleNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const numericValue = e.target.value.replace(/\D/g, '');
    setPhoneNumber(numericValue);
    onChange(numericValue ? `${countryCode}${numericValue}` : '');
  };

  return (
    <div className="flex gap-2">
      <select
        value={countryCode}
        onChange={(e) => handleCodeChange(e.target.value)}
        disabled={disabled}
        className={`px-3 py-3 bg-gray-800 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] focus:outline-none focus:border-opacity-100 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed ${className || ''}`}
        style={{ width: '110px' }}
      >
        {countryCodes.map(({ code, country, flag }) => (
          <option key={code} value={code}>
            {flag} {code}
          </option>
        ))}
      </select>
      <input
        type="tel"
        value={phoneNumber}
        onChange={handleNumberChange}
        disabled={disabled}
        className={`flex-1 px-4 py-3 bg-gray-800 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] placeholder-[#39ff14] placeholder-opacity-40 focus:outline-none focus:border-opacity-100 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed ${className || ''}`}
        placeholder={placeholder || '1234567890'}
      />
    </div>
  );
}
