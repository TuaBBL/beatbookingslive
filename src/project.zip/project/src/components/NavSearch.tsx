import { Search, Music2, MapPin, Youtube, Instagram, Facebook, Music as SoundCloudIcon, Radio, Headphones } from 'lucide-react';
import { useState, useEffect, useRef } from 'react';
import { supabase, Artist } from '../lib/supabase';

interface NavSearchProps {
  onArtistSelect: (artist: Artist) => void;
}

export function NavSearch({ onArtistSelect }: NavSearchProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<Artist[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    if (query.trim().length < 2) {
      setResults([]);
      setIsOpen(false);
      return;
    }

    const searchArtists = async () => {
      setLoading(true);
      try {
        const { data, error } = await supabase
          .from('artist_cards')
          .select('*')
          .or(`name.ilike.%${query}%,stage_name.ilike.%${query}%,genre.ilike.%${query}%,category.ilike.%${query}%`)
          .order('is_premium', { ascending: false })
          .order('featured_priority', { ascending: true, nullsFirst: false })
          .order('name', { ascending: true })
          .limit(10);

        if (error) throw error;
        setResults(data || []);
        setIsOpen(true);
      } catch (error) {
        console.error('Error searching artists:', error);
        setResults([]);
      } finally {
        setLoading(false);
      }
    };

    const debounce = setTimeout(searchArtists, 300);
    return () => clearTimeout(debounce);
  }, [query]);

  const handleSelectArtist = (artist: Artist) => {
    onArtistSelect(artist);
    setQuery('');
    setIsOpen(false);
  };

  return (
    <div ref={searchRef} className="relative w-full max-w-md">
      <div className="relative">
        <input
          type="text"
          placeholder="Search artists..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => query.trim().length >= 2 && setIsOpen(true)}
          className="w-full px-4 py-2 pr-10 bg-gray-900 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] placeholder-[#39ff14] placeholder-opacity-40 focus:outline-none focus:border-opacity-100 transition-all duration-300 text-sm"
          style={{ textShadow: '0 0 5px #ff0000' }}
        />
        <Search
          className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#39ff14] w-5 h-5 opacity-60"
          style={{ filter: 'drop-shadow(0 0 3px #ff0000)' }}
        />
      </div>

      {isOpen && (
        <div className="absolute top-full mt-2 w-full bg-gray-900 border-2 border-[#39ff14] border-opacity-70 rounded-lg shadow-2xl max-h-96 overflow-y-auto z-50 glow-red">
          {loading ? (
            <div className="px-4 py-8 text-center text-fluro-green-subtle">
              Searching...
            </div>
          ) : results.length > 0 ? (
            <div className="py-2">
              {results.map((artist) => (
                <button
                  key={artist.id}
                  onClick={() => handleSelectArtist(artist)}
                  className="w-full px-4 py-3 text-left hover:bg-gray-800 transition-colors duration-200 border-b border-red-500 border-opacity-20 last:border-b-0 flex items-start gap-3 relative"
                >
                  {artist.is_premium && (
                    <div className="absolute top-2 right-2 px-2 py-0.5 bg-[#39ff14] text-black text-xs font-bold rounded">
                      PREMIUM
                    </div>
                  )}
                  <img
                    src={artist.image_url}
                    alt={artist.name}
                    className="w-12 h-12 rounded object-cover border border-red-500 border-opacity-50"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="text-fluro-green-subtle font-semibold truncate">
                      {artist.stage_name || artist.name}
                    </h4>
                    <div className="flex items-center gap-3 text-xs text-[#39ff14] opacity-70 mt-1">
                      <div className="flex items-center gap-1">
                        <Music2 className="w-3 h-3" />
                        <span>{artist.category}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3 h-3" />
                        <span>{artist.location}</span>
                      </div>
                    </div>
                    <div className="flex gap-2 mt-2">
                      {artist.youtube_link && (
                        <a
                          href={artist.youtube_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="text-red-500 hover:text-red-400 transition-colors"
                          title="YouTube"
                        >
                          <Youtube className="w-3 h-3" />
                        </a>
                      )}
                      {artist.instagram_link && (
                        <a
                          href={artist.instagram_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="text-pink-500 hover:text-pink-400 transition-colors"
                          title="Instagram"
                        >
                          <Instagram className="w-3 h-3" />
                        </a>
                      )}
                      {artist.facebook_link && (
                        <a
                          href={artist.facebook_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="text-blue-500 hover:text-blue-400 transition-colors"
                          title="Facebook"
                        >
                          <Facebook className="w-3 h-3" />
                        </a>
                      )}
                      {artist.soundcloud_link && (
                        <a
                          href={artist.soundcloud_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="text-orange-500 hover:text-orange-400 transition-colors"
                          title="SoundCloud"
                        >
                          <SoundCloudIcon className="w-3 h-3" />
                        </a>
                      )}
                      {artist.mixcloud_link && (
                        <a
                          href={artist.mixcloud_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="text-teal-500 hover:text-teal-400 transition-colors"
                          title="Mixcloud"
                        >
                          <Radio className="w-3 h-3" />
                        </a>
                      )}
                      {artist.spotify_link && (
                        <a
                          href={artist.spotify_link}
                          target="_blank"
                          rel="noopener noreferrer"
                          onClick={(e) => e.stopPropagation()}
                          className="text-green-500 hover:text-green-400 transition-colors"
                          title="Spotify"
                        >
                          <Headphones className="w-3 h-3" />
                        </a>
                      )}
                    </div>
                  </div>
                </button>
              ))}
            </div>
          ) : (
            <div className="px-4 py-8 text-center text-fluro-green-subtle opacity-70">
              No artists found matching "{query}"
            </div>
          )}
        </div>
      )}
    </div>
  );
}
