import { useState } from 'react';
import { X, Mail, Lock, Eye, EyeOff } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'signin' | 'signup';
  onUserNeedsProfileSetup?: (userId: string, email: string) => void;
  onArtistNeedsProfileSetup?: (userId: string, email: string) => void;
}

export function AuthModal({ isOpen, onClose, initialMode = 'signin', onUserNeedsProfileSetup, onArtistNeedsProfileSetup }: AuthModalProps) {
  const [mode, setMode] = useState<'signin' | 'signup' | 'forgot'>(initialMode);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setMessage(null);
    setLoading(true);

    try {
      if (mode === 'forgot') {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
          redirectTo: 'https://beatbookingslive.com/reset-password',
        });
        if (error) throw error;
        setMessage('Password reset email sent! Check your inbox.');
        setEmail('');
      } else if (mode === 'signup') {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: 'https://beatbookingslive.com/auth/callback',
            data: {
              role: 'user',
            },
          },
        });
        if (error) throw error;

        if (data.user) {
          if (data.user.identities && data.user.identities.length === 0) {
            setMessage('This email is already registered. Please sign in instead.');
            setEmail('');
            setPassword('');
            setMode('signin');
            return;
          }

          const { error: userError } = await supabase
            .from('users')
            .insert({
              id: data.user.id,
              email: data.user.email!,
              user_type: 'client',
              profile_completed: false,
            });

          if (userError) {
            console.error('Error creating user record:', userError);
          }

          try {
            const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
            const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

            await fetch(`${supabaseUrl}/functions/v1/send-welcome-email`, {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${supabaseAnonKey}`,
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                email: data.user.email,
                name: email.split('@')[0],
                userType: 'planner',
              }),
            });
          } catch (emailError) {
            console.error('Failed to send welcome email:', emailError);
          }

          setMessage('Account created! Redirecting...');
          setTimeout(() => {
            if (onUserNeedsProfileSetup) {
              onUserNeedsProfileSetup(data.user.id, email);
            }
            setPassword('');
          }, 1000);
        }
      } else {
        const { error, data } = await supabase.auth.signInWithPassword({
          email,
          password,
        });
        if (error) throw error;

        if (data.user) {
          const role = data.user.user_metadata?.role;

          const { data: userData } = await supabase
            .from('users')
            .select('user_type, profile_completed, full_name, location, state_territory')
            .eq('id', data.user.id)
            .maybeSingle();

          if (role === 'artist' || userData?.user_type === 'artist') {
            const { data: profile } = await supabase
              .from('artist_profiles')
              .select('*')
              .eq('user_id', data.user.id)
              .maybeSingle();

            if (!profile || !profile.profile_completed) {
              if (onUserNeedsProfileSetup) {
                onClose();
                window.dispatchEvent(new CustomEvent('open-artist-profile-modal', {
                  detail: { userId: data.user.id, email: data.user.email || email }
                }));
              }
              return;
            }
          } else if (role === 'user' || userData?.user_type === 'client') {
            const needsProfileSetup =
              !userData?.profile_completed ||
              !userData?.full_name ||
              !userData?.location ||
              !userData?.state_territory;

            if (needsProfileSetup && onUserNeedsProfileSetup) {
              onUserNeedsProfileSetup(data.user.id, data.user.email || email);
              return;
            }
          }
        }

        setMessage('Signed in successfully!');
        setTimeout(() => {
          onClose();
        }, 1000);
      }
    } catch (err: any) {
      const errorMessage = err.message || 'An error occurred';
      if (errorMessage.includes('User already registered') || errorMessage.includes('user_already_exists')) {
        setError('This email is already registered. Please sign in instead.');
      } else {
        setError(errorMessage);
      }
    } finally {
      setLoading(false);
    }
  };

  const switchMode = () => {
    setMode(mode === 'signin' ? 'signup' : 'signin');
    setError(null);
    setMessage(null);
  };

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-gray-900 rounded-2xl border-2 border-red-500 glow-red-strong max-w-md w-full p-8"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-3xl font-bold text-fluro-green">
            {mode === 'signin' ? 'Sign In' : mode === 'signup' ? 'Sign Up' : 'Reset Password'}
          </h2>
          <button
            onClick={onClose}
            className="text-fluro-green-subtle hover:text-fluro-green transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {error && (
          <div className="mb-4 p-3 bg-red-500 bg-opacity-20 border border-red-500 rounded-lg">
            <p className="text-red-400 text-sm">{error}</p>
          </div>
        )}

        {message && (
          <div className="mb-4 p-3 bg-green-500 bg-opacity-20 border border-green-500 rounded-lg">
            <p className="text-green-400 text-sm">{message}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
              Email
            </label>
            <div className="relative">
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="w-full px-4 py-3 pl-12 bg-gray-800 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] placeholder-[#39ff14] placeholder-opacity-40 focus:outline-none focus:border-opacity-100 transition-all duration-300"
                placeholder="your@email.com"
                style={{ textShadow: '0 0 5px #ff0000' }}
              />
              <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#39ff14] w-5 h-5 opacity-60" />
            </div>
          </div>

          {mode !== 'forgot' && (
            <div>
              <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
                Password
              </label>
              <div className="relative">
                <input
                  type={showPassword ? 'text' : 'password'}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                  minLength={6}
                  className="w-full px-4 py-3 pl-12 pr-12 bg-gray-800 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] placeholder-[#39ff14] placeholder-opacity-40 focus:outline-none focus:border-opacity-100 transition-all duration-300"
                  placeholder="••••••••"
                  style={{ textShadow: '0 0 5px #ff0000' }}
                />
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 text-[#39ff14] w-5 h-5 opacity-60" />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#39ff14] opacity-60 hover:opacity-100 transition-opacity"
                >
                  {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                </button>
              </div>
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full px-6 py-3 bg-[#39ff14] text-black rounded-lg font-bold hover:glow-red-strong transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? 'Loading...' : mode === 'signin' ? 'Sign In' : mode === 'signup' ? 'Create Account' : 'Send Reset Link'}
          </button>
        </form>

        <div className="mt-6 text-center space-y-2">
          {mode === 'signin' && (
            <button
              onClick={() => setMode('forgot')}
              className="text-fluro-green-subtle text-sm hover:text-fluro-green hover:underline transition-colors"
            >
              Forgot password?
            </button>
          )}
          <p className="text-fluro-green-subtle text-sm">
            {mode === 'signin' ? "Don't have an account? " : mode === 'signup' ? 'Already have an account? ' : 'Remember your password? '}
            <button
              onClick={switchMode}
              className="text-fluro-green font-semibold hover:underline"
            >
              {mode === 'signin' ? 'Sign Up' : 'Sign In'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
