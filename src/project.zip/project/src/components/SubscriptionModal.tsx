import { X, Check, Crown } from 'lucide-react';
import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { showToast } from './Toast';

interface SubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function SubscriptionModal({ isOpen, onClose }: SubscriptionModalProps) {
  const [selectedPlan] = useState<'standard'>('standard');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [isFreeForever, setIsFreeForever] = useState(false);
  const [artistCount, setArtistCount] = useState(0);

  useEffect(() => {
    if (isOpen) {
      clearStaleLocalStorage();
      checkFreeEligibility();
    }
  }, [isOpen]);

  const clearStaleLocalStorage = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();

      // If no user or session, clear all subscription-related localStorage
      if (!user) {
        localStorage.removeItem('subscriptionSession');
        localStorage.removeItem('checkoutSessionId');
        localStorage.removeItem('activeSubscription');
        return;
      }

      // Check if user has actual subscription in profiles table
      const { data: profileData } = await supabase
        .from('profiles')
        .select('is_free_forever, subscription_tier')
        .eq('id', user.id)
        .maybeSingle();

      // Check if user has active subscription
      const hasActiveSub = profileData && (
        profileData.is_free_forever === true ||
        profileData.subscription_tier === 'premium' ||
        profileData.subscription_tier === 'standard'
      );

      // If localStorage has session but no DB subscription, clear localStorage
      if (!hasActiveSub && (localStorage.getItem('subscriptionSession') || localStorage.getItem('checkoutSessionId'))) {
        localStorage.removeItem('subscriptionSession');
        localStorage.removeItem('checkoutSessionId');
        localStorage.removeItem('activeSubscription');
      }
    } catch (err) {
      console.error('Error clearing stale localStorage:', err);
      // On error, clear to be safe
      localStorage.removeItem('subscriptionSession');
      localStorage.removeItem('checkoutSessionId');
      localStorage.removeItem('activeSubscription');
    }
  };

  const checkFreeEligibility = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      // Check if user already has free-forever in profiles
      const { data: profileData } = await supabase
        .from('profiles')
        .select('is_free_forever')
        .eq('id', user.id)
        .maybeSingle();

      if (profileData?.is_free_forever) {
        setIsFreeForever(true);
        return;
      }

      // Count total free-forever profiles
      const { count } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true })
        .eq('is_free_forever', true);

      setArtistCount(count || 0);

      // ALL users get free forever (promotion active)
      setIsFreeForever(true);

    } catch (err) {
      console.error('Error checking free eligibility:', err);
    }
  };

  if (!isOpen) return null;

  const handleSubscribe = async () => {
    setLoading(true);
    setError('');

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('You must be logged in');

      const { data: profileData } = await supabase
        .from('profiles')
        .select('id, is_free_forever')
        .eq('id', user.id)
        .maybeSingle();

      if (!profileData) throw new Error('Profile not found');

      // Call create-free-subscription for ALL users (free forever promotion)
      const { data, error } = await supabase.functions.invoke('create-free-subscription', {
        body: { user_id: profileData.id }
      });

      if (error) {
        throw new Error(error.message || 'Failed to activate subscription');
      }

      if (!data?.success) {
        throw new Error('Failed to activate subscription');
      }

      showToast('Success', 'Premium subscription activated!');

      // Hard refresh to update UI
      window.location.reload();

    } catch (err: any) {
      const msg = err.message || 'Subscription error';
      setError(msg);
      showToast('Subscription Error', msg);
    } finally {
      setLoading(false);
    }
  };

  // PLAN DEFINITIONS
  const plans = {
    standard: {
      name: isFreeForever ? 'Premium' : 'Standard',
      price: isFreeForever ? 'FREE FOREVER' : '$25.00 AUD',
      period: isFreeForever ? '' : 'month',
      description: isFreeForever
        ? '🎉 You are one of the first 50 artists! Premium features FREE FOREVER.'
        : 'Get your artist profile listed and discovered across Australia & NZ.',
      features: isFreeForever ? [
        'Featured on homepage',
        'Priority search placement',
        'Premium badge on profile',
        'Enhanced visibility',
        'Top of category listings',
        'Upload photos and videos',
        'Receive booking inquiries',
        'Priority support'
      ] : [
        'Create artist profile',
        'Upload media',
        'Connect socials',
        'Receive inquiries',
        'Availability calendar',
        'Appear in searches'
      ]
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gray-900 rounded-2xl border-2 border-[#39ff14] max-w-5xl w-full max-h-[90vh] overflow-y-auto p-8 relative">

        <button onClick={onClose} className="absolute top-4 right-4 text-white hover:text-[#39ff14] transition-colors">
          <X className="w-6 h-6" />
        </button>

        <div className="text-center mb-8">
          <h2 className="text-4xl font-bold text-[#39ff14]">
            {isFreeForever ? 'Activate Your Premium Subscription' : 'Choose Your Subscription'}
          </h2>

          {isFreeForever && (
            <div className="mt-4 p-4 bg-[#39ff14] bg-opacity-20 border border-[#39ff14] rounded-lg">
              <p className="text-[#39ff14] font-bold">
                🎉 Special Promotion: Premium is FREE FOREVER!
              </p>
              <p className="text-[#39ff14] text-xs mt-2">
                Limited time offer - activate now
              </p>
            </div>
          )}
        </div>

        <div className="grid md:grid-cols-1 gap-6 mb-8 max-w-2xl mx-auto">

          {/* FREE FOREVER VERSION - ONLY OPTION */}
          {isFreeForever && (
            <div className="p-6 rounded-xl border-2 border-[#39ff14] bg-[#39ff14] bg-opacity-10">
              <div className="flex items-center justify-center gap-2 mb-4">
                <Crown className="w-6 h-6 text-[#39ff14]" />
                <h3 className="text-2xl font-bold text-[#39ff14]">Premium (Free Forever)</h3>
              </div>

              <p className="text-[#39ff14] font-bold text-3xl text-center mb-2">FREE FOREVER</p>
              <p className="text-gray-300 text-sm text-center mb-4">{plans.standard.description}</p>

              <ul className="space-y-2 mt-4">
                {plans.standard.features.map((f, i) => (
                  <li key={i} className="flex gap-2 text-[#39ff14]">
                    <Check className="w-5 h-5 flex-shrink-0" /> {f}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* PAID PLAN – only show if NOT free */}
          {!isFreeForever ? (
            <div className="p-6 rounded-xl border-2 border-[#39ff14] bg-[#39ff14] bg-opacity-10">
              <h3 className="text-2xl font-bold text-white mb-2">
                {plans.standard.name}
              </h3>
              <p className="text-[#39ff14] text-4xl font-bold mb-1">
                {plans.standard.price}
              </p>
              <p className="text-gray-400 text-sm mb-1">per {plans.standard.period}</p>
              <p className="text-gray-300 text-sm mb-4">{plans.standard.description}</p>

              <ul className="space-y-2">
                {plans.standard.features.map((f, i) => (
                  <li key={i} className="flex gap-2 text-gray-300">
                    <Check className="w-4 h-4 flex-shrink-0" /> {f}
                  </li>
                ))}
              </ul>
            </div>
          ) : null}
        </div>

        <button
          onClick={handleSubscribe}
          disabled={loading}
          className="w-full px-6 py-4 bg-[#39ff14] text-black font-bold text-lg rounded-lg hover:scale-105 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? 'Processing...' : 'Activate Free Premium Subscription'}
        </button>

        {error && (
          <p className="text-red-500 text-center mt-3 text-sm">{error}</p>
        )}
      </div>
    </div>
  );
}
