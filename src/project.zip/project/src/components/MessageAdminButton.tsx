import { useState } from 'react';
import { MessageCircle, X, Send } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { showToast } from './Toast';

interface MessageAdminButtonProps {
  userId: string;
  userEmail: string;
  variant?: 'floating' | 'inline';
}

export function MessageAdminButton({ userId, userEmail, variant = 'inline' }: MessageAdminButtonProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);

  async function sendMessage() {
    if (!subject.trim() || !message.trim()) {
      showToast('Please fill in all fields', 'error');
      return;
    }

    setSending(true);
    try {
      const { error } = await supabase
        .from('admin_messages')
        .insert({
          sender_id: userId,
          is_from_admin: false,
          recipient_email: 'admin@beatbookingslive.com',
          subject: subject.trim(),
          message: message.trim(),
          status: 'unread'
        });

      if (error) throw error;

      showToast('Message sent to admin successfully', 'success');
      setSubject('');
      setMessage('');
      setIsOpen(false);
    } catch (error) {
      console.error('Error sending message:', error);
      showToast('Failed to send message', 'error');
    } finally {
      setSending(false);
    }
  }

  if (variant === 'floating') {
    return (
      <>
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-40 p-4 bg-[#39ff14] text-black rounded-full shadow-lg hover:shadow-[0_0_30px_rgba(57,255,20,0.5)] transition-all duration-300 hover:scale-110"
          title="Message Admin"
        >
          <MessageCircle className="w-6 h-6" />
        </button>

        {isOpen && (
          <div className="fixed inset-0 bg-black bg-opacity-80 backdrop-blur-sm z-50 overflow-y-auto flex items-center justify-center p-4">
            <div className="bg-gray-900 rounded-2xl border-2 border-[#39ff14] shadow-2xl max-w-2xl w-full">
              <div className="flex items-center justify-between p-6 border-b border-gray-800">
                <div className="flex items-center gap-3">
                  <div className="bg-[#39ff14] bg-opacity-20 rounded-full p-3">
                    <MessageCircle className="w-6 h-6 text-[#39ff14]" />
                  </div>
                  <h2 className="text-2xl font-bold text-[#39ff14]">Message Admin</h2>
                </div>
                <button
                  onClick={() => setIsOpen(false)}
                  className="text-gray-400 hover:text-white transition-colors"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>

              <div className="p-6 space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-[#39ff14] mb-2">
                    Subject
                  </label>
                  <input
                    type="text"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    placeholder="What is this about?"
                    className="w-full px-4 py-3 bg-gray-800 border-2 border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-[#39ff14] transition-colors"
                    maxLength={100}
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-[#39ff14] mb-2">
                    Message
                  </label>
                  <textarea
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Type your message here..."
                    rows={6}
                    className="w-full px-4 py-3 bg-gray-800 border-2 border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-[#39ff14] transition-colors resize-none"
                    maxLength={1000}
                  />
                  <p className="text-xs text-gray-500 mt-1">{message.length}/1000 characters</p>
                </div>

                <button
                  onClick={sendMessage}
                  disabled={!subject.trim() || !message.trim() || sending}
                  className="w-full px-4 py-3 bg-[#39ff14] bg-opacity-20 border-2 border-[#39ff14] text-[#39ff14] rounded-lg hover:bg-[#39ff14] hover:text-black transition-all duration-300 font-semibold disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  {sending ? 'Sending...' : 'Send Message'}
                </button>
              </div>
            </div>
          </div>
        )}
      </>
    );
  }

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="px-4 py-2 bg-[#39ff14] bg-opacity-20 border-2 border-[#39ff14] text-[#39ff14] rounded-lg hover:bg-[#39ff14] hover:text-black transition-all duration-300 font-semibold flex items-center gap-2"
      >
        <MessageCircle className="w-4 h-4" />
        Message Admin
      </button>

      {isOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-80 backdrop-blur-sm z-50 overflow-y-auto flex items-center justify-center p-4">
          <div className="bg-gray-900 rounded-2xl border-2 border-[#39ff14] shadow-2xl max-w-2xl w-full">
            <div className="flex items-center justify-between p-6 border-b border-gray-800">
              <div className="flex items-center gap-3">
                <div className="bg-[#39ff14] bg-opacity-20 rounded-full p-3">
                  <MessageCircle className="w-6 h-6 text-[#39ff14]" />
                </div>
                <h2 className="text-2xl font-bold text-[#39ff14]">Message Admin</h2>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="text-gray-400 hover:text-white transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-semibold text-[#39ff14] mb-2">
                  Subject
                </label>
                <input
                  type="text"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="What is this about?"
                  className="w-full px-4 py-3 bg-gray-800 border-2 border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-[#39ff14] transition-colors"
                  maxLength={100}
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-[#39ff14] mb-2">
                  Message
                </label>
                <textarea
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  placeholder="Type your message here..."
                  rows={6}
                  className="w-full px-4 py-3 bg-gray-800 border-2 border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-[#39ff14] transition-colors resize-none"
                  maxLength={1000}
                />
                <p className="text-xs text-gray-500 mt-1">{message.length}/1000 characters</p>
              </div>

              <button
                onClick={sendMessage}
                disabled={!subject.trim() || !message.trim() || sending}
                className="w-full px-4 py-3 bg-[#39ff14] bg-opacity-20 border-2 border-[#39ff14] text-[#39ff14] rounded-lg hover:bg-[#39ff14] hover:text-black transition-all duration-300 font-semibold disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                <Send className="w-4 h-4" />
                {sending ? 'Sending...' : 'Send Message'}
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
