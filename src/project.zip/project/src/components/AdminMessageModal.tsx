import { useState, useEffect } from 'react';
import { X, Send, Mail } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { showToast } from './Toast';

interface AdminMessageModalProps {
  isOpen: boolean;
  onClose: () => void;
  recipientEmail?: string;
  recipientName?: string;
}

export function AdminMessageModal({ isOpen, onClose, recipientEmail = '', recipientName = '' }: AdminMessageModalProps) {
  const [email, setEmail] = useState(recipientEmail);
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [sending, setSending] = useState(false);

  useEffect(() => {
    if (isOpen) {
      setEmail(recipientEmail);
      setSubject('');
      setMessage('');
    }
  }, [isOpen, recipientEmail]);

  if (!isOpen) return null;

  async function handleSendMessage(e: React.FormEvent) {
    e.preventDefault();

    if (!email.trim() || !subject.trim() || !message.trim()) {
      showToast('Please fill in all fields', 'error');
      return;
    }

    if (!email.includes('@')) {
      showToast('Please enter a valid email address', 'error');
      return;
    }

    setSending(true);

    try {
      // Refresh session to ensure we have the latest JWT with admin role
      const { data: { session } } = await supabase.auth.refreshSession();

      if (!session?.user) {
        showToast('You must be logged in to send messages. Please log out and log back in.', 'error');
        return;
      }

      const { error } = await supabase
        .from('admin_messages')
        .insert({
          admin_id: session.user.id,
          recipient_email: email.trim().toLowerCase(),
          subject: subject.trim(),
          message: message.trim(),
        });

      if (error) {
        console.error('Error sending message:', error);
        showToast(`Failed to send message: ${error.message}`, 'error');
        return;
      }

      showToast('Message sent successfully!', 'success');

      setEmail('');
      setSubject('');
      setMessage('');
      onClose();
    } catch (error) {
      console.error('Error sending message:', error);
      showToast('Failed to send message', 'error');
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-80 backdrop-blur-sm z-50 overflow-y-auto flex items-center justify-center p-4">
      <div className="bg-gray-900 rounded-2xl border-2 border-[#39ff14] shadow-2xl max-w-2xl w-full">
        <div className="flex items-center justify-between p-6 border-b border-gray-800">
          <div className="flex items-center gap-3">
            <div className="bg-[#39ff14] bg-opacity-20 rounded-full p-3">
              <Mail className="w-6 h-6 text-[#39ff14]" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-[#39ff14]">Send Admin Message</h2>
              {recipientName && (
                <p className="text-sm text-gray-400">To: {recipientName}</p>
              )}
              <p className="text-xs text-gray-500 mt-1">Admin use only - Messages sent to users and artists</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
            disabled={sending}
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSendMessage} className="p-6 space-y-4">
          <div>
            <label htmlFor="email" className="block text-sm font-semibold text-[#39ff14] mb-2">
              Recipient Email *
            </label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full px-4 py-3 bg-gray-800 border-2 border-gray-700 rounded-lg text-white focus:border-[#39ff14] focus:outline-none transition-colors"
              placeholder="user@example.com"
              required
              disabled={sending || !!recipientEmail}
            />
            <p className="text-xs text-gray-400 mt-1">
              Enter the email address of the user or artist you want to message
            </p>
          </div>

          <div>
            <label htmlFor="subject" className="block text-sm font-semibold text-[#39ff14] mb-2">
              Subject *
            </label>
            <input
              type="text"
              id="subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full px-4 py-3 bg-gray-800 border-2 border-gray-700 rounded-lg text-white focus:border-[#39ff14] focus:outline-none transition-colors"
              placeholder="Message subject"
              required
              disabled={sending}
              maxLength={200}
            />
          </div>

          <div>
            <label htmlFor="message" className="block text-sm font-semibold text-[#39ff14] mb-2">
              Message *
            </label>
            <textarea
              id="message"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="w-full px-4 py-3 bg-gray-800 border-2 border-gray-700 rounded-lg text-white focus:border-[#39ff14] focus:outline-none transition-colors resize-none"
              placeholder="Type your message here..."
              required
              disabled={sending}
              rows={8}
              maxLength={5000}
            />
            <p className="text-xs text-gray-400 mt-1">
              {message.length} / 5000 characters
            </p>
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 bg-gray-800 border-2 border-gray-700 text-white rounded-lg font-semibold hover:bg-gray-700 transition-all duration-300"
              disabled={sending}
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-[#39ff14] text-black rounded-lg font-semibold hover:shadow-lg hover:shadow-[#39ff14]/50 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
              disabled={sending}
            >
              {sending ? (
                <>
                  <div className="w-5 h-5 border-2 border-black border-t-transparent rounded-full animate-spin" />
                  Sending...
                </>
              ) : (
                <>
                  <Send className="w-5 h-5" />
                  Send Message
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
