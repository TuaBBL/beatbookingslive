import { X, MapPin, DollarSign, Star, Play, Image as ImageIcon, Calendar, Mail, Phone } from 'lucide-react';
import { useState } from 'react';
import { Artist, supabase } from '../lib/supabase';
import { MediaViewer } from './MediaViewer';
import { BookingRequestModal } from './BookingRequestModal';
import { getThemeClasses, getThemeColors } from '../lib/themeUtils';

interface ArtistDetailViewProps {
  artist: Artist | null;
  onClose: () => void;
  reviews: any[];
  onSignIn?: () => void;
  isLoggedIn?: boolean;
}

export function ArtistDetailView({ artist, onClose, reviews, onSignIn, isLoggedIn = false }: ArtistDetailViewProps) {
  const [mediaViewerOpen, setMediaViewerOpen] = useState(false);
  const [selectedMediaIndex, setSelectedMediaIndex] = useState(0);
  const [bookingModalOpen, setBookingModalOpen] = useState(false);

  if (!artist) return null;

  const theme = getThemeClasses(artist.profile_theme);
  const themeColors = getThemeColors(artist.profile_theme);

  const allImages = [
    { type: 'image' as const, url: artist.image_url },
    ...(artist.additional_images || []).map(url => ({ type: 'image' as const, url }))
  ];

  const allVideos = (artist.video_urls || []).map(url => ({ type: 'video' as const, url }));
  const allMedia = [...allImages, ...allVideos];

  const socialLinks = [
    { platform: 'YouTube', url: artist.youtube_link, icon: '🎥' },
    { platform: 'Instagram', url: artist.instagram_link, icon: '📸' },
    { platform: 'Facebook', url: artist.facebook_link, icon: '👥' },
    { platform: 'SoundCloud', url: artist.soundcloud_link, icon: '🎵' },
    { platform: 'Mixcloud', url: artist.mixcloud_link, icon: '🎧' },
    { platform: 'Spotify', url: artist.spotify_link, icon: '🎶' },
    { platform: 'TikTok', url: artist.tiktok_link, icon: '📱' },
  ].filter(link => link.url && link.url.trim() !== '');

  const avgRating = reviews.length > 0
    ? reviews.reduce((acc, r) => acc + r.rating, 0) / reviews.length
    : typeof artist.rating === 'number'
    ? artist.rating
    : parseFloat(artist.rating || '0');

  const handleMediaClick = (index: number) => {
    setSelectedMediaIndex(index);
    setMediaViewerOpen(true);
    trackPortfolioView();
  };

  const handleBookingClick = () => {
    setBookingModalOpen(true);
    trackBookingClick();
  };

  const handleSocialClick = async () => {
    try {
      await supabase.rpc('increment_analytics_metric', {
        p_artist_id: artist.id,
        p_metric: 'social_clicks'
      });
    } catch (error) {
      console.error('Error tracking social click:', error);
    }
  };

  const trackBookingClick = async () => {
    try {
      await supabase.rpc('increment_analytics_metric', {
        p_artist_id: artist.id,
        p_metric: 'booking_button_clicks'
      });
    } catch (error) {
      console.error('Error tracking booking click:', error);
    }
  };

  const trackPortfolioView = async () => {
    try {
      await supabase.rpc('increment_analytics_metric', {
        p_artist_id: artist.id,
        p_metric: 'portfolio_views'
      });
    } catch (error) {
      console.error('Error tracking portfolio view:', error);
    }
  };

  const renderStars = (rating: number) => {
    return (
      <div className="flex items-center gap-1">
        {[...Array(5)].map((_, i) => (
          <Star
            key={i}
            className={`w-4 h-4 ${
              i < Math.floor(rating)
                ? 'fill-[#39ff14] text-[#39ff14]'
                : 'text-gray-600'
            }`}
          />
        ))}
      </div>
    );
  };

  return (
    <>
      <div className="fixed inset-0 bg-black bg-opacity-90 backdrop-blur-sm z-40 flex items-center justify-center p-4" onClick={onClose}>
        <div className={`bg-gray-900 rounded-2xl ${theme.border} ${theme.glowStrong} max-w-7xl w-full relative`} onClick={(e) => e.stopPropagation()} style={{ maxHeight: 'calc(100vh - 2rem)', overflowY: 'auto', WebkitOverflowScrolling: 'touch' }}>
          <div className="sticky top-0 left-0 right-0 z-50 flex justify-end p-2 md:p-4 pointer-events-none">
            <button
              onClick={onClose}
              className="bg-black bg-opacity-90 rounded-full p-2 md:p-3 text-fluro-green-subtle hover:text-fluro-green hover:bg-opacity-100 transition-all duration-300 shadow-lg pointer-events-auto"
              style={{ minWidth: '44px', minHeight: '44px' }}
            >
              <X className="w-5 h-5 md:w-6 md:h-6" />
            </button>
          </div>
          <div className="relative -mt-14 md:-mt-16">


            <div className="relative h-48 sm:h-64 md:h-80 lg:h-96 rounded-t-2xl overflow-hidden">
              <img
                src={artist.image_url}
                alt={artist.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-gray-900 via-transparent to-transparent"></div>
              <div className="absolute bottom-6 left-6 right-6">
                <div className="flex items-center gap-2 mb-2 flex-wrap">
                  {artist.stage_name && (
                    <span className="px-3 py-1 bg-[#39ff14] text-black text-sm font-bold rounded-full">
                      {artist.stage_name}
                    </span>
                  )}
                  <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                    artist.availability === 'available'
                      ? 'bg-[#39ff14] bg-opacity-20 border border-[#39ff14] text-[#39ff14]'
                      : 'bg-red-500 bg-opacity-20 border border-red-500 text-red-500'
                  }`}>
                    {artist.availability === 'available' ? 'Available' : 'Booked'}
                  </span>
                  {artist.is_verified && (
                    <span className="px-3 py-1 bg-blue-500 text-white text-sm font-bold rounded-full flex items-center gap-1">
                      <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                      </svg>
                      VERIFIED
                    </span>
                  )}
                  {artist.is_demo && (
                    <span className="px-3 py-1 bg-orange-500 text-white text-sm font-bold rounded-full">
                      DEMO
                    </span>
                  )}
                </div>
                <h2 className="text-4xl md:text-5xl font-bold text-white mb-2">{artist.stage_name || artist.name}</h2>
                <div className="flex flex-wrap items-center gap-4 text-fluro-green-subtle">
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4" />
                    <span>{artist.location}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    {renderStars(avgRating)}
                    <span>{avgRating.toFixed(1)}</span>
                    <span className="text-gray-500">({reviews.length} reviews)</span>
                  </div>
                </div>
              </div>
            </div>

            <div className="p-6 md:p-8 overflow-hidden">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div className="lg:col-span-2 space-y-8 min-w-0">
                  <section>
                    <h3 className="text-2xl font-bold text-fluro-green mb-4">About</h3>
                    <p className="text-fluro-green-subtle leading-relaxed whitespace-pre-line break-words overflow-wrap-anywhere">
                      {artist.about}
                    </p>
                  </section>

                  {allMedia.length > 0 && (
                    <section>
                      <div className="flex items-center justify-between mb-4">
                        <h3 className="text-2xl font-bold text-fluro-green">Portfolio</h3>
                        <span className="text-sm text-fluro-green-subtle">
                          {allImages.length} {allImages.length === 1 ? 'Image' : 'Images'} • {allVideos.length} {allVideos.length === 1 ? 'Video' : 'Videos'}
                        </span>
                      </div>
                      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                        {allMedia.slice(0, 9).map((media, index) => (
                          <button
                            key={index}
                            onClick={() => handleMediaClick(index)}
                            className="relative aspect-square rounded-lg overflow-hidden bg-gray-800 hover:scale-105 transition-transform duration-300 group"
                          >
                            {media.type === 'video' ? (
                              <div className="w-full h-full bg-black flex items-center justify-center">
                                <Play className="w-12 h-12 text-fluro-green group-hover:scale-110 transition-transform duration-300" />
                              </div>
                            ) : (
                              <img
                                src={media.url}
                                alt={`Portfolio ${index + 1}`}
                                className="w-full h-full object-cover"
                              />
                            )}
                            <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-40 transition-all duration-300 flex items-center justify-center">
                              {media.type === 'image' ? (
                                <ImageIcon className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                              ) : (
                                <Play className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
                              )}
                            </div>
                          </button>
                        ))}
                      </div>
                      {allMedia.length > 9 && (
                        <button
                          onClick={() => handleMediaClick(0)}
                          className="mt-4 w-full px-4 py-3 bg-[#39ff14] bg-opacity-20 border-2 border-[#39ff14] text-[#39ff14] rounded-lg font-semibold hover:bg-opacity-30 transition-all duration-300"
                        >
                          View All {allMedia.length} Items
                        </button>
                      )}
                    </section>
                  )}

                  {reviews.length > 0 && (
                    <section>
                      <h3 className="text-2xl font-bold text-fluro-green mb-4">Reviews</h3>
                      <div className="space-y-4">
                        {reviews.slice(0, 3).map((review) => (
                          <div key={review.id} className="bg-gray-800 rounded-lg p-4 border border-gray-700">
                            <div className="flex items-center justify-between mb-2">
                              {renderStars(review.rating)}
                              <span className="text-sm text-gray-500">
                                {new Date(review.created_at).toLocaleDateString()}
                              </span>
                            </div>
                            <p className="text-fluro-green-subtle">{review.comment}</p>
                          </div>
                        ))}
                      </div>
                    </section>
                  )}
                </div>

                <div className="lg:col-span-1 space-y-6">
                  <div className={`bg-gray-800 rounded-lg p-6 ${theme.border} ${theme.glow} sticky top-4`}>
                    <h3 className="text-xl font-bold text-fluro-green mb-4">Booking Information</h3>
                    <div className="space-y-4">
                      {artist.cost && isLoggedIn && (
                        <div className="flex items-start gap-3">
                          <DollarSign className="w-5 h-5 text-fluro-green-subtle flex-shrink-0 mt-0.5" />
                          <div>
                            <p className="text-sm text-fluro-green-subtle">Starting Rate</p>
                            <p className="text-2xl font-bold text-fluro-green">
                              ${(typeof artist.cost === 'number' ? artist.cost : parseFloat(artist.cost || '0')).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                            </p>
                            <p className="text-xs text-gray-500">
                              {artist.cost_type === 'per_hour' ? 'per hour' : artist.cost_type === 'per_event' ? 'per event' : 'per event/hour'}
                            </p>
                          </div>
                        </div>
                      )}

                      <div className="flex items-start gap-3">
                        <Calendar className="w-5 h-5 text-fluro-green-subtle flex-shrink-0 mt-0.5" />
                        <div>
                          <p className="text-sm text-fluro-green-subtle">Category</p>
                          <p className="text-lg font-semibold text-fluro-green">{artist.category}</p>
                          {artist.genre && (
                            <p className="text-sm text-gray-400">{artist.genre}</p>
                          )}
                        </div>
                      </div>

                      {artist.is_demo ? (
                        <div className="w-full px-6 py-3 bg-gray-700 text-gray-400 rounded-lg font-bold text-center cursor-not-allowed">
                          Demo Profile – Not Bookable
                        </div>
                      ) : isLoggedIn ? (
                        <button
                          onClick={handleBookingClick}
                          className={`w-full px-6 py-3 bg-[#39ff14] text-black rounded-lg font-bold ${theme.hoverGlow} transition-all duration-300 transform hover:scale-105`}
                        >
                          Request Booking
                        </button>
                      ) : (
                        <button
                          onClick={onSignIn}
                          className={`w-full px-6 py-3 bg-[#39ff14] text-black rounded-lg font-bold ${theme.hoverGlow} transition-all duration-300 transform hover:scale-105`}
                        >
                          Sign In to Book
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <MediaViewer
        isOpen={mediaViewerOpen}
        media={allMedia}
        initialIndex={selectedMediaIndex}
        onClose={() => setMediaViewerOpen(false)}
      />

      <BookingRequestModal
        isOpen={bookingModalOpen}
        onClose={() => setBookingModalOpen(false)}
        artistId={artist.id}
        artistName={artist.stage_name || artist.name}
        artistEmail={artist.email}
      />
    </>
  );
}
