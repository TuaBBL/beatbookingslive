import { Loader2, Lock, AlertCircle } from 'lucide-react';
import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

interface ProfileCompletionLockScreenProps {
  message?: string;
  showSpinner?: boolean;
}

export function ProfileCompletionLockScreen({
  message = 'Loading your profile...',
  showSpinner = true
}: ProfileCompletionLockScreenProps) {
  const [showEscapeHatch, setShowEscapeHatch] = useState(false);
  const [countdown, setCountdown] = useState(15);

  // Show escape hatch after 15 seconds as a safety measure
  useEffect(() => {
    if (!showSpinner) return; // Only for loading states

    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          setShowEscapeHatch(true);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [showSpinner]);

  const handleEmergencySignOut = async () => {
    console.log('[ProfileCompletionLockScreen] Emergency sign out triggered');
    await supabase.auth.signOut();
    window.location.reload();
  };

  return (
    <div className="fixed inset-0 z-[9999] bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center">
      <div className="text-center px-4 max-w-md">
        {showSpinner ? (
          <>
            <Loader2 className="w-16 h-16 text-[#39ff14] animate-spin mx-auto mb-6" />
            <p className="text-[#39ff14] text-xl font-semibold mb-2">{message}</p>
            <p className="text-gray-400 text-sm mb-4">Please wait while we check your profile...</p>

            {!showEscapeHatch && countdown > 0 && (
              <p className="text-gray-500 text-xs">
                If this takes too long, an option to continue will appear in {countdown}s
              </p>
            )}

            {showEscapeHatch && (
              <div className="mt-6 p-4 bg-red-900 bg-opacity-20 border border-red-500 rounded-lg">
                <AlertCircle className="w-8 h-8 text-red-500 mx-auto mb-2" />
                <p className="text-red-400 text-sm mb-3">
                  Profile check is taking longer than expected.
                </p>
                <button
                  onClick={handleEmergencySignOut}
                  className="px-4 py-2 bg-red-500 text-white rounded-lg font-semibold hover:bg-red-600 transition-colors"
                >
                  Sign Out and Try Again
                </button>
              </div>
            )}
          </>
        ) : (
          <>
            <Lock className="w-16 h-16 text-[#39ff14] mx-auto mb-6" />
            <p className="text-[#39ff14] text-xl font-semibold mb-2">Profile Setup Required</p>
            <p className="text-gray-400 text-sm">Please complete your profile to continue.</p>
          </>
        )}
      </div>
    </div>
  );
}
