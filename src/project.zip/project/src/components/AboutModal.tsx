import { X } from 'lucide-react';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AboutModal({ isOpen, onClose }: AboutModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 border-2 border-[#39ff14] rounded-lg w-full max-w-4xl max-h-[90vh] overflow-y-auto shadow-[0_0_30px_rgba(57,255,20,0.3)]">
        <div className="sticky top-0 bg-gray-900 border-b border-[#39ff14]/30 p-6 flex justify-between items-center">
          <h2 className="text-3xl font-bold text-[#39ff14]" style={{ textShadow: '0 0 10px #ff0000' }}>
            About Us
          </h2>
          <button
            onClick={onClose}
            className="text-red-500 hover:text-red-400 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 md:p-8 space-y-6 text-gray-200">
          <div>
            <h3 className="text-2xl font-bold text-[#39ff14] mb-3">BeatBookingsLive — About Us</h3>
            <p className="leading-relaxed">
              Kia ora Koutou & welcome to BeatBookingsLive.
              I'm Gene Tua, the founder — a DJ with over 15 years experience behind the decks across Australia and New Zealand. After spending years in the industry, working with planners, venues, artists, and promoters, I kept seeing the same problem:
            </p>
          </div>

          <p className="text-xl font-semibold text-[#39ff14] italic">
            There was no simple, user-friendly way to connect planners with musicians.
          </p>

          <div className="space-y-2">
            <p>Planners were constantly searching through socials, inboxes, random referrals, and unreliable pages…</p>
            <p>Artists were struggling to get discovered, wasting time managing DMs, and missing opportunities.</p>
          </div>

          <div className="space-y-2 text-center">
            <p className="text-lg font-semibold text-red-500">The system was scattered.</p>
            <p className="text-lg font-semibold text-red-500">The process was outdated.</p>
          </div>

          <p className="text-lg font-semibold">So I decided to build something better.</p>

          <div>
            <h3 className="text-2xl font-bold text-[#39ff14] mb-3">🎧 Why BeatBookingsLive was created</h3>
            <p className="leading-relaxed mb-4">
              BeatBookingsLive was born from a simple idea:
            </p>
            <p className="text-xl font-semibold text-[#39ff14] mb-4">
              Create one clean platform where planners and musicians can find each other effortlessly.
            </p>
            <p className="mb-2">A place where:</p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Artists can showcase who they are</li>
              <li>Planners can explore talent in seconds</li>
              <li>Communication is straightforward</li>
              <li>No middleman</li>
              <li>No commissions</li>
              <li>No complicated booking system</li>
            </ul>
            <p className="mt-4 text-lg font-semibold text-[#39ff14]">Just connection done right.</p>
          </div>

          <div className="space-y-2">
            <p>Whether you're a DJ, artist, or performer…</p>
            <p>Or an event planner, venue owner, or organiser…</p>
            <p className="text-lg font-semibold text-[#39ff14]">
              BeatBookingsLive brings the entire community together in one place.
            </p>
          </div>

          <div>
            <h3 className="text-2xl font-bold text-[#39ff14] mb-3">🌏 Our Mission</h3>
            <p className="leading-relaxed mb-4">Our mission is to:</p>
            <p className="text-xl font-semibold text-[#39ff14] mb-4">
              Empower artists. Streamline planning. Build a connected entertainment culture across NZ and Australia.
            </p>
            <p className="mb-2">We want to:</p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Give artists a place to shine</li>
              <li>Help planners discover talent quickly</li>
              <li>Bridge the gap between two worlds</li>
              <li>Make communication fast, clean, and safe</li>
              <li>Support creative industries with modern tools</li>
            </ul>
            <p className="mt-4 font-semibold">
              BeatBookingsLive exists to make the industry better for everyone — artists AND planners.
            </p>
          </div>

          <div>
            <h3 className="text-2xl font-bold text-[#39ff14] mb-3">🚀 Our Future & Expansion</h3>
            <p className="leading-relaxed mb-4">This is just the beginning.</p>
            <p className="mb-2">Our vision includes:</p>
            <ul className="list-disc list-inside space-y-2 ml-4">
              <li>Expanding across Australia & New Zealand</li>
              <li>Adding more categories of performers</li>
              <li>Enhancing messaging tools</li>
              <li>Giving artists better profile features</li>
              <li>Adding planner tools & discovery filters</li>
              <li>Building a supportive creative ecosystem</li>
              <li>Eventually taking BeatBookingsLive global</li>
            </ul>
            <p className="mt-4">
              We're here to create long-term opportunities, long-term connections, and a platform that continues to grow with the industry.
            </p>
          </div>

          <div>
            <h3 className="text-2xl font-bold text-[#39ff14] mb-3">❤️ Join Us</h3>
            <p className="leading-relaxed mb-4">
              Whether you're planning an event or performing at one, BeatBookingsLive is here to support you, empower you, and connect you with the people who need your talent.
            </p>
            <div className="space-y-2 text-center">
              <p className="text-lg font-semibold">This platform isn't just a tool —</p>
              <p className="text-lg font-semibold text-[#39ff14]">
                it's a movement for the entertainment community across NZ and Australia.
              </p>
            </div>
          </div>

          <div className="text-center space-y-2 pt-4 border-t border-[#39ff14]/30">
            <p className="text-xl font-bold text-[#39ff14]">Welcome to BeatBookingsLive.</p>
            <p className="text-lg font-semibold text-red-500">Let's build something massive together.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
