import { User, MapPin, Phone, Mail, Calendar, Star, Heart, History } from 'lucide-react';
import { useState, useEffect } from 'react';
import { supabase, Artist } from '../lib/supabase';

interface UserProfileViewProps {
  user: {
    id: string;
    email: string;
    full_name: string;
    location: string;
    phone_number: string | null;
    profile_image_url: string | null;
    created_at: string;
  };
  onSelectArtist?: (artist: Artist) => void;
}

interface Booking {
  id: string;
  artist_id: number;
  requested_date: string;
  status: string;
  created_at: string;
  artist?: Artist;
}

export function UserProfileView({ user, onSelectArtist }: UserProfileViewProps) {
  const [favorites, setFavorites] = useState<Artist[]>([]);
  const [bookingHistory, setBookingHistory] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUserData();
  }, [user.id]);

  async function fetchUserData() {
    setLoading(true);
    try {
      const [favoritesData, bookingsData] = await Promise.all([
        fetchFavorites(),
        fetchBookingHistory(),
      ]);
      setFavorites(favoritesData);
      setBookingHistory(bookingsData);
    } catch (error) {
      console.error('Error fetching user data:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchFavorites() {
    console.log('UserProfileView - fetchFavorites called with user.id:', user.id);
    const { data, error } = await supabase
      .from('user_favorites')
      .select(`
        id,
        artist_id,
        artist_cards!user_favorites_artist_id_fkey (*)
      `)
      .eq('user_id', user.id);

    console.log('UserProfileView - Favorites result:', { data, error });

    if (error) {
      console.error('Error fetching favorites:', error);
      return [];
    }

    const favorites = data?.map((fav: any) => fav.artist_cards) || [];
    console.log('UserProfileView - Mapped favorites:', favorites.length);
    return favorites;
  }

  async function fetchBookingHistory() {
    const { data, error } = await supabase
      .from('bookings')
      .select(`
        *,
        artist:artist_cards!bookings_artist_id_fkey (*)
      `)
      .eq('user_email', user.email)
      .order('created_at', { ascending: false })
      .limit(5);

    if (error) {
      console.error('Error fetching booking history:', error);
      return [];
    }

    return data || [];
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'confirmed':
        return 'text-green-400 border-green-400';
      case 'pending':
        return 'text-yellow-400 border-yellow-400';
      case 'cancelled':
        return 'text-red-400 border-red-400';
      default:
        return 'text-gray-400 border-gray-400';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  return (
    <div className="bg-gradient-to-br from-gray-900 via-black to-gray-900 rounded-2xl border-2 border-[#39ff14] glow-green p-8 space-y-8">
      <div className="flex flex-col md:flex-row gap-8 items-start">
        <div className="flex-shrink-0">
          {user.profile_image_url ? (
            <img
              src={user.profile_image_url}
              alt={user.full_name}
              className="w-40 h-40 rounded-full object-cover border-4 border-[#39ff14] glow-green"
            />
          ) : (
            <div className="w-40 h-40 rounded-full bg-gradient-to-br from-gray-800 to-gray-900 border-4 border-[#39ff14] glow-green flex items-center justify-center">
              <User className="w-20 h-20 text-[#39ff14]" />
            </div>
          )}
        </div>

        <div className="flex-grow space-y-4">
          <div>
            <h2 className="text-4xl font-bold text-[#39ff14] mb-2 drop-shadow-[0_0_8px_rgba(57,255,20,0.8)]">
              {user.full_name}
            </h2>
            <div className="flex flex-wrap gap-4 text-fluro-green-subtle">
              <div className="flex items-center gap-2">
                <Mail className="w-5 h-5" />
                <span>{user.email}</span>
              </div>
              {user.location && (
                <div className="flex items-center gap-2">
                  <MapPin className="w-5 h-5" />
                  <span>{user.location}</span>
                </div>
              )}
              {user.phone_number && (
                <div className="flex items-center gap-2">
                  <Phone className="w-5 h-5" />
                  <span>{user.phone_number}</span>
                </div>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 text-gray-400">
            <Calendar className="w-4 h-4" />
            <span className="text-sm">Member since {formatDate(user.created_at)}</span>
          </div>

          <div className="grid grid-cols-2 gap-4 pt-4">
            <div className="bg-gray-900 border border-gray-700 rounded-lg p-4">
              <div className="flex items-center gap-2 text-[#39ff14] mb-2">
                <Heart className="w-5 h-5" />
                <span className="font-semibold">Favorites</span>
              </div>
              <p className="text-3xl font-bold text-fluro-green-subtle">{favorites.length}</p>
            </div>
            <div className="bg-gray-900 border border-gray-700 rounded-lg p-4">
              <div className="flex items-center gap-2 text-[#39ff14] mb-2">
                <History className="w-5 h-5" />
                <span className="font-semibold">Bookings</span>
              </div>
              <p className="text-3xl font-bold text-fluro-green-subtle">{bookingHistory.length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Favorite Artists Library Section */}
      <div className="border-t border-gray-700 pt-8">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-[#39ff14] bg-opacity-20 rounded-lg">
            <Star className="w-7 h-7 text-[#39ff14]" />
          </div>
          <div>
            <h3 className="text-3xl font-bold text-[#39ff14] drop-shadow-[0_0_8px_rgba(57,255,20,0.8)]">
              My Favorite Artists Library
            </h3>
            <p className="text-fluro-green-subtle text-sm mt-1">
              {favorites.length} {favorites.length === 1 ? 'artist' : 'artists'} in your collection
            </p>
          </div>
        </div>

        {favorites.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {favorites.map((artist) => (
              <div
                key={artist.id}
                onClick={() => onSelectArtist && onSelectArtist(artist)}
                className="bg-gray-900 rounded-xl overflow-hidden border-2 border-gray-700 hover:border-[#39ff14] glow-green-subtle hover:glow-green transition-all duration-300 cursor-pointer group transform hover:scale-105"
              >
                <div className="relative overflow-hidden h-48">
                  <img
                    src={artist.image_url}
                    alt={artist.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-80"></div>
                  {artist.is_premium && (
                    <div className="absolute top-2 right-2 px-2 py-1 bg-[#39ff14] text-black text-xs font-bold rounded">
                      PREMIUM
                    </div>
                  )}
                  <div className="absolute bottom-0 left-0 right-0 p-4">
                    <div className="flex items-center gap-2 mb-1">
                      <Heart className="w-4 h-4 text-red-500 fill-red-500" />
                      <span className="text-xs text-gray-300">Favorite</span>
                    </div>
                  </div>
                </div>
                <div className="p-4">
                  <h4 className="text-lg font-bold text-[#39ff14] mb-1 truncate group-hover:text-shadow-[0_0_8px_rgba(57,255,20,0.8)]">
                    {artist.stage_name || artist.name}
                  </h4>
                  <p className="text-sm text-fluro-green-subtle mb-1">{artist.category}</p>
                  {artist.genre && (
                    <p className="text-xs text-gray-400 truncate">{artist.genre}</p>
                  )}
                  {artist.location && (
                    <div className="flex items-center gap-1 mt-2 text-xs text-gray-400">
                      <MapPin className="w-3 h-3" />
                      <span className="truncate">{artist.location}</span>
                    </div>
                  )}
                  {artist.average_rating > 0 && (
                    <div className="flex items-center gap-1 mt-2">
                      <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                      <span className="text-sm text-yellow-400 font-semibold">
                        {artist.average_rating.toFixed(1)}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="bg-gray-900 border-2 border-dashed border-gray-700 rounded-xl p-12 text-center">
            <Heart className="w-16 h-16 text-gray-600 mx-auto mb-4" />
            <h4 className="text-xl font-semibold text-gray-400 mb-2">No Favorite Artists Yet</h4>
            <p className="text-gray-500 text-sm">
              Start exploring and add artists to your favorites by clicking the heart icon on their profiles
            </p>
          </div>
        )}
      </div>

      {bookingHistory.length > 0 && (
        <div className="border-t border-gray-700 pt-6">
          <div className="flex items-center gap-2 mb-4">
            <History className="w-6 h-6 text-[#39ff14]" />
            <h3 className="text-2xl font-bold text-[#39ff14]">Recent Bookings</h3>
          </div>
          <div className="space-y-3">
            {bookingHistory.map((booking) => (
              <div
                key={booking.id}
                className="bg-gray-900 border border-gray-700 rounded-lg p-4 hover:border-[#39ff14] transition-all duration-300"
              >
                <div className="flex items-center justify-between gap-4">
                  <div className="flex items-center gap-4 flex-grow">
                    {booking.artist && (
                      <img
                        src={booking.artist.image_url}
                        alt={booking.artist.name}
                        className="w-12 h-12 rounded-full object-cover border-2 border-gray-700"
                      />
                    )}
                    <div className="flex-grow">
                      <h4 className="font-semibold text-fluro-green-subtle">
                        {booking.artist?.stage_name || booking.artist?.name}
                      </h4>
                      <p className="text-sm text-gray-400">
                        {formatDate(booking.requested_date)}
                      </p>
                    </div>
                  </div>
                  <div className={`px-3 py-1 border rounded-full text-xs font-semibold uppercase ${getStatusColor(booking.status)}`}>
                    {booking.status}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {loading && (
        <div className="flex items-center justify-center py-12">
          <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-[#39ff14]"></div>
        </div>
      )}
    </div>
  );
}
