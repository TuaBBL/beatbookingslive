import React, { useState } from 'react';
import { Check, Crown, Star } from 'lucide-react';
import { stripeProducts } from '../../stripe-config';
import { useAuth } from '../../hooks/useAuth';
import { createCheckoutSession } from '../../lib/stripe';

export function SubscriptionPlans() {
  const { user } = useAuth();
  const [loading, setLoading] = useState<string | null>(null);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const handleSubscribe = async (priceId: string) => {
    if (!user) {
      setMessage({ type: 'error', text: 'Please sign in to subscribe' });
      return;
    }

    setLoading(priceId);
    setMessage(null);

    try {
      const { url } = await createCheckoutSession({
        priceId,
        mode: 'subscription',
        successUrl: `${window.location.origin}/subscription/success`,
        cancelUrl: `${window.location.origin}/subscription`,
      });

      if (url) {
        window.location.href = url;
      }
    } catch (error) {
      console.error('Checkout error:', error);
      setMessage({ type: 'error', text: 'Failed to start checkout process. Please try again.' });
    } finally {
      setLoading(null);
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-12 px-4">
      <div className="text-center mb-12">
        <h1 className="text-4xl font-bold text-gray-900 mb-4">Choose Your Plan</h1>
        <p className="text-xl text-gray-600">
          Get your music career started with our artist listing plans
        </p>
      </div>

      {message && (
        <div className={`mb-6 p-4 rounded-md ${
          message.type === 'error' 
            ? 'bg-red-50 text-red-700 border border-red-200' 
            : 'bg-green-50 text-green-700 border border-green-200'
        }`}>
          {message.text}
        </div>
      )}

      <div className="grid md:grid-cols-2 gap-8">
        {stripeProducts.map((product) => {
          const isPremium = product.name.includes('Premium');
          
          return (
            <div
              key={product.priceId}
              className={`relative bg-white rounded-2xl shadow-lg border-2 ${
                isPremium ? 'border-yellow-400' : 'border-gray-200'
              } p-8`}
            >
              {isPremium && (
                <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                  <div className="bg-yellow-400 text-yellow-900 px-4 py-1 rounded-full text-sm font-semibold flex items-center">
                    <Crown className="w-4 h-4 mr-1" />
                    Most Popular
                  </div>
                </div>
              )}

              <div className="text-center mb-8">
                <div className="flex items-center justify-center mb-4">
                  {isPremium ? (
                    <Star className="w-8 h-8 text-yellow-500" />
                  ) : (
                    <Check className="w-8 h-8 text-green-500" />
                  )}
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{product.name}</h3>
                <div className="text-4xl font-bold text-gray-900 mb-2">
                  A${product.price}
                  <span className="text-lg font-normal text-gray-600">/month</span>
                </div>
              </div>

              <p className="text-gray-600 mb-8 text-center leading-relaxed">
                {product.description}
              </p>

              <div className="space-y-4 mb-8">
                <div className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Artist profile listing</span>
                </div>
                <div className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Searchable by event planners</span>
                </div>
                <div className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Media gallery (photos & videos)</span>
                </div>
                <div className="flex items-center">
                  <Check className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                  <span className="text-gray-700">Social media integration</span>
                </div>
                {isPremium && (
                  <>
                    <div className="flex items-center">
                      <Star className="w-5 h-5 text-yellow-500 mr-3 flex-shrink-0" />
                      <span className="text-gray-700 font-semibold">Featured placement</span>
                    </div>
                    <div className="flex items-center">
                      <Star className="w-5 h-5 text-yellow-500 mr-3 flex-shrink-0" />
                      <span className="text-gray-700 font-semibold">Priority in search results</span>
                    </div>
                    <div className="flex items-center">
                      <Star className="w-5 h-5 text-yellow-500 mr-3 flex-shrink-0" />
                      <span className="text-gray-700 font-semibold">Homepage highlighting</span>
                    </div>
                  </>
                )}
              </div>

              <button
                onClick={() => handleSubscribe(product.priceId)}
                disabled={loading === product.priceId}
                className={`w-full py-3 px-6 rounded-lg font-semibold transition-colors ${
                  isPremium
                    ? 'bg-yellow-400 hover:bg-yellow-500 text-yellow-900'
                    : 'bg-indigo-600 hover:bg-indigo-700 text-white'
                } disabled:opacity-50 disabled:cursor-not-allowed`}
              >
                {loading === product.priceId ? 'Processing...' : 'Get Started'}
              </button>
            </div>
          );
        })}
      </div>

      <div className="text-center mt-12">
        <p className="text-gray-600">
          All plans include a 30-day money-back guarantee. Cancel anytime.
        </p>
      </div>
    </div>
  );
}