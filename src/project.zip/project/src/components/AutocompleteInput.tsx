import { useState, useRef, useEffect } from 'react';
import { Search, Loader2 } from 'lucide-react';

interface AutocompleteInputProps {
  suggestions: string[];
  value: string;
  onChange: (value: string) => void;
  onSelect: (value: string) => void;
  placeholder?: string;
  loading?: boolean;
  icon?: React.ReactNode;
  className?: string;
  label?: string;
  required?: boolean;
  error?: string;
}

export function AutocompleteInput({
  suggestions,
  value,
  onChange,
  onSelect,
  placeholder = 'Start typing...',
  loading = false,
  icon,
  className = '',
  label,
  required = false,
  error,
}: AutocompleteInputProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [highlightedIndex, setHighlightedIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(event.target as Node) &&
        inputRef.current &&
        !inputRef.current.contains(event.target as Node)
      ) {
        setIsOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    onChange(newValue);
    setIsOpen(newValue.trim().length > 0);
    setHighlightedIndex(-1);
  };

  const handleSelectSuggestion = (suggestion: string) => {
    onSelect(suggestion);
    setIsOpen(false);
    setHighlightedIndex(-1);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (!isOpen || suggestions.length === 0) return;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setHighlightedIndex(prev =>
          prev < suggestions.length - 1 ? prev + 1 : 0
        );
        break;
      case 'ArrowUp':
        e.preventDefault();
        setHighlightedIndex(prev =>
          prev > 0 ? prev - 1 : suggestions.length - 1
        );
        break;
      case 'Enter':
        e.preventDefault();
        if (highlightedIndex >= 0 && highlightedIndex < suggestions.length) {
          handleSelectSuggestion(suggestions[highlightedIndex]);
        }
        break;
      case 'Escape':
        setIsOpen(false);
        setHighlightedIndex(-1);
        break;
    }
  };

  const filteredSuggestions = suggestions.filter(suggestion =>
    suggestion.toLowerCase().includes(value.toLowerCase())
  );

  return (
    <div className={`relative ${className}`}>
      {label && (
        <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </label>
      )}

      <div className="relative">
        <input
          ref={inputRef}
          type="text"
          value={value}
          onChange={handleInputChange}
          onKeyDown={handleKeyDown}
          onFocus={() => value.trim().length > 0 && setIsOpen(true)}
          placeholder={placeholder}
          required={required}
          className={`w-full px-4 py-2 pr-10 bg-black bg-opacity-50 border-2 rounded-lg text-[#39ff14] placeholder-[#39ff14] placeholder-opacity-40 focus:outline-none transition-all duration-300 text-sm ${
            error
              ? 'border-red-500'
              : 'border-[#39ff14] border-opacity-50 focus:border-opacity-100'
          }`}
          style={{ textShadow: '0 0 5px #ff0000' }}
          aria-autocomplete="list"
          aria-controls="autocomplete-dropdown"
          aria-expanded={isOpen}
        />
        <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
          {loading ? (
            <Loader2 className="w-5 h-5 text-[#39ff14] opacity-60 animate-spin" />
          ) : (
            icon || <Search className="w-5 h-5 text-[#39ff14] opacity-60" />
          )}
        </div>
      </div>

      {error && (
        <p className="mt-1 text-xs text-red-500">{error}</p>
      )}

      {isOpen && filteredSuggestions.length > 0 && (
        <div
          ref={dropdownRef}
          id="autocomplete-dropdown"
          className="absolute z-50 w-full mt-2 bg-gray-900 border-2 border-[#39ff14] border-opacity-70 rounded-lg shadow-2xl max-h-64 overflow-y-auto glow-red"
          role="listbox"
        >
          {filteredSuggestions.map((suggestion, index) => {
            const matchIndex = suggestion.toLowerCase().indexOf(value.toLowerCase());
            const beforeMatch = suggestion.slice(0, matchIndex);
            const match = suggestion.slice(matchIndex, matchIndex + value.length);
            const afterMatch = suggestion.slice(matchIndex + value.length);

            return (
              <div
                key={index}
                onClick={() => handleSelectSuggestion(suggestion)}
                onMouseEnter={() => setHighlightedIndex(index)}
                className={`px-4 py-3 cursor-pointer transition-colors duration-200 border-b border-red-500 border-opacity-20 last:border-b-0 ${
                  highlightedIndex === index
                    ? 'bg-[#39ff14] bg-opacity-20'
                    : 'hover:bg-gray-800'
                }`}
                role="option"
                aria-selected={highlightedIndex === index}
              >
                <span className="text-[#39ff14] text-sm">
                  {beforeMatch}
                  <span className="font-bold">{match}</span>
                  {afterMatch}
                </span>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
