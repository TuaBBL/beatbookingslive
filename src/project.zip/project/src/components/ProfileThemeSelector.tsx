import { Palette } from 'lucide-react';
import { useState } from 'react';

interface ProfileThemeSelectorProps {
  currentTheme: string;
  isPremium: boolean;
  onChange: (theme: string) => void;
}

type ThemeOption = {
  value: string;
  name: string;
  color: string;
  borderColor: string;
  glowClass: string;
  isPremiumOnly: boolean;
};

const themes: ThemeOption[] = [
  { value: 'red', name: 'Classic Red', color: '#ff0000', borderColor: 'border-red-500', glowClass: 'glow-red', isPremiumOnly: false },
  { value: 'green', name: 'Neon Green', color: '#39ff14', borderColor: 'border-[#39ff14]', glowClass: 'glow-green', isPremiumOnly: true },
  { value: 'blue', name: 'Electric Blue', color: '#00d4ff', borderColor: 'border-blue-400', glowClass: 'glow-blue', isPremiumOnly: true },
  { value: 'purple', name: 'Royal Purple', color: '#a855f7', borderColor: 'border-purple-500', glowClass: 'glow-purple', isPremiumOnly: true },
  { value: 'gold', name: 'Luxury Gold', color: '#fbbf24', borderColor: 'border-yellow-500', glowClass: 'glow-yellow', isPremiumOnly: true },
  { value: 'cyan', name: 'Cyber Cyan', color: '#06b6d4', borderColor: 'border-cyan-400', glowClass: 'glow-cyan', isPremiumOnly: true },
];

export function ProfileThemeSelector({ currentTheme, isPremium, onChange }: ProfileThemeSelectorProps) {
  const [selectedTheme, setSelectedTheme] = useState(currentTheme);

  const handleThemeChange = (theme: string, isPremiumOnly: boolean) => {
    if (isPremiumOnly && !isPremium) return;
    setSelectedTheme(theme);
    onChange(theme);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Palette className="w-5 h-5 text-fluro-green" />
        <h4 className="text-lg font-semibold text-fluro-green">Profile Theme</h4>
        {!isPremium && (
          <span className="text-xs text-gray-500">Premium themes available with upgrade</span>
        )}
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        {themes.map((theme) => {
          const isLocked = theme.isPremiumOnly && !isPremium;
          const isSelected = selectedTheme === theme.value;

          return (
            <button
              key={theme.value}
              type="button"
              onClick={() => handleThemeChange(theme.value, theme.isPremiumOnly)}
              disabled={isLocked}
              className={`relative p-4 rounded-lg border-2 transition-all duration-300 ${
                isSelected
                  ? `${theme.borderColor} ${theme.glowClass}`
                  : 'border-gray-700 hover:border-gray-600'
              } ${isLocked ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:scale-105'}`}
            >
              <div className="flex flex-col items-center gap-2">
                <div
                  className="w-12 h-12 rounded-full border-2"
                  style={{
                    backgroundColor: theme.color,
                    borderColor: theme.color,
                    boxShadow: isSelected ? `0 0 20px ${theme.color}` : 'none',
                  }}
                />
                <span className="text-sm font-semibold text-fluro-green-subtle">
                  {theme.name}
                </span>
                {theme.isPremiumOnly && (
                  <span className="px-2 py-0.5 bg-[#39ff14] text-black text-xs font-bold rounded">
                    PREMIUM
                  </span>
                )}
                {isLocked && (
                  <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-60 rounded-lg">
                    <svg className="w-6 h-6 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                    </svg>
                  </div>
                )}
                {isSelected && !isLocked && (
                  <div className="absolute top-2 right-2">
                    <svg className="w-5 h-5 text-[#39ff14]" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                    </svg>
                  </div>
                )}
              </div>
            </button>
          );
        })}
      </div>

      {!isPremium && (
        <div className="bg-gray-800 rounded-lg p-4 border border-gray-700">
          <p className="text-sm text-gray-400 text-center">
            Upgrade to Premium to unlock all custom profile themes and stand out with your unique style
          </p>
        </div>
      )}
    </div>
  );
}
