import { X, MapPin, Mail } from 'lucide-react';
import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

interface EditBookingModalProps {
  isOpen: boolean;
  onClose: () => void;
  booking: {
    id: string;
    artist_id: number;
    user_name: string;
    user_email: string;
    user_phone: string | null;
    requested_date: string;
    time_from: string;
    time_to: string;
    location: string;
    comments: string | null;
    artist?: {
      id: number;
      name: string;
      email: string;
      stage_name?: string;
    };
  } | null;
  onSuccess: () => void;
}

export function EditBookingModal({ isOpen, onClose, booking, onSuccess }: EditBookingModalProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [locationSuggestions, setLocationSuggestions] = useState<string[]>([]);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [emailSending, setEmailSending] = useState(false);
  const [emailSent, setEmailSent] = useState(false);

  const [formData, setFormData] = useState({
    requestedDate: '',
    timeFrom: '',
    timeTo: '',
    location: '',
    comments: ''
  });

  useEffect(() => {
    if (booking) {
      setFormData({
        requestedDate: booking.requested_date,
        timeFrom: booking.time_from,
        timeTo: booking.time_to,
        location: booking.location,
        comments: booking.comments || ''
      });
    }
  }, [booking]);

  const searchLocations = async (query: string) => {
    if (query.length < 3) {
      setLocationSuggestions([]);
      return;
    }

    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query)}&limit=5`,
        {
          headers: {
            'User-Agent': 'BeatBookings/1.0'
          }
        }
      );
      const data = await response.json();
      const suggestions = data.map((item: any) => item.display_name);
      setLocationSuggestions(suggestions);
    } catch (err) {
      console.error('Error fetching locations:', err);
    }
  };

  const handleLocationChange = (value: string) => {
    setFormData({ ...formData, location: value });
    setShowSuggestions(true);
    searchLocations(value);
  };

  const selectLocation = (location: string) => {
    setFormData({ ...formData, location });
    setShowSuggestions(false);
    setLocationSuggestions([]);
  };

  const sendEmailNotification = async () => {
    if (!booking || !booking.artist) return;

    if (!booking.artist.email) {
      setError('Artist email not available. This artist may not have a registered account.');
      return;
    }

    setEmailSending(true);
    setEmailSent(false);
    setError('');

    try {
      const { data: { session } } = await supabase.auth.getSession();

      if (!session) {
        throw new Error('No active session');
      }

      const artistName = booking.artist.stage_name || booking.artist.name;
      const apiUrl = `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/send-booking-notification`;
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${session.access_token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          artistEmail: booking.artist.email,
          artistName: artistName,
          userName: booking.user_name,
          userEmail: booking.user_email,
          userPhone: booking.user_phone,
          requestedDate: formData.requestedDate,
          timeFrom: formData.timeFrom,
          timeTo: formData.timeTo,
          location: formData.location,
          comments: formData.comments,
        }),
      });

      const result = await response.json();
      console.log('Email notification response:', result);

      if (!response.ok) {
        throw new Error(result.error || 'Failed to send email');
      }

      if (result.testMode) {
        setError(result.warning);
      } else {
        setEmailSent(true);
        setTimeout(() => setEmailSent(false), 3000);
      }
    } catch (error: any) {
      console.error('Failed to send email notification:', error);
      setError(error.message || 'Failed to send email notification');
    } finally {
      setEmailSending(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!booking) return;

    setLoading(true);
    setError('');

    try {
      const { error: updateError } = await supabase
        .from('bookings')
        .update({
          requested_date: formData.requestedDate,
          time_from: formData.timeFrom,
          time_to: formData.timeTo,
          location: formData.location,
          comments: formData.comments || null,
          updated_at: new Date().toISOString()
        })
        .eq('id', booking.id);

      if (updateError) throw updateError;

      onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to update booking');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen || !booking) return null;

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="bg-gray-900 rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto border-2 border-[#39ff14] glow-green">
        <div className="sticky top-0 bg-gray-900 border-b border-[#39ff14] p-6 flex justify-between items-center z-10">
          <h2 className="text-2xl font-bold text-fluro-green">Edit Booking Request</h2>
          <button
            onClick={onClose}
            className="text-fluro-green-subtle hover:text-fluro-green transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {emailSent && (
            <div className="bg-green-900/30 border border-green-500 text-green-400 px-4 py-3 rounded flex items-center gap-2">
              <Mail className="w-5 h-5" />
              Email notification sent successfully!
            </div>
          )}

          {error && (
            <div className="bg-red-900/30 border border-red-500 text-red-400 px-4 py-3 rounded">
              {error}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-fluro-green-subtle text-sm font-medium mb-2">
                Requested Date *
              </label>
              <input
                type="date"
                required
                value={formData.requestedDate}
                onChange={(e) => setFormData({ ...formData, requestedDate: e.target.value })}
                className="w-full bg-gray-800 border border-gray-700 rounded px-4 py-2 text-fluro-green-subtle focus:border-[#39ff14] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-fluro-green-subtle text-sm font-medium mb-2">
                Time From *
              </label>
              <input
                type="time"
                required
                value={formData.timeFrom}
                onChange={(e) => setFormData({ ...formData, timeFrom: e.target.value })}
                className="w-full bg-gray-800 border border-gray-700 rounded px-4 py-2 text-fluro-green-subtle focus:border-[#39ff14] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-fluro-green-subtle text-sm font-medium mb-2">
                Time To *
              </label>
              <input
                type="time"
                required
                value={formData.timeTo}
                onChange={(e) => setFormData({ ...formData, timeTo: e.target.value })}
                className="w-full bg-gray-800 border border-gray-700 rounded px-4 py-2 text-fluro-green-subtle focus:border-[#39ff14] focus:outline-none"
              />
            </div>
          </div>

          <div className="relative">
            <label className="block text-fluro-green-subtle text-sm font-medium mb-2">
              Location/Venue *
            </label>
            <div className="relative">
              <input
                type="text"
                required
                value={formData.location}
                onChange={(e) => handleLocationChange(e.target.value)}
                onFocus={() => setShowSuggestions(true)}
                onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                placeholder="Start typing a location..."
                className="w-full bg-gray-800 border border-gray-700 rounded px-4 py-2 pl-10 text-fluro-green-subtle focus:border-[#39ff14] focus:outline-none"
              />
              <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-fluro-green-subtle w-4 h-4 opacity-60" />
            </div>
            {showSuggestions && locationSuggestions.length > 0 && (
              <div className="absolute z-10 w-full mt-1 bg-gray-800 border border-gray-700 rounded-lg shadow-lg max-h-48 overflow-y-auto">
                {locationSuggestions.map((suggestion, index) => (
                  <button
                    key={index}
                    type="button"
                    onClick={() => selectLocation(suggestion)}
                    className="w-full text-left px-4 py-2 hover:bg-gray-700 text-fluro-green-subtle text-sm transition-colors"
                  >
                    {suggestion}
                  </button>
                ))}
              </div>
            )}
          </div>

          <div>
            <label className="block text-fluro-green-subtle text-sm font-medium mb-2">
              Comments / Special Requests
            </label>
            <textarea
              value={formData.comments}
              onChange={(e) => setFormData({ ...formData, comments: e.target.value })}
              rows={4}
              placeholder="Tell the artist about your event, any special requirements, equipment needs, etc."
              className="w-full bg-gray-800 border border-gray-700 rounded px-4 py-2 text-fluro-green-subtle focus:border-[#39ff14] focus:outline-none resize-none"
            />
          </div>

          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="w-full sm:flex-1 px-6 py-3 border-2 border-gray-700 text-fluro-green-subtle rounded-lg hover:bg-gray-800 transition-colors"
            >
              Cancel
            </button>
            {booking?.artist && booking.artist.email && (
              <button
                type="button"
                onClick={sendEmailNotification}
                disabled={emailSending}
                className="w-full sm:flex-1 px-6 py-3 border-2 border-[#39ff14] text-[#39ff14] rounded-lg hover:bg-[#39ff14] hover:text-gray-900 transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-semibold flex items-center justify-center gap-2"
              >
                <Mail className="w-5 h-5" />
                {emailSending ? 'Sending...' : 'Resend Email'}
              </button>
            )}
            <button
              type="submit"
              disabled={loading}
              className="w-full sm:flex-1 px-6 py-3 bg-[#39ff14] text-black rounded-lg hover:bg-[#2acc00] transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-semibold"
            >
              {loading ? 'Saving...' : 'Save Changes'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
