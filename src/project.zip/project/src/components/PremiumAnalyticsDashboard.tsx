import { useEffect, useState } from 'react';
import { TrendingUp, Eye, Users, MousePointer, Calendar, Image as ImageIcon } from 'lucide-react';
import { supabase, ArtistAnalyticsDetailed } from '../lib/supabase';

interface PremiumAnalyticsDashboardProps {
  artistId: number;
  isPremium: boolean;
}

interface AnalyticsSummary {
  totalViews: number;
  totalSocialClicks: number;
  totalPortfolioViews: number;
  totalBookingClicks: number;
  last30Days: ArtistAnalyticsDetailed[];
  last7Days: ArtistAnalyticsDetailed[];
}

export function PremiumAnalyticsDashboard({ artistId, isPremium }: PremiumAnalyticsDashboardProps) {
  const [analytics, setAnalytics] = useState<AnalyticsSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedPeriod, setSelectedPeriod] = useState<'7days' | '30days'>('7days');

  useEffect(() => {
    if (!isPremium) return;
    fetchAnalytics();
  }, [artistId, isPremium]);

  const fetchAnalytics = async () => {
    try {
      setLoading(true);
      const today = new Date();
      const thirtyDaysAgo = new Date(today);
      thirtyDaysAgo.setDate(today.getDate() - 30);
      const sevenDaysAgo = new Date(today);
      sevenDaysAgo.setDate(today.getDate() - 7);

      const { data, error } = await supabase
        .from('artist_analytics_detailed')
        .select('*')
        .eq('artist_id', artistId)
        .gte('date', thirtyDaysAgo.toISOString().split('T')[0])
        .order('date', { ascending: false });

      if (error) throw error;

      const last30Days = data || [];
      const last7Days = last30Days.filter(d => new Date(d.date) >= sevenDaysAgo);

      const summary: AnalyticsSummary = {
        totalViews: last30Days.reduce((sum, d) => sum + d.profile_views, 0),
        totalSocialClicks: last30Days.reduce((sum, d) => sum + d.social_clicks, 0),
        totalPortfolioViews: last30Days.reduce((sum, d) => sum + d.portfolio_views, 0),
        totalBookingClicks: last30Days.reduce((sum, d) => sum + d.booking_button_clicks, 0),
        last30Days,
        last7Days,
      };

      setAnalytics(summary);
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!isPremium) {
    return (
      <div className="bg-gray-800 rounded-lg p-8 border-2 border-gray-700 text-center">
        <TrendingUp className="w-16 h-16 text-gray-600 mx-auto mb-4" />
        <h3 className="text-xl font-bold text-gray-400 mb-2">Premium Analytics</h3>
        <p className="text-gray-500 mb-4">
          Upgrade to Premium to unlock detailed analytics about your profile performance
        </p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="bg-gray-800 rounded-lg p-8 border-2 border-[#39ff14] glow-green">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-700 rounded w-1/3"></div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-24 bg-gray-700 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const currentData = selectedPeriod === '7days' ? analytics?.last7Days : analytics?.last30Days;
  const periodViews = currentData?.reduce((sum, d) => sum + d.profile_views, 0) || 0;
  const periodSocialClicks = currentData?.reduce((sum, d) => sum + d.social_clicks, 0) || 0;
  const periodPortfolioViews = currentData?.reduce((sum, d) => sum + d.portfolio_views, 0) || 0;
  const periodBookingClicks = currentData?.reduce((sum, d) => sum + d.booking_button_clicks, 0) || 0;

  return (
    <div className="bg-gray-800 rounded-lg p-6 border-2 border-[#39ff14] glow-green">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <TrendingUp className="w-6 h-6 text-[#39ff14]" />
          <h3 className="text-2xl font-bold text-[#39ff14]">Premium Analytics</h3>
        </div>
        <div className="flex gap-2">
          <button
            onClick={() => setSelectedPeriod('7days')}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-300 ${
              selectedPeriod === '7days'
                ? 'bg-[#39ff14] text-black'
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
          >
            Last 7 Days
          </button>
          <button
            onClick={() => setSelectedPeriod('30days')}
            className={`px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-300 ${
              selectedPeriod === '30days'
                ? 'bg-[#39ff14] text-black'
                : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
            }`}
          >
            Last 30 Days
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-gray-900 rounded-lg p-4 border border-gray-700">
          <div className="flex items-center gap-3 mb-2">
            <Eye className="w-5 h-5 text-blue-400" />
            <span className="text-sm text-gray-400">Profile Views</span>
          </div>
          <p className="text-3xl font-bold text-white">{periodViews}</p>
          <p className="text-xs text-gray-500 mt-1">Total profile visits</p>
        </div>

        <div className="bg-gray-900 rounded-lg p-4 border border-gray-700">
          <div className="flex items-center gap-3 mb-2">
            <MousePointer className="w-5 h-5 text-green-400" />
            <span className="text-sm text-gray-400">Social Clicks</span>
          </div>
          <p className="text-3xl font-bold text-white">{periodSocialClicks}</p>
          <p className="text-xs text-gray-500 mt-1">Links clicked</p>
        </div>

        <div className="bg-gray-900 rounded-lg p-4 border border-gray-700">
          <div className="flex items-center gap-3 mb-2">
            <ImageIcon className="w-5 h-5 text-purple-400" />
            <span className="text-sm text-gray-400">Portfolio Views</span>
          </div>
          <p className="text-3xl font-bold text-white">{periodPortfolioViews}</p>
          <p className="text-xs text-gray-500 mt-1">Media opened</p>
        </div>

        <div className="bg-gray-900 rounded-lg p-4 border border-gray-700">
          <div className="flex items-center gap-3 mb-2">
            <Calendar className="w-5 h-5 text-[#39ff14]" />
            <span className="text-sm text-gray-400">Booking Interest</span>
          </div>
          <p className="text-3xl font-bold text-white">{periodBookingClicks}</p>
          <p className="text-xs text-gray-500 mt-1">Booking button clicks</p>
        </div>
      </div>

      {currentData && currentData.length > 0 && (
        <div className="bg-gray-900 rounded-lg p-4 border border-gray-700">
          <h4 className="text-sm font-semibold text-gray-400 mb-3">Daily Breakdown</h4>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {currentData.map((day) => (
              <div key={day.id} className="flex items-center justify-between py-2 border-b border-gray-800">
                <span className="text-sm text-gray-400">
                  {new Date(day.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                </span>
                <div className="flex gap-4 text-xs">
                  <span className="text-blue-400">{day.profile_views} views</span>
                  <span className="text-green-400">{day.social_clicks} clicks</span>
                  <span className="text-purple-400">{day.portfolio_views} portfolio</span>
                  <span className="text-[#39ff14]">{day.booking_button_clicks} bookings</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {(!currentData || currentData.length === 0) && (
        <div className="bg-gray-900 rounded-lg p-8 border border-gray-700 text-center">
          <Users className="w-12 h-12 text-gray-600 mx-auto mb-3" />
          <p className="text-gray-400">No analytics data available yet</p>
          <p className="text-sm text-gray-500 mt-1">Data will appear as users interact with your profile</p>
        </div>
      )}
    </div>
  );
}
