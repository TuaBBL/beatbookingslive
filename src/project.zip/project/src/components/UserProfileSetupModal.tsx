import { X, Upload, Save, MapPin, Phone, User } from 'lucide-react';
import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { StateSelector } from './StateSelector';

interface UserProfileSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  userEmail: string;
  onComplete: () => void;
}

export function UserProfileSetupModal({ isOpen, onClose, userId, userEmail, onComplete }: UserProfileSetupModalProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [fullName, setFullName] = useState('');
  const [location, setLocation] = useState('');
  const [stateTerritory, setStateTerritory] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [profileImage, setProfileImage] = useState<File | null>(null);
  const [profileImagePreview, setProfileImagePreview] = useState<string | null>(null);
  const [dataLoaded, setDataLoaded] = useState(false);

  useEffect(() => {
    if (isOpen && userId && !dataLoaded) {
      fetchUserData();
    }
  }, [isOpen, userId]);

  const fetchUserData = async () => {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('full_name, location, state_territory, phone_number, profile_image_url')
        .eq('id', userId)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setFullName(data.full_name || '');
        setLocation(data.location || '');
        setStateTerritory(data.state_territory || '');
        setPhoneNumber(data.phone_number || '');
        if (data.profile_image_url) {
          setProfileImagePreview(data.profile_image_url);
        }
        setDataLoaded(true);
      }
    } catch (err) {
      console.error('Error fetching user data:', err);
    }
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) {
        setError('Image size must be less than 5MB');
        return;
      }
      if (!file.type.startsWith('image/')) {
        setError('File must be an image');
        return;
      }
      setProfileImage(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfileImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
      setError('');
    }
  };

  const removeImage = () => {
    setProfileImage(null);
    setProfileImagePreview(null);
  };

  const uploadProfileImage = async (): Promise<string | null> => {
    if (!profileImage) return null;

    try {
      const fileExt = profileImage.name.split('.').pop();
      const fileName = `${userId}/profile.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('user-profiles')
        .upload(fileName, profileImage, {
          upsert: true,
          contentType: profileImage.type,
        });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from('user-profiles')
        .getPublicUrl(fileName);

      return publicUrl;
    } catch (error) {
      console.error('Error uploading profile image:', error);
      throw error;
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      let profileImageUrl = profileImagePreview;

      if (profileImage) {
        profileImageUrl = await uploadProfileImage();
      }

      const trimmedFullName = fullName.trim();
      const trimmedLocation = location.trim();
      const trimmedStateTerritory = stateTerritory.trim();

      const isProfileComplete = !!(
        trimmedFullName &&
        trimmedLocation &&
        trimmedStateTerritory
      );

      const { error: updateError } = await supabase
        .from('profiles')
        .upsert({
          id: userId,
          full_name: trimmedFullName || null,
          location: trimmedLocation || null,
          state_territory: trimmedStateTerritory || null,
          phone_number: phoneNumber.trim() || null,
          profile_image_url: profileImageUrl || null,
          profile_completed: isProfileComplete
        });

      if (updateError) throw updateError;

      const { error: userUpdateError } = await supabase
        .from('users')
        .update({
          full_name: trimmedFullName || null,
          location: trimmedLocation || null,
          state_territory: trimmedStateTerritory || null,
          phone_number: phoneNumber.trim() || null,
          profile_image_url: profileImageUrl || null,
          profile_completed: isProfileComplete
        })
        .eq('id', userId);

      if (userUpdateError) throw userUpdateError;

      onComplete();
      onClose();
    } catch (err: any) {
      setError(err.message || 'Failed to complete profile');
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 overflow-y-auto p-0 md:p-4 flex items-center justify-center">
      <div className="bg-gray-900 rounded-lg max-w-md w-full border-2 border-[#39ff14] glow-green my-8 md:my-0">
        <div className="border-b border-[#39ff14] p-6 flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-bold text-fluro-green">Confirm Your Profile</h2>
            <p className="text-fluro-green-subtle text-sm mt-1">Review and confirm your account details</p>
          </div>
          <button
            onClick={onClose}
            className="text-fluro-green-subtle hover:text-fluro-green transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          {error && (
            <div className="bg-red-900/30 border border-red-500 text-red-400 px-4 py-3 rounded">
              {error}
            </div>
          )}

          <div>
            <label className="block text-fluro-green-subtle text-sm font-medium mb-2">
              Profile Image (Optional)
            </label>
            <div className="flex flex-col items-center">
              {profileImagePreview ? (
                <div className="relative inline-block mb-4">
                  <img
                    src={profileImagePreview}
                    alt="Profile preview"
                    className="w-32 h-32 rounded-full object-cover border-2 border-[#39ff14]"
                  />
                  <button
                    type="button"
                    onClick={removeImage}
                    className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 hover:bg-red-600 transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ) : (
                <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-gray-700 border-dashed rounded-lg cursor-pointer hover:bg-gray-800 transition-colors mb-4">
                  <div className="flex flex-col items-center justify-center">
                    <Upload className="w-8 h-8 text-fluro-green-subtle mb-2" />
                    <p className="text-sm text-fluro-green-subtle">Click to upload</p>
                    <p className="text-xs text-gray-500">PNG, JPG up to 5MB</p>
                  </div>
                  <input
                    type="file"
                    className="hidden"
                    accept="image/*"
                    onChange={handleImageChange}
                  />
                </label>
              )}
              {!profileImagePreview && (
                <label className="w-full px-4 py-2 border-2 border-[#39ff14] text-[#39ff14] rounded-lg hover:bg-[#39ff14] hover:text-gray-900 transition-colors font-semibold text-center cursor-pointer">
                  <Upload className="w-5 h-5 inline mr-2" />
                  Choose Image
                  <input
                    type="file"
                    className="hidden"
                    accept="image/*"
                    onChange={handleImageChange}
                  />
                </label>
              )}
            </div>
          </div>

          <div>
            <label htmlFor="fullName" className="block text-fluro-green-subtle text-sm font-medium mb-2">
              Full Name *
            </label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-fluro-green-subtle opacity-50" />
              <input
                id="fullName"
                type="text"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
                className="w-full bg-gray-800 border border-gray-700 rounded pl-10 pr-4 py-2 text-fluro-green-subtle focus:border-[#39ff14] focus:outline-none"
                placeholder="Enter your full name"
              />
            </div>
          </div>

          <div>
            <label className="block text-fluro-green-subtle text-sm font-medium mb-2">
              Email
            </label>
            <input
              type="email"
              value={userEmail}
              disabled
              className="w-full bg-gray-800 border border-gray-700 rounded px-4 py-2 text-gray-500 cursor-not-allowed"
            />
          </div>

          <div>
            <StateSelector
              value={stateTerritory}
              onChange={(value) => setStateTerritory(value as string)}
              required={true}
              label="State/Territory *"
              placeholder="Select your state/territory"
            />
          </div>

          <div>
            <label htmlFor="location" className="block text-fluro-green-subtle text-sm font-medium mb-2">
              City/Location *
            </label>
            <div className="relative">
              <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-fluro-green-subtle opacity-50" />
              <input
                id="location"
                type="text"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                required
                className="w-full bg-gray-800 border border-gray-700 rounded pl-10 pr-4 py-2 text-fluro-green-subtle focus:border-[#39ff14] focus:outline-none"
                placeholder="Enter your city"
              />
            </div>
          </div>

          <div>
            <label htmlFor="phoneNumber" className="block text-fluro-green-subtle text-sm font-medium mb-2">
              Phone Number (Optional)
            </label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-fluro-green-subtle opacity-50" />
              <input
                id="phoneNumber"
                type="tel"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
                className="w-full bg-gray-800 border border-gray-700 rounded pl-10 pr-4 py-2 text-fluro-green-subtle focus:border-[#39ff14] focus:outline-none"
                placeholder="Enter your phone number"
              />
            </div>
          </div>

          <div className="bg-gray-800/50 border border-gray-700 rounded p-4 mt-6">
            <p className="text-fluro-green-subtle text-sm">
              <strong>Welcome!</strong> Please confirm your profile information below. You can update it anytime from your dashboard.
            </p>
          </div>

          <div className="flex gap-4 pt-4">
            <button
              type="submit"
              disabled={loading}
              className="flex-1 px-6 py-3 bg-[#39ff14] text-black rounded-lg hover:bg-[#2acc00] transition-colors disabled:opacity-50 disabled:cursor-not-allowed font-semibold flex items-center justify-center gap-2"
            >
              <Save className="w-5 h-5" />
              {loading ? 'Completing...' : 'Complete Profile'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
