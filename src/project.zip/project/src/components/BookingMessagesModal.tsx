import { X, Send } from 'lucide-react';
import { useState, useEffect, useRef } from 'react';
import { supabase } from '../lib/supabase';

interface BookingMessagesModalProps {
  isOpen: boolean;
  onClose: () => void;
  booking: any;
  currentUserId: string;
  isArtist: boolean;
  artistName?: string;
}

export function BookingMessagesModal({
  isOpen,
  onClose,
  booking,
  currentUserId,
  isArtist,
  artistName,
}: BookingMessagesModalProps) {
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen && booking) {
      fetchMessages();
      const subscription = supabase
        .channel(`booking_messages_${booking.id}`)
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'booking_messages',
            filter: `booking_id=eq.${booking.id}`,
          },
          (payload) => {
            setMessages((prev) => {
              const messageExists = prev.some((msg) => msg.id === payload.new.id);
              if (messageExists) {
                return prev;
              }
              return [...prev, payload.new];
            });
          }
        )
        .subscribe();

      return () => {
        subscription.unsubscribe();
      };
    }
  }, [isOpen, booking]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const fetchMessages = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('booking_messages')
        .select('*')
        .eq('booking_id', booking.id)
        .order('created_at', { ascending: true });

      if (error) throw error;
      setMessages(data || []);
    } catch (error) {
      console.error('Error fetching messages:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || sending) return;

    setSending(true);
    const messageText = newMessage.trim();
    setNewMessage('');

    const optimisticMessage = {
      id: `temp-${Date.now()}`,
      booking_id: booking.id,
      sender_id: currentUserId,
      message: messageText,
      created_at: new Date().toISOString(),
    };

    setMessages((prev) => [...prev, optimisticMessage]);

    try {
      const isPriority = isArtist && booking.artist?.is_premium;

      const { data, error } = await supabase
        .from('booking_messages')
        .insert({
          booking_id: booking.id,
          sender_id: currentUserId,
          message: messageText,
          is_priority: isPriority || false,
        })
        .select()
        .single();

      if (error) throw error;

      setMessages((prev) =>
        prev.map((msg) => (msg.id === optimisticMessage.id ? data : msg))
      );
    } catch (error) {
      console.error('Error sending message:', error);
      setMessages((prev) => prev.filter((msg) => msg.id !== optimisticMessage.id));
      setNewMessage(messageText);
    } finally {
      setSending(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50">
      <div className="bg-gray-900 rounded-lg border-2 border-[#39ff14] glow-green w-full max-w-2xl max-h-[80vh] flex flex-col">
        <div className="flex items-center justify-between p-6 border-b border-gray-700">
          <div>
            <h2 className="text-2xl font-bold text-fluro-green">Messages</h2>
            <p className="text-fluro-green-subtle text-sm mt-1">
              {isArtist ? `Chat with ${booking.user_name}` : `Chat with artist`}
            </p>
          </div>
          <button
            onClick={onClose}
            className="text-fluro-green-subtle hover:text-red-500 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4">
          {loading ? (
            <div className="flex items-center justify-center py-8">
              <p className="text-fluro-green-subtle">Loading messages...</p>
            </div>
          ) : messages.length === 0 ? (
            <div className="flex items-center justify-center py-8">
              <p className="text-fluro-green-subtle">No messages yet. Start the conversation!</p>
            </div>
          ) : (
            messages.map((message) => {
              const isCurrentUser = message.sender_id === currentUserId;
              return (
                <div
                  key={message.id}
                  className={`flex ${isCurrentUser ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`max-w-[70%] rounded-lg px-4 py-3 ${
                      isCurrentUser
                        ? 'bg-[#39ff14] text-black'
                        : 'bg-gray-800 border border-gray-700 text-fluro-green-subtle'
                    }`}
                  >
                    {message.is_priority && !isCurrentUser && (
                      <div className="flex items-center gap-1 mb-1">
                        <span className="px-2 py-0.5 bg-[#39ff14] text-black text-xs font-bold rounded">
                          PREMIUM
                        </span>
                      </div>
                    )}
                    <p className="break-words">{message.message}</p>
                    <p
                      className={`text-xs mt-1 ${
                        isCurrentUser ? 'text-black text-opacity-60' : 'text-fluro-green-subtle'
                      }`}
                    >
                      {new Date(message.created_at).toLocaleTimeString('en-US', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </p>
                  </div>
                </div>
              );
            })
          )}
          <div ref={messagesEndRef} />
        </div>

        <form onSubmit={handleSendMessage} className="p-6 border-t border-gray-700">
          {isArtist && artistName && booking.status === 'pending' && (
            <div className="mb-3">
              <button
                type="button"
                onClick={() => {
                  const declineMessage = `Thanks for your request. ${artistName} isn't available for this date, but we appreciate you reaching out.\n\nFeel free to explore other artists on BeatBookingsLive — we're confident you'll find the perfect match for your event.`;
                  setNewMessage(declineMessage);
                }}
                className="text-sm text-fluro-green-subtle hover:text-fluro-green transition-colors underline"
              >
                Use decline template
              </button>
            </div>
          )}
          <div className="flex gap-3">
            <textarea
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              placeholder="Type your message..."
              rows={3}
              className="flex-1 px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-fluro-green placeholder-fluro-green-subtle focus:outline-none focus:border-[#39ff14] focus:ring-1 focus:ring-[#39ff14] resize-none"
              disabled={sending}
            />
            <button
              type="submit"
              disabled={!newMessage.trim() || sending}
              className="px-6 py-3 bg-[#39ff14] text-black rounded-lg font-bold hover:glow-red-strong transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 self-end"
            >
              <Send className="w-5 h-5" />
              Send
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
