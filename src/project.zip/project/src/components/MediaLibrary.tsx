import { Plus, Trash2, Upload, AlertCircle, Image as ImageIcon, Video, Loader2, Link as LinkIcon } from 'lucide-react';
import { useState, useRef } from 'react';
import { supabase } from '../lib/supabase';

interface MediaLibraryProps {
  type: 'images' | 'videos';
  items: string[];
  maxItems: number | null;
  onChange: (items: string[]) => void;
  disabled?: boolean;
  userId: string;
  isPremium?: boolean;
}

interface UploadProgress {
  [key: string]: number;
}

export function MediaLibrary({ type, items, maxItems, onChange, disabled = false, userId, isPremium = false }: MediaLibraryProps) {
  const [newItemUrl, setNewItemUrl] = useState('');
  const [error, setError] = useState('');
  const [draggedIndex, setDraggedIndex] = useState<number | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<UploadProgress>({});
  const [showUrlInput, setShowUrlInput] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const isVideo = type === 'videos';
  const label = isVideo ? 'Video' : 'Image';
  const Icon = isVideo ? Video : ImageIcon;
  const placeholder = isVideo
    ? 'https://youtube.com/watch?v=... or https://vimeo.com/...'
    : 'https://example.com/image.jpg';

  const bucketName = isVideo ? 'artist-videos' : 'artist-images';
  const acceptedTypes = isVideo
    ? 'video/mp4,video/webm,video/ogg,video/quicktime'
    : 'image/jpeg,image/jpg,image/png,image/gif,image/webp';
  const maxFileSize = isVideo ? 100 * 1024 * 1024 : 5 * 1024 * 1024;

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    const file = files[0];
    setError('');

    if (maxItems !== null && items.length >= maxItems) {
      setError(`Maximum ${maxItems} ${type} allowed`);
      return;
    }

    if (file.size > maxFileSize) {
      const sizeMB = (maxFileSize / (1024 * 1024)).toFixed(0);
      setError(`File size must be less than ${sizeMB}MB`);
      return;
    }

    const fileExt = file.name.split('.').pop()?.toLowerCase();
    const validExtensions = isVideo
      ? ['mp4', 'webm', 'ogg', 'mov']
      : ['jpg', 'jpeg', 'png', 'gif', 'webp'];

    if (!fileExt || !validExtensions.includes(fileExt)) {
      setError(`Invalid file type. Allowed: ${validExtensions.join(', ')}`);
      return;
    }

    try {
      setUploading(true);
      const fileName = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9.-]/g, '_')}`;
      const filePath = `${userId}/${fileName}`;

      const { data, error: uploadError } = await supabase.storage
        .from(bucketName)
        .upload(filePath, file, {
          cacheControl: '3600',
          upsert: false,
        });

      if (uploadError) throw uploadError;

      const { data: { publicUrl } } = supabase.storage
        .from(bucketName)
        .getPublicUrl(filePath);

      onChange([...items, publicUrl]);

      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    } catch (err: any) {
      console.error('Upload error:', err);
      setError(err.message || 'Failed to upload file');
    } finally {
      setUploading(false);
    }
  };

  const handleUrlAdd = () => {
    setError('');

    if (!newItemUrl.trim()) {
      setError('Please enter a valid URL');
      return;
    }

    if (maxItems !== null && items.length >= maxItems) {
      setError(`Maximum ${maxItems} ${type} allowed`);
      return;
    }

    try {
      new URL(newItemUrl);

      if (isVideo) {
        if (!isValidVideoUrl(newItemUrl)) {
          setError('Please enter a valid video URL (YouTube, Vimeo, etc.)');
          return;
        }
      } else {
        if (!isValidImageUrl(newItemUrl)) {
          setError('Please enter a valid image URL (.jpg, .jpeg, .png, .gif, .webp)');
          return;
        }
      }

      onChange([...items, newItemUrl]);
      setNewItemUrl('');
      setShowUrlInput(false);
    } catch {
      setError('Please enter a valid URL');
    }
  };

  const handleRemove = async (index: number) => {
    const url = items[index];

    if (url.includes(bucketName)) {
      try {
        const pathMatch = url.match(new RegExp(`${bucketName}/(.+)$`));
        if (pathMatch) {
          const filePath = pathMatch[1];
          await supabase.storage.from(bucketName).remove([filePath]);
        }
      } catch (err) {
        console.error('Error deleting file:', err);
      }
    }

    onChange(items.filter((_, i) => i !== index));
  };

  const handleDragStart = (index: number) => {
    setDraggedIndex(index);
  };

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    if (draggedIndex === null || draggedIndex === index) return;

    const newItems = [...items];
    const draggedItem = newItems[draggedIndex];
    newItems.splice(draggedIndex, 1);
    newItems.splice(index, 0, draggedItem);

    onChange(newItems);
    setDraggedIndex(index);
  };

  const handleDragEnd = () => {
    setDraggedIndex(null);
  };

  const isValidVideoUrl = (url: string): boolean => {
    const videoPatterns = [
      /youtube\.com\/watch\?v=/i,
      /youtu\.be\//i,
      /vimeo\.com\//i,
      /dailymotion\.com\//i,
      /\.mp4$/i,
      /\.webm$/i,
      /\.ogg$/i
    ];
    return videoPatterns.some(pattern => pattern.test(url));
  };

  const isValidImageUrl = (url: string): boolean => {
    const imagePatterns = [
      /\.(jpg|jpeg|png|gif|webp|svg)$/i,
      /unsplash\.com/i,
      /pexels\.com/i,
      /images\./i
    ];
    return imagePatterns.some(pattern => pattern.test(url));
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Icon className="w-5 h-5 text-fluro-green" />
          <h4 className="text-lg font-semibold text-fluro-green">
            {label} Library
          </h4>
          <span className="text-sm text-fluro-green-subtle">
            ({items.length}/{maxItems === null ? '∞' : maxItems})
          </span>
          {isPremium && maxItems === null && (
            <span className="px-2 py-1 bg-[#39ff14] text-black text-xs font-bold rounded">
              UNLIMITED
            </span>
          )}
        </div>
      </div>

      {error && (
        <div className="flex items-center gap-2 p-3 bg-red-500 bg-opacity-20 border border-red-500 rounded-lg">
          <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
          <p className="text-red-500 text-sm">{error}</p>
        </div>
      )}

      <div className="flex flex-col gap-3">
        <div className="flex gap-2">
          <input
            ref={fileInputRef}
            type="file"
            accept={acceptedTypes}
            onChange={handleFileSelect}
            disabled={disabled || uploading || (maxItems !== null && items.length >= maxItems)}
            className="hidden"
            id={`file-upload-${type}`}
          />
          <label
            htmlFor={`file-upload-${type}`}
            className={`flex-1 px-4 py-3 bg-[#39ff14] bg-opacity-20 border-2 border-[#39ff14] text-[#39ff14] rounded-lg hover:bg-opacity-30 transition-all duration-300 cursor-pointer flex items-center justify-center gap-2 font-semibold ${
              disabled || uploading || (maxItems !== null && items.length >= maxItems) ? 'opacity-50 cursor-not-allowed' : ''
            }`}
          >
            {uploading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Uploading...
              </>
            ) : (
              <>
                <Upload className="w-5 h-5" />
                Upload from Device
              </>
            )}
          </label>
          <button
            type="button"
            onClick={() => setShowUrlInput(!showUrlInput)}
            disabled={disabled || items.length >= maxItems}
            className="px-4 py-3 bg-gray-800 border-2 border-[#39ff14] border-opacity-50 text-[#39ff14] rounded-lg hover:border-opacity-100 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
          >
            <LinkIcon className="w-5 h-5" />
            {showUrlInput ? 'Cancel' : 'Add URL'}
          </button>
        </div>

        {showUrlInput && (
          <div className="flex gap-2 p-4 bg-gray-800 rounded-lg border border-gray-700">
            <input
              type="url"
              value={newItemUrl}
              onChange={(e) => {
                setNewItemUrl(e.target.value);
                setError('');
              }}
              onKeyPress={(e) => e.key === 'Enter' && handleUrlAdd()}
              disabled={disabled || items.length >= maxItems}
              className="flex-1 px-4 py-3 bg-gray-900 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] placeholder-[#39ff14] placeholder-opacity-40 focus:outline-none focus:border-opacity-100 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
              placeholder={placeholder}
            />
            <button
              type="button"
              onClick={handleUrlAdd}
              disabled={disabled || items.length >= maxItems}
              className="px-4 py-3 bg-[#39ff14] bg-opacity-20 border-2 border-[#39ff14] text-[#39ff14] rounded-lg hover:bg-opacity-30 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              <Plus className="w-5 h-5" />
              Add
            </button>
          </div>
        )}
      </div>

      {items.length === 0 ? (
        <div className="border-2 border-dashed border-gray-700 rounded-lg p-8 text-center">
          <Upload className="w-12 h-12 text-gray-600 mx-auto mb-3" />
          <p className="text-gray-500">No {type} added yet</p>
          <p className="text-gray-600 text-sm mt-1">Upload from your device or add a URL</p>
          <p className="text-gray-600 text-xs mt-2">
            {isVideo
              ? 'Max 100MB per video • MP4, WebM, OGG, MOV'
              : 'Max 5MB per image • JPG, PNG, GIF, WebP'
            }
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {items.map((item, index) => (
            <div
              key={index}
              draggable={!disabled}
              onDragStart={() => handleDragStart(index)}
              onDragOver={(e) => handleDragOver(e, index)}
              onDragEnd={handleDragEnd}
              className={`relative bg-gray-800 rounded-lg overflow-hidden border-2 border-gray-700 hover:border-[#39ff14] transition-all duration-300 ${
                draggedIndex === index ? 'opacity-50' : ''
              } ${disabled ? '' : 'cursor-move'}`}
            >
              {isVideo ? (
                <div className="aspect-video bg-black flex items-center justify-center">
                  <Video className="w-12 h-12 text-fluro-green-subtle" />
                  <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-60">
                    <p className="text-xs text-fluro-green-subtle text-center px-4 break-all">
                      {item.split('/').pop()?.substring(0, 30) || 'Video'}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="aspect-video bg-gray-900">
                  <img
                    src={item}
                    alt={`${label} ${index + 1}`}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.src = 'https://via.placeholder.com/400x300?text=Image+Not+Found';
                    }}
                  />
                </div>
              )}

              {!disabled && (
                <button
                  type="button"
                  onClick={() => handleRemove(index)}
                  className="absolute top-2 right-2 p-2 bg-red-500 bg-opacity-90 hover:bg-opacity-100 rounded-lg transition-all duration-300 group"
                >
                  <Trash2 className="w-4 h-4 text-white" />
                </button>
              )}

              <div className="absolute bottom-2 left-2 px-2 py-1 bg-black bg-opacity-70 rounded text-xs text-fluro-green-subtle">
                #{index + 1}
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="text-xs text-fluro-green-subtle space-y-1">
        <p>• Upload files from your device or add URLs from external sources</p>
        <p>• Drag and drop to reorder {type}</p>
        <p>• {isVideo ? 'Max 100MB per video' : 'Max 5MB per image'}</p>
        <p>• First {isVideo ? 'video' : 'image'} will be featured prominently</p>
      </div>
    </div>
  );
}
