import { Search, Music2, MapPin, X, Youtube, Headphones, Music } from 'lucide-react';
import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { StateSelector } from './StateSelector';

interface ArtistFiltersProps {
  onFilterChange: (filters: FilterState) => void;
}

export interface FilterState {
  searchQuery: string;
  location: string;
  states: string[];
  category: string;
  genre: string;
  hasSoundcloud: boolean;
  hasYoutube: boolean;
  hasSpotify: boolean;
}

export function ArtistFilters({ onFilterChange }: ArtistFiltersProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [location, setLocation] = useState('');
  const [selectedStates, setSelectedStates] = useState<string[]>([]);
  const [category, setCategory] = useState('');
  const [genre, setGenre] = useState('');
  const [hasSoundcloud, setHasSoundcloud] = useState(false);
  const [hasYoutube, setHasYoutube] = useState(false);
  const [hasSpotify, setHasSpotify] = useState(false);
  const [locations, setLocations] = useState<string[]>([]);
  const [genres, setGenres] = useState<string[]>([]);

  useEffect(() => {
    fetchUniqueValues();
  }, []);

  useEffect(() => {
    const debounce = setTimeout(() => {
      onFilterChange({ searchQuery, location, states: selectedStates, category, genre, hasSoundcloud, hasYoutube, hasSpotify });
    }, 300);
    return () => clearTimeout(debounce);
  }, [searchQuery, location, selectedStates, category, genre, hasSoundcloud, hasYoutube, hasSpotify, onFilterChange]);

  async function fetchUniqueValues() {
    try {
      const { data, error } = await supabase
        .from('artist_cards')
        .select('location, genre');

      if (error) throw error;

      const uniqueLocations = Array.from(new Set(data?.map(d => d.location).filter(Boolean))) as string[];
      const uniqueGenres = Array.from(new Set(data?.map(d => d.genre).filter(Boolean))) as string[];

      setLocations(uniqueLocations.sort());
      setGenres(uniqueGenres.sort());
    } catch (error) {
      console.error('Error fetching filter values:', error);
    }
  }

  const clearFilters = () => {
    setSearchQuery('');
    setLocation('');
    setSelectedStates([]);
    setCategory('');
    setGenre('');
    setHasSoundcloud(false);
    setHasYoutube(false);
    setHasSpotify(false);
  };

  const hasActiveFilters = searchQuery || location || selectedStates.length > 0 || category || genre || hasSoundcloud || hasYoutube || hasSpotify;

  return (
    <div className="bg-gray-900 border-2 border-red-500 border-opacity-30 rounded-lg p-6 mb-8 glow-red">
      <div className="flex flex-col lg:flex-row gap-4">
        <div className="flex-1">
          <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
            Search by Name
          </label>
          <div className="relative">
            <input
              type="text"
              placeholder="Search artists..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full px-4 py-2 pr-10 bg-black bg-opacity-50 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] placeholder-[#39ff14] placeholder-opacity-40 focus:outline-none focus:border-opacity-100 transition-all duration-300 text-sm"
              style={{ textShadow: '0 0 5px #ff0000' }}
            />
            <Search
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#39ff14] w-5 h-5 opacity-60"
              style={{ filter: 'drop-shadow(0 0 3px #ff0000)' }}
            />
          </div>
        </div>

        <div className="flex-1">
          <StateSelector
            value={selectedStates}
            onChange={(value) => setSelectedStates(value as string[])}
            multiple={true}
            label="Filter by State/Territory"
            placeholder="All States"
          />
        </div>

        <div className="flex-1">
          <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
            Filter by City
          </label>
          <div className="relative">
            <select
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full px-4 py-2 pr-10 bg-black bg-opacity-50 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] focus:outline-none focus:border-opacity-100 transition-all duration-300 text-sm appearance-none cursor-pointer"
              style={{ textShadow: '0 0 5px #ff0000' }}
            >
              <option value="">All Cities</option>
              {locations.map((loc) => (
                <option key={loc} value={loc} className="bg-gray-900">
                  {loc}
                </option>
              ))}
            </select>
            <MapPin
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#39ff14] w-5 h-5 opacity-60 pointer-events-none"
              style={{ filter: 'drop-shadow(0 0 3px #ff0000)' }}
            />
          </div>
        </div>

        <div className="flex-1">
          <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
            Filter by Category
          </label>
          <div className="relative">
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              className="w-full px-4 py-2 pr-10 bg-black bg-opacity-50 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] focus:outline-none focus:border-opacity-100 transition-all duration-300 text-sm appearance-none cursor-pointer"
              style={{ textShadow: '0 0 5px #ff0000' }}
            >
              <option value="">All Categories</option>
              <option value="DJ" className="bg-gray-900">DJ</option>
              <option value="Band" className="bg-gray-900">Band</option>
              <option value="Solo Artist" className="bg-gray-900">Solo Artist</option>
              <option value="Producer" className="bg-gray-900">Producer</option>
              <option value="Duo" className="bg-gray-900">Duo</option>
              <option value="MC" className="bg-gray-900">MC</option>
              <option value="Specialty Act" className="bg-gray-900">Specialty Act</option>
              <option value="Other" className="bg-gray-900">Other</option>
            </select>
            <Music2
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#39ff14] w-5 h-5 opacity-60 pointer-events-none"
              style={{ filter: 'drop-shadow(0 0 3px #ff0000)' }}
            />
          </div>
        </div>

        <div className="flex-1">
          <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
            Filter by Genre
          </label>
          <div className="relative">
            <select
              value={genre}
              onChange={(e) => setGenre(e.target.value)}
              className="w-full px-4 py-2 pr-10 bg-black bg-opacity-50 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] focus:outline-none focus:border-opacity-100 transition-all duration-300 text-sm appearance-none cursor-pointer"
              style={{ textShadow: '0 0 5px #ff0000' }}
            >
              <option value="">All Genres</option>
              <option value="R&B" className="bg-gray-900">R&B</option>
              <option value="Rock" className="bg-gray-900">Rock</option>
              <option value="Reggae" className="bg-gray-900">Reggae</option>
              <option value="DNB" className="bg-gray-900">DNB</option>
              <option value="Open Format" className="bg-gray-900">Open Format</option>
              {genres.map((g) => (
                !['R&B', 'Rock', 'Reggae', 'DNB', 'Open Format'].includes(g) && (
                  <option key={g} value={g} className="bg-gray-900">
                    {g}
                  </option>
                )
              ))}
            </select>
            <Music
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#39ff14] w-5 h-5 opacity-60 pointer-events-none"
              style={{ filter: 'drop-shadow(0 0 3px #ff0000)' }}
            />
          </div>
        </div>

        {hasActiveFilters && (
          <div className="flex items-end">
            <button
              onClick={clearFilters}
              className="px-4 py-2 bg-red-500 bg-opacity-20 border-2 border-red-500 text-red-500 rounded-lg font-semibold hover:bg-red-500 hover:text-white transition-all duration-300 flex items-center gap-2 whitespace-nowrap"
            >
              <X className="w-4 h-4" />
              Clear
            </button>
          </div>
        )}
      </div>

      <div className="mt-4 pt-4 border-t border-red-500 border-opacity-30">
        <label className="block text-fluro-green-subtle text-sm font-semibold mb-3">
          Filter by Platform
        </label>
        <div className="flex flex-wrap gap-3">
          <button
            onClick={() => setHasYoutube(!hasYoutube)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-semibold transition-all duration-300 ${
              hasYoutube
                ? 'bg-red-600 border-2 border-red-600 text-white'
                : 'bg-red-600 bg-opacity-20 border-2 border-red-600 text-red-500 hover:bg-red-600 hover:text-white'
            }`}
          >
            <Youtube className="w-5 h-5" />
            YouTube
          </button>

          <button
            onClick={() => setHasSoundcloud(!hasSoundcloud)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-semibold transition-all duration-300 ${
              hasSoundcloud
                ? 'bg-orange-600 border-2 border-orange-600 text-white'
                : 'bg-orange-600 bg-opacity-20 border-2 border-orange-600 text-orange-500 hover:bg-orange-600 hover:text-white'
            }`}
          >
            <Music className="w-5 h-5" />
            SoundCloud
          </button>

          <button
            onClick={() => setHasSpotify(!hasSpotify)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg font-semibold transition-all duration-300 ${
              hasSpotify
                ? 'bg-green-600 border-2 border-green-600 text-white'
                : 'bg-green-600 bg-opacity-20 border-2 border-green-600 text-green-500 hover:bg-green-600 hover:text-white'
            }`}
          >
            <Headphones className="w-5 h-5" />
            Spotify
          </button>
        </div>
      </div>
    </div>
  );
}
