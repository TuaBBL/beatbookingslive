import { Search, Music2, MapPin, X, Youtube, Instagram, Facebook, Music as SoundCloudIcon, Radio, ChevronDown } from 'lucide-react';
import { useState, useEffect, useRef } from 'react';
import { Artist } from '../lib/supabase';
import { AUSTRALIAN_STATES } from '../lib/australianStates';

interface ArtistDirectorySearchProps {
  artists: Artist[];
  onFilteredArtistsChange: (filtered: Artist[]) => void;
}

const CATEGORIES = ['DJ', 'Band', 'Solo Artist', 'Producer', 'Duo', 'MC', 'Specialty Act', 'Other'];
const GENRES = [
  'R&B',
  'Rock',
  'Reggae',
  'DNB',
  'Open Format',
  'Pop/Soul',
  'Rock/Alternative',
  'Hip-Hop/RnB',
  'EDM/House',
  'Jazz/Lounge/Piano',
  'Acoustic/Indie',
  'Reggae/Acoustic',
  'Funk/Groove'
];

export function ArtistDirectorySearch({ artists, onFilteredArtistsChange }: ArtistDirectorySearchProps) {
  const [nameQuery, setNameQuery] = useState('');
  const [genreQuery, setGenreQuery] = useState('');
  const [categoryQuery, setCategoryQuery] = useState('');
  const [locationQuery, setLocationQuery] = useState('');
  const [stateQuery, setStateQuery] = useState('');
  const [activeSocialFilter, setActiveSocialFilter] = useState<string | null>(null);
  const [locationDropdownOpen, setLocationDropdownOpen] = useState(false);
  const [availableLocations, setAvailableLocations] = useState<string[]>([]);
  const locationRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (locationRef.current && !locationRef.current.contains(event.target as Node)) {
        setLocationDropdownOpen(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    const locationsSet = new Set<string>();

    artists.forEach((artist) => {
      if (artist.state_territories && artist.state_territories.length > 0) {
        artist.state_territories.forEach(state => {
          const stateObj = AUSTRALIAN_STATES.find(s => s.code === state);
          if (stateObj) {
            locationsSet.add(`${stateObj.name} (${stateObj.code})`);
          }
        });
      }

      if (artist.locations && artist.locations.length > 0) {
        artist.locations.forEach(loc => {
          if (loc && loc.trim()) {
            locationsSet.add(loc.trim());
          }
        });
      }

      if (artist.location && artist.location.trim()) {
        locationsSet.add(artist.location.trim());
      }
    });

    const sortedLocations = Array.from(locationsSet).sort((a, b) => a.localeCompare(b));
    setAvailableLocations(sortedLocations);
  }, [artists]);

  useEffect(() => {
    const name = nameQuery.toLowerCase().trim();
    const genre = genreQuery.toLowerCase().trim();
    const category = categoryQuery.toLowerCase().trim();
    const location = locationQuery.toLowerCase().trim();
    const state = stateQuery.toLowerCase().trim();

    if (!name && !genre && !category && !location && !state && !activeSocialFilter) {
      onFilteredArtistsChange(artists);
      return;
    }

    const filtered = artists.filter((artist) => {
      const nameMatch = !name ||
        artist.name.toLowerCase().includes(name) ||
        artist.stage_name?.toLowerCase().includes(name);

      const genreMatch = !genre ||
        artist.genre?.toLowerCase().includes(genre);

      const categoryMatch = !category ||
        artist.category.toLowerCase().includes(category);

      const locationMatch = !location ||
        artist.location.toLowerCase().includes(location) ||
        (artist.locations && artist.locations.some(loc => loc.toLowerCase().includes(location)));

      const stateMatch = !state ||
        (artist.state_territories && artist.state_territories.some(st => st.toLowerCase().includes(state)));

      let socialMatch = true;
      if (activeSocialFilter) {
        switch (activeSocialFilter) {
          case 'youtube':
            socialMatch = !!artist.youtube_link;
            break;
          case 'instagram':
            socialMatch = !!artist.instagram_link;
            break;
          case 'facebook':
            socialMatch = !!artist.facebook_link;
            break;
          case 'soundcloud':
            socialMatch = !!artist.soundcloud_link;
            break;
          case 'spotify':
            socialMatch = !!artist.spotify_link;
            break;
        }
      }

      return nameMatch && genreMatch && categoryMatch && locationMatch && stateMatch && socialMatch;
    });

    onFilteredArtistsChange(filtered);
  }, [nameQuery, genreQuery, categoryQuery, locationQuery, stateQuery, activeSocialFilter, artists, onFilteredArtistsChange]);

  const handleClearAll = () => {
    setNameQuery('');
    setGenreQuery('');
    setCategoryQuery('');
    setLocationQuery('');
    setStateQuery('');
    setActiveSocialFilter(null);
  };

  const handleSocialFilter = (platform: string) => {
    if (activeSocialFilter === platform) {
      setActiveSocialFilter(null);
    } else {
      setActiveSocialFilter(platform);
    }
  };

  const hasActiveFilters = nameQuery || genreQuery || categoryQuery || locationQuery || stateQuery || activeSocialFilter;

  return (
    <div className="w-full max-w-5xl mx-auto mb-12">
      <div className="bg-gray-900 border-2 border-[#39ff14] border-opacity-50 rounded-lg p-6 glow-red">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl font-bold text-[#39ff14]" style={{ textShadow: '0 0 8px #ff0000' }}>
            Search Artist Directory
          </h3>
          {hasActiveFilters && (
            <button
              onClick={handleClearAll}
              className="flex items-center gap-2 px-4 py-2 bg-red-500 bg-opacity-20 border border-red-500 text-red-500 rounded-lg hover:bg-opacity-40 transition-all duration-300"
              aria-label="Clear all filters"
            >
              <X className="w-4 h-4" />
              Clear All
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4 mb-6">
          <div className="relative">
            <label htmlFor="name-search" className="block text-xs text-[#39ff14] opacity-70 mb-2 uppercase font-semibold">
              Artist Name
            </label>
            <input
              id="name-search"
              type="text"
              placeholder="Search by name..."
              value={nameQuery}
              onChange={(e) => setNameQuery(e.target.value)}
              className="w-full px-4 py-3 bg-gray-800 border border-[#39ff14] border-opacity-30 rounded-lg text-[#39ff14] placeholder-[#39ff14] placeholder-opacity-30 focus:outline-none focus:border-opacity-100 transition-all duration-300 text-sm"
              style={{ textShadow: '0 0 5px #ff0000' }}
            />
            {nameQuery && (
              <button
                onClick={() => setNameQuery('')}
                className="absolute right-3 top-9 text-red-500 hover:text-red-400 transition-colors"
                aria-label="Clear name search"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          <div className="relative">
            <label htmlFor="genre-search" className="block text-xs text-[#39ff14] opacity-70 mb-2 uppercase font-semibold">
              Genre
            </label>
            <select
              id="genre-search"
              value={genreQuery}
              onChange={(e) => setGenreQuery(e.target.value)}
              className="w-full px-4 py-3 bg-gray-800 border border-[#39ff14] border-opacity-30 rounded-lg text-[#39ff14] focus:outline-none focus:border-opacity-100 transition-all duration-300 text-sm appearance-none cursor-pointer"
              style={{ textShadow: '0 0 5px #ff0000' }}
            >
              <option value="">All Genres</option>
              {GENRES.map((genre) => (
                <option key={genre} value={genre} className="bg-gray-900 text-[#39ff14]">
                  {genre}
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-9 w-4 h-4 text-[#39ff14] pointer-events-none" />
          </div>

          <div className="relative">
            <label htmlFor="category-search" className="block text-xs text-[#39ff14] opacity-70 mb-2 uppercase font-semibold">
              Category
            </label>
            <select
              id="category-search"
              value={categoryQuery}
              onChange={(e) => setCategoryQuery(e.target.value)}
              className="w-full px-4 py-3 bg-gray-800 border border-[#39ff14] border-opacity-30 rounded-lg text-[#39ff14] focus:outline-none focus:border-opacity-100 transition-all duration-300 text-sm appearance-none cursor-pointer"
              style={{ textShadow: '0 0 5px #ff0000' }}
            >
              <option value="">All Categories</option>
              {CATEGORIES.map((category) => (
                <option key={category} value={category} className="bg-gray-900 text-[#39ff14]">
                  {category}
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-9 w-4 h-4 text-[#39ff14] pointer-events-none" />
          </div>

          <div className="relative">
            <label htmlFor="state-search" className="block text-xs text-[#39ff14] opacity-70 mb-2 uppercase font-semibold">
              State/Territory
            </label>
            <select
              id="state-search"
              value={stateQuery}
              onChange={(e) => setStateQuery(e.target.value)}
              className="w-full px-4 py-3 bg-gray-800 border border-[#39ff14] border-opacity-30 rounded-lg text-[#39ff14] focus:outline-none focus:border-opacity-100 transition-all duration-300 text-sm appearance-none cursor-pointer"
              style={{ textShadow: '0 0 5px #ff0000' }}
            >
              <option value="">All States</option>
              {AUSTRALIAN_STATES.map((state) => (
                <option key={state.code} value={state.code} className="bg-gray-900 text-[#39ff14]">
                  {state.name}
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-9 w-4 h-4 text-[#39ff14] pointer-events-none" />
          </div>

          <div className="relative" ref={locationRef}>
            <label htmlFor="location-search" className="block text-xs text-[#39ff14] opacity-70 mb-2 uppercase font-semibold">
              Location
            </label>
            <input
              id="location-search"
              type="text"
              placeholder="City/Suburb/State..."
              value={locationQuery}
              onChange={(e) => {
                setLocationQuery(e.target.value);
                setLocationDropdownOpen(true);
              }}
              onFocus={() => setLocationDropdownOpen(true)}
              className="w-full px-4 py-3 bg-gray-800 border border-[#39ff14] border-opacity-30 rounded-lg text-[#39ff14] placeholder-[#39ff14] placeholder-opacity-30 focus:outline-none focus:border-opacity-100 transition-all duration-300 text-sm"
              style={{ textShadow: '0 0 5px #ff0000' }}
            />
            {locationQuery && (
              <button
                onClick={() => {
                  setLocationQuery('');
                  setLocationDropdownOpen(false);
                }}
                className="absolute right-3 top-9 text-red-500 hover:text-red-400 transition-colors z-10"
                aria-label="Clear location search"
              >
                <X className="w-4 h-4" />
              </button>
            )}
            {locationDropdownOpen && availableLocations.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-1 bg-gray-800 border border-[#39ff14] border-opacity-50 rounded-lg shadow-2xl max-h-64 overflow-y-auto z-20">
                {availableLocations
                  .filter(loc =>
                    locationQuery === '' ||
                    loc.toLowerCase().includes(locationQuery.toLowerCase())
                  )
                  .slice(0, 50)
                  .map((location, index) => (
                    <button
                      key={index}
                      type="button"
                      onClick={() => {
                        setLocationQuery(location);
                        setLocationDropdownOpen(false);
                      }}
                      className="w-full px-4 py-2 text-left text-[#39ff14] hover:bg-gray-700 transition-colors text-sm border-b border-red-500 border-opacity-10 last:border-b-0"
                    >
                      {location}
                    </button>
                  ))}
                {availableLocations.filter(loc =>
                  locationQuery === '' ||
                  loc.toLowerCase().includes(locationQuery.toLowerCase())
                ).length === 0 && (
                  <div className="px-4 py-3 text-[#39ff14] opacity-50 text-sm text-center">
                    No matching locations found
                  </div>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="border-t border-red-500 border-opacity-20 pt-6">
          <label className="block text-xs text-[#39ff14] opacity-70 mb-3 uppercase font-semibold">
            Filter by Social Media Platform
          </label>
          <div className="flex flex-wrap gap-3">
            <button
              onClick={() => handleSocialFilter('youtube')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-semibold transition-all duration-300 ${
                activeSocialFilter === 'youtube'
                  ? 'bg-red-500 text-white border-2 border-red-500'
                  : 'bg-transparent border-2 border-red-500 text-red-500 hover:bg-red-500 hover:text-white'
              }`}
              aria-label="Filter by YouTube"
              aria-pressed={activeSocialFilter === 'youtube'}
            >
              <Youtube className="w-4 h-4" />
              YouTube
            </button>

            <button
              onClick={() => handleSocialFilter('instagram')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-semibold transition-all duration-300 ${
                activeSocialFilter === 'instagram'
                  ? 'bg-pink-500 text-white border-2 border-pink-500'
                  : 'bg-transparent border-2 border-pink-500 text-pink-500 hover:bg-pink-500 hover:text-white'
              }`}
              aria-label="Filter by Instagram"
              aria-pressed={activeSocialFilter === 'instagram'}
            >
              <Instagram className="w-4 h-4" />
              Instagram
            </button>

            <button
              onClick={() => handleSocialFilter('facebook')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-semibold transition-all duration-300 ${
                activeSocialFilter === 'facebook'
                  ? 'bg-blue-500 text-white border-2 border-blue-500'
                  : 'bg-transparent border-2 border-blue-500 text-blue-500 hover:bg-blue-500 hover:text-white'
              }`}
              aria-label="Filter by Facebook"
              aria-pressed={activeSocialFilter === 'facebook'}
            >
              <Facebook className="w-4 h-4" />
              Facebook
            </button>

            <button
              onClick={() => handleSocialFilter('soundcloud')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-semibold transition-all duration-300 ${
                activeSocialFilter === 'soundcloud'
                  ? 'bg-orange-500 text-white border-2 border-orange-500'
                  : 'bg-transparent border-2 border-orange-500 text-orange-500 hover:bg-orange-500 hover:text-white'
              }`}
              aria-label="Filter by SoundCloud"
              aria-pressed={activeSocialFilter === 'soundcloud'}
            >
              <SoundCloudIcon className="w-4 h-4" />
              SoundCloud
            </button>

            <button
              onClick={() => handleSocialFilter('spotify')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg font-semibold transition-all duration-300 ${
                activeSocialFilter === 'spotify'
                  ? 'bg-green-500 text-white border-2 border-green-500'
                  : 'bg-transparent border-2 border-green-500 text-green-500 hover:bg-green-500 hover:text-white'
              }`}
              aria-label="Filter by Spotify"
              aria-pressed={activeSocialFilter === 'spotify'}
            >
              <Radio className="w-4 h-4" />
              Spotify
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
