import { useState, useEffect } from 'react';
import { Trophy, Eye, Calendar, TrendingUp } from 'lucide-react';
import { supabase, Artist } from '../lib/supabase';

interface FeaturedArtistOfMonthProps {
  onArtistClick: (artist: Artist) => void;
}

interface FeaturedArtistData {
  artist: Artist;
  totalScore: number;
  viewCount: number;
  bookingCount: number;
}

export function FeaturedArtistOfMonth({ onArtistClick }: FeaturedArtistOfMonthProps) {
  const [featuredArtist, setFeaturedArtist] = useState<FeaturedArtistData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchFeaturedArtist();
  }, []);

  const fetchFeaturedArtist = async () => {
    try {
      const currentMonth = new Date();
      currentMonth.setDate(1);
      const monthStr = currentMonth.toISOString().split('T')[0];

      const { data: featuredData, error: featuredError } = await supabase
        .from('featured_artists')
        .select('artist_id, total_score')
        .eq('is_prime_featured', true)
        .eq('month', monthStr)
        .maybeSingle();

      if (featuredError || !featuredData) {
        setFeaturedArtist(null);
        return;
      }

      const { data: artistData, error: artistError } = await supabase
        .from('artist_cards')
        .select('*')
        .eq('id', featuredData.artist_id)
        .maybeSingle();

      if (artistError || !artistData) {
        setFeaturedArtist(null);
        return;
      }

      const { data: analyticsData } = await supabase
        .from('artist_analytics')
        .select('view_count, booking_request_count')
        .eq('artist_id', featuredData.artist_id)
        .eq('month', monthStr)
        .maybeSingle();

      setFeaturedArtist({
        artist: artistData,
        totalScore: featuredData.total_score,
        viewCount: analyticsData?.view_count || 0,
        bookingCount: analyticsData?.booking_request_count || 0,
      });
    } catch (error) {
      console.error('Error fetching featured artist:', error);
      setFeaturedArtist(null);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <section className="mb-16">
        <div className="bg-gradient-to-r from-yellow-900 to-yellow-800 rounded-lg p-8 border-2 border-yellow-500 glow-yellow animate-pulse">
          <div className="h-8 bg-yellow-700 rounded w-1/3 mb-4"></div>
          <div className="h-64 bg-yellow-700 rounded"></div>
        </div>
      </section>
    );
  }

  if (!featuredArtist) {
    return null;
  }

  const { artist } = featuredArtist;
  const currentMonthName = new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' });

  return (
    <section className="mb-16">
      <div className="flex items-center gap-3 mb-6">
        <Trophy className="w-8 h-8 text-yellow-500" />
        <h3 className="text-3xl sm:text-4xl font-bold text-yellow-500">
          Featured Artist of the Month
        </h3>
      </div>

      <div
        onClick={() => onArtistClick(artist)}
        className="bg-gradient-to-br from-gray-900 via-yellow-900 to-gray-900 rounded-lg border-4 border-yellow-500 glow-yellow-strong overflow-hidden cursor-pointer transform transition-all duration-300 hover:scale-[1.02] hover:glow-yellow-strong"
      >
        <div className="relative">
          <div className="absolute top-4 left-4 z-20 flex flex-col gap-2">
            <div className="px-4 py-2 bg-yellow-500 text-black text-sm font-bold rounded-lg flex items-center gap-2 shadow-lg">
              <Trophy className="w-5 h-5" />
              FEATURED ARTIST
            </div>
            <div className="px-3 py-1 bg-black bg-opacity-80 text-yellow-500 text-xs font-semibold rounded">
              {currentMonthName}
            </div>
          </div>

          {artist.is_verified && (
            <div className="absolute top-4 right-4 z-20">
              <div className="px-3 py-2 bg-blue-500 text-white text-sm font-bold rounded-lg flex items-center gap-1">
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                </svg>
                VERIFIED
              </div>
            </div>
          )}

          <div className="grid md:grid-cols-2 gap-0">
            <div className="relative h-96 md:h-auto overflow-hidden">
              <img
                src={artist.image_url}
                alt={artist.stage_name || artist.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
            </div>

            <div className="p-8 flex flex-col justify-center bg-gradient-to-br from-yellow-900 to-gray-900">
              <h4 className="text-4xl font-bold text-yellow-500 mb-3">
                {artist.stage_name || artist.name}
              </h4>

              <p className="text-yellow-400 text-xl mb-2">{artist.category}</p>
              {artist.genre && (
                <p className="text-yellow-400 text-sm mb-4 opacity-80">{artist.genre}</p>
              )}

              <div className="flex items-center gap-2 text-yellow-400 mb-6">
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                </svg>
                <span>{artist.location}</span>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div className="bg-black bg-opacity-40 rounded-lg p-4 border border-yellow-500 border-opacity-30">
                  <div className="flex items-center gap-2 mb-2">
                    <Eye className="w-5 h-5 text-yellow-500" />
                    <span className="text-sm text-yellow-400">Views</span>
                  </div>
                  <p className="text-3xl font-bold text-yellow-500">{featuredArtist.viewCount}</p>
                </div>

                <div className="bg-black bg-opacity-40 rounded-lg p-4 border border-yellow-500 border-opacity-30">
                  <div className="flex items-center gap-2 mb-2">
                    <Calendar className="w-5 h-5 text-yellow-500" />
                    <span className="text-sm text-yellow-400">Bookings</span>
                  </div>
                  <p className="text-3xl font-bold text-yellow-500">{featuredArtist.bookingCount}</p>
                </div>
              </div>

              <p className="text-yellow-400 text-sm leading-relaxed mb-6 line-clamp-4">
                {artist.about}
              </p>

              <div className="flex items-center gap-3 p-4 bg-yellow-500 bg-opacity-10 border border-yellow-500 rounded-lg">
                <TrendingUp className="w-6 h-6 text-yellow-500" />
                <div>
                  <p className="text-xs text-yellow-400 uppercase tracking-wider">Top Performer</p>
                  <p className="text-lg font-bold text-yellow-500">
                    {featuredArtist.totalScore} Total Engagement Points
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
