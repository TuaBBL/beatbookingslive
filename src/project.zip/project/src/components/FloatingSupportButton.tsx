import { MessageCircle } from 'lucide-react';

interface FloatingSupportButtonProps {
  onClick: () => void;
}

export function FloatingSupportButton({ onClick }: FloatingSupportButtonProps) {
  return (
    <button
      onClick={onClick}
      className="fixed bottom-6 right-6 z-40 w-14 h-14 bg-gradient-to-br from-[#39ff14] to-red-500 rounded-full shadow-lg hover:shadow-xl transition-all duration-300 transform hover:scale-110 flex items-center justify-center group"
      style={{ boxShadow: '0 0 20px rgba(57, 255, 20, 0.5)' }}
      aria-label="Support Chat"
    >
      <MessageCircle className="w-6 h-6 text-black group-hover:scale-110 transition-transform" />
    </button>
  );
}
