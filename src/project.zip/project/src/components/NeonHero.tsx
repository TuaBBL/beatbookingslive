import { motion } from "framer-motion";
import React, { useState, useEffect } from "react";

interface ArtistCard {
  id: number;
  name: string;
  image: string;
  genre: string;
}

const mockArtists: ArtistCard[] = [
  { id: 1, name: "DJ Nova", image: "https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=400", genre: "Electronic" },
  { id: 2, name: "The Beats", image: "https://images.pexels.com/photos/1105666/pexels-photo-1105666.jpeg?auto=compress&cs=tinysrgb&w=400", genre: "Hip Hop" },
  { id: 3, name: "Neon Lights", image: "https://images.pexels.com/photos/1268558/pexels-photo-1268558.jpeg?auto=compress&cs=tinysrgb&w=400", genre: "EDM" },
  { id: 4, name: "Sound Wave", image: "https://images.pexels.com/photos/1649693/pexels-photo-1649693.jpeg?auto=compress&cs=tinysrgb&w=400", genre: "House" },
  { id: 5, name: "Rhythm Soul", image: "https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=400", genre: "R&B" },
  { id: 6, name: "Bass Drop", image: "https://images.pexels.com/photos/1834895/pexels-photo-1834895.jpeg?auto=compress&cs=tinysrgb&w=400", genre: "Dubstep" },
  { id: 7, name: "Synth Master", image: "https://images.pexels.com/photos/1699161/pexels-photo-1699161.jpeg?auto=compress&cs=tinysrgb&w=400", genre: "Techno" },
  { id: 8, name: "Melody Mix", image: "https://images.pexels.com/photos/1047442/pexels-photo-1047442.jpeg?auto=compress&cs=tinysrgb&w=400", genre: "Pop" },
];

export default function NeonHero() {
  const lines = [
    "Connecting Artists and Planners across Australia & New Zealand.",
    "Book the Beat — Live the Moment.",
  ];

  const [index, setIndex] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setIndex((prev) => (prev + 1) % lines.length);
    }, 3500);
    return () => clearInterval(interval);
  }, []);

  const duplicatedArtists = [...mockArtists, ...mockArtists, ...mockArtists];

  return (
    <div className="hero w-full min-h-dvh h-auto flex items-center justify-center bg-black text-white overflow-visible relative px-4 py-8 sm:py-16">

      {/* Neon glow background aura */}
      <div className="absolute w-[200px] h-[200px] sm:w-[300px] sm:h-[300px] rounded-full blur-3xl bg-red-600 opacity-30 -top-10 -left-10 animate-pulse" />
      <div className="absolute w-[200px] h-[200px] sm:w-[300px] sm:h-[300px] rounded-full blur-3xl bg-green-500 opacity-30 bottom-0 right-0 animate-pulse" />

      {/* Animated Artist Cards Background - Row 1 (Left to Right) */}
      <div className="absolute top-[15%] left-0 w-full overflow-hidden opacity-40 hidden sm:block">
        <div className="flex gap-4 animate-scroll-left">
          {duplicatedArtists.map((artist, idx) => (
            <div
              key={`row1-${idx}`}
              className="flex-shrink-0 w-32 h-32 rounded-lg overflow-hidden border-2 border-[#39ff14] shadow-lg"
              style={{ boxShadow: '0 0 15px rgba(57,255,20,0.4)' }}
            >
              <img
                src={artist.image}
                alt={artist.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
            </div>
          ))}
        </div>
      </div>

      {/* Animated Artist Cards Background - Row 2 (Right to Left) */}
      <div className="absolute bottom-[15%] left-0 w-full overflow-hidden opacity-40 hidden sm:block">
        <div className="flex gap-4 animate-scroll-right">
          {duplicatedArtists.map((artist, idx) => (
            <div
              key={`row2-${idx}`}
              className="flex-shrink-0 w-32 h-32 rounded-lg overflow-hidden border-2 border-red-500 shadow-lg"
              style={{ boxShadow: '0 0 15px rgba(255,0,0,0.4)' }}
            >
              <img
                src={artist.image}
                alt={artist.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
            </div>
          ))}
        </div>
      </div>

      <motion.h1
        key={index}
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -30 }}
        transition={{ duration: 0.7 }}
        className="
          hero-text text-2xl sm:text-3xl md:text-5xl lg:text-6xl font-extrabold text-center px-4 sm:px-6 relative z-10
          drop-shadow-[0_0_15px_rgba(57,255,20,0.8)]
          animate-glow
        "
        style={{
          textShadow:
            "0 0 12px rgba(57,255,20,0.9), 0 0 22px rgba(255,0,0,0.7), 0 0 32px rgba(57,255,20,0.5), 0 0 3px rgba(0,0,0,0.8)",
          color: "#39ff14"
        }}
      >
        {lines[index]}
      </motion.h1>

      <style>{`
        @keyframes neonPulse {
          0% { text-shadow: 0 0 10px #39ff14, 0 0 20px #ff0000; }
          50% { text-shadow: 0 0 20px #39ff14, 0 0 35px #ff0000; }
          100% { text-shadow: 0 0 10px #39ff14, 0 0 20px #ff0000; }
        }
        .animate-glow {
          animation: neonPulse 2.5s infinite alternate;
        }

        @keyframes scrollLeft {
          0% {
            transform: translateX(0);
          }
          100% {
            transform: translateX(-33.333%);
          }
        }

        @keyframes scrollRight {
          0% {
            transform: translateX(-33.333%);
          }
          100% {
            transform: translateX(0);
          }
        }

        .animate-scroll-left {
          animation: scrollLeft 40s linear infinite;
          display: flex;
        }

        .animate-scroll-right {
          animation: scrollRight 40s linear infinite;
          display: flex;
        }
      `}</style>
    </div>
  );
}
