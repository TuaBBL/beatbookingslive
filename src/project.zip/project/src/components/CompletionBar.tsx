import { ProfileStatus } from '../lib/profileCompleteness';

interface CompletionBarProps {
  percentage: number;
  status?: ProfileStatus;
  showPercentage?: boolean;
  height?: 'sm' | 'md' | 'lg';
}

export function CompletionBar({
  percentage,
  status,
  showPercentage = true,
  height = 'md',
}: CompletionBarProps) {
  const heightClasses = {
    sm: 'h-1',
    md: 'h-2',
    lg: 'h-3',
  };

  const getBarColor = () => {
    if (status) {
      switch (status) {
        case 'green':
          return 'bg-green-500';
        case 'yellow':
          return 'bg-yellow-500';
        case 'red':
          return 'bg-red-500';
      }
    }
    // Fallback: color based on percentage
    if (percentage >= 100) return 'bg-green-500';
    if (percentage >= 50) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-1">
        {showPercentage && (
          <span className="text-xs text-gray-400 font-medium">
            {percentage}% Complete
          </span>
        )}
      </div>
      <div className={`w-full bg-gray-700 rounded-full overflow-hidden ${heightClasses[height]}`}>
        <div
          className={`${getBarColor()} ${heightClasses[height]} rounded-full transition-all duration-500 ease-out`}
          style={{ width: `${Math.min(percentage, 100)}%` }}
        />
      </div>
    </div>
  );
}
