import { X, Save, AlertCircle, Trash2 } from 'lucide-react';
import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { MediaLibrary } from './MediaLibrary';
import { ProfileThemeSelector } from './ProfileThemeSelector';
import { PhoneInput } from './PhoneInput';

interface EditProfileModalProps {
  isOpen: boolean;
  artistCard: any;
  artistProfile: any;
  userId: string;
  onClose: () => void;
  onSuccess: () => void;
}

export function EditProfileModal({ isOpen, artistCard, artistProfile, userId, onClose, onSuccess }: EditProfileModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    stageName: '',
    category: '',
    genre: '',
    location: '',
    about: '',
    phone: '',
    cost: '',
    costType: '',
    imageUrl: '',
    youtubeLink: '',
    instagramLink: '',
    facebookLink: '',
    soundcloudLink: '',
    mixcloudLink: '',
    spotifyLink: '',
    tiktokLink: '',
    availability: 'available',
  });
  const [additionalImages, setAdditionalImages] = useState<string[]>([]);
  const [videoUrls, setVideoUrls] = useState<string[]>([]);
  const [profileTheme, setProfileTheme] = useState('red');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    if (artistCard && isOpen) {
      setFormData({
        name: artistCard.name || '',
        stageName: artistCard.stage_name || '',
        category: artistCard.category || '',
        genre: artistCard.genre || '',
        location: artistCard.location || '',
        about: artistCard.about || '',
        phone: artistProfile?.phone || '',
        cost: artistCard.cost?.toString() || '',
        costType: artistCard.cost_type || '',
        imageUrl: artistCard.image_url || '',
        youtubeLink: artistCard.youtube_link || '',
        instagramLink: artistCard.instagram_link || '',
        facebookLink: artistCard.facebook_link || '',
        soundcloudLink: artistCard.soundcloud_link || '',
        mixcloudLink: artistCard.mixcloud_link || '',
        spotifyLink: artistCard.spotify_link || '',
        tiktokLink: artistCard.tiktok_link || '',
        availability: artistCard.availability || 'available',
      });
      setAdditionalImages(artistCard.additional_images || []);
      setVideoUrls(artistCard.video_urls || []);
      setProfileTheme(artistCard.profile_theme || 'red');
    }
  }, [artistCard, artistProfile, isOpen]);

  if (!isOpen) return null;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (additionalImages.length > 4) {
        throw new Error('Maximum 4 additional images allowed (5 total including main image)');
      }

      if (videoUrls.length > 5) {
        throw new Error('Maximum 5 videos allowed');
      }

      const { data: userData } = await supabase
        .from('users')
        .select('email')
        .eq('id', userId)
        .maybeSingle();

      const userEmail = userData?.email || artistProfile?.email || '';

      const { error: updateError } = await supabase
        .from('artist_cards')
        .update({
          name: formData.name,
          stage_name: formData.stageName,
          category: formData.category,
          genre: formData.genre,
          location: formData.location,
          about: formData.about,
          cost: formData.cost ? parseFloat(formData.cost) : null,
          cost_type: formData.cost && formData.costType ? formData.costType : null,
          image_url: formData.imageUrl,
          additional_images: additionalImages,
          video_urls: videoUrls,
          youtube_link: formData.youtubeLink,
          instagram_link: formData.instagramLink,
          facebook_link: formData.facebookLink,
          soundcloud_link: formData.soundcloudLink,
          mixcloud_link: formData.mixcloudLink,
          spotify_link: formData.spotifyLink,
          tiktok_link: formData.tiktokLink,
          availability: formData.availability,
          profile_theme: profileTheme,
          email: userEmail,
        })
        .eq('id', artistCard.id);

      if (updateError) throw updateError;

      if (artistProfile) {
        const { error: profileError } = await supabase
          .from('artist_profiles')
          .update({
            phone: formData.phone,
          })
          .eq('id', artistProfile.id);

        if (profileError) throw profileError;
      }

      onSuccess();
    } catch (err: any) {
      setError(err.message || 'An error occurred while updating your profile');
    } finally {
      setLoading(false);
    }
  };

  const handleDeleteProfile = async () => {
    if (!confirm('Are you sure you want to delete your artist profile? This action cannot be undone and will permanently remove all your profile data, media, reviews, and account.')) {
      return;
    }

    setError('');
    setDeleting(true);

    try {
      // Cancel any active subscriptions immediately
      const { error: subscriptionError } = await supabase
        .from('subscriptions')
        .update({
          status: 'cancelled',
          end_date: new Date().toISOString()
        })
        .eq('user_id', userId)
        .eq('status', 'active');

      if (subscriptionError) throw subscriptionError;

      // First, fetch all booking IDs for this artist
      const { data: bookingsData, error: fetchBookingsError } = await supabase
        .from('bookings')
        .select('id')
        .eq('artist_id', artistCard.id);

      if (fetchBookingsError) throw fetchBookingsError;

      // Delete booking messages if there are any bookings
      if (bookingsData && bookingsData.length > 0) {
        const bookingIds = bookingsData.map(b => b.id);
        const { error: bookingMessagesError } = await supabase
          .from('booking_messages')
          .delete()
          .in('booking_id', bookingIds);

        if (bookingMessagesError) throw bookingMessagesError;
      }

      // Delete bookings
      const { error: bookingsError } = await supabase
        .from('bookings')
        .delete()
        .eq('artist_id', artistCard.id);

      if (bookingsError) throw bookingsError;

      // Delete user favorites that reference this artist
      const { error: favoritesError } = await supabase
        .from('user_favorites')
        .delete()
        .eq('artist_id', artistCard.id);

      if (favoritesError) throw favoritesError;

      // Delete reviews
      const { error: reviewsError } = await supabase
        .from('reviews')
        .delete()
        .eq('artist_id', artistCard.id);

      if (reviewsError) throw reviewsError;

      // Delete analytics
      const { error: analyticsError } = await supabase
        .from('artist_analytics')
        .delete()
        .eq('artist_id', artistCard.id);

      if (analyticsError) throw analyticsError;

      // Delete detailed analytics
      const { error: detailedAnalyticsError } = await supabase
        .from('artist_analytics_detailed')
        .delete()
        .eq('artist_id', artistCard.id);

      if (detailedAnalyticsError) throw detailedAnalyticsError;

      // Delete featured artists
      const { error: featuredError } = await supabase
        .from('featured_artists')
        .delete()
        .eq('artist_id', artistCard.id);

      if (featuredError) throw featuredError;

      // Delete artist profile
      const { error: profileError } = await supabase
        .from('artist_profiles')
        .delete()
        .eq('user_id', userId);

      if (profileError) throw profileError;

      // Delete the artist card
      const { error: cardError } = await supabase
        .from('artist_cards')
        .delete()
        .eq('id', artistCard.id);

      if (cardError) throw cardError;

      alert('Profile deleted successfully. You can create a new profile anytime.');
      onSuccess();
      onClose();
    } catch (err: any) {
      setError(err.message || 'An error occurred while deleting your profile');
    } finally {
      setDeleting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-90 backdrop-blur-sm z-50 overflow-y-auto p-4">
      <div className="min-h-screen flex items-center justify-center py-8">
        <div className="bg-gray-900 rounded-2xl border-2 border-red-500 glow-red-strong max-w-6xl w-full my-8" onClick={(e) => e.stopPropagation()}>
        <div className="relative p-8 pb-4">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 bg-black bg-opacity-70 rounded-full p-2 text-fluro-green-subtle hover:text-fluro-green hover:bg-opacity-100 transition-all duration-300 z-10"
          >
            <X className="w-6 h-6" />
          </button>

          <h2 className="text-3xl font-bold text-fluro-green mb-2">
            Edit Your Artist Profile
          </h2>
          <p className="text-fluro-green-subtle mb-6">
            Update your information and manage your media library
          </p>

          {error && (
            <div className="mb-4 p-3 bg-red-500 bg-opacity-20 border border-red-500 rounded-lg flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-red-500 flex-shrink-0" />
              <p className="text-red-500 text-sm">{error}</p>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-6">
            <section className="bg-black bg-opacity-30 rounded-lg p-6 border border-red-500 border-opacity-30">
              <h3 className="text-xl font-bold text-fluro-green mb-4">Basic Information</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-gray-800 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] placeholder-[#39ff14] placeholder-opacity-40 focus:outline-none focus:border-opacity-100 transition-all duration-300"
                    required
                  />
                </div>

                <div>
                  <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
                    Stage Name *
                  </label>
                  <input
                    type="text"
                    name="stageName"
                    value={formData.stageName}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-gray-800 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] placeholder-[#39ff14] placeholder-opacity-40 focus:outline-none focus:border-opacity-100 transition-all duration-300"
                    required
                  />
                </div>

                <div>
                  <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
                    Category *
                  </label>
                  <select
                    name="category"
                    value={formData.category}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-gray-800 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] focus:outline-none focus:border-opacity-100 transition-all duration-300"
                    required
                  >
                    <option value="">Select a category</option>
                    <option value="DJ">DJ</option>
                    <option value="Band">Band</option>
                    <option value="Solo Artist">Solo Artist</option>
                    <option value="Producer">Producer</option>
                    <option value="Duo">Duo</option>
                    <option value="MC">MC</option>
                    <option value="Specialty Act">Specialty Act</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
                    Genre *
                  </label>
                  <input
                    type="text"
                    name="genre"
                    value={formData.genre}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-gray-800 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] placeholder-[#39ff14] placeholder-opacity-40 focus:outline-none focus:border-opacity-100 transition-all duration-300"
                    placeholder="e.g., House, Techno, Rock, Jazz"
                    required
                  />
                </div>

                <div>
                  <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
                    Location *
                  </label>
                  <input
                    type="text"
                    name="location"
                    value={formData.location}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-gray-800 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] placeholder-[#39ff14] placeholder-opacity-40 focus:outline-none focus:border-opacity-100 transition-all duration-300"
                    required
                  />
                </div>

                <div>
                  <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
                    Booking Cost (Optional)
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    <div className="relative">
                      <span className="absolute left-4 top-1/2 -translate-y-1/2 text-[#39ff14] pointer-events-none">$</span>
                      <input
                        type="number"
                        name="cost"
                        value={formData.cost}
                        onChange={handleChange}
                        className="w-full pl-8 pr-4 py-3 bg-gray-800 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] placeholder-[#39ff14] placeholder-opacity-40 focus:outline-none focus:border-opacity-100 transition-all duration-300"
                        min="0"
                        step="0.01"
                        placeholder="500"
                      />
                    </div>
                    <select
                      name="costType"
                      value={formData.costType}
                      onChange={handleChange}
                      disabled={!formData.cost}
                      className="w-full px-4 py-3 bg-gray-800 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] focus:outline-none focus:border-opacity-100 transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <option value="">Select type</option>
                      <option value="per_hour">Per Hour</option>
                      <option value="per_event">Per Event</option>
                    </select>
                  </div>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
                    Availability Status *
                  </label>
                  <select
                    name="availability"
                    value={formData.availability}
                    onChange={handleChange}
                    className="w-full px-4 py-3 bg-gray-800 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] focus:outline-none focus:border-opacity-100 transition-all duration-300"
                    required
                  >
                    <option value="available">Available</option>
                    <option value="booked">Booked</option>
                  </select>
                </div>
              </div>

              <div className="mt-6">
                <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
                  About *
                </label>
                <textarea
                  name="about"
                  value={formData.about}
                  onChange={handleChange}
                  className="w-full px-4 py-3 bg-gray-800 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] placeholder-[#39ff14] placeholder-opacity-40 focus:outline-none focus:border-opacity-100 transition-all duration-300 min-h-[120px]"
                  required
                />
              </div>
            </section>

            <section className="bg-black bg-opacity-30 rounded-lg p-6 border border-red-500 border-opacity-30">
              <h3 className="text-xl font-bold text-fluro-green mb-4">Contact Details</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
                    Email
                  </label>
                  <input
                    type="email"
                    value={artistProfile?.email || ''}
                    disabled
                    className="w-full px-4 py-3 bg-gray-700 border-2 border-gray-600 rounded-lg text-gray-400 cursor-not-allowed"
                  />
                </div>

                <div>
                  <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
                    Phone Number
                  </label>
                  <PhoneInput
                    value={formData.phone}
                    onChange={(value) => setFormData({ ...formData, phone: value })}
                    placeholder="1234567890"
                  />
                </div>
              </div>
            </section>

            <section className="bg-black bg-opacity-30 rounded-lg p-6 border border-red-500 border-opacity-30">
              <h3 className="text-xl font-bold text-fluro-green mb-6">Media Library</h3>

              <div className="mb-8">
                <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
                  Main Profile Image *
                </label>
                <input
                  type="url"
                  name="imageUrl"
                  value={formData.imageUrl}
                  onChange={handleChange}
                  className="w-full px-4 py-3 bg-gray-800 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] placeholder-[#39ff14] placeholder-opacity-40 focus:outline-none focus:border-opacity-100 transition-all duration-300"
                  placeholder="https://example.com/image.jpg"
                  required
                />
              </div>

              <div className="space-y-8">
                <MediaLibrary
                  type="images"
                  items={additionalImages}
                  maxItems={artistCard?.is_premium ? null : 4}
                  onChange={setAdditionalImages}
                  userId={userId}
                  isPremium={artistCard?.is_premium || false}
                />

                <MediaLibrary
                  type="videos"
                  items={videoUrls}
                  maxItems={artistCard?.is_premium ? null : 5}
                  onChange={setVideoUrls}
                  userId={userId}
                  isPremium={artistCard?.is_premium || false}
                />
              </div>
            </section>

            <section className="bg-black bg-opacity-30 rounded-lg p-6 border border-red-500 border-opacity-30">
              <ProfileThemeSelector
                currentTheme={profileTheme}
                isPremium={artistCard?.is_premium || false}
                onChange={setProfileTheme}
              />
            </section>

            <section className="bg-black bg-opacity-30 rounded-lg p-6 border border-red-500 border-opacity-30">
              <h3 className="text-xl font-bold text-fluro-green mb-4">Social Links</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {[
                  { name: 'youtubeLink', label: 'YouTube', placeholder: 'https://youtube.com/...' },
                  { name: 'instagramLink', label: 'Instagram', placeholder: 'https://instagram.com/...' },
                  { name: 'facebookLink', label: 'Facebook', placeholder: 'https://facebook.com/...' },
                  { name: 'soundcloudLink', label: 'SoundCloud', placeholder: 'https://soundcloud.com/...' },
                  { name: 'mixcloudLink', label: 'Mixcloud', placeholder: 'https://mixcloud.com/...' },
                  { name: 'spotifyLink', label: 'Spotify', placeholder: 'https://open.spotify.com/...' },
                  { name: 'tiktokLink', label: 'TikTok', placeholder: 'https://tiktok.com/@...' },
                ].map((field) => (
                  <div key={field.name}>
                    <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
                      {field.label}
                    </label>
                    <input
                      type="url"
                      name={field.name}
                      value={formData[field.name as keyof typeof formData]}
                      onChange={handleChange}
                      className="w-full px-4 py-3 bg-gray-800 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] placeholder-[#39ff14] placeholder-opacity-40 focus:outline-none focus:border-opacity-100 transition-all duration-300"
                      placeholder={field.placeholder}
                    />
                  </div>
                ))}
              </div>
            </section>

            <div className="flex flex-col sm:flex-row gap-4 pt-6">
              <button
                type="button"
                onClick={handleDeleteProfile}
                disabled={loading || deleting}
                className="px-6 py-4 bg-red-500 bg-opacity-20 border-2 border-red-500 text-red-500 rounded-lg font-bold text-lg hover:bg-red-500 hover:text-white transition-all duration-300 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {deleting ? (
                  'Deleting...'
                ) : (
                  <>
                    <Trash2 className="w-5 h-5" />
                    Delete Profile
                  </>
                )}
              </button>
              <div className="flex gap-4 flex-1">
                <button
                  type="button"
                  onClick={onClose}
                  disabled={loading || deleting}
                  className="px-6 py-4 bg-gray-800 border-2 border-gray-700 text-gray-400 rounded-lg font-bold text-lg hover:border-gray-600 transition-all duration-300 disabled:opacity-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={loading || deleting}
                  className="flex-1 px-6 py-4 bg-[#39ff14] text-black rounded-lg font-bold text-lg hover:glow-red-strong transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {loading ? (
                    'Saving...'
                  ) : (
                    <>
                      <Save className="w-5 h-5" />
                      Save Changes
                    </>
                  )}
                </button>
              </div>
            </div>
          </form>
        </div>
        </div>
      </div>
    </div>
  );
}
