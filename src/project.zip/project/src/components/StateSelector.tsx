import { useState, useRef, useEffect } from 'react';
import { ChevronDown, X, Check, MapPin } from 'lucide-react';
import { AUSTRALIAN_STATES, AustralianState } from '../lib/australianStates';

interface StateSelectorProps {
  value: string | string[];
  onChange: (value: string | string[]) => void;
  multiple?: boolean;
  required?: boolean;
  placeholder?: string;
  error?: string;
  label?: string;
  className?: string;
}

export function StateSelector({
  value,
  onChange,
  multiple = false,
  required = false,
  placeholder = 'Select state/territory',
  error,
  label,
  className = '',
}: StateSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const dropdownRef = useRef<HTMLDivElement>(null);

  const selectedValues = Array.isArray(value) ? value : value ? [value] : [];

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
        setSearchQuery('');
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const filteredStates = AUSTRALIAN_STATES.filter(
    state =>
      state.abbreviation.toLowerCase().includes(searchQuery.toLowerCase()) ||
      state.fullName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleToggleState = (stateAbbr: string) => {
    if (multiple) {
      const newValue = selectedValues.includes(stateAbbr)
        ? selectedValues.filter(s => s !== stateAbbr)
        : [...selectedValues, stateAbbr];
      onChange(newValue);
    } else {
      onChange(stateAbbr);
      setIsOpen(false);
      setSearchQuery('');
    }
  };

  const handleRemoveState = (stateAbbr: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const newValue = selectedValues.filter(s => s !== stateAbbr);
    onChange(multiple ? newValue : '');
  };

  const getDisplayText = () => {
    if (selectedValues.length === 0) return placeholder;
    if (selectedValues.length === 1) {
      const state = AUSTRALIAN_STATES.find(s => s.abbreviation === selectedValues[0]);
      return state ? state.abbreviation : selectedValues[0];
    }
    return `${selectedValues.length} states selected`;
  };

  return (
    <div className={`relative ${className}`} ref={dropdownRef}>
      {label && (
        <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
          {label}
          {required && <span className="text-red-500 ml-1">*</span>}
        </label>
      )}

      <div
        onClick={() => setIsOpen(!isOpen)}
        className={`w-full px-4 py-2.5 pr-10 bg-black bg-opacity-50 border-2 rounded-lg cursor-pointer transition-all duration-300 flex items-center justify-between ${
          error
            ? 'border-red-500'
            : isOpen
            ? 'border-[#39ff14] border-opacity-100'
            : 'border-[#39ff14] border-opacity-50'
        }`}
        style={{ textShadow: '0 0 5px #ff0000' }}
        role="button"
        aria-haspopup="listbox"
        aria-expanded={isOpen}
        tabIndex={0}
        onKeyDown={(e) => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            setIsOpen(!isOpen);
          }
        }}
      >
        <div className="flex items-center gap-2 flex-1 overflow-hidden">
          <MapPin className="w-5 h-5 text-[#39ff14] opacity-60 flex-shrink-0" />
          <span className={`text-sm ${selectedValues.length === 0 ? 'text-[#39ff14] opacity-40' : 'text-[#39ff14]'}`}>
            {getDisplayText()}
          </span>
        </div>
        <ChevronDown
          className={`w-5 h-5 text-[#39ff14] opacity-60 transition-transform duration-200 ${
            isOpen ? 'transform rotate-180' : ''
          }`}
        />
      </div>

      {multiple && selectedValues.length > 0 && (
        <div className="flex flex-wrap gap-2 mt-2">
          {selectedValues.map(stateAbbr => {
            const state = AUSTRALIAN_STATES.find(s => s.abbreviation === stateAbbr);
            return (
              <div
                key={stateAbbr}
                className="flex items-center gap-1 px-3 py-1 bg-[#39ff14] bg-opacity-20 border border-[#39ff14] rounded-full text-xs text-[#39ff14] font-semibold"
              >
                <span>{state?.abbreviation || stateAbbr}</span>
                <button
                  onClick={(e) => handleRemoveState(stateAbbr, e)}
                  className="hover:text-red-500 transition-colors"
                  aria-label={`Remove ${state?.fullName || stateAbbr}`}
                >
                  <X className="w-3 h-3" />
                </button>
              </div>
            );
          })}
        </div>
      )}

      {error && (
        <p className="mt-1 text-xs text-red-500">{error}</p>
      )}

      {isOpen && (
        <div className="absolute z-50 w-full mt-2 bg-gray-900 border-2 border-[#39ff14] border-opacity-70 rounded-lg shadow-2xl overflow-hidden glow-red">
          <div className="p-2 border-b border-[#39ff14] border-opacity-30">
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search states..."
              className="w-full px-3 py-2 bg-black bg-opacity-50 border border-[#39ff14] border-opacity-50 rounded text-[#39ff14] text-sm placeholder-[#39ff14] placeholder-opacity-40 focus:outline-none focus:border-opacity-100"
              onClick={(e) => e.stopPropagation()}
            />
          </div>
          <div className="max-h-64 overflow-y-auto" role="listbox">
            {filteredStates.length > 0 ? (
              filteredStates.map((state) => {
                const isSelected = selectedValues.includes(state.abbreviation);
                return (
                  <div
                    key={state.abbreviation}
                    onClick={() => handleToggleState(state.abbreviation)}
                    className={`px-4 py-3 cursor-pointer transition-colors duration-200 flex items-center justify-between ${
                      isSelected
                        ? 'bg-[#39ff14] bg-opacity-20 border-l-4 border-[#39ff14]'
                        : 'hover:bg-gray-800'
                    }`}
                    role="option"
                    aria-selected={isSelected}
                  >
                    <div>
                      <div className="text-[#39ff14] font-semibold text-sm">
                        {state.abbreviation}
                      </div>
                      <div className="text-[#39ff14] opacity-70 text-xs">
                        {state.fullName}
                      </div>
                    </div>
                    {isSelected && (
                      <Check className="w-5 h-5 text-[#39ff14]" />
                    )}
                  </div>
                );
              })
            ) : (
              <div className="px-4 py-8 text-center text-[#39ff14] opacity-60 text-sm">
                No states found matching "{searchQuery}"
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
