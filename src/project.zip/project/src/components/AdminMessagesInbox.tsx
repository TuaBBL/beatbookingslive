import { useState, useEffect } from 'react';
import { X, Mail, MailOpen, Trash2, Clock, Send, Reply, User } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { showToast } from './Toast';
import { isAdminOrAmbassador } from '../lib/adminUtils';

interface AdminMessage {
  id: string;
  subject: string;
  message: string;
  created_at: string;
  read: boolean;
  read_at: string | null;
  sender_id: string;
  is_from_admin: boolean;
  recipient_email: string;
  recipient_id: string | null;
  parent_message_id: string | null;
  status: string;
  sender_name?: string;
  recipient_name?: string;
}

interface AdminMessagesInboxProps {
  isOpen: boolean;
  onClose: () => void;
  userId: string;
  userEmail: string;
}

export function AdminMessagesInbox({ isOpen, onClose, userId, userEmail }: AdminMessagesInboxProps) {
  const [messages, setMessages] = useState<AdminMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMessage, setSelectedMessage] = useState<AdminMessage | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [sendingReply, setSendingReply] = useState(false);

  useEffect(() => {
    if (isOpen) {
      checkAdminStatus();
      fetchMessages();
    }
  }, [isOpen, userId, userEmail]);

  async function checkAdminStatus() {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        setIsAdmin(isAdminOrAmbassador(user));
      }
    } catch (error) {
      console.error('Error checking admin status:', error);
    }
  }

  async function fetchMessages() {
    setLoading(true);
    try {
      const adminCheck = await checkAdminStatus();

      let query = supabase
        .from('admin_messages')
        .select('*');

      if (adminCheck) {
        query = query.order('created_at', { ascending: false });
      } else {
        query = query
          .or(`sender_id.eq.${userId},recipient_id.eq.${userId},recipient_email.eq.${userEmail}`)
          .order('created_at', { ascending: false });
      }

      const { data, error } = await query;

      if (error) {
        console.error('Error fetching messages:', error);
        showToast('Failed to load messages', 'error');
        return;
      }

      const messagesWithNames = await Promise.all(
        (data || []).map(async (msg) => {
          const senderName = await getUserName(msg.sender_id);
          const recipientName = msg.recipient_id ? await getUserName(msg.recipient_id) : null;
          return {
            ...msg,
            sender_name: senderName,
            recipient_name: recipientName
          };
        })
      );

      setMessages(messagesWithNames);
    } catch (error) {
      console.error('Error fetching messages:', error);
      showToast('Failed to load messages', 'error');
    } finally {
      setLoading(false);
    }
  }

  async function getUserName(userId: string): Promise<string> {
    try {
      const { data: profile } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', userId)
        .maybeSingle();

      if (profile?.full_name) return profile.full_name;

      const { data: artistCard } = await supabase
        .from('artist_cards')
        .select('name')
        .eq('user_id', userId)
        .maybeSingle();

      return artistCard?.name || 'Unknown User';
    } catch (error) {
      return 'Unknown User';
    }
  }

  async function markAsRead(messageId: string) {
    try {
      const { error } = await supabase
        .from('admin_messages')
        .update({ read: true, read_at: new Date().toISOString() })
        .eq('id', messageId);

      if (error) {
        console.error('Error marking message as read:', error);
        return;
      }

      setMessages(messages.map(msg =>
        msg.id === messageId ? { ...msg, read: true, read_at: new Date().toISOString() } : msg
      ));
    } catch (error) {
      console.error('Error marking message as read:', error);
    }
  }

  async function deleteMessage(messageId: string) {
    if (!confirm('Are you sure you want to delete this message?')) {
      return;
    }

    try {
      const { error } = await supabase
        .from('admin_messages')
        .delete()
        .eq('id', messageId);

      if (error) {
        console.error('Error deleting message:', error);
        showToast('Failed to delete message', 'error');
        return;
      }

      setMessages(messages.filter(msg => msg.id !== messageId));
      if (selectedMessage?.id === messageId) {
        setSelectedMessage(null);
      }
      showToast('Message deleted', 'success');
    } catch (error) {
      console.error('Error deleting message:', error);
      showToast('Failed to delete message', 'error');
    }
  }

  function handleMessageClick(message: AdminMessage) {
    setSelectedMessage(message);
    setReplyText('');
    if (!message.read) {
      markAsRead(message.id);
    }
  }

  async function sendReply() {
    if (!replyText.trim() || !selectedMessage) return;

    setSendingReply(true);
    try {
      const replyMessage = {
        sender_id: userId,
        is_from_admin: isAdmin,
        recipient_email: selectedMessage.is_from_admin ? selectedMessage.recipient_email : 'admin@beatbookingslive.com',
        recipient_id: selectedMessage.is_from_admin ? selectedMessage.recipient_id : null,
        subject: `Re: ${selectedMessage.subject}`,
        message: replyText,
        parent_message_id: selectedMessage.id,
        status: 'unread'
      };

      const { error } = await supabase
        .from('admin_messages')
        .insert(replyMessage);

      if (error) throw error;

      await supabase
        .from('admin_messages')
        .update({ status: 'replied' })
        .eq('id', selectedMessage.id);

      showToast('Reply sent successfully', 'success');
      setReplyText('');
      setSelectedMessage(null);
      fetchMessages();
    } catch (error) {
      console.error('Error sending reply:', error);
      showToast('Failed to send reply', 'error');
    } finally {
      setSendingReply(false);
    }
  }

  if (!isOpen) return null;

  const unreadCount = messages.filter(msg => !msg.read).length;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-80 backdrop-blur-sm z-50 overflow-y-auto flex items-center justify-center p-4">
      <div className="bg-gray-900 rounded-2xl border-2 border-[#39ff14] shadow-2xl max-w-4xl w-full max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between p-6 border-b border-gray-800">
          <div className="flex items-center gap-3">
            <div className="bg-[#39ff14] bg-opacity-20 rounded-full p-3">
              <Mail className="w-6 h-6 text-[#39ff14]" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-[#39ff14]">Admin Messages</h2>
              {unreadCount > 0 && (
                <p className="text-sm text-gray-400">{unreadCount} unread message{unreadCount !== 1 ? 's' : ''}</p>
              )}
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="flex-1 overflow-hidden flex">
          {selectedMessage ? (
            <div className="flex-1 flex flex-col">
              <div className="p-6 border-b border-gray-800">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-white mb-2">{selectedMessage.subject}</h3>
                    <div className="flex flex-col gap-2 text-sm text-gray-400">
                      <div className="flex items-center gap-2">
                        <User className="w-4 h-4" />
                        <span>From: {selectedMessage.is_from_admin ? 'Admin' : selectedMessage.sender_name || 'User'}</span>
                      </div>
                      {selectedMessage.recipient_name && (
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4" />
                          <span>To: {selectedMessage.recipient_name}</span>
                        </div>
                      )}
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4" />
                        {new Date(selectedMessage.created_at).toLocaleString()}
                      </div>
                      {selectedMessage.status && (
                        <div className={`px-2 py-1 rounded text-xs w-fit ${
                          selectedMessage.status === 'unread' ? 'bg-[#39ff14] bg-opacity-20 text-[#39ff14]' :
                          selectedMessage.status === 'read' ? 'bg-blue-500 bg-opacity-20 text-blue-400' :
                          selectedMessage.status === 'replied' ? 'bg-green-500 bg-opacity-20 text-green-400' :
                          'bg-gray-500 bg-opacity-20 text-gray-400'
                        }`}>
                          {selectedMessage.status.toUpperCase()}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={() => setSelectedMessage(null)}
                      className="px-3 py-1.5 bg-gray-800 border border-gray-700 text-white rounded-lg text-sm hover:bg-gray-700 transition-colors"
                    >
                      Back
                    </button>
                    {isAdmin && (
                      <button
                        onClick={() => deleteMessage(selectedMessage.id)}
                        className="px-3 py-1.5 bg-red-500 bg-opacity-20 border border-red-500 text-red-500 rounded-lg text-sm hover:bg-red-500 hover:text-white transition-all duration-300"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </div>
              <div className="flex-1 overflow-y-auto p-6">
                <div className="prose prose-invert max-w-none">
                  <p className="text-gray-300 whitespace-pre-wrap leading-relaxed">{selectedMessage.message}</p>
                </div>
              </div>
              <div className="p-6 border-t border-gray-800">
                <div className="space-y-3">
                  <div className="flex items-center gap-2 text-sm text-[#39ff14]">
                    <Reply className="w-4 h-4" />
                    <span>Reply to this message</span>
                  </div>
                  <textarea
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    placeholder="Type your reply..."
                    rows={4}
                    className="w-full px-4 py-3 bg-gray-800 border-2 border-gray-700 rounded-lg text-white placeholder-gray-500 focus:outline-none focus:border-[#39ff14] transition-colors resize-none"
                  />
                  <button
                    onClick={sendReply}
                    disabled={!replyText.trim() || sendingReply}
                    className="w-full px-4 py-3 bg-[#39ff14] bg-opacity-20 border-2 border-[#39ff14] text-[#39ff14] rounded-lg hover:bg-[#39ff14] hover:text-black transition-all duration-300 font-semibold disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    {sendingReply ? 'Sending...' : 'Send Reply'}
                  </button>
                </div>
              </div>
            </div>
          ) : (
            <div className="flex-1 overflow-y-auto">
              {loading ? (
                <div className="flex items-center justify-center h-64">
                  <div className="text-[#39ff14]">Loading messages...</div>
                </div>
              ) : messages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-64 text-gray-400">
                  <Mail className="w-16 h-16 mb-4 opacity-50" />
                  <p className="text-lg">No messages yet</p>
                  <p className="text-sm">Messages from admins will appear here</p>
                </div>
              ) : (
                <div className="divide-y divide-gray-800">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      onClick={() => handleMessageClick(message)}
                      className={`p-4 hover:bg-gray-800 transition-colors cursor-pointer ${
                        !message.read ? 'bg-gray-800 bg-opacity-50' : ''
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <div className="flex-shrink-0 mt-1">
                          {message.read ? (
                            <MailOpen className="w-5 h-5 text-gray-500" />
                          ) : (
                            <Mail className="w-5 h-5 text-[#39ff14]" />
                          )}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2">
                            <div className="flex-1">
                              <h4 className={`font-semibold truncate ${
                                message.read ? 'text-gray-300' : 'text-white'
                              }`}>
                                {message.subject}
                              </h4>
                              <p className="text-xs text-gray-500 mt-0.5">
                                From: {message.is_from_admin ? 'Admin' : message.sender_name || 'User'}
                              </p>
                            </div>
                            <div className="flex flex-col items-end gap-1 flex-shrink-0">
                              <span className="text-xs text-gray-500">
                                {new Date(message.created_at).toLocaleDateString()}
                              </span>
                              {message.status && message.status !== 'unread' && (
                                <span className={`px-2 py-0.5 rounded text-xs ${
                                  message.status === 'read' ? 'bg-blue-500 bg-opacity-20 text-blue-400' :
                                  message.status === 'replied' ? 'bg-green-500 bg-opacity-20 text-green-400' :
                                  'bg-gray-500 bg-opacity-20 text-gray-400'
                                }`}>
                                  {message.status}
                                </span>
                              )}
                            </div>
                          </div>
                          <p className="text-sm text-gray-400 line-clamp-2 mt-1">
                            {message.message}
                          </p>
                        </div>
                        {isAdmin && (
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              deleteMessage(message.id);
                            }}
                            className="flex-shrink-0 p-2 text-gray-500 hover:text-red-500 transition-colors"
                            title="Delete message"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
