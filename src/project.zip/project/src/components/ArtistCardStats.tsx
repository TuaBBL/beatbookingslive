import { Eye, Calendar } from 'lucide-react';
import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

interface ArtistCardStatsProps {
  artistId: number;
}

interface ArtistStats {
  views: number;
  bookings: number;
}

export function ArtistCardStats({ artistId }: ArtistCardStatsProps) {
  const [stats, setStats] = useState<ArtistStats>({ views: 0, bookings: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchStats();
  }, [artistId]);

  const fetchStats = async () => {
    try {
      const currentMonth = new Date();
      currentMonth.setDate(1);
      const monthStr = currentMonth.toISOString().split('T')[0];

      const { data, error } = await supabase
        .from('artist_analytics')
        .select('view_count, booking_request_count')
        .eq('artist_id', artistId)
        .eq('month', monthStr)
        .maybeSingle();

      if (!error && data) {
        setStats({
          views: data.view_count || 0,
          bookings: data.booking_request_count || 0,
        });
      }
    } catch (error) {
      console.error('Error fetching artist stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return null;
  }

  if (stats.views === 0 && stats.bookings === 0) {
    return null;
  }

  return (
    <div className="absolute bottom-2 left-2 right-2 z-10 flex gap-2">
      {stats.views > 0 && (
        <div className="flex items-center gap-1 px-2 py-1 bg-black bg-opacity-80 rounded text-xs font-semibold text-blue-400 border border-blue-400 border-opacity-30">
          <Eye className="w-3 h-3" />
          <span>{stats.views}</span>
        </div>
      )}
      {stats.bookings > 0 && (
        <div className="flex items-center gap-1 px-2 py-1 bg-black bg-opacity-80 rounded text-xs font-semibold text-green-400 border border-green-400 border-opacity-30">
          <Calendar className="w-3 h-3" />
          <span>{stats.bookings}</span>
        </div>
      )}
    </div>
  );
}
