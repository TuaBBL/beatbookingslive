import { X, Eye, EyeOff } from 'lucide-react';
import { useState } from 'react';
import { supabase } from '../lib/supabase';

interface ArtistAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSignupSuccess: (userId: string, email: string) => void;
}

export function ArtistAuthModal({ isOpen, onClose, onSignupSuccess }: ArtistAuthModalProps) {
  const [isSignup, setIsSignup] = useState(true);
  const [isForgotPassword, setIsForgotPassword] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');

  if (!isOpen) return null;

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setMessage('');
    setLoading(true);

    try {
      const { error } = await supabase.auth.resetPasswordForEmail(email, {
        redirectTo: 'https://beatbookingslive.com/reset-password',
      });

      if (error) throw error;

      setMessage('Password reset link sent! Check your email for instructions.');
      setEmail('');
    } catch (err: any) {
      setError(err.message || 'Failed to send password reset email');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isSignup) {
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: 'https://beatbookingslive.com/auth/callback',
            data: {
              role: 'artist',
            },
          },
        });

        if (error) throw error;

        if (data.user) {
          if (data.user.identities && data.user.identities.length === 0) {
            setMessage('This email is already registered. Please sign in to continue setting up your artist profile.');
            setPassword('');
            setIsSignup(false);
            return;
          }

          const { error: userError } = await supabase
            .from('users')
            .insert({
              id: data.user.id,
              email: data.user.email!,
              user_type: 'artist',
              profile_completed: false,
            });

          if (userError) {
            console.error('Error creating user record:', userError);
          }

          try {
            const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
            const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

            await fetch(`${supabaseUrl}/functions/v1/send-welcome-email`, {
              method: 'POST',
              headers: {
                'Authorization': `Bearer ${supabaseAnonKey}`,
                'Content-Type': 'application/json',
              },
              body: JSON.stringify({
                email: data.user.email,
                name: email.split('@')[0],
                userType: 'artist',
              }),
            });
          } catch (emailError) {
            console.error('Failed to send welcome email:', emailError);
          }

          setMessage('Account created! Redirecting...');
          setTimeout(() => {
            window.location.reload();
          }, 1000);
          return;
        }
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({
          email,
          password,
        });

        if (error) throw error;

        if (data.user) {
          window.location.reload();
        }
      }
    } catch (err: any) {
      const errorMessage = err.message || 'An error occurred';
      if (errorMessage.includes('User already registered') || errorMessage.includes('user_already_exists')) {
        setError('This email is already registered. Please sign in instead.');
      } else {
        setError(errorMessage);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gray-900 rounded-2xl border-2 border-red-500 glow-red-strong max-w-md w-full" onClick={(e) => e.stopPropagation()}>
        <div className="relative p-8">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 bg-black bg-opacity-70 rounded-full p-2 text-fluro-green-subtle hover:text-fluro-green hover:bg-opacity-100 transition-all duration-300"
          >
            <X className="w-6 h-6" />
          </button>

          <h2 className="text-3xl font-bold text-fluro-green mb-6">
            {isForgotPassword ? 'Reset Password' : isSignup ? 'Artist Sign Up' : 'Artist Sign In'}
          </h2>

          {error && (
            <div className="mb-4 p-3 bg-red-500 bg-opacity-20 border border-red-500 rounded-lg">
              <p className="text-red-500 text-sm">{error}</p>
            </div>
          )}

          {message && (
            <div className="mb-4 p-3 bg-green-500 bg-opacity-20 border border-green-500 rounded-lg">
              <p className="text-green-400 text-sm">{message}</p>
            </div>
          )}

          <form onSubmit={isForgotPassword ? handleForgotPassword : handleSubmit} className="space-y-4">
            <div>
              <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full px-4 py-3 bg-gray-800 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] placeholder-[#39ff14] placeholder-opacity-40 focus:outline-none focus:border-opacity-100 transition-all duration-300"
                placeholder="artist@example.com"
                required
              />
            </div>

            {!isForgotPassword && (
              <div>
                <label className="block text-fluro-green-subtle text-sm font-semibold mb-2">
                  Password
                </label>
                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-4 py-3 pr-12 bg-gray-800 border-2 border-[#39ff14] border-opacity-50 rounded-lg text-[#39ff14] placeholder-[#39ff14] placeholder-opacity-40 focus:outline-none focus:border-opacity-100 transition-all duration-300"
                    placeholder="••••••••"
                    required
                    minLength={6}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-[#39ff14] opacity-60 hover:opacity-100 transition-opacity"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full px-6 py-3 bg-[#39ff14] text-black rounded-lg font-bold hover:glow-red-strong transition-all duration-300 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? 'Please wait...' : isForgotPassword ? 'Send Reset Link' : isSignup ? 'Sign Up' : 'Sign In'}
            </button>
          </form>

          <div className="mt-6 text-center space-y-3">
            {!isForgotPassword && !isSignup && (
              <button
                onClick={() => {
                  setIsForgotPassword(true);
                  setError('');
                  setMessage('');
                }}
                className="block w-full text-fluro-green-subtle hover:text-fluro-green transition-all duration-300 text-sm"
              >
                Forgot your password?
              </button>
            )}

            <button
              onClick={() => {
                setIsSignup(!isSignup);
                setIsForgotPassword(false);
                setError('');
                setMessage('');
              }}
              className="text-fluro-green-subtle hover:text-fluro-green transition-all duration-300"
            >
              {isSignup ? 'Already have an account? Sign In' : "Don't have an account? Sign Up"}
            </button>

            {isForgotPassword && (
              <button
                onClick={() => {
                  setIsForgotPassword(false);
                  setError('');
                  setMessage('');
                }}
                className="block w-full text-fluro-green-subtle hover:text-fluro-green transition-all duration-300 text-sm"
              >
                Back to Sign In
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
