import { Crown, Star, ArrowUpCircle } from 'lucide-react';
import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

interface SubscriptionStatusProps {
  userId: string;
  artistCard: any;
  onUpgrade: () => void;
}

export function SubscriptionStatus({ userId, artistCard, onUpgrade }: SubscriptionStatusProps) {
  const [isFreeForever, setIsFreeForever] = useState(false);
  const [isPremium, setIsPremium] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSubscriptionStatus();
  }, [userId, artistCard]);

  async function fetchSubscriptionStatus() {
    try {
      const { data: profileData } = await supabase
        .from('profiles')
        .select('is_free_forever, subscription_tier, subscription_active')
        .eq('id', userId)
        .maybeSingle();

      setIsFreeForever(profileData?.is_free_forever || false);
      setIsPremium(profileData?.subscription_tier === 'premium' && profileData?.subscription_active);
    } catch (error) {
      console.error('Error fetching subscription status:', error);
    } finally {
      setLoading(false);
    }
  }

  if (loading) {
    return null;
  }

  const getSubscriptionType = () => {
    if (isFreeForever) return 'Premium (Free Forever)';
    if (isPremium) return 'Premium';
    return 'Standard';
  };

  const getSubscriptionPrice = () => {
    if (isPremium) return '$35.00 AUD/month';
    if (isFreeForever) return 'Free Forever';
    return '$25.00 AUD/month';
  };

  const getIcon = () => {
    if (isPremium || isFreeForever) {
      return <Crown className="w-6 h-6 text-yellow-400" />;
    }
    return <Star className="w-6 h-6 text-[#39ff14]" />;
  };

  const canUpgrade = !isPremium && !isFreeForever;

  return (
    <div className="bg-gray-900 rounded-lg border-2 border-red-500 glow-red p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-xl font-bold text-fluro-green">Your Subscription</h3>
        {getIcon()}
      </div>

      <div className="space-y-4">
        <div>
          <div className="flex items-center justify-between mb-2">
            <span className="text-fluro-green-subtle text-sm">Current Plan</span>
            {(isPremium || isFreeForever) && (
              <span className="px-2 py-1 bg-yellow-400 bg-opacity-20 border border-yellow-400 text-yellow-400 rounded text-xs font-bold">
                PREMIUM
              </span>
            )}
          </div>
          <div className="text-2xl font-bold text-fluro-green">
            {getSubscriptionType()}
          </div>
          <div className="text-fluro-green-subtle text-sm mt-1">
            {getSubscriptionPrice()}
          </div>
        </div>

        <div className="border-t border-red-500 border-opacity-30 pt-4">
          <div className="text-fluro-green-subtle text-sm mb-3">
            {(isPremium || isFreeForever) ? (
              <>
                <div className="flex items-center gap-2 mb-2">
                  <Crown className="w-4 h-4 text-yellow-400" />
                  <span className="font-semibold text-yellow-400">Premium Benefits:</span>
                </div>
                <ul className="space-y-1 ml-6 list-disc">
                  <li>Featured on homepage</li>
                  <li>Priority in search results</li>
                  <li>Premium badge on profile</li>
                  <li>Enhanced visibility</li>
                </ul>
              </>
            ) : (
              <>
                <div className="flex items-center gap-2 mb-2">
                  <Star className="w-4 h-4 text-[#39ff14]" />
                  <span className="font-semibold text-[#39ff14]">Standard Benefits:</span>
                </div>
                <ul className="space-y-1 ml-6 list-disc">
                  <li>Artist profile listing</li>
                  <li>Searchable by event planners</li>
                  <li>Media gallery</li>
                  <li>Social media integration</li>
                </ul>
              </>
            )}
          </div>
        </div>

        {isFreeForever && (
          <div className="text-[#39ff14] font-bold text-sm bg-black bg-opacity-40 p-2 rounded-lg border border-[#39ff14] text-center">
            Premium (Free Forever)
          </div>
        )}

        {canUpgrade && (
          <button
            onClick={onUpgrade}
            className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-yellow-500 to-yellow-600 text-black rounded-lg font-bold hover:from-yellow-400 hover:to-yellow-500 transition-all duration-300 transform hover:scale-105"
          >
            <ArrowUpCircle className="w-5 h-5" />
            Upgrade to Premium
          </button>
        )}
      </div>
    </div>
  );
}
