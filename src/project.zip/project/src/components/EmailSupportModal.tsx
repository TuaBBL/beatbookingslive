import { X, Mail } from 'lucide-react';

interface EmailSupportModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function EmailSupportModal({ isOpen, onClose }: EmailSupportModalProps) {
  if (!isOpen) return null;

  const supportEmail = 'info@beatbookingslive.com';
  const subject = 'Support Request - BeatBookingsLive';
  const body = 'Hi BeatBookingsLive Support,\n\nI need help with:\n\n\n\nThank you!';

  const mailtoLink = `mailto:${supportEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-[60] p-4">
      <div className="bg-gray-900 border-2 border-[#39ff14] rounded-lg w-full max-w-md shadow-[0_0_30px_rgba(57,255,20,0.3)]">
        <div className="bg-gray-900 border-b border-[#39ff14]/30 p-6 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-[#39ff14]" style={{ textShadow: '0 0 10px #ff0000' }}>
            Email Support
          </h2>
          <button
            onClick={onClose}
            className="text-red-500 hover:text-red-400 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="text-center">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-[#39ff14] to-red-500 flex items-center justify-center mx-auto mb-4">
              <Mail className="w-8 h-8 text-black" />
            </div>
            <p className="text-gray-200 leading-relaxed mb-4">
              Need more help? Contact our support team directly via email.
            </p>
          </div>

          <div className="bg-gray-800 border border-[#39ff14]/30 rounded-lg p-4">
            <p className="text-sm text-gray-400 mb-2">Email Address:</p>
            <a
              href={mailtoLink}
              className="text-[#39ff14] text-lg font-semibold hover:text-[#2dd90f] transition-colors block break-all"
            >
              {supportEmail}
            </a>
          </div>

          <div className="space-y-3">
            <a
              href={mailtoLink}
              className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-[#39ff14] to-red-500 text-black rounded-lg font-bold hover:opacity-90 transition-opacity"
            >
              <Mail className="w-5 h-5" />
              Open Email Client
            </a>

            <button
              onClick={() => {
                navigator.clipboard.writeText(supportEmail);
                alert('Email address copied to clipboard!');
              }}
              className="w-full px-6 py-3 bg-transparent border-2 border-[#39ff14] text-[#39ff14] rounded-lg font-semibold hover:bg-[#39ff14] hover:text-black transition-all duration-300"
            >
              Copy Email Address
            </button>
          </div>

          <p className="text-xs text-gray-400 text-center">
            We typically respond within 24-48 hours during business days.
          </p>
        </div>
      </div>
    </div>
  );
}
