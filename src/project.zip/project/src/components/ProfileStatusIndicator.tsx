import { getStatusColor, getStatusLabel, getStatusEmoji, ProfileStatus } from '../lib/profileCompleteness';

interface ProfileStatusIndicatorProps {
  status: ProfileStatus;
  percentage: number;
  missingFields?: string[];
  size?: 'sm' | 'md' | 'lg';
  showLabel?: boolean;
  showPercentage?: boolean;
}

export function ProfileStatusIndicator({
  status,
  percentage,
  missingFields = [],
  size = 'md',
  showLabel = false,
  showPercentage = false,
}: ProfileStatusIndicatorProps) {
  const color = getStatusColor(status);
  const label = getStatusLabel(status);
  const emoji = getStatusEmoji(status);

  const sizeClasses = {
    sm: 'w-3 h-3',
    md: 'w-4 h-4',
    lg: 'w-6 h-6',
  };

  const tooltipContent = missingFields.length > 0
    ? `Missing: ${missingFields.join(', ')}`
    : 'Profile complete!';

  return (
    <div className="inline-flex items-center gap-2">
      <div
        className={`${sizeClasses[size]} rounded-full relative group cursor-help`}
        style={{ backgroundColor: color }}
        title={tooltipContent}
      >
        {/* Tooltip */}
        <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 px-3 py-2 bg-gray-900 text-white text-xs rounded-lg opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap z-50 shadow-lg">
          <div className="font-semibold mb-1">{label} ({percentage}%)</div>
          {missingFields.length > 0 && (
            <div className="text-gray-300">Missing: {missingFields.join(', ')}</div>
          )}
          {missingFields.length === 0 && (
            <div className="text-green-300">All fields completed!</div>
          )}
          {/* Arrow */}
          <div
            className="absolute top-full left-1/2 transform -translate-x-1/2 -mt-1"
            style={{
              width: 0,
              height: 0,
              borderLeft: '6px solid transparent',
              borderRight: '6px solid transparent',
              borderTop: '6px solid #111827',
            }}
          />
        </div>
      </div>

      {showLabel && (
        <span className="text-sm font-medium" style={{ color }}>
          {label}
        </span>
      )}

      {showPercentage && (
        <span className="text-sm text-gray-400">
          {percentage}%
        </span>
      )}
    </div>
  );
}
