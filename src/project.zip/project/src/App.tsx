import { X, MapPin, Music2, Star, LogOut, Youtube, Instagram, Facebook, Music as SoundCloudIcon, Radio, Headphones } from 'lucide-react';
import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase, Artist, Review } from './lib/supabase';
import { NavSearch } from './components/NavSearch';
import { ArtistDirectorySearch } from './components/ArtistDirectorySearch';
import { AuthModal } from './components/AuthModal';
import { ArtistAuthModal } from './components/ArtistAuthModal';
import { ArtistProfileModal } from './components/ArtistProfileModal';
import { UserProfileSetupModal } from './components/UserProfileSetupModal';
import { SubscriptionModal } from './components/SubscriptionModal';
import { ArtistDetailView } from './components/ArtistDetailView';
import { UserDashboard } from './pages/UserDashboard';
import { ArtistProfile } from './pages/ArtistProfile';
import { BrowserRouter as Router, Routes, Route, Navigate, Link } from 'react-router-dom';
import { LoginPage } from './pages/LoginPage';
import { SignupPage } from './pages/SignupPage';
import { CreateArtistPage } from './pages/CreateArtistPage';
import { SubscriptionPage } from './pages/SubscriptionPage';
import { SubscriptionSuccessPage } from './pages/SubscriptionSuccessPage';
import TermsPage from './pages/TermsPage';
import TermsPageAlt from './pages/terms';
import PrivacyPage from './pages/PrivacyPage';
import PrivacyPageAlt from './pages/privacy';
import { ResetPasswordPage } from './pages/ResetPasswordPage';
import { AuthCallbackPage } from './pages/AuthCallbackPage';
import { AdminProfilesDashboard } from './pages/AdminProfilesDashboard';
import { useAuth } from './hooks/useAuth';
import { useProfileCompletionGuard } from './hooks/useProfileCompletionGuard';
import { Loader2 } from 'lucide-react';
import { NotificationBell } from './components/NotificationBell';
import { SupportChatModal } from './components/SupportChatModal';
import { FloatingSupportButton } from './components/FloatingSupportButton';
import NeonHero from './components/NeonHero';
import { AboutModal } from './components/AboutModal';
import { ToastContainer } from './components/Toast';
import { FeaturedArtistOfMonth } from './components/FeaturedArtistOfMonth';
import { ArtistCardStats } from './components/ArtistCardStats';
import { checkForNewNotifications } from './lib/notifications';
import { ProfileCompletionLockScreen } from './components/ProfileCompletionLockScreen';
import { EditUserProfileModal } from './components/EditUserProfileModal';
import { EditProfileModal } from './components/EditProfileModal';

function App() {
  // Check for password recovery token FIRST - bypass entire app
  const rawHash = typeof window !== 'undefined' ? window.location.hash : '';
  const isPasswordRecovery = rawHash.includes('type=recovery') || rawHash.includes('access_token');

  // When password recovery detected, ONLY render ResetPasswordPage
  if (isPasswordRecovery) {
    return (
      <Router>
        <ResetPasswordPage />
      </Router>
    );
  }

  const { user: authUser, loading: authLoading } = useAuth();

  // Clear stale subscription localStorage on app mount if no auth user
  useEffect(() => {
    const clearStaleSubscriptionData = async () => {
      const { data: { session } } = await supabase.auth.getSession();

      if (!session) {
        // No valid session - clear all subscription localStorage
        localStorage.removeItem('subscriptionSession');
        localStorage.removeItem('checkoutSessionId');
        localStorage.removeItem('activeSubscription');
        console.log('[App] Cleared stale subscription localStorage - no valid session');
      }
    };

    clearStaleSubscriptionData();
  }, []);

  const profileGuard = useProfileCompletionGuard(authUser);

  const [selectedArtist, setSelectedArtist] = useState<Artist | null>(null);
  const [artists, setArtists] = useState<Artist[]>([]);
  const [loading, setLoading] = useState(true);
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [artistAuthModalOpen, setArtistAuthModalOpen] = useState(false);
  const [artistProfileModalOpen, setArtistProfileModalOpen] = useState(false);
  const [subscriptionModalOpen, setSubscriptionModalOpen] = useState(false);
  const [aboutModalOpen, setAboutModalOpen] = useState(false);
  const [artistUserId, setArtistUserId] = useState<string>('');
  const [artistEmail, setArtistEmail] = useState<string>('');
  const [isArtist, setIsArtist] = useState(false);
  const [userProfileSetupModalOpen, setUserProfileSetupModalOpen] = useState(false);
  const [setupUserId, setSetupUserId] = useState<string>('');
  const [setupUserEmail, setSetupUserEmail] = useState<string>('');
  const [reviews, setReviews] = useState<Review[]>([]);
  const [loadingReviews, setLoadingReviews] = useState(false);
  const [artistListVersion, setArtistListVersion] = useState(0);
  const [supportChatOpen, setSupportChatOpen] = useState(false);

  async function checkUserType(userId: string) {
    const { data } = await supabase
      .from('users')
      .select('user_type')
      .eq('id', userId)
      .maybeSingle();

    if (data) {
      setIsArtist(data.user_type === 'artist');
    } else {
      setIsArtist(false);
    }
  }

  async function fetchArtists() {
    try {
      console.log('Fetching artists...');
      const { data, error } = await supabase
        .from('artist_cards')
        .select('*')
        .order('is_premium', { ascending: false })
        .order('featured_priority', { ascending: true, nullsFirst: false })
        .order('created_at', { ascending: true });

      console.log('Fetch result:', { data: data?.length, error });
      if (error) {
        console.error('Supabase error:', error);
        throw error;
      }
      setArtists(data || []);
      console.log('Artists set:', data?.length);
    } catch (error) {
      console.error('Error fetching artists:', error);
    } finally {
      setLoading(false);
    }
  }

  async function fetchReviews(artistId: number) {
    setLoadingReviews(true);
    try {
      const { data, error } = await supabase
        .from('reviews')
        .select('*')
        .eq('artist_id', artistId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setReviews(data || []);
    } catch (error) {
      console.error('Error fetching reviews:', error);
    } finally {
      setLoadingReviews(false);
    }
  }

  // Fetch artists on mount and when artist list version changes
  useEffect(() => {
    fetchArtists();
  }, [artistListVersion]);

  // Check user type when authUser changes
  useEffect(() => {
    if (authUser && !authLoading) {
      checkUserType(authUser.id);
    }
  }, [authUser, authLoading]);

  useEffect(() => {
    if (selectedArtist) {
      fetchReviews(selectedArtist.id);
      trackArtistView(selectedArtist);
    }
  }, [selectedArtist]);

  async function trackArtistView(artist: Artist) {
    try {
      const { error } = await supabase.rpc('track_artist_view', {
        p_artist_id: artist.id
      });

      if (error) {
        console.error('Error tracking artist view:', error);
      }
    } catch (error) {
      console.error('Error tracking artist view:', error);
    }
  }

  useEffect(() => {
    const handleOpenArtistModal = (event: CustomEvent) => {
      const { userId, email } = event.detail;
      setArtistUserId(userId);
      setArtistEmail(email);
      setArtistProfileModalOpen(true);
    };

    window.addEventListener('open-artist-profile-modal', handleOpenArtistModal as EventListener);

    return () => {
      window.removeEventListener('open-artist-profile-modal', handleOpenArtistModal as EventListener);
    };
  }, []);

  const refreshArtistList = () => {
    setArtistListVersion(prev => prev + 1);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-[#39ff14] mx-auto mb-4" />
          <p className="text-[#39ff14]">Loading...</p>
        </div>
      </div>
    );
  }

  const handleArtistSignupSuccess = (userId: string, email: string) => {
    setArtistUserId(userId);
    setArtistEmail(email);
    setArtistAuthModalOpen(false);
    setArtistProfileModalOpen(true);
  };

  const handleProfileComplete = () => {
    setArtistProfileModalOpen(false);
    checkUserType(artistUserId);
  };

  const handleUserNeedsProfileSetup = (userId: string, email: string) => {
    setSetupUserId(userId);
    setSetupUserEmail(email);
    setAuthModalOpen(false);
    setUserProfileSetupModalOpen(true);
  };

  const handleUserProfileSetupComplete = () => {
    setUserProfileSetupModalOpen(false);
    setSetupUserId('');
    setSetupUserEmail('');
  };

  const handleSubscribe = () => {
    setArtistProfileModalOpen(false);
    setSubscriptionModalOpen(true);
  };


  const handleSignOut = async () => {
    setIsArtist(false);
    await supabase.auth.signOut();
  };

  const handleUserProfileUpdateSuccess = () => {
    profileGuard.refreshGuard();
  };

  const handleArtistProfileUpdateSuccess = () => {
    profileGuard.refreshGuard();
  };

  if (authUser && profileGuard.loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-[#39ff14] mx-auto mb-4" />
          <p className="text-[#39ff14]">Checking profile...</p>
        </div>
      </div>
    );
  }

  if (authUser && profileGuard.needsSubscription) {
    return (
      <Router>
        <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
          <SubscriptionModal
            isOpen={true}
            onClose={() => {}}
          />
        </div>
      </Router>
    );
  }

  if (authUser && profileGuard.redirectToCreateArtist) {
    return (
      <Router>
        <Routes>
          <Route path="*" element={<Navigate to="/create-artist" replace />} />
        </Routes>
      </Router>
    );
  }

  if (authUser && profileGuard.showCreateUserProfile) {
    return (
      <Router>
        <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
          <EditUserProfileModal
            isOpen={true}
            onClose={() => {}}
            user={{
              id: authUser.id,
              email: authUser.email || '',
              full_name: profileGuard.userProfileData?.full_name || '',
              location: profileGuard.userProfileData?.location || '',
              state_territory: profileGuard.userProfileData?.state_territory || null,
              phone_number: profileGuard.userProfileData?.phone_number || null,
              profile_image_url: profileGuard.userProfileData?.profile_image_url || null,
            }}
            onSuccess={handleUserProfileUpdateSuccess}
          />
        </div>
      </Router>
    );
  }

  return (
    <Router>
      <ToastContainer />
      <Routes>
        <Route path="/login" element={authUser ? <Navigate to="/" /> : <LoginPage />} />
        <Route path="/signup" element={authUser ? <Navigate to="/" /> : <SignupPage />} />
        <Route path="/create-artist" element={authUser ? <CreateArtistPage /> : <Navigate to="/login" />} />
        <Route path="/reset-password" element={<ResetPasswordPage />} />
        <Route path="/auth/callback" element={<AuthCallbackPage />} />
        <Route path="/terms" element={<TermsPageAlt />} />
        <Route path="/privacy" element={<PrivacyPageAlt />} />
        <Route path="/admin/profiles" element={<AdminProfilesDashboard />} />
        <Route
          path="/subscription"
          element={authUser ? <SubscriptionPage /> : <Navigate to="/login" />}
        />
        <Route
          path="/subscription/success"
          element={authUser ? <SubscriptionSuccessPage /> : <Navigate to="/login" />}
        />
        <Route
          path="/"
          element={
            authUser && profileGuard.isArtist ? (
              <ArtistProfile user={authUser} onSignOut={handleSignOut} onArtistDeleteSuccess={refreshArtistList} />
            ) : authUser && !profileGuard.isArtist ? (
              <UserDashboard user={authUser} onSignOut={handleSignOut} onArtistDeleteSuccess={refreshArtistList} />
            ) : (
              <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
                <HomePage
                  selectedArtist={selectedArtist}
                  setSelectedArtist={setSelectedArtist}
                  artists={artists}
                  loading={loading}
                  authModalOpen={authModalOpen}
                  setAuthModalOpen={setAuthModalOpen}
                  artistAuthModalOpen={artistAuthModalOpen}
                  setArtistAuthModalOpen={setArtistAuthModalOpen}
                  artistProfileModalOpen={artistProfileModalOpen}
                  artistUserId={artistUserId}
                  artistEmail={artistEmail}
                  handleArtistSignupSuccess={handleArtistSignupSuccess}
                  handleProfileComplete={handleProfileComplete}
                  handleSubscribe={handleSubscribe}
                  subscriptionModalOpen={subscriptionModalOpen}
                  reviews={reviews}
                  supportChatOpen={supportChatOpen}
                  setSupportChatOpen={setSupportChatOpen}
                  aboutModalOpen={aboutModalOpen}
                  setAboutModalOpen={setAboutModalOpen}
                  userProfileSetupModalOpen={userProfileSetupModalOpen}
                  setUserProfileSetupModalOpen={setUserProfileSetupModalOpen}
                  setupUserId={setupUserId}
                  setupUserEmail={setupUserEmail}
                  handleUserNeedsProfileSetup={handleUserNeedsProfileSetup}
                  handleUserProfileSetupComplete={handleUserProfileSetupComplete}
                />
              </div>
            )
          }
        />
      </Routes>
    </Router>
  );
}

interface HomePageProps {
  selectedArtist: Artist | null;
  setSelectedArtist: (artist: Artist | null) => void;
  artists: Artist[];
  loading: boolean;
  authModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;
  artistAuthModalOpen: boolean;
  setArtistAuthModalOpen: (open: boolean) => void;
  artistProfileModalOpen: boolean;
  artistUserId: string;
  artistEmail: string;
  handleArtistSignupSuccess: (userId: string, email: string) => void;
  handleProfileComplete: () => void;
  handleSubscribe: () => void;
  subscriptionModalOpen: boolean;
  reviews: Review[];
  supportChatOpen: boolean;
  setSupportChatOpen: (open: boolean) => void;
  aboutModalOpen: boolean;
  setAboutModalOpen: (open: boolean) => void;
  userProfileSetupModalOpen: boolean;
  setUserProfileSetupModalOpen: (open: boolean) => void;
  setupUserId: string;
  setupUserEmail: string;
  handleUserNeedsProfileSetup: (userId: string, email: string) => void;
  handleUserProfileSetupComplete: () => void;
}

function HomePage({
  selectedArtist,
  setSelectedArtist,
  artists,
  loading,
  authModalOpen,
  setAuthModalOpen,
  artistAuthModalOpen,
  setArtistAuthModalOpen,
  artistProfileModalOpen,
  artistUserId,
  artistEmail,
  handleArtistSignupSuccess,
  handleProfileComplete,
  handleSubscribe,
  subscriptionModalOpen,
  reviews,
  supportChatOpen,
  setSupportChatOpen,
  aboutModalOpen,
  setAboutModalOpen,
  userProfileSetupModalOpen,
  setUserProfileSetupModalOpen,
  setupUserId,
  setupUserEmail,
  handleUserNeedsProfileSetup,
  handleUserProfileSetupComplete
}: HomePageProps) {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const [filteredArtists, setFilteredArtists] = useState<Artist[]>(artists);

  const trackSocialClick = async (artistId: number) => {
    try {
      await supabase.rpc('increment_analytics_metric', {
        p_artist_id: artistId,
        p_metric: 'social_clicks'
      });
    } catch (error) {
      console.error('Error tracking social click:', error);
    }
  };

  useEffect(() => {
    setFilteredArtists(artists);
  }, [artists]);

  useEffect(() => {
    checkForNewNotifications();
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
      <header className="relative z-20 bg-black border-b-2 border-red-500 shadow-lg overflow-visible">
        <div className="container mx-auto px-2 sm:px-4 py-3 sm:py-6 flex flex-wrap sm:flex-nowrap justify-between items-center gap-2 sm:gap-4 overflow-visible">
          <Link to="/" className="flex items-center gap-2 sm:gap-4 flex-shrink-0 hover:opacity-80 transition-opacity cursor-pointer">
            <div className="flex items-center gap-2">
              <svg width="35" height="28" viewBox="0 0 50 40" fill="none" xmlns="http://www.w3.org/2000/svg" className="sm:w-[50px] sm:h-[40px]">
                <rect x="2" y="12" width="3" height="16" rx="1.5" fill="#39ff14" style={{ filter: 'drop-shadow(0 0 6px #ff0000)' }} />
                <rect x="8" y="8" width="3" height="24" rx="1.5" fill="#39ff14" style={{ filter: 'drop-shadow(0 0 6px #ff0000)' }} />
                <rect x="14" y="4" width="3" height="32" rx="1.5" fill="#39ff14" style={{ filter: 'drop-shadow(0 0 6px #ff0000)' }} />
                <path d="M24 8L42 20L24 32V8Z" fill="#39ff14" style={{ filter: 'drop-shadow(0 0 6px #ff0000)' }} />
              </svg>
            </div>
            <div className="flex flex-col leading-none">
              <div>
                <span className="text-base sm:text-2xl font-bold text-[#39ff14]" style={{ textShadow: '0 0 8px #ff0000' }}>Beat</span>
              </div>
              <div>
                <span className="text-base sm:text-2xl font-bold text-[#39ff14]" style={{ textShadow: '0 0 8px #ff0000' }}>Bookings</span>
              </div>
              <div>
                <span className="text-xs sm:text-base font-bold text-red-500" style={{ textShadow: '0 0 8px #ff0000' }}>LIVE</span>
              </div>
            </div>
          </Link>

          <h1 className="hidden md:block text-xl lg:text-2xl font-bold nav-title">
            <span className="text-[#39ff14]" style={{ textShadow: '0 0 8px #ff0000' }}>Beatbookingslive</span>
            <span className="text-red-500" style={{ textShadow: '0 0 8px #ff0000' }}>.com</span>
          </h1>

          <nav className="flex gap-2 sm:gap-4 lg:gap-6 items-center flex-wrap sm:flex-nowrap">
            {user && <NotificationBell />}
            <button
              onClick={() => setAboutModalOpen(true)}
              className="px-2 sm:px-4 py-1.5 sm:py-2 bg-transparent border-2 border-[#39ff14] text-[#39ff14] rounded-lg text-xs sm:text-base font-semibold hover:bg-[#39ff14] hover:text-black transition-all duration-300"
              style={{ textShadow: '0 0 8px #ff0000' }}
            >
              About
            </button>
            {user && (
              <button
                onClick={signOut}
                className="flex items-center gap-1 sm:gap-2 px-2 sm:px-4 py-1.5 sm:py-2 bg-transparent border-2 border-red-500 text-red-500 rounded-lg text-xs sm:text-base font-semibold hover:bg-red-500 hover:text-white transition-all duration-300"
              >
                <LogOut className="w-3 h-3 sm:w-4 sm:h-4" />
                <span className="hidden sm:inline">Sign Out</span>
              </button>
            )}
          </nav>
        </div>
      </header>

      <NeonHero />

      <main className="relative z-10 container mx-auto px-4 py-12">
        <section className="text-center mb-16 relative">
          <div className="absolute inset-0 flex justify-center items-center opacity-20 pointer-events-none">
            <div className="flex gap-3">
              {[...Array(30)].map((_, i) => {
                const animations = ['wave', 'wave-intense', 'wave-smooth'];
                const randomAnimation = animations[i % 3];
                const height = Math.random() * 250 + 80;
                const duration = Math.random() * 1.5 + 2;
                const delay = Math.random() * 1.5;

                return (
                  <div
                    key={i}
                    className="bg-gradient-to-t from-red-500 via-red-600 to-transparent rounded-full"
                    style={{
                      width: i % 5 === 0 ? '16px' : '12px',
                      height: `${height}px`,
                      animation: `${randomAnimation} ${duration}s ease-in-out infinite`,
                      animationDelay: `${delay}s`,
                      filter: 'blur(1.5px)',
                      opacity: 0.8
                    }}
                  ></div>
                );
              })}
            </div>
          </div>

          {!user && (
            <div className="flex flex-col sm:flex-row gap-6 justify-center">
              <button
                onClick={() => setAuthModalOpen(true)}
                className="px-8 py-4 bg-transparent border-2 border-[#39ff14] text-fluro-green-subtle rounded-lg font-semibold hover:bg-[#39ff14] hover:text-black hover:glow-red-strong transition-all duration-300 transform hover:scale-105"
              >
                Sign In as User
              </button>
              <button
                onClick={() => setArtistAuthModalOpen(true)}
                className="px-8 py-4 bg-transparent border-2 border-red-500 text-red-500 rounded-lg font-semibold hover:bg-red-500 hover:text-white transition-all duration-300 transform hover:scale-105"
              >
                Sign In as Artist
              </button>
            </div>
          )}
        </section>

        {loading ? (
          <div className="text-center py-12">
            <p className="text-fluro-green-subtle text-lg">Loading artists...</p>
          </div>
        ) : artists.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-fluro-green-subtle text-lg">No artists found</p>
          </div>
        ) : (
          <>
            <ArtistDirectorySearch
              artists={artists}
              onFilteredArtistsChange={setFilteredArtists}
            />

            {/* Featured Artist of the Month Section */}
            <FeaturedArtistOfMonth onArtistClick={setSelectedArtist} />

            {/* Featured Premium Artists Section - Max 100 */}
            {filteredArtists.filter(a => a.is_premium && a.featured_priority && a.featured_priority <= 100).length > 0 && (
              <section className="mb-16">
                <div className="flex items-center gap-3 mb-8">
                  <h3 className="text-2xl sm:text-3xl font-bold text-[#39ff14]">Featured Premium Artists</h3>
                  <span className="px-3 py-1 bg-[#39ff14] text-black text-xs font-bold rounded-full">PREMIUM</span>
                </div>
                <div className="artist-grid">
                  {filteredArtists
                    .filter(a => a.is_premium && a.featured_priority && a.featured_priority <= 100)
                    .map((artist) => (
                      <div
                        key={artist.id}
                        onClick={() => setSelectedArtist(artist)}
                        className="artist-card bg-gray-900 rounded-lg border-2 border-[#39ff14] glow-green hover:glow-green-strong transition-all duration-300 transform hover:scale-105 cursor-pointer group relative"
                      >
                        <div className="absolute top-2 right-2 z-10 flex gap-2">
                          <div className="px-2 py-1 bg-[#39ff14] text-black text-xs font-bold rounded">
                            PREMIUM
                          </div>
                          {artist.is_verified && (
                            <div className="px-2 py-1 bg-blue-500 text-white text-xs font-bold rounded flex items-center gap-1">
                              <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                              </svg>
                              VERIFIED
                            </div>
                          )}
                          {artist.is_demo && (
                            <div className="px-2 py-1 bg-orange-500 text-white text-xs font-bold rounded">
                              DEMO
                            </div>
                          )}
                        </div>
                        <div className="relative overflow-hidden h-64">
                          <img
                            src={artist.image_url}
                            alt={artist.name}
                            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                          />
                          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-70"></div>
                          <ArtistCardStats artistId={artist.id} />
                        </div>
                        <div className="p-6">
                          <h4 className="text-2xl font-bold text-[#39ff14] mb-2">{artist.stage_name || artist.name}</h4>
                          <p className="text-fluro-green-subtle text-sm mb-1">{artist.category}</p>
                          {artist.genre && (
                            <p className="text-fluro-green-subtle text-xs mb-1 opacity-70">{artist.genre}</p>
                          )}
                          <p className="text-fluro-green-subtle text-sm opacity-80 mb-3">{artist.location}</p>
                          <div className="flex gap-2 flex-wrap">
                            {artist.youtube_link && (
                              <a href={artist.youtube_link} target="_blank" rel="noopener noreferrer" onClick={(e) => { e.stopPropagation(); trackSocialClick(artist.id); }} className="text-red-500 hover:text-red-400 transition-colors" title="YouTube">
                                <Youtube className="w-4 h-4" />
                              </a>
                            )}
                            {artist.instagram_link && (
                              <a href={artist.instagram_link} target="_blank" rel="noopener noreferrer" onClick={(e) => { e.stopPropagation(); trackSocialClick(artist.id); }} className="text-pink-500 hover:text-pink-400 transition-colors" title="Instagram">
                                <Instagram className="w-4 h-4" />
                              </a>
                            )}
                            {artist.facebook_link && (
                              <a href={artist.facebook_link} target="_blank" rel="noopener noreferrer" onClick={(e) => { e.stopPropagation(); trackSocialClick(artist.id); }} className="text-blue-500 hover:text-blue-400 transition-colors" title="Facebook">
                                <Facebook className="w-4 h-4" />
                              </a>
                            )}
                            {artist.soundcloud_link && (
                              <a href={artist.soundcloud_link} target="_blank" rel="noopener noreferrer" onClick={(e) => { e.stopPropagation(); trackSocialClick(artist.id); }} className="text-orange-500 hover:text-orange-400 transition-colors" title="SoundCloud">
                                <SoundCloudIcon className="w-4 h-4" />
                              </a>
                            )}
                            {artist.mixcloud_link && (
                              <a href={artist.mixcloud_link} target="_blank" rel="noopener noreferrer" onClick={(e) => { e.stopPropagation(); trackSocialClick(artist.id); }} className="text-teal-500 hover:text-teal-400 transition-colors" title="Mixcloud">
                                <Radio className="w-4 h-4" />
                              </a>
                            )}
                            {artist.spotify_link && (
                              <a href={artist.spotify_link} target="_blank" rel="noopener noreferrer" onClick={(e) => { e.stopPropagation(); trackSocialClick(artist.id); }} className="text-green-500 hover:text-green-400 transition-colors" title="Spotify">
                                <Headphones className="w-4 h-4" />
                              </a>
                            )}
                          </div>
                        </div>
                      </div>
                    ))}
                </div>
              </section>
            )}

            {/* All Artists Section */}
            <section className="mb-16">
              <h3 className="text-2xl sm:text-3xl font-bold text-fluro-green-subtle mb-8">All Artists</h3>
              <div className="artist-grid">
                {filteredArtists.map((artist) => (
                  <div
                    key={artist.id}
                    onClick={() => setSelectedArtist(artist)}
                    className="artist-card bg-gray-900 rounded-lg border-2 border-red-500 glow-red hover:glow-red-strong transition-all duration-300 transform hover:scale-105 cursor-pointer group relative"
                  >
                    <div className="absolute top-2 right-2 z-10 flex gap-2">
                      {artist.is_premium && (
                        <div className="px-2 py-1 bg-[#39ff14] text-black text-xs font-bold rounded">
                          PREMIUM
                        </div>
                      )}
                      {artist.is_verified && (
                        <div className="px-2 py-1 bg-blue-500 text-white text-xs font-bold rounded flex items-center gap-1">
                          <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
                          </svg>
                          VERIFIED
                        </div>
                      )}
                      {artist.is_demo && (
                        <div className="px-2 py-1 bg-orange-500 text-white text-xs font-bold rounded">
                          DEMO
                        </div>
                      )}
                    </div>
                    <div className="relative overflow-hidden h-64">
                      <img
                        src={artist.image_url}
                        alt={artist.name}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent opacity-70"></div>
                      <ArtistCardStats artistId={artist.id} />
                    </div>
                    <div className="p-6">
                      <h4 className="text-2xl font-bold text-fluro-green-subtle mb-2">{artist.stage_name || artist.name}</h4>
                      <p className="text-fluro-green-subtle text-sm mb-1">{artist.category}</p>
                      {artist.genre && (
                        <p className="text-fluro-green-subtle text-xs mb-1 opacity-70">{artist.genre}</p>
                      )}
                      <p className="text-fluro-green-subtle text-sm opacity-80 mb-3">{artist.location}</p>
                      <div className="flex gap-2 flex-wrap">
                        {artist.youtube_link && (
                          <a href={artist.youtube_link} target="_blank" rel="noopener noreferrer" onClick={(e) => { e.stopPropagation(); trackSocialClick(artist.id); }} className="text-red-500 hover:text-red-400 transition-colors" title="YouTube">
                            <Youtube className="w-4 h-4" />
                          </a>
                        )}
                        {artist.instagram_link && (
                          <a href={artist.instagram_link} target="_blank" rel="noopener noreferrer" onClick={(e) => { e.stopPropagation(); trackSocialClick(artist.id); }} className="text-pink-500 hover:text-pink-400 transition-colors" title="Instagram">
                            <Instagram className="w-4 h-4" />
                          </a>
                        )}
                        {artist.facebook_link && (
                          <a href={artist.facebook_link} target="_blank" rel="noopener noreferrer" onClick={(e) => { e.stopPropagation(); trackSocialClick(artist.id); }} className="text-blue-500 hover:text-blue-400 transition-colors" title="Facebook">
                            <Facebook className="w-4 h-4" />
                          </a>
                        )}
                        {artist.soundcloud_link && (
                          <a href={artist.soundcloud_link} target="_blank" rel="noopener noreferrer" onClick={(e) => { e.stopPropagation(); trackSocialClick(artist.id); }} className="text-orange-500 hover:text-orange-400 transition-colors" title="SoundCloud">
                            <SoundCloudIcon className="w-4 h-4" />
                          </a>
                        )}
                        {artist.mixcloud_link && (
                          <a href={artist.mixcloud_link} target="_blank" rel="noopener noreferrer" onClick={(e) => { e.stopPropagation(); trackSocialClick(artist.id); }} className="text-teal-500 hover:text-teal-400 transition-colors" title="Mixcloud">
                            <Radio className="w-4 h-4" />
                          </a>
                        )}
                        {artist.spotify_link && (
                          <a href={artist.spotify_link} target="_blank" rel="noopener noreferrer" onClick={(e) => { e.stopPropagation(); trackSocialClick(artist.id); }} className="text-green-500 hover:text-green-400 transition-colors" title="Spotify">
                            <Headphones className="w-4 h-4" />
                          </a>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </>
        )}
      </main>

      <footer className="relative z-10 container mx-auto px-4 py-8 text-center border-t border-red-500 border-opacity-30">
        <div className="flex flex-col items-center gap-3">
          <div className="flex gap-6">
            <Link
              to="/terms"
              className="text-fluro-green-subtle text-sm hover:text-[#39ff14] transition-colors underline"
            >
              Terms & Conditions
            </Link>
            <Link
              to="/privacy"
              className="text-fluro-green-subtle text-sm hover:text-[#39ff14] transition-colors underline"
            >
              Privacy Policy
            </Link>
          </div>
          <p className="text-fluro-green-subtle text-sm">
            © 2025 Beat Bookings Live. All rights reserved.
          </p>
        </div>
      </footer>

      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onUserNeedsProfileSetup={handleUserNeedsProfileSetup}
        onArtistNeedsProfileSetup={handleArtistSignupSuccess}
      />

      <UserProfileSetupModal
        isOpen={userProfileSetupModalOpen}
        userId={setupUserId}
        userEmail={setupUserEmail}
        onClose={() => setUserProfileSetupModalOpen(false)}
        onComplete={handleUserProfileSetupComplete}
      />

      <ArtistAuthModal
        isOpen={artistAuthModalOpen}
        onClose={() => setArtistAuthModalOpen(false)}
        onSignupSuccess={handleArtistSignupSuccess}
      />

      <ArtistProfileModal
        isOpen={artistProfileModalOpen}
        userId={artistUserId}
        userEmail={artistEmail}
        onClose={() => setArtistProfileModalOpen(false)}
        onComplete={handleProfileComplete}
        onSubscribe={handleSubscribe}
      />

      <SubscriptionModal
        isOpen={subscriptionModalOpen}
        onClose={() => setSubscriptionModalOpen(false)}
      />

      <AboutModal
        isOpen={aboutModalOpen}
        onClose={() => setAboutModalOpen(false)}
      />

      <ArtistDetailView
        artist={selectedArtist}
        onClose={() => setSelectedArtist(null)}
        reviews={reviews}
        isLoggedIn={!!user}
        onSignIn={() => {
          setSelectedArtist(null);
          setAuthModalOpen(true);
        }}
      />

      <FloatingSupportButton onClick={() => setSupportChatOpen(true)} />

      <SupportChatModal
        isOpen={supportChatOpen}
        onClose={() => setSupportChatOpen(false)}
        userId={user?.id}
      />
    </div>
  );
}

export default App;
