import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Artist {
  id: number;
  name: string;
  category: string;
  location: string;
  locations?: string[];
  state_territories?: string[];
  image_url: string;
  about: string;
  cost?: number | null;
  cost_type?: string | null;
  youtube_link: string;
  instagram_link: string;
  facebook_link: string;
  soundcloud_link: string;
  mixcloud_link: string;
  spotify_link: string;
  tiktok_link: string;
  availability: string;
  rating: number | string;
  created_at: string;
  stage_name?: string;
  genre?: string;
  additional_images?: string[];
  video_urls?: string[];
  is_premium?: boolean;
  premium_start_date?: string | null;
  premium_end_date?: string | null;
  featured_priority?: number | null;
  is_verified?: boolean;
  profile_theme?: 'red' | 'green' | 'blue' | 'purple' | 'gold' | 'cyan';
  max_media_items?: number | null;
  email: string;
}

export interface ArtistAnalyticsDetailed {
  id: string;
  artist_id: number;
  date: string;
  profile_views: number;
  unique_visitors: number;
  social_clicks: number;
  portfolio_views: number;
  booking_button_clicks: number;
  created_at: string;
  updated_at: string;
}

export interface Review {
  id: string;
  artist_id: number;
  user_id: string;
  rating: number;
  comment: string;
  created_at: string;
  updated_at: string;
}
