import { supabase } from './supabase';

export async function updateUserType(userId: string, userType: 'client' | 'artist') {
  const { error } = await supabase
    .from('users')
    .update({ user_type: userType })
    .eq('id', userId);

  if (error) {
    console.error('Error updating user type:', error);
    throw error;
  }
}

export async function getUserProfile(userId: string) {
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('id', userId)
    .maybeSingle();

  if (error) {
    console.error('Error fetching user profile:', error);
    throw error;
  }

  return data;
}

export async function updateUserProfile(userId: string, updates: { full_name?: string; is_active?: boolean }) {
  const { error } = await supabase
    .from('users')
    .update({ ...updates, updated_at: new Date().toISOString() })
    .eq('id', userId);

  if (error) {
    console.error('Error updating user profile:', error);
    throw error;
  }
}
