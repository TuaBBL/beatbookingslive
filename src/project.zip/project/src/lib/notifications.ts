import { supabase } from './supabase';
import { showToast } from '../components/Toast';

export interface Notification {
  id: string;
  user_id: string | null;
  type: string;
  title: string;
  message: string;
  created_at: string;
}

export async function fetchLatestNotification(): Promise<Notification | null> {
  try {
    const { data, error } = await supabase
      .from('notifications')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error fetching latest notification:', error);
    return null;
  }
}

export function checkAndShowNotification(notification: Notification | null) {
  if (!notification) return;

  const lastSeenId = localStorage.getItem('last_seen_notification_id');

  if (lastSeenId !== notification.id) {
    showToast(notification.title, notification.message);
    localStorage.setItem('last_seen_notification_id', notification.id);
  }
}

export async function checkForNewNotifications() {
  const latestNotification = await fetchLatestNotification();
  checkAndShowNotification(latestNotification);
}
