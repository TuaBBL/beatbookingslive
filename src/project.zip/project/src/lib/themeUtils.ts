export type ThemeValue = 'red' | 'green' | 'blue' | 'purple' | 'gold' | 'cyan';

export interface ThemeColors {
  borderColor: string;
  glowClass: string;
  color: string;
  name: string;
}

const themeMap: Record<ThemeValue, ThemeColors> = {
  red: {
    borderColor: 'border-red-500',
    glowClass: 'glow-red',
    color: '#ff0000',
    name: 'Classic Red',
  },
  green: {
    borderColor: 'border-[#39ff14]',
    glowClass: 'glow-green',
    color: '#39ff14',
    name: 'Neon Green',
  },
  blue: {
    borderColor: 'border-blue-400',
    glowClass: 'glow-blue',
    color: '#00d4ff',
    name: 'Electric Blue',
  },
  purple: {
    borderColor: 'border-purple-500',
    glowClass: 'glow-purple',
    color: '#a855f7',
    name: 'Royal Purple',
  },
  gold: {
    borderColor: 'border-yellow-500',
    glowClass: 'glow-yellow',
    color: '#fbbf24',
    name: 'Luxury Gold',
  },
  cyan: {
    borderColor: 'border-cyan-400',
    glowClass: 'glow-cyan',
    color: '#06b6d4',
    name: 'Cyber Cyan',
  },
};

export function getThemeColors(theme?: string): ThemeColors {
  const validTheme = (theme as ThemeValue) || 'red';
  return themeMap[validTheme] || themeMap.red;
}

export function getThemeClasses(theme?: string): {
  border: string;
  borderStrong: string;
  glow: string;
  glowStrong: string;
  hoverGlow: string;
} {
  const themeColors = getThemeColors(theme);
  return {
    border: `border-2 ${themeColors.borderColor}`,
    borderStrong: `border-2 ${themeColors.borderColor}`,
    glow: themeColors.glowClass,
    glowStrong: `${themeColors.glowClass}-strong`,
    hoverGlow: `hover:${themeColors.glowClass}-strong`,
  };
}
