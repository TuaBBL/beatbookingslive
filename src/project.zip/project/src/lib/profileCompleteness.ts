/**
 * Profile Completeness Utilities
 * Provides traffic-light system for user and artist profiles
 */

export type ProfileStatus = 'red' | 'yellow' | 'green';

export interface ProfileCompletenessResult {
  status: ProfileStatus;
  percentage: number;
  missingFields: string[];
  totalFields: number;
  completedFields: number;
}

/**
 * Check if a field value is valid (not null, "null", empty, or whitespace)
 */
function isValidField(value: any): boolean {
  if (value === null || value === undefined) return false;
  if (typeof value === 'string') {
    if (value === 'null' || value.trim() === '') return false;
  }
  if (Array.isArray(value) && value.length === 0) return false;
  return true;
}

/**
 * Calculate user profile completeness
 * Required fields: full_name, location, state_territory, phone_number, profile_image_url
 */
export function calculateUserProfileCompleteness(profile: any): ProfileCompletenessResult {
  const requiredFields = {
    full_name: 'Full Name',
    location: 'Location',
    state_territory: 'State/Territory',
    phone_number: 'Phone Number',
    profile_image_url: 'Profile Image',
  };

  const missingFields: string[] = [];
  let completedFields = 0;
  const totalFields = Object.keys(requiredFields).length;

  Object.entries(requiredFields).forEach(([key, label]) => {
    if (isValidField(profile?.[key])) {
      completedFields++;
    } else {
      missingFields.push(label);
    }
  });

  const percentage = Math.round((completedFields / totalFields) * 100);

  let status: ProfileStatus;
  if (completedFields === totalFields) {
    status = 'green';
  } else if (completedFields === 0) {
    status = 'red';
  } else {
    status = 'yellow';
  }

  return {
    status,
    percentage,
    missingFields,
    totalFields,
    completedFields,
  };
}

/**
 * Calculate artist profile completeness
 * Required fields: stage_name (or name), category, state_territories, genre, locations, image_url
 */
export function calculateArtistProfileCompleteness(artist: any): ProfileCompletenessResult {
  const requiredFields = {
    name_or_stage: 'Name/Stage Name',
    category: 'Category',
    state_territories: 'State/Territory',
    genre: 'Genre',
    locations: 'Location',
    image_url: 'Profile Image',
  };

  const missingFields: string[] = [];
  let completedFields = 0;
  const totalFields = Object.keys(requiredFields).length;

  // Check stage_name OR name
  if (isValidField(artist?.stage_name) || isValidField(artist?.name)) {
    completedFields++;
  } else {
    missingFields.push('Name/Stage Name');
  }

  // Check category
  if (isValidField(artist?.category)) {
    completedFields++;
  } else {
    missingFields.push('Category');
  }

  // Check state_territories (array)
  if (isValidField(artist?.state_territories)) {
    completedFields++;
  } else {
    missingFields.push('State/Territory');
  }

  // Check genre
  if (isValidField(artist?.genre)) {
    completedFields++;
  } else {
    missingFields.push('Genre');
  }

  // Check locations (array)
  if (isValidField(artist?.locations)) {
    completedFields++;
  } else {
    missingFields.push('Location');
  }

  // Check image_url
  if (isValidField(artist?.image_url)) {
    completedFields++;
  } else {
    missingFields.push('Profile Image');
  }

  const percentage = Math.round((completedFields / totalFields) * 100);

  let status: ProfileStatus;
  if (completedFields === totalFields) {
    status = 'green';
  } else if (completedFields === 0) {
    status = 'red';
  } else {
    status = 'yellow';
  }

  return {
    status,
    percentage,
    missingFields,
    totalFields,
    completedFields,
  };
}

/**
 * Get status color for UI rendering
 */
export function getStatusColor(status: ProfileStatus): string {
  switch (status) {
    case 'green':
      return '#22c55e'; // green-500
    case 'yellow':
      return '#eab308'; // yellow-500
    case 'red':
      return '#ef4444'; // red-500
    default:
      return '#6b7280'; // gray-500
  }
}

/**
 * Get status label for UI rendering
 */
export function getStatusLabel(status: ProfileStatus): string {
  switch (status) {
    case 'green':
      return 'Complete';
    case 'yellow':
      return 'Partial';
    case 'red':
      return 'Incomplete';
    default:
      return 'Unknown';
  }
}

/**
 * Get status emoji for UI rendering
 */
export function getStatusEmoji(status: ProfileStatus): string {
  switch (status) {
    case 'green':
      return '🟩';
    case 'yellow':
      return '🟧';
    case 'red':
      return '🟥';
    default:
      return '⬜';
  }
}
