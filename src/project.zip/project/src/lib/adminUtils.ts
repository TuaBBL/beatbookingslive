/**
 * Admin Utilities
 * Helper functions for checking admin and ambassador roles
 */

import { User } from '@supabase/supabase-js';

/**
 * Check if a user has admin role in their JWT app_metadata
 * @param user - Supabase auth user object
 * @returns true if user is an admin
 */
export function isAdmin(user: User | null | undefined): boolean {
  if (!user) return false;
  return user.app_metadata?.role === 'admin';
}

/**
 * Check if a user has ambassador role in their JWT app_metadata
 * @param user - Supabase auth user object
 * @returns true if user is an ambassador
 */
export function isAmbassador(user: User | null | undefined): boolean {
  if (!user) return false;
  return user.app_metadata?.role === 'ambassador';
}

/**
 * Check if a user has admin or ambassador role
 * @param user - Supabase auth user object
 * @returns true if user is admin or ambassador
 */
export function isAdminOrAmbassador(user: User | null | undefined): boolean {
  return isAdmin(user) || isAmbassador(user);
}

/**
 * Get user role from app_metadata
 * @param user - Supabase auth user object
 * @returns user role ('admin', 'ambassador', 'user', or null)
 */
export function getUserRole(user: User | null | undefined): string | null {
  if (!user) return null;
  return user.app_metadata?.role || 'user';
}
