import { supabase } from './supabase';

export interface UserProfile {
  id: string;
  full_name: string | null;
  location: string | null;
  state_territory: string | null;
  phone_number: string | null;
  profile_image_url: string | null;
  created_at: string;
  updated_at: string;
}

export function isProfileComplete(profile: UserProfile | null): boolean {
  if (!profile) return false;

  const requiredFields = [
    profile.full_name,
    profile.location,
    profile.state_territory
  ];

  return requiredFields.every(field =>
    field !== null && field !== '' && field.toLowerCase() !== 'null'
  );
}

export async function getOrCreateProfile(userId: string): Promise<UserProfile | null> {
  try {
    const { data: existingProfile, error: fetchError } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (fetchError && fetchError.code !== 'PGRST116') {
      throw fetchError;
    }

    if (existingProfile) {
      return existingProfile;
    }

    const { data: newProfile, error: insertError } = await supabase
      .from('profiles')
      .insert({
        id: userId,
        full_name: null,
        location: null,
        state_territory: null,
        phone_number: null,
        profile_image_url: null
      })
      .select()
      .single();

    if (insertError) throw insertError;

    return newProfile;
  } catch (error) {
    console.error('Error getting or creating profile:', error);
    return null;
  }
}

export async function fetchUserProfile(userId: string): Promise<UserProfile | null> {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .maybeSingle();

    if (error) throw error;
    return data;
  } catch (error) {
    console.error('Error fetching user profile:', error);
    return null;
  }
}
