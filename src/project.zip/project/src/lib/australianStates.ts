export interface AustralianState {
  abbreviation: string;
  fullName: string;
}

export const AUSTRALIAN_STATES: AustralianState[] = [
  { abbreviation: 'NSW', fullName: 'New South Wales' },
  { abbreviation: 'VIC', fullName: 'Victoria' },
  { abbreviation: 'QLD', fullName: 'Queensland' },
  { abbreviation: 'WA', fullName: 'Western Australia' },
  { abbreviation: 'SA', fullName: 'South Australia' },
  { abbreviation: 'TAS', fullName: 'Tasmania' },
  { abbreviation: 'ACT', fullName: 'Australian Capital Territory' },
  { abbreviation: 'NT', fullName: 'Northern Territory' },
];

export const STATE_ABBREVIATIONS = AUSTRALIAN_STATES.map(s => s.abbreviation);
export const STATE_FULL_NAMES = AUSTRALIAN_STATES.map(s => s.fullName);

export function getStateFullName(abbreviation: string): string | undefined {
  return AUSTRALIAN_STATES.find(s => s.abbreviation === abbreviation)?.fullName;
}

export function getStateAbbreviation(fullName: string): string | undefined {
  return AUSTRALIAN_STATES.find(s => s.fullName === fullName)?.abbreviation;
}

export function isValidState(state: string): boolean {
  return AUSTRALIAN_STATES.some(
    s => s.abbreviation === state || s.fullName === state
  );
}

export function formatStateDisplay(abbreviation: string): string {
  const state = AUSTRALIAN_STATES.find(s => s.abbreviation === abbreviation);
  return state ? `${state.abbreviation} - ${state.fullName}` : abbreviation;
}
