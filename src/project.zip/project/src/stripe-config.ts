export interface StripeProduct {
  priceId: string;
  name: string;
  description: string;
  mode: 'subscription' | 'payment';
  price: number;
  currency: string;
}

export const stripeProducts: StripeProduct[] = [
  {
    priceId: 'price_1SWsr8L9JEMfabAdRBqgp5GP',
    name: 'Artist Listing - Premium',
    description: 'Boost your visibility with featured placement. Priority artists appear at the top of search results & highlighted on the homepage.',
    mode: 'subscription',
    price: 35.00,
    currency: 'AUD'
  },
  {
    priceId: 'price_1SWsjNL9JEMfabAdzlltRjay',
    name: 'Artist Listing - Standard',
    description: 'Get your artist profile listed on BeatBookingsLive. Appear in search and get discovered by event planners across Australia & NZ.',
    mode: 'subscription',
    price: 25.00,
    currency: 'AUD'
  }
];

export function getProductByPriceId(priceId: string): StripeProduct | undefined {
  return stripeProducts.find(product => product.priceId === priceId);
}