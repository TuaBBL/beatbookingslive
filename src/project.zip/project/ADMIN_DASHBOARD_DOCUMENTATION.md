# Admin Dashboard & Traffic-Light Profile System Documentation

## Overview

A comprehensive admin dashboard with traffic-light profile completeness indicators that provides owners and ambassadors with full visibility and control over all user and artist profiles.

---

## Features Implemented

### 1. Traffic-Light Profile Completeness System

**Status Levels:**
- 🟩 **GREEN** - Profile 100% complete
- 🟧 **YELLOW** - Profile partially complete (1-99%)
- 🟥 **RED** - Profile incomplete (0% or missing all fields)

**Components Created:**
- `ProfileStatusIndicator` - Visual traffic light with tooltip
- `CompletionBar` - Progress bar showing completion percentage
- `profileCompleteness.ts` - Calculation utilities

---

### 2. Admin Role System

**Roles:**
- `admin` - Full access to admin dashboard and all data
- `ambassador` - Same access as admin
- `user` - Normal user, no admin access

**Database Changes:**
- Added `role` column to `users` table
- Default role: `user`
- Role constraint: `('user', 'ambassador', 'admin')`

**Helper Function:**
```sql
is_admin_or_ambassador() → BOOLEAN
```

---

### 3. Admin Profiles Dashboard

**Route:** `/admin/profiles`

**Access Control:**
- Only users with role `admin` or `ambassador` can access
- Automatic redirect to homepage if unauthorized
- RLS policies enforce data access at database level

**Features:**

#### Tabs
- **Users Tab** - View all user profiles
- **Artists Tab** - View all artist profiles

#### Filters (Users Tab)
- Search by name or email
- Sort by: Name, Completion %, State
- State filter
- "Incomplete Only" checkbox

#### Filters (Artists Tab)
- Search by stage name or email
- Sort by: Name, Completion %, State
- State filter
- Genre filter
- Category filter
- "Incomplete Only" checkbox

#### Table Columns (Users)
| Column | Description |
|--------|-------------|
| Name | Full name |
| Email | User email address |
| State | State/Territory |
| Location | City/Location |
| Status | Traffic light indicator with label |
| Completion | Progress bar showing % complete |

#### Table Columns (Artists)
| Column | Description |
|--------|-------------|
| Stage Name | Artist stage name or name |
| Category | Artist category (DJ, Band, etc.) |
| Genre | Music genre |
| State | Primary state/territory |
| Location | Primary location |
| Status | Traffic light indicator with label |
| Completion | Progress bar showing % complete |
| Verified | Checkmark if verified artist |

---

## Profile Completeness Calculation

### User Profile

**Required Fields:**
1. `full_name`
2. `location`
3. `state_territory`
4. `phone_number`
5. `profile_image_url`

**Calculation Logic:**
```javascript
const missingFields = [];
let completedFields = 0;
const totalFields = 5;

// Check each field
if (isValidField(profile.full_name)) completedFields++;
else missingFields.push('Full Name');

// ... repeat for all fields

const percentage = (completedFields / totalFields) * 100;

// Determine status
if (completedFields === totalFields) status = 'green';
else if (completedFields === 0) status = 'red';
else status = 'yellow';
```

**Field Validation:**
```javascript
function isValidField(value) {
  if (value === null || value === undefined) return false;
  if (value === 'null') return false;
  if (value.trim() === '') return false;
  if (Array.isArray(value) && value.length === 0) return false;
  return true;
}
```

### Artist Profile

**Required Fields:**
1. `stage_name` OR `name`
2. `category`
3. `state_territories` (array with at least one entry)
4. `genre`
5. `locations` (array with at least one entry)
6. `image_url`

**Same calculation logic as user profiles**

---

## RLS Policies Created

### Admin Read Access

```sql
-- Profiles table
CREATE POLICY "Admins and ambassadors can read all profiles"
ON profiles FOR SELECT
TO authenticated
USING (is_admin_or_ambassador());

-- Artist_cards table
CREATE POLICY "Admins and ambassadors can read all artist cards"
ON artist_cards FOR SELECT
TO authenticated
USING (is_admin_or_ambassador());

-- Users table
CREATE POLICY "Admins and ambassadors can read all users"
ON users FOR SELECT
TO authenticated
USING (is_admin_or_ambassador());
```

---

## Usage Instructions

### For Owners/Developers

**1. Set a User as Admin:**

```sql
-- Via SQL
UPDATE users SET role = 'admin' WHERE id = 'user-uuid';

-- Or via Supabase Dashboard
-- Go to Table Editor → users → find user → edit role column
```

**2. Set a User as Ambassador:**

```sql
UPDATE users SET role = 'ambassador' WHERE id = 'user-uuid';
```

**3. Access the Admin Dashboard:**

1. Log in as an admin or ambassador
2. Navigate to: `/admin/profiles`
3. Dashboard will automatically load if authorized

**4. View Incomplete Profiles:**

1. Click "Incomplete Only" checkbox
2. Table will filter to show only incomplete profiles
3. Sort by "Completion" to see worst profiles first

**5. Monitor Profile Quality:**

- Green profiles = No action needed
- Yellow profiles = Encourage users to complete
- Red profiles = Contact users urgently

---

## Component API Reference

### ProfileStatusIndicator

```typescript
<ProfileStatusIndicator
  status="red" | "yellow" | "green"
  percentage={75}
  missingFields={['Full Name', 'Phone Number']}
  size="sm" | "md" | "lg"  // Optional, default: "md"
  showLabel={true}          // Optional, default: false
  showPercentage={true}     // Optional, default: false
/>
```

**Features:**
- Colored circular indicator
- Hover tooltip showing missing fields
- Optional label text
- Optional percentage display

### CompletionBar

```typescript
<CompletionBar
  percentage={75}
  status="yellow"           // Optional
  showPercentage={true}     // Optional, default: true
  height="sm" | "md" | "lg" // Optional, default: "md"
/>
```

**Features:**
- Animated progress bar
- Color matches status or percentage
- Smooth transitions

### Profile Completeness Functions

```typescript
import {
  calculateUserProfileCompleteness,
  calculateArtistProfileCompleteness,
  getStatusColor,
  getStatusLabel,
  getStatusEmoji
} from '../lib/profileCompleteness';

// Calculate user completeness
const result = calculateUserProfileCompleteness(userProfile);
// Returns: {
//   status: 'red' | 'yellow' | 'green',
//   percentage: 80,
//   missingFields: ['Phone Number'],
//   totalFields: 5,
//   completedFields: 4
// }

// Calculate artist completeness
const result = calculateArtistProfileCompleteness(artistCard);

// Get UI helpers
getStatusColor('green');  // Returns: '#22c55e'
getStatusLabel('yellow'); // Returns: 'Partial'
getStatusEmoji('red');    // Returns: '🟥'
```

---

## Security Considerations

### Role Escalation Prevention

**Issue:** Normal users should not be able to promote themselves to admin.

**Solution:**
- Role changes can only be made:
  - By admins via SQL
  - By admins via Supabase Dashboard
  - NOT by users updating their own profile

**Future Enhancement:**
```sql
-- Add policy to prevent self-promotion
CREATE POLICY "Users cannot change their own role"
ON users FOR UPDATE
TO authenticated
USING (id = auth.uid())
WITH CHECK (
  id = auth.uid() AND
  (role IS NULL OR role = (SELECT role FROM users WHERE id = auth.uid()))
);
```

### Data Access Control

**Admin Dashboard Access:**
- Client-side: Route checks user role and redirects
- Server-side: RLS policies enforce data access
- Even if client checks bypassed, RLS prevents data access

**Cannot Be Bypassed:**
- RLS policies run on every query
- Admin function (`is_admin_or_ambassador()`) checks database
- No client-side manipulation can escalate privileges

---

## Performance Optimization

### Indexes Created

```sql
CREATE INDEX idx_users_role ON users(role);
```

**Benefits:**
- Fast role lookups
- Efficient `is_admin_or_ambassador()` function
- Minimal impact on admin dashboard load time

### Query Optimization

**Dashboard loads all profiles in one query:**
- Users: Single query to `profiles`
- Artists: Single query to `artist_cards`
- Email lookups: Batched via Promise.all()

**Pagination (Future Enhancement):**
```typescript
// Add offset/limit for large datasets
const { data, error } = await supabase
  .from('profiles')
  .select('*')
  .range(offset, offset + limit - 1);
```

---

## Testing Scenarios

### Test Case 1: Admin Access

**Steps:**
1. Set user role to 'admin'
2. Log in as that user
3. Navigate to `/admin/profiles`

**Expected:**
- ✅ Dashboard loads successfully
- ✅ Can see all users
- ✅ Can see all artists
- ✅ Can apply filters
- ✅ Traffic lights display correctly

---

### Test Case 2: Ambassador Access

**Steps:**
1. Set user role to 'ambassador'
2. Log in as that user
3. Navigate to `/admin/profiles`

**Expected:**
- ✅ Dashboard loads (same as admin)
- ✅ Full access to all features

---

### Test Case 3: Normal User Access (Blocked)

**Steps:**
1. Log in as normal user (role = 'user')
2. Navigate to `/admin/profiles`

**Expected:**
- ✅ Redirected to homepage
- ✅ Cannot see any admin data
- ✅ Console shows "Checking permissions..."
- ✅ No errors thrown

---

### Test Case 4: Unauthenticated Access (Blocked)

**Steps:**
1. Log out
2. Navigate to `/admin/profiles`

**Expected:**
- ✅ Redirected to homepage
- ✅ No data accessed

---

### Test Case 5: Traffic Light Colors

**Setup:**
```sql
-- Create test users with different completion levels
INSERT INTO profiles (id, full_name, location, state_territory, phone_number, profile_image_url)
VALUES
  ('user1', 'Complete User', 'Sydney', 'NSW', '0400000000', 'https://...'), -- GREEN
  ('user2', 'Partial User', 'Melbourne', 'VIC', null, null),                -- YELLOW
  ('user3', null, null, null, null, null);                                  -- RED
```

**Expected:**
- ✅ user1 shows green indicator, 100%
- ✅ user2 shows yellow indicator, 60%
- ✅ user3 shows red indicator, 0%

---

### Test Case 6: Filters Working

**Steps:**
1. Load admin dashboard
2. Check "Incomplete Only"
3. Enter "NSW" in state filter
4. Enter "DJ" in category filter (artists tab)

**Expected:**
- ✅ Only incomplete profiles shown
- ✅ Only NSW profiles shown
- ✅ Only DJ artists shown (on artists tab)
- ✅ Counts update correctly

---

### Test Case 7: Sorting

**Steps:**
1. Sort by "Completion"
2. Sort by "Name"
3. Sort by "State"

**Expected:**
- ✅ Completion: Lowest % first
- ✅ Name: Alphabetical A-Z
- ✅ State: Alphabetical by state

---

## Troubleshooting

### Issue: "Checking permissions..." Never Resolves

**Cause:** User role not set or database error

**Solution:**
1. Check user has role: `SELECT role FROM users WHERE id = 'user-id';`
2. Ensure role is 'admin' or 'ambassador'
3. Check browser console for errors

---

### Issue: Dashboard Empty (No Data)

**Cause:** RLS policies blocking access

**Solution:**
1. Verify `is_admin_or_ambassador()` function exists
2. Check RLS policies are created
3. Confirm user role in database
4. Check Supabase logs for policy errors

---

### Issue: Traffic Lights Not Showing

**Cause:** Missing data or component error

**Solution:**
1. Check profile data structure matches expected fields
2. Verify `calculateUserProfileCompleteness()` function works
3. Check browser console for React errors
4. Inspect element to see if indicator is rendered but hidden

---

## Future Enhancements

### Planned Features

1. **Actions Column:**
   - View profile button
   - Edit profile button
   - Send message button
   - Verify artist button

2. **Bulk Actions:**
   - Select multiple profiles
   - Bulk verify artists
   - Bulk send reminders

3. **Export Functionality:**
   - Export to CSV
   - Export filtered results
   - Email reports

4. **Analytics:**
   - Average completion percentage
   - Completion trends over time
   - Most common missing fields

5. **Auto-Reminders:**
   - Email users with incomplete profiles
   - Scheduled reminder campaigns
   - Customizable email templates

6. **Advanced Filters:**
   - Date range filter (created_at)
   - Subscription status filter
   - Booking activity filter

---

## Summary

The admin dashboard provides:

✅ Full visibility into all user and artist profiles
✅ Traffic-light system for instant completeness assessment
✅ Powerful filtering and sorting capabilities
✅ Secure role-based access control
✅ Real-time data updates
✅ Mobile-responsive design
✅ Hover tooltips showing missing fields
✅ Progress bars for visual completion tracking
✅ Ambassador role support
✅ RLS-enforced security at database level

**Result:** Owners and ambassadors have complete control and visibility over profile quality across the entire platform.
