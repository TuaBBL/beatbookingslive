# Authentication Setup Instructions

## Disable Email Confirmation in Supabase

To complete the authentication workflow setup, you need to disable email confirmation in your Supabase project:

1. Go to your Supabase Dashboard
2. Navigate to **Authentication** → **Providers** → **Email**
3. Under **Email Auth Configuration**, find the setting **"Confirm email"**
4. **Uncheck** (disable) the "Confirm email" option
5. Click **Save**

## How It Works

After disabling email confirmation:

- Users can sign up and immediately log in without confirming their email
- After login, the app loads immediately (no blocking checks)
- Once the user is authenticated, the system checks if a profile exists in the `users` table (non-blocking)
- If no profile exists or the profile is incomplete:
  - **User accounts**: Opens the UserProfileModal to collect profile information
  - **Artist accounts**: Opens the ArtistProfileModal to set up their artist profile
- A welcome email is still sent after signup using the `send-welcome-email` edge function

## Profile Check Logic

The profile check happens in `App.tsx` AFTER the user is fully authenticated:

1. **Non-Blocking**: The app loads immediately, profile check runs in background
2. Checks if user has a record in the `users` table
3. For regular users: Checks if `profile_completed`, `full_name`, `location`, and `state_territory` exist
4. For artists: Checks if a record exists in `artist_profiles` with `profile_completed = true`
5. If profile is incomplete, triggers the appropriate modal

**Location**: `src/App.tsx` - `checkProfileCompletion()` function

## Architecture

### useAuth Hook (`src/hooks/useAuth.ts`)
- **Purpose**: Handle authentication state ONLY
- **Returns**: `user`, `loading`, `signOut`
- **Does NOT**: Block loading or check profiles
- **Simple**: Just manages auth session state

### App Component (`src/App.tsx`)
- **Profile Check**: Runs AFTER auth is loaded
- **Non-Blocking**: Doesn't prevent app from loading
- **Function**: `checkProfileCompletion(user)`
- **Triggers**: Appropriate profile modal if needed

## Important Files Modified

- `src/hooks/useAuth.ts` - Simplified to handle auth state only (no blocking)
- `src/App.tsx` - Added non-blocking profile check function
- `src/components/auth/LoginForm.tsx` - Removed email verification checks
- `src/components/auth/SignupForm.tsx` - Updated success message

## Key Improvements

1. **No More Infinite Loading**: Auth hook doesn't block on profile checks
2. **Fast Load Times**: App loads immediately, profile check runs async
3. **Clean Separation**: Auth state and profile checking are separate concerns
4. **Error Resilient**: Profile check failures don't break the app
