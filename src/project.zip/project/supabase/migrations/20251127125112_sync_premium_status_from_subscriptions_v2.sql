/*
  # Sync Premium Status from Subscriptions to Artist Cards

  1. New Functions
    - `sync_artist_premium_status()` - Updates is_premium flag based on subscription status
  
  2. Trigger
    - Automatically syncs premium status when subscription changes
  
  3. Purpose
    - Ensures first 50 artists with free premium subscriptions show premium badge
    - Updates artist cards when subscription status changes
    - Sets is_premium=true for users with active premium subscriptions
*/

-- Function to sync premium status
CREATE OR REPLACE FUNCTION sync_artist_premium_status()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Update artist cards based on active premium subscriptions
  UPDATE "Artist Cards" ac
  SET 
    is_premium = CASE 
      WHEN EXISTS (
        SELECT 1 
        FROM subscriptions s
        WHERE s.user_id = ac.user_id 
        AND s.status = 'active'
        AND s.subscription_type = 'premium'
      ) THEN true
      ELSE false
    END,
    subscription_type = COALESCE(
      (SELECT s.subscription_type 
       FROM subscriptions s
       WHERE s.user_id = ac.user_id 
       AND s.status = 'active' 
       ORDER BY s.created_at DESC 
       LIMIT 1),
      'standard'
    );
END;
$$;

-- Run initial sync
SELECT sync_artist_premium_status();

-- Create trigger to auto-sync when subscriptions change
CREATE OR REPLACE FUNCTION trigger_sync_premium_status()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  PERFORM sync_artist_premium_status();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS subscriptions_sync_premium ON subscriptions;
CREATE TRIGGER subscriptions_sync_premium
AFTER INSERT OR UPDATE OR DELETE ON subscriptions
FOR EACH STATEMENT
EXECUTE FUNCTION trigger_sync_premium_status();