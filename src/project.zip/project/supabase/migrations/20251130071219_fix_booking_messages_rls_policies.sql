/*
  # Fix Booking Messages RLS Policies

  ## Problem
  The booking_messages RLS policies were checking the artist_profiles table,
  but bookings are linked directly to Artist Cards table which has a user_id column.
  This was preventing artists from reading and sending messages.

  ## Changes
  1. Drop existing RLS policies for booking_messages
  2. Create new policies that check Artist Cards.user_id directly
  3. Allow both users who created the booking and artists who own the Artist Card to:
     - Read messages for their bookings
     - Send messages for their bookings

  ## Security
  - Maintains authentication requirement
  - Users can only access messages for their own bookings
  - Artists can only access messages for bookings made to their artist cards
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can read messages for their bookings" ON booking_messages;
DROP POLICY IF EXISTS "Users can send messages for their bookings" ON booking_messages;

-- Create new read policy for booking messages
CREATE POLICY "Users and artists can read booking messages"
  ON booking_messages
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM bookings
      WHERE bookings.id = booking_messages.booking_id
      AND (
        bookings.user_id = auth.uid()
        OR
        EXISTS (
          SELECT 1 FROM "Artist Cards"
          WHERE "Artist Cards".id = bookings.artist_id
          AND "Artist Cards".user_id = auth.uid()
        )
      )
    )
  );

-- Create new insert policy for booking messages
CREATE POLICY "Users and artists can send booking messages"
  ON booking_messages
  FOR INSERT
  TO authenticated
  WITH CHECK (
    sender_id = auth.uid()
    AND EXISTS (
      SELECT 1 FROM bookings
      WHERE bookings.id = booking_messages.booking_id
      AND (
        bookings.user_id = auth.uid()
        OR
        EXISTS (
          SELECT 1 FROM "Artist Cards"
          WHERE "Artist Cards".id = bookings.artist_id
          AND "Artist Cards".user_id = auth.uid()
        )
      )
    )
  );
