/*
  # Fix user_favorites RLS policies

  1. Changes
    - Drop and recreate RLS policies for user_favorites to properly check user ownership
    - Since user_favorites.user_id references users.id (which references auth.users.id)
    - We need to check if the user_id matches the users table record that corresponds to auth.uid()
  
  2. Security
    - Ensures authenticated users can only access their own favorites
    - Prevents unauthorized access to other users' favorites
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view their own favorites" ON user_favorites;
DROP POLICY IF EXISTS "Users can add their own favorites" ON user_favorites;
DROP POLICY IF EXISTS "Users can remove their own favorites" ON user_favorites;

-- Recreate policies with proper checks
-- Since user_favorites.user_id -> users.id -> auth.users.id
-- We need to check if user_id exists in users table where id = auth.uid()

CREATE POLICY "Users can view their own favorites"
  ON user_favorites
  FOR SELECT
  TO authenticated
  USING (
    user_id IN (
      SELECT id FROM users WHERE id = auth.uid()
    )
  );

CREATE POLICY "Users can add their own favorites"
  ON user_favorites
  FOR INSERT
  TO authenticated
  WITH CHECK (
    user_id IN (
      SELECT id FROM users WHERE id = auth.uid()
    )
  );

CREATE POLICY "Users can remove their own favorites"
  ON user_favorites
  FOR DELETE
  TO authenticated
  USING (
    user_id IN (
      SELECT id FROM users WHERE id = auth.uid()
    )
  );
