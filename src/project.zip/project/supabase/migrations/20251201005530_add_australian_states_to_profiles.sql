/*
  # Add Australian State/Territory Support to Profiles

  ## Overview
  This migration adds state/territory fields to support location-based filtering
  for the Australian music platform.

  ## Changes
  
  ### 1. Users Table
  - Add `state_territory` column (text) to store user's home state
  - Optional field with CHECK constraint for valid Australian states
  
  ### 2. Artist Cards Table
  - Add `state_territories` column (text array) to support multiple service areas
  - Artists can operate in multiple states
  - Includes GIN index for fast array search operations
  
  ### 3. Valid States
  - NSW (New South Wales)
  - VIC (Victoria)
  - QLD (Queensland)
  - WA (Western Australia)
  - SA (South Australia)
  - TAS (Tasmania)
  - ACT (Australian Capital Territory)
  - NT (Northern Territory)

  ## Performance
  - GIN index on artist_cards.state_territories for fast filtering
  - Regular index on users.state_territory for user queries
  
  ## Backward Compatibility
  - All new columns are nullable
  - Existing location fields preserved
  - No breaking changes to existing functionality
*/

-- Add state_territory column to users table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'state_territory'
  ) THEN
    ALTER TABLE users 
    ADD COLUMN state_territory text;
    
    -- Add CHECK constraint for valid Australian states
    ALTER TABLE users
    ADD CONSTRAINT users_state_territory_check 
    CHECK (
      state_territory IS NULL OR 
      state_territory IN ('NSW', 'VIC', 'QLD', 'WA', 'SA', 'TAS', 'ACT', 'NT')
    );
    
    -- Add index for fast filtering
    CREATE INDEX IF NOT EXISTS idx_users_state_territory 
    ON users(state_territory);
  END IF;
END $$;

-- Add state_territories array column to artist_cards table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'artist_cards' AND column_name = 'state_territories'
  ) THEN
    ALTER TABLE artist_cards 
    ADD COLUMN state_territories text[] DEFAULT '{}';
    
    -- Add CHECK constraint to ensure array contains only valid states
    ALTER TABLE artist_cards
    ADD CONSTRAINT artist_cards_state_territories_check 
    CHECK (
      state_territories <@ ARRAY['NSW', 'VIC', 'QLD', 'WA', 'SA', 'TAS', 'ACT', 'NT']::text[]
    );
    
    -- Add GIN index for fast array containment queries (@> operator)
    CREATE INDEX IF NOT EXISTS idx_artist_cards_state_territories 
    ON artist_cards USING GIN(state_territories);
  END IF;
END $$;

-- Add helpful comment
COMMENT ON COLUMN users.state_territory IS 'User home state/territory (Australian states only)';
COMMENT ON COLUMN artist_cards.state_territories IS 'Array of states/territories where artist operates (Australian states only)';
