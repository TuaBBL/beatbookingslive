/*
  # Create notifications table

  1. New Tables
    - `notifications`
      - `id` (uuid, primary key, default: gen_random_uuid())
      - `type` (text) - Type of notification (e.g., "new_artist")
      - `title` (text) - Notification title
      - `message` (text) - Notification message body
      - `created_at` (timestamptz, default: now())
  
  2. Security
    - Enable RLS on `notifications` table
    - Add policy for public read access (notifications are system-wide)
*/

CREATE TABLE IF NOT EXISTS notifications (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type text NOT NULL DEFAULT 'general',
  title text NOT NULL,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read notifications"
  ON notifications
  FOR SELECT
  TO public
  USING (true);