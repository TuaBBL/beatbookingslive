/*
  # Create email verification check function

  1. New Function
    - `check_email_verified(user_id)` - Safely checks if a user's email is verified
    - Returns boolean indicating email confirmation status
    - Accessible by authenticated users checking their own status

  2. Security
    - Function runs with invoker's privileges
    - Users can only check their own verification status
*/

-- Create function to check email verification status
CREATE OR REPLACE FUNCTION check_email_verified(user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY INVOKER
AS $$
DECLARE
  email_confirmed timestamptz;
BEGIN
  -- Check if the requesting user is checking their own status
  IF auth.uid() = user_id THEN
    -- Query auth.users for email confirmation
    SELECT email_confirmed_at INTO email_confirmed
    FROM auth.users
    WHERE id = user_id;
    
    RETURN email_confirmed IS NOT NULL;
  ELSE
    -- Return false if user is trying to check someone else's status
    RETURN false;
  END IF;
END;
$$;