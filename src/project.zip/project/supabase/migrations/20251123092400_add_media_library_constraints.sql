/*
  # Add Media Library Management to Artist Cards

  1. Updates to Artist Cards Table
    - Add check constraints to limit videos and images to maximum 5 each
    - Add metadata fields for tracking media library
    - Add profile status field

  2. Notes
    - Enforces maximum 5 videos per profile at database level
    - Enforces maximum 5 images (including main + additional) per profile
    - Helps maintain quality and performance standards
*/

DO $$
BEGIN
  -- Add check constraint for video URLs (max 5)
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'check_max_videos'
  ) THEN
    ALTER TABLE "Artist Cards" 
    ADD CONSTRAINT check_max_videos 
    CHECK (array_length(video_urls, 1) IS NULL OR array_length(video_urls, 1) <= 5);
  END IF;

  -- Add check constraint for additional images (max 4, since we have 1 main image)
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'check_max_additional_images'
  ) THEN
    ALTER TABLE "Artist Cards" 
    ADD CONSTRAINT check_max_additional_images 
    CHECK (array_length(additional_images, 1) IS NULL OR array_length(additional_images, 1) <= 4);
  END IF;

  -- Add profile_status field if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Artist Cards' AND column_name = 'profile_status'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN profile_status text DEFAULT 'draft';
  END IF;

  -- Add last_updated field if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Artist Cards' AND column_name = 'updated_at'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN updated_at timestamptz DEFAULT now();
  END IF;
END $$;

-- Add trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

DROP TRIGGER IF EXISTS update_artist_cards_updated_at ON "Artist Cards";

CREATE TRIGGER update_artist_cards_updated_at 
    BEFORE UPDATE ON "Artist Cards"
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();