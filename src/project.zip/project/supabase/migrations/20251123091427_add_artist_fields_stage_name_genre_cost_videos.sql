/*
  # Add Additional Artist Fields

  1. Changes to Artist Cards Table
    - Add `stage_name` (text) - Artist's stage/performance name
    - Add `genre` (text) - Music genre (replacing category for more specificity)
    - Add `cost` (numeric) - Booking cost/rate
    - Add `video_urls` (text array) - Array of video URLs
    - Add `additional_images` (text array) - Array of additional image URLs

  2. Notes
    - All new fields are nullable to allow gradual migration
    - Using arrays for videos and additional images for flexibility
    - Cost field uses numeric type for precise pricing
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Artist Cards' AND column_name = 'stage_name'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN stage_name text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Artist Cards' AND column_name = 'genre'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN genre text DEFAULT '';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Artist Cards' AND column_name = 'cost'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN cost numeric DEFAULT 0;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Artist Cards' AND column_name = 'video_urls'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN video_urls text[] DEFAULT '{}';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Artist Cards' AND column_name = 'additional_images'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN additional_images text[] DEFAULT '{}';
  END IF;
END $$;