/*
  # Add Write Policies for Artist Cards

  1. New Policies
    - Allow authenticated users (artists) to insert their own Artist Cards
    - Allow artists to update their own Artist Cards
    - Add user_id column to Artist Cards for ownership tracking

  2. Changes
    - Add user_id column to Artist Cards
    - Create policies for insert and update operations
    - Link Artist Cards to users via user_id

  3. Security
    - Artists can only create and update their own cards
    - Public read access remains unchanged
*/

-- Add user_id column to Artist Cards if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Artist Cards' AND column_name = 'user_id'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE;
  END IF;
END $$;

-- Create index for faster user lookups
CREATE INDEX IF NOT EXISTS idx_artist_cards_user_id ON "Artist Cards"(user_id);

-- Policy: Artists can insert their own cards
DROP POLICY IF EXISTS "Artists can create own card" ON "Artist Cards";

CREATE POLICY "Artists can create own card"
ON "Artist Cards" FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

-- Policy: Artists can update their own cards
DROP POLICY IF EXISTS "Artists can update own card" ON "Artist Cards";

CREATE POLICY "Artists can update own card"
ON "Artist Cards" FOR UPDATE
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);

-- Policy: Artists can delete their own cards
DROP POLICY IF EXISTS "Artists can delete own card" ON "Artist Cards";

CREATE POLICY "Artists can delete own card"
ON "Artist Cards" FOR DELETE
TO authenticated
USING (auth.uid() = user_id);