/*
  # Update RLS Policies to Use JWT Role

  1. Changes
    - Replace database role column checks with JWT role checks
    - Update is_admin_or_ambassador() function to check JWT
    - Recreate admin policies to use JWT-based role

  2. Security
    - JWT role is set via app_metadata
    - Cannot be modified by users
    - Automatically included in all requests
*/

-- Drop existing admin policies first
DROP POLICY IF EXISTS "Admins and ambassadors can read all profiles" ON profiles;
DROP POLICY IF EXISTS "Admins and ambassadors can read all artist cards" ON artist_cards;
DROP POLICY IF EXISTS "Admins and ambassadors can read all users" ON users;

-- Now drop and recreate the function
DROP FUNCTION IF EXISTS is_admin_or_ambassador();

-- Create new function that checks JWT role from app_metadata
CREATE OR REPLACE FUNCTION is_admin_or_ambassador()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN (
    COALESCE(
      current_setting('request.jwt.claims', true)::json->>'role',
      ''
    ) IN ('admin', 'ambassador')
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- Recreate admin policies using the JWT-based function

-- Profiles table
CREATE POLICY "Admins and ambassadors can read all profiles"
ON profiles FOR SELECT
TO authenticated
USING (is_admin_or_ambassador());

-- Artist_cards table
CREATE POLICY "Admins and ambassadors can read all artist cards"
ON artist_cards FOR SELECT
TO authenticated
USING (is_admin_or_ambassador());

-- Users table
CREATE POLICY "Admins and ambassadors can read all users"
ON users FOR SELECT
TO authenticated
USING (is_admin_or_ambassador());

-- Add comment explaining the JWT role system
COMMENT ON FUNCTION is_admin_or_ambassador IS 
'Checks if the current user has admin or ambassador role in their JWT app_metadata. 
Role must be set via: UPDATE auth.users SET raw_app_meta_data = raw_app_meta_data || ''{"role": "admin"}''::jsonb WHERE email = ''user@example.com'';';
