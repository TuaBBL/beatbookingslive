/*
  # Add profile_completed column to profiles table

  1. Changes
    - Add `profile_completed` boolean column to `profiles` table
    - Default to false for new profiles
    - Update existing profiles to true if they have all required fields filled

  2. Migration Details
    - Adds the column safely with IF NOT EXISTS pattern
    - Sets profile_completed = true for existing complete profiles
    - Sets profile_completed = false for incomplete profiles
*/

-- Add profile_completed column if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'profile_completed'
  ) THEN
    ALTER TABLE profiles ADD COLUMN profile_completed boolean DEFAULT false;
  END IF;
END $$;

-- Update existing profiles: mark as complete if all required fields are filled
UPDATE profiles
SET profile_completed = true
WHERE 
  full_name IS NOT NULL 
  AND full_name != '' 
  AND location IS NOT NULL 
  AND location != ''
  AND state_territory IS NOT NULL 
  AND state_territory != '';

-- Mark as incomplete if any required field is missing
UPDATE profiles
SET profile_completed = false
WHERE 
  full_name IS NULL 
  OR full_name = '' 
  OR location IS NULL 
  OR location = ''
  OR state_territory IS NULL 
  OR state_territory = '';
