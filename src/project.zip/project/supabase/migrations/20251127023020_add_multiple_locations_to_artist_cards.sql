/*
  # Add Multiple Locations Support for Artists

  1. Changes
    - Add `locations` column to store array of locations
    - Keep existing `location` column for backward compatibility
    - Artists can now specify multiple cities/regions where they perform

  2. Notes
    - The `locations` column uses text array type for storing multiple locations
    - Existing single location data is preserved in the `location` column
    - Default value is an empty array
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Artist Cards' AND column_name = 'locations'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN locations text[] DEFAULT '{}';
  END IF;
END $$;
