/*
  # Create delete_user function

  1. New Functions
    - `delete_user()` - Allows authenticated users to delete their own auth.users record
  
  2. Security
    - Function is SECURITY DEFINER to allow deletion from auth schema
    - Only allows users to delete their own account (auth.uid() check)
    - Returns void on success, raises exception on failure
  
  3. Purpose
    - Enables complete account deletion including auth.users entry
    - Used when artists want to completely remove their profile and sign up fresh
*/

CREATE OR REPLACE FUNCTION delete_user()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Only allow users to delete their own account
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  -- Delete the user from auth.users
  DELETE FROM auth.users WHERE id = auth.uid();
END;
$$;