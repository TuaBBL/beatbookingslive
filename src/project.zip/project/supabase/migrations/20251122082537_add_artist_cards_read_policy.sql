/*
  # Add public read access to Artist Cards

  1. Changes
    - Add policy to allow anyone to read artist cards
    - This enables the search functionality to work for all users
  
  2. Security
    - Read-only access for all users (public data)
    - No write permissions granted
*/

CREATE POLICY "Allow public read access to artist cards"
  ON "Artist Cards"
  FOR SELECT
  TO anon, authenticated
  USING (true);
