/*
  # Fix sync_artist_premium_status Function - Add WHERE Clause

  1. Changes
    - Fix UPDATE statement to only update rows that need updating
    - Add WHERE clause to prevent "UPDATE requires WHERE clause" error
    - Improve performance by only updating affected rows

  2. Security
    - Maintains SECURITY DEFINER for proper permissions
    - Still syncs premium status correctly
*/

-- Function to sync premium status with proper WHERE clause
CREATE OR REPLACE FUNCTION sync_artist_premium_status()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Update artist cards based on active premium subscriptions
  -- Only update rows where the status has changed
  UPDATE "Artist Cards" ac
  SET 
    is_premium = CASE 
      WHEN EXISTS (
        SELECT 1 
        FROM subscriptions s
        WHERE s.user_id = ac.user_id 
        AND s.status = 'active'
        AND s.subscription_type = 'premium'
      ) THEN true
      ELSE false
    END,
    subscription_type = COALESCE(
      (SELECT s.subscription_type 
       FROM subscriptions s
       WHERE s.user_id = ac.user_id 
       AND s.status = 'active' 
       ORDER BY s.created_at DESC 
       LIMIT 1),
      'standard'
    )
  WHERE ac.user_id IS NOT NULL;
END;
$$;
