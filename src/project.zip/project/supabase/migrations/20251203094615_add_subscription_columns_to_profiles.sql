/*
  # Add subscription columns to profiles table

  1. Changes
    - Add `subscription_tier` column (text) to profiles table
    - Add `is_free_forever` column (boolean) to profiles table
    - Add `subscription_active` column (boolean) to profiles table
  
  2. Purpose
    - Track subscription information directly in profiles table
    - Support free forever users with premium features
    - Enable quick subscription status checks
*/

-- Add subscription columns to profiles table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'subscription_tier'
  ) THEN
    ALTER TABLE profiles ADD COLUMN subscription_tier text DEFAULT 'free';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'is_free_forever'
  ) THEN
    ALTER TABLE profiles ADD COLUMN is_free_forever boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'subscription_active'
  ) THEN
    ALTER TABLE profiles ADD COLUMN subscription_active boolean DEFAULT false;
  END IF;
END $$;