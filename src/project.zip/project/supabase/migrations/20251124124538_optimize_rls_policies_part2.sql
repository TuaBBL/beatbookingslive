/*
  # Optimize RLS Policies for Performance - Part 2

  1. Changes
    - Replace all `auth.uid()` calls with `(select auth.uid())` in RLS policies
    - This prevents re-evaluation of auth function for each row
    - Significantly improves query performance at scale

  2. Tables Updated
    - subscriptions
    - stripe_customers
    - stripe_subscriptions (via customer_id join)
    - stripe_orders (via customer_id join)
    - bookings

  3. Security
    - Maintains same security guarantees
    - Optimizes policy evaluation by calling auth functions once per query
*/

-- Subscriptions policies
DROP POLICY IF EXISTS "Users can read own subscriptions" ON subscriptions;
CREATE POLICY "Users can read own subscriptions"
  ON subscriptions FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can insert own subscriptions" ON subscriptions;
CREATE POLICY "Users can insert own subscriptions"
  ON subscriptions FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own subscriptions" ON subscriptions;
CREATE POLICY "Users can update own subscriptions"
  ON subscriptions FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

-- Stripe customers policy
DROP POLICY IF EXISTS "Users can view their own customer data" ON stripe_customers;
CREATE POLICY "Users can view their own customer data"
  ON stripe_customers FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

-- Stripe subscriptions policy (uses customer_id join)
DROP POLICY IF EXISTS "Users can view their own subscription data" ON stripe_subscriptions;
CREATE POLICY "Users can view their own subscription data"
  ON stripe_subscriptions FOR SELECT
  TO authenticated
  USING (
    customer_id IN (
      SELECT customer_id FROM stripe_customers WHERE user_id = (select auth.uid())
    )
  );

-- Stripe orders policy (uses customer_id join)
DROP POLICY IF EXISTS "Users can view their own order data" ON stripe_orders;
CREATE POLICY "Users can view their own order data"
  ON stripe_orders FOR SELECT
  TO authenticated
  USING (
    customer_id IN (
      SELECT customer_id FROM stripe_customers WHERE user_id = (select auth.uid())
    )
  );

-- Bookings policies
DROP POLICY IF EXISTS "Users can create own bookings" ON bookings;
CREATE POLICY "Users can create own bookings"
  ON bookings FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can view own bookings" ON bookings;
CREATE POLICY "Users can view own bookings"
  ON bookings FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Artists can view bookings for their cards" ON bookings;
CREATE POLICY "Artists can view bookings for their cards"
  ON bookings FOR SELECT
  TO authenticated
  USING (
    artist_id IN (
      SELECT id FROM "Artist Cards" WHERE user_id = (select auth.uid())
    )
  );

DROP POLICY IF EXISTS "Users can update own bookings" ON bookings;
CREATE POLICY "Users can update own bookings"
  ON bookings FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Artists can update bookings for their cards" ON bookings;
CREATE POLICY "Artists can update bookings for their cards"
  ON bookings FOR UPDATE
  TO authenticated
  USING (
    artist_id IN (
      SELECT id FROM "Artist Cards" WHERE user_id = (select auth.uid())
    )
  )
  WITH CHECK (
    artist_id IN (
      SELECT id FROM "Artist Cards" WHERE user_id = (select auth.uid())
    )
  );

DROP POLICY IF EXISTS "Users can delete own bookings" ON bookings;
CREATE POLICY "Users can delete own bookings"
  ON bookings FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Artists can delete bookings for their cards" ON bookings;
CREATE POLICY "Artists can delete bookings for their cards"
  ON bookings FOR DELETE
  TO authenticated
  USING (
    artist_id IN (
      SELECT id FROM "Artist Cards" WHERE user_id = (select auth.uid())
    )
  );