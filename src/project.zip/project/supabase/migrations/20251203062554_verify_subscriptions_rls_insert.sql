/*
  # Verify Subscriptions RLS Insert Policy

  1. Purpose
    - Ensure authenticated users can insert their own subscriptions
    - Verify RLS policy allows user_id = auth.uid() for INSERT operations

  2. Changes
    - Drop and recreate INSERT policy to ensure it's correctly configured
    - Policy allows authenticated users to insert where user_id matches their auth.uid()

  3. Security
    - Users can ONLY insert subscriptions for themselves
    - user_id must match authenticated user's ID
*/

-- Drop existing insert policy
DROP POLICY IF EXISTS "Users can insert own subscriptions" ON subscriptions;

-- Recreate insert policy with explicit security check
CREATE POLICY "Users can insert own subscriptions"
  ON subscriptions FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());
