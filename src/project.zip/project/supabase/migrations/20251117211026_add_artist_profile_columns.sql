/*
  # Add Artist Profile Columns

  1. Changes to Tables
    - `Artist Cards`
      - Add `name` (text, not null) - Artist/Band/DJ name
      - Add `about` (text) - Biography or description
      - Add `location` (text) - Geographic location
      - Add `category` (text) - Type: artist, band, or DJ
      - Add `image_url` (text) - URL to stored image in Supabase Storage
      - Add `socials` (jsonb, default '{}') - Social media links as JSON object
  
  2. Notes
    - Using `image_url` to store the path/URL from Supabase Storage
    - Social links stored as JSONB for flexibility (e.g., {"instagram": "url", "twitter": "url"})
    - All new columns allow NULL except `name` for data safety during migration
    - Existing rows will need to be updated with appropriate values
*/

-- Add new columns to Artist Cards table
DO $$
BEGIN
  -- Add name column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' 
    AND table_name = 'Artist Cards' 
    AND column_name = 'name'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN name text NOT NULL DEFAULT '';
  END IF;

  -- Add about column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' 
    AND table_name = 'Artist Cards' 
    AND column_name = 'about'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN about text DEFAULT '';
  END IF;

  -- Add location column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' 
    AND table_name = 'Artist Cards' 
    AND column_name = 'location'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN location text DEFAULT '';
  END IF;

  -- Add category column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' 
    AND table_name = 'Artist Cards' 
    AND column_name = 'category'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN category text DEFAULT '';
  END IF;

  -- Add image_url column for Supabase Storage
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' 
    AND table_name = 'Artist Cards' 
    AND column_name = 'image_url'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN image_url text DEFAULT '';
  END IF;

  -- Add socials column as JSONB
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' 
    AND table_name = 'Artist Cards' 
    AND column_name = 'socials'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN socials jsonb DEFAULT '{}'::jsonb;
  END IF;
END $$;