/*
  # Recreate Profiles Table with NULL Defaults and Admin Access

  1. Drop and Recreate
    - Drop existing profiles table (if exists)
    - Create new profiles table with proper NULL handling
    - All text fields default to NULL (not empty strings)

  2. New Tables
    - `profiles`
      - `id` (uuid, primary key) - References auth.users.id
      - `full_name` (text, nullable) - User's full name
      - `location` (text, nullable) - User's city/location
      - `state_territory` (text, nullable) - Australian state/territory
      - `phone_number` (text, nullable) - User's phone number
      - `profile_image_url` (text, nullable) - URL to profile image
      - `created_at` (timestamptz) - Timestamp when profile was created
      - `updated_at` (timestamptz) - Timestamp when profile was last updated

  3. Security
    - Enable RLS on `profiles` table
    - Users can read their own profile
    - Users can insert their own profile
    - Users can update their own profile
    - Admins can read ALL profiles (role = 'admin' in JWT)

  4. Important Notes
    - NULL values force users to complete their profile
    - Frontend checks for NULL to determine if profile is complete
    - Admin access allows support/management to view all user profiles
*/

-- Drop existing profiles table if it exists
DROP TABLE IF EXISTS profiles CASCADE;

-- Create profiles table with NULL defaults
CREATE TABLE profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text DEFAULT NULL,
  location text DEFAULT NULL,
  state_territory text DEFAULT NULL,
  phone_number text DEFAULT NULL,
  profile_image_url text DEFAULT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

-- RLS Policy: Users can read their own profile
CREATE POLICY "Users can read own profile"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

-- RLS Policy: Users can insert their own profile
CREATE POLICY "Users can insert own profile"
  ON profiles
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- RLS Policy: Users can update their own profile
CREATE POLICY "Users can update own profile"
  ON profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

-- RLS Policy: Admins can read all profiles
CREATE POLICY "Admins can read all profiles"
  ON profiles
  FOR SELECT
  TO authenticated
  USING (
    (auth.jwt() ->> 'role'::text) = 'admin'
  );

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_profiles_id ON profiles(id);

-- Create trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_profiles_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS profiles_updated_at ON profiles;

CREATE TRIGGER profiles_updated_at
  BEFORE UPDATE ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION update_profiles_updated_at();