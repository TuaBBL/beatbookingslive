/*
  # Fix Admin Messages RLS Policies to Use JWT Role

  1. Changes
    - Update RLS policies to check JWT app_metadata.role instead of users.role
    - Align with JWT admin role system setup
    - Ensure admins can send and manage messages using JWT-based auth

  2. Security
    - Only users with role='admin' in JWT app_metadata can send messages
    - Recipients can view their own messages
    - Admins can view and delete all messages
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Admins can send messages" ON admin_messages;
DROP POLICY IF EXISTS "Admins can view all messages" ON admin_messages;
DROP POLICY IF EXISTS "Recipients can view their messages" ON admin_messages;
DROP POLICY IF EXISTS "Recipients can update their messages" ON admin_messages;
DROP POLICY IF EXISTS "Admins can delete messages" ON admin_messages;

-- Create updated policies using JWT role check

-- Admins can send messages (check JWT app_metadata.role)
CREATE POLICY "Admins can send messages"
  ON admin_messages
  FOR INSERT
  TO authenticated
  WITH CHECK (
    (auth.jwt()->>'role')::text = 'admin'
  );

-- Admins can view all messages (check JWT app_metadata.role)
CREATE POLICY "Admins can view all messages"
  ON admin_messages
  FOR SELECT
  TO authenticated
  USING (
    (auth.jwt()->>'role')::text = 'admin'
  );

-- Recipients can view messages sent to them
CREATE POLICY "Recipients can view their messages"
  ON admin_messages
  FOR SELECT
  TO authenticated
  USING (
    recipient_email = (SELECT email FROM auth.users WHERE id = auth.uid())
    OR recipient_id = auth.uid()
  );

-- Recipients can mark messages as read
CREATE POLICY "Recipients can update their messages"
  ON admin_messages
  FOR UPDATE
  TO authenticated
  USING (
    recipient_email = (SELECT email FROM auth.users WHERE id = auth.uid())
    OR recipient_id = auth.uid()
  )
  WITH CHECK (
    recipient_email = (SELECT email FROM auth.users WHERE id = auth.uid())
    OR recipient_id = auth.uid()
  );

-- Admins can delete messages (check JWT app_metadata.role)
CREATE POLICY "Admins can delete messages"
  ON admin_messages
  FOR DELETE
  TO authenticated
  USING (
    (auth.jwt()->>'role')::text = 'admin'
  );
