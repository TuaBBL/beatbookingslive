/*
  # Fix user_favorites artist_id data type

  1. Changes
    - Change user_favorites.artist_id from integer to bigint to match Artist Cards.id
    - This fixes the foreign key relationship and allows proper joins
  
  2. Reason
    - Artist Cards.id is bigint (int8)
    - user_favorites.artist_id was integer (int4)
    - This mismatch causes Supabase PostgREST to fail when doing foreign key joins
*/

-- Change artist_id column type from integer to bigint
ALTER TABLE user_favorites 
  ALTER COLUMN artist_id TYPE bigint;
