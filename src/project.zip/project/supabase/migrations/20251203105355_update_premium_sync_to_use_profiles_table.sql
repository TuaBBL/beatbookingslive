/*
  # Update Premium Sync to Use Profiles Table

  1. Changes
    - Update sync_artist_premium_status() to read from profiles table instead of subscriptions
    - Check is_free_forever, subscription_tier from profiles
    - Set is_premium=true for users with:
      - is_free_forever = true
      - subscription_tier = 'premium'
    - Update trigger to watch profiles table changes

  2. Purpose
    - Sync artist premium status with new profiles-based subscription system
    - Ensure free forever users get premium features
    - Maintain backward compatibility with existing premium users

  3. Security
    - Maintain SECURITY DEFINER for system-level updates
*/

-- Update the sync function to use profiles table
CREATE OR REPLACE FUNCTION sync_artist_premium_status()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Update artist cards based on profiles subscription data
  UPDATE artist_cards ac
  SET 
    is_premium = CASE 
      WHEN EXISTS (
        SELECT 1 
        FROM profiles p
        WHERE p.id = ac.user_id 
        AND (
          p.is_free_forever = true 
          OR p.subscription_tier = 'premium'
        )
      ) THEN true
      ELSE false
    END,
    subscription_type = COALESCE(
      (SELECT 
        CASE 
          WHEN p.is_free_forever = true THEN 'premium'
          WHEN p.subscription_tier = 'premium' THEN 'premium'
          WHEN p.subscription_tier = 'standard' THEN 'standard'
          ELSE 'free'
        END
       FROM profiles p
       WHERE p.id = ac.user_id
       LIMIT 1),
      'standard'
    ),
    premium_start_date = CASE
      WHEN EXISTS (
        SELECT 1 
        FROM profiles p
        WHERE p.id = ac.user_id 
        AND (
          p.is_free_forever = true 
          OR p.subscription_tier = 'premium'
        )
      ) THEN COALESCE(
        ac.premium_start_date,
        now()
      )
      ELSE ac.premium_start_date
    END,
    premium_end_date = CASE
      WHEN EXISTS (
        SELECT 1 
        FROM profiles p
        WHERE p.id = ac.user_id 
        AND p.is_free_forever = true
      ) THEN NULL -- Free forever has no end date
      WHEN EXISTS (
        SELECT 1 
        FROM profiles p
        WHERE p.id = ac.user_id 
        AND p.subscription_tier = 'premium'
        AND p.subscription_active = true
      ) THEN NULL -- Active subscriptions managed elsewhere
      ELSE ac.premium_end_date
    END,
    max_media_items = CASE
      WHEN EXISTS (
        SELECT 1 
        FROM profiles p
        WHERE p.id = ac.user_id 
        AND (
          p.is_free_forever = true 
          OR p.subscription_tier = 'premium'
        )
      ) THEN NULL -- Unlimited for premium users
      ELSE 10
    END;
  
  -- Assign featured priority to premium artists
  PERFORM assign_featured_priority();
END;
$$;

-- Update trigger to watch profiles table instead of subscriptions
DROP TRIGGER IF EXISTS subscriptions_sync_premium ON subscriptions;
DROP TRIGGER IF EXISTS profiles_sync_premium ON profiles;

CREATE OR REPLACE FUNCTION trigger_sync_premium_status()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  PERFORM sync_artist_premium_status();
  RETURN NEW;
END;
$$;

CREATE TRIGGER profiles_sync_premium
AFTER INSERT OR UPDATE OF is_free_forever, subscription_tier, subscription_active ON profiles
FOR EACH STATEMENT
EXECUTE FUNCTION trigger_sync_premium_status();

-- Run sync now to update all existing artists
SELECT sync_artist_premium_status();
