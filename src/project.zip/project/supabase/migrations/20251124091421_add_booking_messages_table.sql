/*
  # Add booking messages table for user-artist communication

  1. New Tables
    - `booking_messages`
      - `id` (uuid, primary key)
      - `booking_id` (uuid, foreign key to bookings)
      - `sender_id` (uuid, foreign key to users)
      - `message` (text)
      - `created_at` (timestamp)
  
  2. Security
    - Enable RLS on `booking_messages` table
    - Add policies for users and artists to read messages for their bookings
    - Add policies for users and artists to send messages for their bookings
*/

CREATE TABLE IF NOT EXISTS booking_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  booking_id uuid NOT NULL REFERENCES bookings(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  message text NOT NULL,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE booking_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can read messages for their bookings"
  ON booking_messages
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM bookings
      WHERE bookings.id = booking_messages.booking_id
      AND (bookings.user_id = auth.uid() OR bookings.artist_id IN (
        SELECT artist_card_id FROM artist_profiles WHERE user_id = auth.uid()
      ))
    )
  );

CREATE POLICY "Users can send messages for their bookings"
  ON booking_messages
  FOR INSERT
  TO authenticated
  WITH CHECK (
    sender_id = auth.uid()
    AND EXISTS (
      SELECT 1 FROM bookings
      WHERE bookings.id = booking_messages.booking_id
      AND (bookings.user_id = auth.uid() OR bookings.artist_id IN (
        SELECT artist_card_id FROM artist_profiles WHERE user_id = auth.uid()
      ))
    )
  );