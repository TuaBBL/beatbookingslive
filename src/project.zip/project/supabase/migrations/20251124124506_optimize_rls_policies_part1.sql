/*
  # Optimize RLS Policies for Performance - Part 1

  1. Changes
    - Replace all `auth.uid()` calls with `(select auth.uid())` in RLS policies
    - This prevents re-evaluation of auth function for each row
    - Significantly improves query performance at scale

  2. Tables Updated
    - reviews
    - artist_profiles
    - users
    - Artist Cards

  3. Security
    - Maintains same security guarantees
    - Optimizes policy evaluation by calling auth functions once per query
*/

-- Reviews table policies
DROP POLICY IF EXISTS "Authenticated users can create reviews" ON reviews;
CREATE POLICY "Authenticated users can create reviews"
  ON reviews FOR INSERT
  TO authenticated
  WITH CHECK ((select auth.uid()) IS NOT NULL);

DROP POLICY IF EXISTS "Users can update own reviews" ON reviews;
CREATE POLICY "Users can update own reviews"
  ON reviews FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can delete own reviews" ON reviews;
CREATE POLICY "Users can delete own reviews"
  ON reviews FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));

-- Artist profiles policies
DROP POLICY IF EXISTS "Artists can read own profile" ON artist_profiles;
CREATE POLICY "Artists can read own profile"
  ON artist_profiles FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Artists can create own profile" ON artist_profiles;
CREATE POLICY "Artists can create own profile"
  ON artist_profiles FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Artists can update own profile" ON artist_profiles;
CREATE POLICY "Artists can update own profile"
  ON artist_profiles FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

-- Users table policies
DROP POLICY IF EXISTS "Users can view own profile" ON users;
CREATE POLICY "Users can view own profile"
  ON users FOR SELECT
  TO authenticated
  USING (id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own profile" ON users;
CREATE POLICY "Users can update own profile"
  ON users FOR UPDATE
  TO authenticated
  USING (id = (select auth.uid()))
  WITH CHECK (id = (select auth.uid()));

-- Artist Cards policies
DROP POLICY IF EXISTS "Artists can create own card" ON "Artist Cards";
CREATE POLICY "Artists can create own card"
  ON "Artist Cards" FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Artists can update own card" ON "Artist Cards";
CREATE POLICY "Artists can update own card"
  ON "Artist Cards" FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Artists can delete own card" ON "Artist Cards";
CREATE POLICY "Artists can delete own card"
  ON "Artist Cards" FOR DELETE
  TO authenticated
  USING (user_id = (select auth.uid()));