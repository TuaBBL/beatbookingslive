/*
  # Create trigger for message notifications

  1. New Functions
    - `create_message_notification()` - Creates a notification when a message is sent

  2. Trigger
    - Fires after INSERT on booking_messages
    - Creates notification for the recipient (not the sender)
    - Includes booking details and sender information

  3. Logic
    - Determines recipient by checking who is NOT the sender
    - For each booking, either the artist or the user can receive notifications
*/

CREATE OR REPLACE FUNCTION create_message_notification()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  booking_record RECORD;
  recipient_id uuid;
  sender_name text;
  artist_name text;
BEGIN
  -- Get booking details
  SELECT b.user_id, b.artist_id, b.user_name, ac.name as artist_name
  INTO booking_record
  FROM bookings b
  LEFT JOIN "Artist Cards" ac ON ac.id = b.artist_id
  WHERE b.id = NEW.booking_id;

  -- Determine recipient (opposite of sender)
  IF NEW.sender_id = booking_record.user_id THEN
    -- Message from user to artist, notify the artist
    SELECT u.id INTO recipient_id
    FROM "Artist Cards" ac
    JOIN users u ON u.id = ac.user_id
    WHERE ac.id = booking_record.artist_id;
    
    sender_name := booking_record.user_name;
    artist_name := booking_record.artist_name;
  ELSE
    -- Message from artist to user, notify the user
    recipient_id := booking_record.user_id;
    sender_name := booking_record.artist_name;
  END IF;

  -- Only create notification if we found a recipient
  IF recipient_id IS NOT NULL THEN
    INSERT INTO notifications (user_id, type, title, message, related_id)
    VALUES (
      recipient_id,
      'new_message',
      'New Message',
      sender_name || ' sent you a message about a booking',
      NEW.booking_id
    );
  END IF;

  RETURN NEW;
END;
$$;

-- Create trigger
DROP TRIGGER IF EXISTS on_booking_message_created ON booking_messages;
CREATE TRIGGER on_booking_message_created
  AFTER INSERT ON booking_messages
  FOR EACH ROW
  EXECUTE FUNCTION create_message_notification();