/*
  # Delete Orphaned Auth Users
  
  This migration removes users from auth.users who don't have either:
  - A regular user profile in the profiles table
  - An artist profile in the artist_profiles table
  
  ## Orphaned Users Found
  - sheldonparke17@hotmail.com (id: 19dacb79-160d-42b5-b921-ce1fad2ce49e)
  - kyahn.solos@gmail.com (id: 588b11d9-19cb-46ff-bb99-35ccbe85433d)
  - kiamaiatuaa@gmail.com (id: 4cde5feb-4424-4b0b-87da-b6dbff8cb31c)
  
  These users have:
  - No profile entries
  - No artist profile entries
  - No bookings
  - No notifications
  - No other dependencies
  
  ## Safety
  - All users verified to have zero dependencies
  - Safe to delete without cascading issues
*/

-- Delete orphaned users from auth.users
DELETE FROM auth.users
WHERE id IN (
  '19dacb79-160d-42b5-b921-ce1fad2ce49e',
  '588b11d9-19cb-46ff-bb99-35ccbe85433d',
  '4cde5feb-4424-4b0b-87da-b6dbff8cb31c'
)
AND id NOT IN (
  SELECT id FROM profiles
  UNION
  SELECT user_id FROM artist_profiles
);
