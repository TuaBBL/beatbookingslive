/*
  # Add cost_type field and make cost optional

  1. Changes
    - Add `cost_type` column to Artist Cards table (values: 'per_hour', 'per_event', or NULL)
    - Modify `cost` column to allow NULL values
    - Set default cost to NULL instead of 0
  
  2. Purpose
    - Allow artists to choose whether they charge per hour or per event
    - Make cost field optional during profile creation
    - Provide flexibility for different pricing models
*/

-- Add cost_type column
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Artist Cards' AND column_name = 'cost_type'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN cost_type text;
  END IF;
END $$;

-- Add check constraint for cost_type values
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.constraint_column_usage
    WHERE constraint_name = 'valid_cost_type'
  ) THEN
    ALTER TABLE "Artist Cards"
    ADD CONSTRAINT valid_cost_type
    CHECK (cost_type IS NULL OR cost_type IN ('per_hour', 'per_event'));
  END IF;
END $$;

-- Modify cost column to allow NULL and change default
ALTER TABLE "Artist Cards" ALTER COLUMN cost DROP DEFAULT;
ALTER TABLE "Artist Cards" ALTER COLUMN cost DROP NOT NULL;
ALTER TABLE "Artist Cards" ALTER COLUMN cost SET DEFAULT NULL;