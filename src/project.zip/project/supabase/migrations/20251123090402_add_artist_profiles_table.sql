/*
  # Add Artist Profiles Table

  1. New Tables
    - `artist_profiles`
      - `id` (uuid, primary key) - Unique identifier for each artist profile
      - `user_id` (uuid, foreign key) - References the auth user
      - `artist_card_id` (bigint, foreign key) - References the Artist Cards table
      - `email` (text) - Artist's email
      - `phone` (text) - Artist's phone number
      - `profile_completed` (boolean) - Whether the artist has completed their profile
      - `created_at` (timestamptz) - When the profile was created
      - `updated_at` (timestamptz) - When the profile was last updated

  2. Security
    - Enable RLS on `artist_profiles` table
    - Add policy for artists to read their own profile
    - Add policy for artists to create their own profile
    - Add policy for artists to update their own profile

  3. Constraints
    - Unique constraint on user_id to ensure one profile per user
    - Unique constraint on artist_card_id to ensure one profile per artist card

  4. Indexes
    - Index on user_id for faster lookups
    - Index on artist_card_id for faster lookups
*/

CREATE TABLE IF NOT EXISTS artist_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  artist_card_id bigint REFERENCES "Artist Cards"(id) ON DELETE SET NULL,
  email text NOT NULL DEFAULT '',
  phone text DEFAULT '',
  profile_completed boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(user_id),
  UNIQUE(artist_card_id)
);

ALTER TABLE artist_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Artists can read own profile"
  ON artist_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Artists can create own profile"
  ON artist_profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Artists can update own profile"
  ON artist_profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS artist_profiles_user_id_idx ON artist_profiles(user_id);
CREATE INDEX IF NOT EXISTS artist_profiles_artist_card_id_idx ON artist_profiles(artist_card_id);