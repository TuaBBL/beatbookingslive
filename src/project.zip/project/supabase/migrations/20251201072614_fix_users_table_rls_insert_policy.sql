/*
  # Fix Users Table RLS Policies

  1. Changes
    - Add INSERT policy for users table to allow authenticated users to insert their own record
    - Add conflict handling for the trigger that auto-creates user records
    
  2. Security
    - Users can only insert a record with their own auth.uid() as the id
    - This allows the signup form to properly create/update user records with profile data
*/

-- Add INSERT policy for users table
CREATE POLICY "Users can insert own profile during signup"
ON users FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = id);

-- Grant INSERT on users table to authenticated users (if not already granted)
GRANT INSERT ON users TO authenticated;
