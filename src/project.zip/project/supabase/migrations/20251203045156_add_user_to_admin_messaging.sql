/*
  # Add User to Admin Messaging Support

  1. Changes to Tables
    - `admin_messages`
      - Add `sender_id` (uuid) - Who sent the message (could be user or admin)
      - Add `is_from_admin` (boolean) - True if from admin, false if from user
      - Make `admin_id` nullable (for user-sent messages)
      - Add `parent_message_id` (uuid) - For threading replies
      - Add `status` (text) - 'unread', 'read', 'replied', 'closed'

  2. New RLS Policies
    - Users can send messages to admin
    - Users can view messages they sent
    - Admins can reply to user messages

  3. Purpose
    - Enable bidirectional communication between users and admin
    - Support message threading and replies
    - Track message status
*/

-- Add new columns
ALTER TABLE admin_messages ADD COLUMN IF NOT EXISTS sender_id uuid REFERENCES auth.users(id) ON DELETE CASCADE;
ALTER TABLE admin_messages ADD COLUMN IF NOT EXISTS is_from_admin boolean DEFAULT true NOT NULL;
ALTER TABLE admin_messages ADD COLUMN IF NOT EXISTS parent_message_id uuid REFERENCES admin_messages(id) ON DELETE SET NULL;
ALTER TABLE admin_messages ADD COLUMN IF NOT EXISTS status text DEFAULT 'unread' CHECK (status IN ('unread', 'read', 'replied', 'closed'));

-- Make admin_id nullable for user-sent messages
ALTER TABLE admin_messages ALTER COLUMN admin_id DROP NOT NULL;

-- Backfill sender_id from admin_id for existing messages
UPDATE admin_messages SET sender_id = admin_id WHERE sender_id IS NULL AND admin_id IS NOT NULL;

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_admin_messages_sender_id ON admin_messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_admin_messages_is_from_admin ON admin_messages(is_from_admin);
CREATE INDEX IF NOT EXISTS idx_admin_messages_parent_id ON admin_messages(parent_message_id);
CREATE INDEX IF NOT EXISTS idx_admin_messages_status ON admin_messages(status);

-- Policy: Users can send messages to admin
DROP POLICY IF EXISTS "Users can send messages to admin" ON admin_messages;
CREATE POLICY "Users can send messages to admin"
  ON admin_messages
  FOR INSERT
  TO authenticated
  WITH CHECK (
    sender_id = auth.uid() AND is_from_admin = false
  );

-- Policy: Users can view messages they sent or received
DROP POLICY IF EXISTS "Users can view their own messages" ON admin_messages;
CREATE POLICY "Users can view their own messages"
  ON admin_messages
  FOR SELECT
  TO authenticated
  USING (
    sender_id = auth.uid()
    OR recipient_id = auth.uid()
    OR recipient_email = (auth.jwt()->>'email')::text
  );

-- Policy: Admins can view all messages
DROP POLICY IF EXISTS "Admins can view all messages" ON admin_messages;
CREATE POLICY "Admins can view all messages"
  ON admin_messages
  FOR SELECT
  TO authenticated
  USING (
    (auth.jwt()->>'role')::text = 'admin'
  );

-- Policy: Admins can send messages (including replies)
DROP POLICY IF EXISTS "Admins can send messages" ON admin_messages;
CREATE POLICY "Admins can send messages"
  ON admin_messages
  FOR INSERT
  TO authenticated
  WITH CHECK (
    (auth.jwt()->>'role')::text = 'admin' AND is_from_admin = true
  );

-- Policy: Admins can update message status
DROP POLICY IF EXISTS "Admins can update messages" ON admin_messages;
CREATE POLICY "Admins can update messages"
  ON admin_messages
  FOR UPDATE
  TO authenticated
  USING (
    (auth.jwt()->>'role')::text = 'admin'
  )
  WITH CHECK (
    (auth.jwt()->>'role')::text = 'admin'
  );

-- Policy: Users can update their own message status
DROP POLICY IF EXISTS "Users can update their message status" ON admin_messages;
CREATE POLICY "Users can update their message status"
  ON admin_messages
  FOR UPDATE
  TO authenticated
  USING (
    sender_id = auth.uid() OR recipient_id = auth.uid()
  )
  WITH CHECK (
    sender_id = auth.uid() OR recipient_id = auth.uid()
  );

-- Policy: Admins can delete messages
DROP POLICY IF EXISTS "Admins can delete messages" ON admin_messages;
CREATE POLICY "Admins can delete messages"
  ON admin_messages
  FOR DELETE
  TO authenticated
  USING (
    (auth.jwt()->>'role')::text = 'admin'
  );

-- Update notification function to work for both directions
CREATE OR REPLACE FUNCTION notify_admin_message()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  -- If message is from user to admin, notify admins (future enhancement)
  -- If message is from admin to user, notify the user
  IF NEW.is_from_admin = true AND NEW.recipient_id IS NOT NULL THEN
    INSERT INTO notifications (user_id, message, link)
    VALUES (
      NEW.recipient_id,
      'You have a new message from admin: ' || NEW.subject,
      '/admin-messages'
    );
  END IF;
  
  RETURN NEW;
END;
$$;
