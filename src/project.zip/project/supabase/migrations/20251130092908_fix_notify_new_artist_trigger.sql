/*
  # Fix notify_new_artist trigger to explicitly set NULL user_id

  1. Function Update
    - Explicitly set user_id to NULL for system-wide notifications
    - Add comment explaining this is intentional for system notifications
    - Makes it clear these are platform-wide announcements, not user-specific
  
  2. Why This Change
    - Previous version omitted user_id, causing constraint violation
    - Now that user_id is nullable, we explicitly set it to NULL
    - This creates a notification visible to all authenticated users
  
  3. Behavior
    - Fires when a new artist card is created
    - Creates one system notification (not one per user)
    - All authenticated users can see the notification via RLS policy
*/

CREATE OR REPLACE FUNCTION notify_new_artist()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Create a system-wide notification (user_id = NULL means visible to all users)
  INSERT INTO notifications (user_id, type, title, message)
  VALUES (
    NULL,  -- System notification visible to all authenticated users
    'new_artist',
    'New Artist Added!',
    'A new artist has joined the platform: ' || COALESCE(NEW.stage_name, NEW.name)
  );
  RETURN NEW;
END;
$$;

-- Trigger remains the same, no need to recreate it
