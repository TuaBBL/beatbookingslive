/*
  # Add Premium Artist Features Schema

  1. Changes to Tables
    - `Artist Cards`
      - Add `is_verified` (boolean) - Premium artists can be verified
      - Add `profile_theme` (text) - Custom profile theme (green, blue, purple, gold)
      - Add `max_media_items` (integer) - Maximum media items allowed (null = unlimited for premium)
    
    - `booking_messages`
      - Add `is_priority` (boolean) - Flag for premium artist messages

  2. New Tables
    - `artist_analytics_detailed` - Enhanced analytics for premium artists
      - `id` (uuid, primary key)
      - `artist_id` (bigint, foreign key)
      - `date` (date) - Daily tracking
      - `profile_views` (integer)
      - `unique_visitors` (integer)
      - `social_clicks` (integer)
      - `portfolio_views` (integer)
      - `booking_button_clicks` (integer)
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  3. Purpose
    - Enable verified badges for premium artists
    - Allow custom profile themes
    - Track unlimited media for premium users
    - Enhanced analytics tracking
    - Priority message flagging

  4. Security
    - Maintain existing RLS policies
    - Add policies for new tables
*/

-- Add new columns to Artist Cards
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Artist Cards' AND column_name = 'is_verified'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN is_verified boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Artist Cards' AND column_name = 'profile_theme'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN profile_theme text DEFAULT 'red';
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Artist Cards' AND column_name = 'max_media_items'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN max_media_items integer DEFAULT 10;
  END IF;
END $$;

-- Add priority flag to booking_messages
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'booking_messages' AND column_name = 'is_priority'
  ) THEN
    ALTER TABLE booking_messages ADD COLUMN is_priority boolean DEFAULT false;
  END IF;
END $$;

-- Create detailed analytics table for premium artists
CREATE TABLE IF NOT EXISTS artist_analytics_detailed (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  artist_id bigint NOT NULL REFERENCES "Artist Cards"(id) ON DELETE CASCADE,
  date date NOT NULL,
  profile_views integer DEFAULT 0,
  unique_visitors integer DEFAULT 0,
  social_clicks integer DEFAULT 0,
  portfolio_views integer DEFAULT 0,
  booking_button_clicks integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(artist_id, date)
);

-- Enable RLS on new table
ALTER TABLE artist_analytics_detailed ENABLE ROW LEVEL SECURITY;

-- RLS Policies for artist_analytics_detailed
CREATE POLICY "Artists can view own detailed analytics"
  ON artist_analytics_detailed
  FOR SELECT
  TO authenticated
  USING (
    artist_id IN (
      SELECT id FROM "Artist Cards" WHERE user_id = auth.uid()
    )
  );

CREATE POLICY "System can insert detailed analytics"
  ON artist_analytics_detailed
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "System can update detailed analytics"
  ON artist_analytics_detailed
  FOR UPDATE
  TO authenticated
  USING (true);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_artist_cards_verified ON "Artist Cards"(is_verified) WHERE is_verified = true;
CREATE INDEX IF NOT EXISTS idx_artist_cards_theme ON "Artist Cards"(profile_theme);
CREATE INDEX IF NOT EXISTS idx_booking_messages_priority ON booking_messages(is_priority) WHERE is_priority = true;
CREATE INDEX IF NOT EXISTS idx_analytics_detailed_artist_date ON artist_analytics_detailed(artist_id, date);

-- Function to increment detailed analytics
CREATE OR REPLACE FUNCTION increment_analytics_metric(
  p_artist_id bigint,
  p_metric text
)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_date date;
BEGIN
  v_date := CURRENT_DATE;
  
  CASE p_metric
    WHEN 'profile_views' THEN
      INSERT INTO artist_analytics_detailed (artist_id, date, profile_views)
      VALUES (p_artist_id, v_date, 1)
      ON CONFLICT (artist_id, date)
      DO UPDATE SET 
        profile_views = artist_analytics_detailed.profile_views + 1,
        updated_at = now();
    
    WHEN 'social_clicks' THEN
      INSERT INTO artist_analytics_detailed (artist_id, date, social_clicks)
      VALUES (p_artist_id, v_date, 1)
      ON CONFLICT (artist_id, date)
      DO UPDATE SET 
        social_clicks = artist_analytics_detailed.social_clicks + 1,
        updated_at = now();
    
    WHEN 'portfolio_views' THEN
      INSERT INTO artist_analytics_detailed (artist_id, date, portfolio_views)
      VALUES (p_artist_id, v_date, 1)
      ON CONFLICT (artist_id, date)
      DO UPDATE SET 
        portfolio_views = artist_analytics_detailed.portfolio_views + 1,
        updated_at = now();
    
    WHEN 'booking_button_clicks' THEN
      INSERT INTO artist_analytics_detailed (artist_id, date, booking_button_clicks)
      VALUES (p_artist_id, v_date, 1)
      ON CONFLICT (artist_id, date)
      DO UPDATE SET 
        booking_button_clicks = artist_analytics_detailed.booking_button_clicks + 1,
        updated_at = now();
  END CASE;
END;
$$;

-- Update premium artists to have unlimited media
UPDATE "Artist Cards" 
SET max_media_items = NULL 
WHERE is_premium = true;

-- Add constraint check for valid themes
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'valid_profile_theme'
  ) THEN
    ALTER TABLE "Artist Cards" 
    ADD CONSTRAINT valid_profile_theme 
    CHECK (profile_theme IN ('red', 'green', 'blue', 'purple', 'gold', 'cyan'));
  END IF;
END $$;