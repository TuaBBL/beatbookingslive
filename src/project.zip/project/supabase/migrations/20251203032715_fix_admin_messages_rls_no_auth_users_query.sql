/*
  # Fix Admin Messages RLS - Remove auth.users Query

  1. Issue
    - Policies are querying auth.users table which fails due to RLS
    - Error: "permission denied for table users"
    
  2. Solution
    - Use auth.jwt()->>'email' to get email from JWT instead of querying auth.users
    - This avoids the RLS permission issue entirely
    
  3. Changes
    - Update "Recipients can view their messages" policy
    - Update "Recipients can update their messages" policy
*/

-- Drop existing recipient policies
DROP POLICY IF EXISTS "Recipients can view their messages" ON admin_messages;
DROP POLICY IF EXISTS "Recipients can update their messages" ON admin_messages;

-- Recreate policies using JWT email instead of querying auth.users
CREATE POLICY "Recipients can view their messages"
  ON admin_messages
  FOR SELECT
  TO authenticated
  USING (
    recipient_email = (auth.jwt()->>'email')::text
    OR recipient_id = auth.uid()
  );

CREATE POLICY "Recipients can update their messages"
  ON admin_messages
  FOR UPDATE
  TO authenticated
  USING (
    recipient_email = (auth.jwt()->>'email')::text
    OR recipient_id = auth.uid()
  )
  WITH CHECK (
    recipient_email = (auth.jwt()->>'email')::text
    OR recipient_id = auth.uid()
  );
