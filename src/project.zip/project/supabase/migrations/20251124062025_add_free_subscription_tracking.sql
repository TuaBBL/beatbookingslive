/*
  # Add Free Subscription Tracking

  1. Changes to Tables
    - `users`
      - Add `is_free_forever` (boolean) - Indicates if user is part of first 50 artists with free subscription forever
    - `Artist Cards`
      - Add `subscription_type` (text) - Track subscription type: 'free', 'standard', 'premium'
  
  2. Purpose
    - Track which artists are part of the first 50 to get free subscription forever
    - Differentiate between free, standard, and premium subscriptions
    - Allow first 50 artists to optionally upgrade to premium for featured placement

  3. Security
    - Maintain existing RLS policies
*/

-- Add free forever tracking to users table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'is_free_forever'
  ) THEN
    ALTER TABLE users ADD COLUMN is_free_forever boolean DEFAULT false;
  END IF;
END $$;

-- Add subscription type to Artist Cards
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Artist Cards' AND column_name = 'subscription_type'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN subscription_type text DEFAULT 'standard';
    ALTER TABLE "Artist Cards" ADD CONSTRAINT check_subscription_type 
      CHECK (subscription_type IN ('free', 'standard', 'premium'));
  END IF;
END $$;

-- Create an index for faster queries on subscription type
CREATE INDEX IF NOT EXISTS idx_artist_cards_subscription_type ON "Artist Cards"(subscription_type);