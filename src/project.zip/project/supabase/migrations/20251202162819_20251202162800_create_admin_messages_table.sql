/*
  # Create Admin Messages System

  1. New Tables
    - `admin_messages`
      - `id` (uuid, primary key)
      - `admin_id` (uuid, references auth.users) - The admin sending the message
      - `recipient_email` (text) - Email of the recipient (user or artist)
      - `recipient_id` (uuid, nullable) - User ID if found
      - `subject` (text) - Message subject
      - `message` (text) - Message content
      - `read` (boolean) - Whether message has been read
      - `created_at` (timestamptz)
      - `read_at` (timestamptz, nullable)

  2. Security
    - Enable RLS on `admin_messages` table
    - Admins can create and view all messages
    - Users can view their own messages (by email or user_id)

  3. Indexes
    - Index on recipient_email for fast lookups
    - Index on recipient_id for fast lookups
    - Index on admin_id for admin message history
*/

-- Create admin_messages table
CREATE TABLE IF NOT EXISTS admin_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  admin_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  recipient_email text NOT NULL,
  recipient_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  subject text NOT NULL,
  message text NOT NULL,
  read boolean DEFAULT false NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  read_at timestamptz
);

-- Create indexes
CREATE INDEX IF NOT EXISTS idx_admin_messages_recipient_email ON admin_messages(recipient_email);
CREATE INDEX IF NOT EXISTS idx_admin_messages_recipient_id ON admin_messages(recipient_id);
CREATE INDEX IF NOT EXISTS idx_admin_messages_admin_id ON admin_messages(admin_id);
CREATE INDEX IF NOT EXISTS idx_admin_messages_created_at ON admin_messages(created_at DESC);

-- Enable RLS
ALTER TABLE admin_messages ENABLE ROW LEVEL SECURITY;

-- Policy: Admins can insert messages
CREATE POLICY "Admins can send messages"
  ON admin_messages
  FOR INSERT
  TO authenticated
  WITH CHECK (
    (auth.jwt()->>'role')::text = 'admin'
  );

-- Policy: Admins can view all messages
CREATE POLICY "Admins can view all messages"
  ON admin_messages
  FOR SELECT
  TO authenticated
  USING (
    (auth.jwt()->>'role')::text = 'admin'
  );

-- Policy: Users can view their own messages by email
CREATE POLICY "Users can view messages sent to their email"
  ON admin_messages
  FOR SELECT
  TO authenticated
  USING (
    recipient_email = auth.jwt()->>'email'
    OR recipient_id = auth.uid()
  );

-- Policy: Users can update read status on their own messages
CREATE POLICY "Users can mark their messages as read"
  ON admin_messages
  FOR UPDATE
  TO authenticated
  USING (
    recipient_email = auth.jwt()->>'email'
    OR recipient_id = auth.uid()
  )
  WITH CHECK (
    recipient_email = auth.jwt()->>'email'
    OR recipient_id = auth.uid()
  );

-- Function to automatically set recipient_id when message is created
CREATE OR REPLACE FUNCTION set_admin_message_recipient_id()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  -- Try to find user by email and set recipient_id
  SELECT id INTO NEW.recipient_id
  FROM auth.users
  WHERE email = NEW.recipient_email
  LIMIT 1;
  
  RETURN NEW;
END;
$$;

-- Trigger to auto-set recipient_id
DROP TRIGGER IF EXISTS set_recipient_id_trigger ON admin_messages;
CREATE TRIGGER set_recipient_id_trigger
  BEFORE INSERT ON admin_messages
  FOR EACH ROW
  EXECUTE FUNCTION set_admin_message_recipient_id();

-- Function to create notification when admin message is sent
CREATE OR REPLACE FUNCTION notify_admin_message()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  -- Create notification for recipient if they have an account
  IF NEW.recipient_id IS NOT NULL THEN
    INSERT INTO notifications (user_id, message, link)
    VALUES (
      NEW.recipient_id,
      'You have a new message from admin: ' || NEW.subject,
      '/admin-messages'
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- Trigger to create notification
DROP TRIGGER IF EXISTS notify_admin_message_trigger ON admin_messages;
CREATE TRIGGER notify_admin_message_trigger
  AFTER INSERT ON admin_messages
  FOR EACH ROW
  EXECUTE FUNCTION notify_admin_message();