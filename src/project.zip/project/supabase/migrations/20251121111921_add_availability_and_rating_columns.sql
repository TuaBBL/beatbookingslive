/*
  # Add Availability and Rating Columns

  1. Changes to Tables
    - `Artist Cards`
      - Add `availability` (text, default 'available') - Artist booking status
      - Add `rating` (numeric, default 0) - Artist rating (e.g., 0-5 scale)
  
  2. Notes
    - Using text for availability to allow flexible values like 'available', 'booked', 'unavailable'
    - Using numeric type for rating to allow decimal values (e.g., 4.5)
    - Both columns have default values for data safety
*/

-- Add availability and rating columns to Artist Cards table
DO $$
BEGIN
  -- Add availability column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' 
    AND table_name = 'Artist Cards' 
    AND column_name = 'availability'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN availability text DEFAULT 'available';
  END IF;

  -- Add rating column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' 
    AND table_name = 'Artist Cards' 
    AND column_name = 'rating'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN rating numeric DEFAULT 0;
  END IF;
END $$;