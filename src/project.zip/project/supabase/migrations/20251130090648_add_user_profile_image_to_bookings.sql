/*
  # Add User Profile Image to Bookings

  1. Changes
    - Add `user_profile_image_url` column to bookings table
    - This allows artists to see the profile image of users who make booking requests
    - Column is nullable to maintain backwards compatibility with existing bookings

  2. Notes
    - Existing bookings will have NULL for this field
    - New bookings should populate this from users.profile_image_url at creation time
*/

-- Add user_profile_image_url column to bookings table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'bookings' AND column_name = 'user_profile_image_url'
  ) THEN
    ALTER TABLE bookings ADD COLUMN user_profile_image_url text;
  END IF;
END $$;
