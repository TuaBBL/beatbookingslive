/*
  # Migrate User Profile Data to Profiles Table

  1. Data Migration
    - Copy existing profile data from `users` table to `profiles` table
    - Only migrate users that don't already have a profile entry
    - Preserve all existing profile information

  2. Important Notes
    - This is a safe migration that only inserts, never deletes
    - Handles cases where profiles may already exist (uses INSERT with ON CONFLICT DO NOTHING)
    - Does not modify the users table
*/

-- Copy existing user profile data to profiles table
INSERT INTO profiles (id, full_name, location, state_territory, phone_number, profile_image_url, created_at, updated_at)
SELECT 
  id,
  COALESCE(full_name, ''),
  COALESCE(location, ''),
  state_territory,
  phone_number,
  profile_image_url,
  created_at,
  updated_at
FROM users
WHERE id NOT IN (SELECT id FROM profiles)
ON CONFLICT (id) DO NOTHING;