/*
  # Enable Real-time for Booking Messages
  
  1. Changes
    - Enable real-time replication for booking_messages table
    
  2. Purpose
    - Allow instant message delivery between users and artists
    - Enable real-time chat functionality using Supabase subscriptions
*/

ALTER PUBLICATION supabase_realtime ADD TABLE booking_messages;
