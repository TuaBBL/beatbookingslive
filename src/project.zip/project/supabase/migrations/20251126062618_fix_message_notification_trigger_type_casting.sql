/*
  # Fix message notification trigger type casting

  1. Changes
    - Update the `create_message_notification()` function to properly cast NEW.booking_id to text then to uuid
    - This fixes the "column related_id is of type uuid but expression is of type text" error
    - The related_id should store the booking ID as a UUID for consistency

  2. Notes
    - The booking_id in booking_messages is already a UUID
    - We need to ensure the trigger properly handles this UUID type
*/

CREATE OR REPLACE FUNCTION create_message_notification()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  booking_record RECORD;
  recipient_id uuid;
  sender_name text;
  artist_name text;
BEGIN
  -- Get booking details
  SELECT b.user_id, b.artist_id, b.user_name, ac.name as artist_name
  INTO booking_record
  FROM bookings b
  LEFT JOIN "Artist Cards" ac ON ac.id = b.artist_id
  WHERE b.id = NEW.booking_id;

  -- Determine recipient (opposite of sender)
  IF NEW.sender_id = booking_record.user_id THEN
    -- Message from user to artist, notify the artist
    SELECT u.id INTO recipient_id
    FROM "Artist Cards" ac
    JOIN users u ON u.id = ac.user_id
    WHERE ac.id = booking_record.artist_id;
    
    sender_name := booking_record.user_name;
    artist_name := booking_record.artist_name;
  ELSE
    -- Message from artist to user, notify the user
    recipient_id := booking_record.user_id;
    sender_name := booking_record.artist_name;
  END IF;

  -- Only create notification if we found a recipient
  IF recipient_id IS NOT NULL THEN
    INSERT INTO notifications (user_id, type, title, message, related_id)
    VALUES (
      recipient_id,
      'new_message',
      'New Message',
      sender_name || ' sent you a message about a booking',
      NEW.booking_id::uuid
    );
  END IF;

  RETURN NEW;
END;
$$;
