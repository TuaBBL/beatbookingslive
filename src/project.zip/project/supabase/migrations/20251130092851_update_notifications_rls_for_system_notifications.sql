/*
  # Update RLS policies for system notifications

  1. Policy Changes
    - Update SELECT policy to allow users to view:
      * Their own notifications (user_id = auth.uid())
      * System-wide notifications (user_id IS NULL)
    - Keep UPDATE policy restricted to user's own notifications only
    - System notifications cannot be updated by users
  
  2. Security
    - Maintains security by ensuring users can only see their own notifications or public system notifications
    - Users cannot modify system notifications (user_id IS NULL would fail the UPDATE policy check)
    - Only authenticated users can view any notifications
  
  3. Use Cases
    - User-specific: booking updates, messages, etc. (user_id set)
    - System-wide: new artist announcements, platform updates (user_id NULL)
*/

-- Drop existing SELECT policy and recreate with system notification support
DROP POLICY IF EXISTS "Users can view own notifications" ON notifications;

CREATE POLICY "Users can view own notifications"
  ON notifications FOR SELECT
  TO authenticated
  USING (user_id = (SELECT auth.uid()) OR user_id IS NULL);

-- Keep UPDATE policy unchanged - users can only update their own notifications
-- This prevents users from modifying system notifications
DROP POLICY IF EXISTS "Users can update own notifications" ON notifications;

CREATE POLICY "Users can update own notifications"
  ON notifications FOR UPDATE
  TO authenticated
  USING (user_id = (SELECT auth.uid()))
  WITH CHECK (user_id = (SELECT auth.uid()));
