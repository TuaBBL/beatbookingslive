/*
  # Fix is_admin_or_ambassador() Function - Correct JWT Path (with CASCADE)

  1. Changes
    - Update function to check JWT app_metadata.role (nested path)
    - Use correct path: current_setting -> 'app_metadata' -> 'role'
    - Drop with CASCADE to handle dependent policies
    - Recreate dependent policies after function update

  2. Security
    - Function checks JWT app_metadata for admin/ambassador roles
    - Cannot be modified by users (SECURITY DEFINER)
    - Used by multiple RLS policies across tables

  3. Affected Policies
    - "Admins and ambassadors can read all profiles" on profiles
    - "Admins and ambassadors can read all artist cards" on artist_cards
    - "Admins and ambassadors can read all users" on users
*/

-- Drop the function with CASCADE to remove dependent policies
DROP FUNCTION IF EXISTS is_admin_or_ambassador() CASCADE;

-- Create new function that checks JWT role from app_metadata using correct path
CREATE OR REPLACE FUNCTION is_admin_or_ambassador()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN (
    COALESCE(
      (current_setting('request.jwt.claims', true)::json -> 'app_metadata' ->> 'role'),
      ''
    ) IN ('admin', 'ambassador')
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER STABLE;

-- Add comment explaining the JWT role system
COMMENT ON FUNCTION is_admin_or_ambassador IS 
'Checks if the current user has admin or ambassador role in their JWT app_metadata. 
Role must be set via: UPDATE auth.users SET raw_app_meta_data = raw_app_meta_data || ''{"role": "admin"}''::jsonb WHERE email = ''user@example.com'';
The function uses the correct nested path: app_metadata -> role';

-- Recreate dependent policies

-- Profiles table
CREATE POLICY "Admins and ambassadors can read all profiles"
ON profiles FOR SELECT
TO authenticated
USING (is_admin_or_ambassador());

-- Artist_cards table
CREATE POLICY "Admins and ambassadors can read all artist cards"
ON artist_cards FOR SELECT
TO authenticated
USING (is_admin_or_ambassador());

-- Users table
CREATE POLICY "Admins and ambassadors can read all users"
ON users FOR SELECT
TO authenticated
USING (is_admin_or_ambassador());
