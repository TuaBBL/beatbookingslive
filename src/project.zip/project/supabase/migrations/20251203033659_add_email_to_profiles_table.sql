/*
  # Add Email Column to Profiles Table

  1. Changes
    - Add email column to profiles table
    - Backfill email from auth.users
    - Create trigger to auto-populate email on profile creation
    
  2. Details
    - Email is stored in profiles for easier admin access
    - Trigger ensures email is always synced from auth.users
    - Makes admin dashboard queries more efficient
*/

-- Add email column to profiles table
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'profiles' AND column_name = 'email'
  ) THEN
    ALTER TABLE profiles ADD COLUMN email text;
  END IF;
END $$;

-- Backfill email from auth.users for existing profiles
UPDATE profiles
SET email = auth.users.email
FROM auth.users
WHERE profiles.id = auth.users.id
AND profiles.email IS NULL;

-- Create trigger function to auto-populate email
CREATE OR REPLACE FUNCTION sync_profile_email()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  -- Get email from auth.users and set it in profiles
  SELECT email INTO NEW.email
  FROM auth.users
  WHERE id = NEW.id;
  
  RETURN NEW;
END;
$$;

-- Create trigger to auto-populate email on insert
DROP TRIGGER IF EXISTS sync_profile_email_trigger ON profiles;
CREATE TRIGGER sync_profile_email_trigger
  BEFORE INSERT ON profiles
  FOR EACH ROW
  EXECUTE FUNCTION sync_profile_email();
