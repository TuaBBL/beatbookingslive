/*
  # Add profile_completed field to users table

  1. Changes
    - Add `profile_completed` boolean column to users table
      - Default value: false
      - Indicates whether user has completed their basic profile setup
    
  2. Data Migration
    - Update existing users with complete profiles
    - A profile is considered complete if it has:
      - full_name (not null and not empty)
      - state_territory (not null)
      - location (not null and not empty)
  
  3. Purpose
    - Track whether regular users (clients) have completed their initial profile setup
    - Used to determine if UserProfileSetupModal should be shown on sign-in
    - Ensures consistent user onboarding experience
*/

-- Add profile_completed column to users table
ALTER TABLE users 
ADD COLUMN IF NOT EXISTS profile_completed boolean DEFAULT false;

-- Update existing users with complete profiles
UPDATE users
SET profile_completed = true
WHERE 
  full_name IS NOT NULL AND full_name != '' AND
  state_territory IS NOT NULL AND
  location IS NOT NULL AND location != '';

-- Add comment for documentation
COMMENT ON COLUMN users.profile_completed IS 'Whether the user has completed their basic profile setup (name, state, location)';