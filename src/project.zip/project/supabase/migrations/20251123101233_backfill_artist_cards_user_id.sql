/*
  # Backfill user_id for existing Artist Cards

  1. Updates
    - Link existing Artist Cards to their corresponding artist_profiles
    - Set user_id based on artist_profiles.user_id where artist_card_id matches

  2. Notes
    - This ensures existing Artist Cards are properly linked to users
    - Only updates cards that don't already have a user_id
*/

-- Update existing Artist Cards with user_id from artist_profiles
UPDATE "Artist Cards" ac
SET user_id = ap.user_id
FROM artist_profiles ap
WHERE ac.id = ap.artist_card_id
  AND ac.user_id IS NULL;