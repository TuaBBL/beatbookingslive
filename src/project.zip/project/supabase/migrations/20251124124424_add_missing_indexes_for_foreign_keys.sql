/*
  # Add Missing Indexes for Foreign Keys

  1. Performance Improvements
    - Add index on `booking_messages.booking_id` for foreign key lookups
    - Add index on `booking_messages.sender_id` for foreign key lookups
    - Add index on `subscriptions.user_id` for foreign key lookups

  2. Security
    - Improves query performance at scale
    - Prevents suboptimal query execution on foreign key constraints
*/

-- Add index for booking_messages.booking_id foreign key
CREATE INDEX IF NOT EXISTS idx_booking_messages_booking_id 
ON booking_messages(booking_id);

-- Add index for booking_messages.sender_id foreign key
CREATE INDEX IF NOT EXISTS idx_booking_messages_sender_id 
ON booking_messages(sender_id);

-- Add index for subscriptions.user_id foreign key
CREATE INDEX IF NOT EXISTS idx_subscriptions_user_id 
ON subscriptions(user_id);