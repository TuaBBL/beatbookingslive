/*
  # Fix Sync Functions with Correct Table Names

  1. Changes
    - Update both sync_artist_premium_status and assign_featured_priority to use artist_cards
    - Ensure premium dates are set
    - Ensure featured priority is assigned
    - Set max_media_items to NULL for premium artists

  2. Purpose
    - Fix table name references from "Artist Cards" to artist_cards
    - Ensure all premium features activate correctly

  3. Security
    - Maintain SECURITY DEFINER for system-level updates
*/

-- Drop and recreate assign_featured_priority with correct table name
DROP FUNCTION IF EXISTS assign_featured_priority();

CREATE FUNCTION assign_featured_priority()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Assign featured_priority to premium artists who don't have one yet
  -- Only assign to first 100 premium artists based on when they became premium
  WITH ranked_premium AS (
    SELECT 
      ac.id,
      ROW_NUMBER() OVER (ORDER BY ac.premium_start_date ASC NULLS LAST, ac.created_at ASC) as priority_rank
    FROM artist_cards ac
    WHERE ac.is_premium = true
  )
  UPDATE artist_cards ac
  SET featured_priority = CASE 
    WHEN rp.priority_rank <= 100 THEN rp.priority_rank::integer
    ELSE NULL
  END
  FROM ranked_premium rp
  WHERE ac.id = rp.id;
END;
$$;

-- Update the sync function with correct table name and all premium features
CREATE OR REPLACE FUNCTION sync_artist_premium_status()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Update artist cards based on active premium subscriptions
  UPDATE artist_cards ac
  SET 
    is_premium = CASE 
      WHEN EXISTS (
        SELECT 1 
        FROM subscriptions s
        WHERE s.user_id = ac.user_id 
        AND s.status = 'active'
        AND s.subscription_type = 'premium'
      ) THEN true
      ELSE false
    END,
    subscription_type = COALESCE(
      (SELECT s.subscription_type 
       FROM subscriptions s
       WHERE s.user_id = ac.user_id 
       AND s.status = 'active' 
       ORDER BY s.created_at DESC 
       LIMIT 1),
      'standard'
    ),
    premium_start_date = CASE
      WHEN EXISTS (
        SELECT 1 
        FROM subscriptions s
        WHERE s.user_id = ac.user_id 
        AND s.status = 'active'
        AND s.subscription_type = 'premium'
      ) THEN COALESCE(
        ac.premium_start_date,
        (SELECT s.start_date 
         FROM subscriptions s
         WHERE s.user_id = ac.user_id 
         AND s.status = 'active'
         AND s.subscription_type = 'premium'
         ORDER BY s.created_at DESC 
         LIMIT 1)
      )
      ELSE ac.premium_start_date
    END,
    premium_end_date = CASE
      WHEN EXISTS (
        SELECT 1 
        FROM subscriptions s
        WHERE s.user_id = ac.user_id 
        AND s.status = 'active'
        AND s.subscription_type = 'premium'
      ) THEN (
        SELECT s.end_date 
        FROM subscriptions s
        WHERE s.user_id = ac.user_id 
        AND s.status = 'active'
        AND s.subscription_type = 'premium'
        ORDER BY s.created_at DESC 
        LIMIT 1
      )
      ELSE NULL
    END,
    max_media_items = CASE
      WHEN EXISTS (
        SELECT 1 
        FROM subscriptions s
        WHERE s.user_id = ac.user_id 
        AND s.status = 'active'
        AND s.subscription_type = 'premium'
      ) THEN NULL
      ELSE 10
    END;
  
  -- Assign featured priority to premium artists
  PERFORM assign_featured_priority();
END;
$$;

-- Run sync now to update all existing premium artists
SELECT sync_artist_premium_status();
