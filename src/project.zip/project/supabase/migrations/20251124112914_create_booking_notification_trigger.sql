/*
  # Create trigger for booking request notifications

  1. New Functions
    - `create_booking_notification()` - Creates a notification when a booking request is made

  2. Trigger
    - Fires after INSERT on bookings
    - Creates notification for the artist when a user makes a booking request

  3. Logic
    - Notifies the artist who owns the artist card
    - Includes user name and booking date in the notification message
*/

CREATE OR REPLACE FUNCTION create_booking_notification()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  artist_user_id uuid;
  artist_name text;
BEGIN
  -- Get the artist's user_id from the Artist Cards table
  SELECT user_id, name INTO artist_user_id, artist_name
  FROM "Artist Cards"
  WHERE id = NEW.artist_id;

  -- Only create notification if we found an artist user_id
  IF artist_user_id IS NOT NULL THEN
    INSERT INTO notifications (user_id, type, title, message, related_id)
    VALUES (
      artist_user_id,
      'new_booking',
      'New Booking Request',
      NEW.user_name || ' has requested a booking for ' || TO_CHAR(NEW.requested_date, 'Mon DD, YYYY'),
      NEW.id
    );
  END IF;

  RETURN NEW;
END;
$$;

-- Create trigger
DROP TRIGGER IF EXISTS on_booking_created ON bookings;
CREATE TRIGGER on_booking_created
  AFTER INSERT ON bookings
  FOR EACH ROW
  EXECUTE FUNCTION create_booking_notification();