/*
  # Add isDemo flag to Artist Cards

  1. Changes
    - Add `is_demo` boolean column to `Artist Cards` table
    - Default value is `false` (normal bookable artists)
    - When `true`, the artist profile is a demo and not bookable

  2. Purpose
    - Allows marking certain artist profiles as demo/showcase profiles
    - Demo profiles will display differently in the UI
    - Book buttons will be hidden/disabled for demo profiles
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Artist Cards' AND column_name = 'is_demo'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN is_demo boolean DEFAULT false;
  END IF;
END $$;
