/*
  # Fix Artist Cards Table References in Database Functions

  ## Overview
  This migration fixes all database functions that still reference "Artist Cards" (with space)
  instead of the correct table name artist_cards (with underscore).

  ## Changes
  
  ### Functions Updated
  1. **create_message_notification** - Fixed 3 references
     - Changed FROM "Artist Cards" to FROM artist_cards
     
  2. **calculate_featured_artists** - Fixed 1 reference
     - Changed JOIN "Artist Cards" to JOIN artist_cards
     
  3. **create_booking_notification** - Fixed 1 reference
     - Changed FROM "Artist Cards" to FROM artist_cards
     
  4. **update_artist_rating** - Fixed 1 reference
     - Changed UPDATE "Artist Cards" to UPDATE artist_cards
     
  5. **assign_featured_priority** - Fixed 2 references
     - Changed FROM/UPDATE "Artist Cards" to artist_cards
     
  6. **sync_artist_premium_status** - Fixed 1 reference
     - Changed UPDATE "Artist Cards" to UPDATE artist_cards
     
  7. **notify_artist_favorited** - Fixed 1 reference
     - Changed FROM "Artist Cards" to FROM artist_cards

  ## Impact
  - Fixes 404 errors when inserting into user_favorites
  - Fixes 404 errors when inserting into bookings
  - All database functions now reference the correct table name
  
  ## Security
  - No changes to RLS policies
  - Function logic remains identical
  - Only table name references updated
*/

-- 1. Fix create_message_notification function
CREATE OR REPLACE FUNCTION create_message_notification()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  booking_record RECORD;
  recipient_id uuid;
  sender_name text;
  artist_name text;
BEGIN
  -- Get booking details
  SELECT b.user_id, b.artist_id, b.user_name, ac.name as artist_name
  INTO booking_record
  FROM bookings b
  LEFT JOIN artist_cards ac ON ac.id = b.artist_id
  WHERE b.id = NEW.booking_id;

  -- Determine recipient (opposite of sender)
  IF NEW.sender_id = booking_record.user_id THEN
    -- Message from user to artist, notify the artist
    SELECT u.id INTO recipient_id
    FROM artist_cards ac
    JOIN users u ON u.id = ac.user_id
    WHERE ac.id = booking_record.artist_id;
    
    sender_name := booking_record.user_name;
    artist_name := booking_record.artist_name;
  ELSE
    -- Message from artist to user, notify the user
    recipient_id := booking_record.user_id;
    sender_name := booking_record.artist_name;
  END IF;

  -- Only create notification if we found a recipient
  IF recipient_id IS NOT NULL THEN
    INSERT INTO notifications (user_id, type, title, message, related_id)
    VALUES (
      recipient_id,
      'new_message',
      'New Message',
      sender_name || ' sent you a message about a booking',
      NEW.booking_id::uuid
    );
  END IF;

  RETURN NEW;
END;
$$;

-- 2. Fix calculate_featured_artists function
CREATE OR REPLACE FUNCTION calculate_featured_artists()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_month date;
  v_prime_artist_id bigint;
  v_max_score integer;
  r RECORD;
BEGIN
  v_month := date_trunc('month', CURRENT_DATE);
  
  -- Delete existing featured artists for this month
  DELETE FROM featured_artists WHERE month = v_month;
  
  -- Calculate scores for all premium artists
  FOR r IN
    SELECT 
      aa.artist_id,
      COALESCE(aa.view_count, 0) + COALESCE(aa.booking_request_count, 0) as total_score
    FROM artist_analytics aa
    INNER JOIN artist_cards ac ON aa.artist_id = ac.id
    WHERE aa.month = v_month
      AND ac.is_premium = true
    ORDER BY total_score DESC
  LOOP
    INSERT INTO featured_artists (artist_id, month, total_score, is_prime_featured)
    VALUES (r.artist_id, v_month, r.total_score, false);
  END LOOP;
  
  -- Set the prime featured artist (highest score)
  SELECT artist_id, total_score INTO v_prime_artist_id, v_max_score
  FROM featured_artists
  WHERE month = v_month
  ORDER BY total_score DESC
  LIMIT 1;
  
  IF v_prime_artist_id IS NOT NULL THEN
    UPDATE featured_artists
    SET is_prime_featured = true
    WHERE artist_id = v_prime_artist_id AND month = v_month;
  END IF;
END;
$$;

-- 3. Fix create_booking_notification function
CREATE OR REPLACE FUNCTION create_booking_notification()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  artist_user_id uuid;
  artist_name text;
BEGIN
  -- Get the artist's user_id from the artist_cards table
  SELECT user_id, name INTO artist_user_id, artist_name
  FROM artist_cards
  WHERE id = NEW.artist_id;
  
  -- Only create notification if we found an artist user_id
  IF artist_user_id IS NOT NULL THEN
    INSERT INTO notifications (user_id, type, title, message, related_id)
    VALUES (
      artist_user_id,
      'new_booking',
      'New Booking Request',
      NEW.user_name || ' has requested a booking for ' || TO_CHAR(NEW.requested_date, 'Mon DD, YYYY'),
      NEW.id::uuid
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- 4. Fix update_artist_rating function
CREATE OR REPLACE FUNCTION update_artist_rating()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  avg_rating NUMERIC;
  review_count INTEGER;
BEGIN
  SELECT AVG(rating)::NUMERIC(3,2), COUNT(*)
  INTO avg_rating, review_count
  FROM public.reviews
  WHERE artist_id = COALESCE(NEW.artist_id, OLD.artist_id);
  
  UPDATE public.artist_cards
  SET 
    rating = COALESCE(avg_rating, 0),
    total_reviews = review_count
  WHERE id = COALESCE(NEW.artist_id, OLD.artist_id);
  
  RETURN COALESCE(NEW, OLD);
END;
$$;

-- 5. Fix assign_featured_priority function
CREATE OR REPLACE FUNCTION assign_featured_priority()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Assign featured_priority to premium artists who don't have one yet
  -- Only assign to first 100 premium artists based on when they became premium
  WITH ranked_premium AS (
    SELECT 
      ac.id,
      ROW_NUMBER() OVER (ORDER BY ac.premium_start_date ASC NULLS LAST, ac.created_at ASC) as priority_rank
    FROM artist_cards ac
    WHERE ac.is_premium = true
  )
  UPDATE artist_cards ac
  SET featured_priority = CASE 
    WHEN rp.priority_rank <= 100 THEN rp.priority_rank::integer
    ELSE NULL
  END
  FROM ranked_premium rp
  WHERE ac.id = rp.id;
END;
$$;

-- 6. Fix sync_artist_premium_status function
CREATE OR REPLACE FUNCTION sync_artist_premium_status()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Update artist cards based on active premium subscriptions
  -- Only update rows where the status has changed
  UPDATE artist_cards ac
  SET 
    is_premium = CASE 
      WHEN EXISTS (
        SELECT 1 
        FROM subscriptions s
        WHERE s.user_id = ac.user_id 
          AND s.status = 'active'
          AND s.subscription_type = 'premium'
      ) THEN true
      ELSE false
    END,
    subscription_type = COALESCE(
      (SELECT s.subscription_type 
       FROM subscriptions s
       WHERE s.user_id = ac.user_id 
         AND s.status = 'active' 
       ORDER BY s.created_at DESC 
       LIMIT 1),
      'standard'
    )
  WHERE ac.user_id IS NOT NULL;
END;
$$;

-- 7. Fix notify_artist_favorited function
CREATE OR REPLACE FUNCTION notify_artist_favorited()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_artist_user_id uuid;
  v_user_name text;
BEGIN
  -- Get the artist's user_id from artist_cards
  SELECT user_id INTO v_artist_user_id
  FROM artist_cards
  WHERE id = NEW.artist_id;
  
  -- Only create notification if artist has a user_id
  IF v_artist_user_id IS NOT NULL THEN
    -- Get the user's name who favorited
    SELECT full_name INTO v_user_name
    FROM users
    WHERE id = NEW.user_id;
    
    -- Create notification for the artist
    INSERT INTO notifications (
      user_id,
      type,
      title,
      message,
      related_id,
      is_read,
      created_at
    ) VALUES (
      v_artist_user_id,
      'favorite',
      'New Favorite!',
      COALESCE(v_user_name, 'A user') || ' added you to their favorite artists!',
      NEW.user_id,
      false,
      now()
    );
  END IF;
  
  RETURN NEW;
END;
$$;