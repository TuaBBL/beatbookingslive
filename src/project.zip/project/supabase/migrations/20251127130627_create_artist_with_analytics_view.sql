/*
  # Create View for Artists with Analytics

  1. New View
    - `artists_with_analytics` - Joins Artist Cards with current month analytics
    - Includes view_count, booking_request_count, is_prime_featured
  
  2. Purpose
    - Simplify queries to get artist data with analytics
    - Show stats on artist cards
*/

CREATE OR REPLACE VIEW artists_with_analytics AS
SELECT 
  ac.*,
  COALESCE(aa.view_count, 0) as view_count,
  COALESCE(aa.booking_request_count, 0) as booking_request_count,
  COALESCE(fa.is_prime_featured, false) as is_prime_featured,
  COALESCE(fa.total_score, 0) as total_score
FROM "Artist Cards" ac
LEFT JOIN artist_analytics aa ON ac.id = aa.artist_id 
  AND aa.month = date_trunc('month', CURRENT_DATE)
LEFT JOIN featured_artists fa ON ac.id = fa.artist_id 
  AND fa.month = date_trunc('month', CURRENT_DATE);