/*
  # Create Artist Analytics and Featured Artist Tracking

  1. New Tables
    - `artist_analytics` - Tracks views and booking requests per artist per month
      - `id` (uuid, primary key)
      - `artist_id` (bigint, foreign key to Artist Cards)
      - `month` (date) - First day of the month
      - `view_count` (integer) - Number of profile views
      - `booking_request_count` (integer) - Number of booking requests
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    
    - `featured_artists` - Tracks which artists are featured each month
      - `id` (uuid, primary key)
      - `artist_id` (bigint, foreign key to Artist Cards)
      - `month` (date) - First day of the month
      - `is_prime_featured` (boolean) - The top artist of the month
      - `total_score` (integer) - Combined views + booking requests
      - `created_at` (timestamp)

  2. Functions
    - `increment_artist_views()` - Increment view count for an artist
    - `increment_booking_requests()` - Increment booking request count
    - `calculate_featured_artists()` - Calculate and set featured artists for the month

  3. Security
    - Enable RLS on all tables
    - Public can read analytics (for display)
    - Only authenticated users can increment counters
*/

-- Create artist_analytics table
CREATE TABLE IF NOT EXISTS artist_analytics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  artist_id bigint NOT NULL REFERENCES "Artist Cards"(id) ON DELETE CASCADE,
  month date NOT NULL,
  view_count integer DEFAULT 0,
  booking_request_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(artist_id, month)
);

-- Create featured_artists table
CREATE TABLE IF NOT EXISTS featured_artists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  artist_id bigint NOT NULL REFERENCES "Artist Cards"(id) ON DELETE CASCADE,
  month date NOT NULL,
  is_prime_featured boolean DEFAULT false,
  total_score integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  UNIQUE(artist_id, month)
);

-- Enable RLS
ALTER TABLE artist_analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE featured_artists ENABLE ROW LEVEL SECURITY;

-- RLS Policies for artist_analytics
CREATE POLICY "Anyone can view analytics"
  ON artist_analytics
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "System can insert analytics"
  ON artist_analytics
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "System can update analytics"
  ON artist_analytics
  FOR UPDATE
  TO authenticated
  USING (true);

-- RLS Policies for featured_artists
CREATE POLICY "Anyone can view featured artists"
  ON featured_artists
  FOR SELECT
  TO public
  USING (true);

CREATE POLICY "System can manage featured artists"
  ON featured_artists
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Function to increment artist views
CREATE OR REPLACE FUNCTION increment_artist_views(p_artist_id bigint)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_month date;
BEGIN
  v_month := date_trunc('month', CURRENT_DATE);
  
  INSERT INTO artist_analytics (artist_id, month, view_count, booking_request_count)
  VALUES (p_artist_id, v_month, 1, 0)
  ON CONFLICT (artist_id, month)
  DO UPDATE SET 
    view_count = artist_analytics.view_count + 1,
    updated_at = now();
END;
$$;

-- Function to increment booking requests
CREATE OR REPLACE FUNCTION increment_booking_requests(p_artist_id bigint)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_month date;
BEGIN
  v_month := date_trunc('month', CURRENT_DATE);
  
  INSERT INTO artist_analytics (artist_id, month, view_count, booking_request_count)
  VALUES (p_artist_id, v_month, 0, 1)
  ON CONFLICT (artist_id, month)
  DO UPDATE SET 
    booking_request_count = artist_analytics.booking_request_count + 1,
    updated_at = now();
END;
$$;

-- Function to calculate and set featured artists for the current month
CREATE OR REPLACE FUNCTION calculate_featured_artists()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_month date;
  v_prime_artist_id bigint;
  v_max_score integer;
  r RECORD;
BEGIN
  v_month := date_trunc('month', CURRENT_DATE);
  
  -- Delete existing featured artists for this month
  DELETE FROM featured_artists WHERE month = v_month;
  
  -- Calculate scores for all premium artists
  FOR r IN
    SELECT 
      aa.artist_id,
      COALESCE(aa.view_count, 0) + COALESCE(aa.booking_request_count, 0) as total_score
    FROM artist_analytics aa
    INNER JOIN "Artist Cards" ac ON aa.artist_id = ac.id
    WHERE aa.month = v_month
      AND ac.is_premium = true
    ORDER BY total_score DESC
  LOOP
    INSERT INTO featured_artists (artist_id, month, total_score, is_prime_featured)
    VALUES (r.artist_id, v_month, r.total_score, false);
  END LOOP;
  
  -- Set the prime featured artist (highest score)
  SELECT artist_id, total_score INTO v_prime_artist_id, v_max_score
  FROM featured_artists
  WHERE month = v_month
  ORDER BY total_score DESC
  LIMIT 1;
  
  IF v_prime_artist_id IS NOT NULL THEN
    UPDATE featured_artists
    SET is_prime_featured = true
    WHERE artist_id = v_prime_artist_id AND month = v_month;
  END IF;
END;
$$;

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_artist_analytics_artist_month ON artist_analytics(artist_id, month);
CREATE INDEX IF NOT EXISTS idx_artist_analytics_month ON artist_analytics(month);
CREATE INDEX IF NOT EXISTS idx_featured_artists_month ON featured_artists(month);
CREATE INDEX IF NOT EXISTS idx_featured_artists_prime ON featured_artists(month, is_prime_featured) WHERE is_prime_featured = true;