/*
  # Fix Function Search Path Security Issues

  1. Changes
    - Set explicit search_path for all functions to prevent role mutable search_path vulnerabilities
    - Uses `SET search_path = ''` to ensure secure function execution
    - This prevents potential schema injection attacks

  2. Functions Updated
    - update_updated_at_column
    - handle_new_user
    - handle_user_sign_in
    - update_artist_rating
    - create_message_notification
    - create_booking_notification
    - update_conversation_timestamp

  3. Security
    - Prevents search_path manipulation attacks
    - Ensures functions only access intended schemas
*/

-- Update update_updated_at_column function
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;

-- Update handle_new_user function
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  INSERT INTO public.users (id, email, full_name, user_type)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', ''),
    COALESCE(NEW.raw_user_meta_data->>'user_type', 'client')
  );
  RETURN NEW;
END;
$$;

-- Update handle_user_sign_in function
CREATE OR REPLACE FUNCTION handle_user_sign_in()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  UPDATE public.users
  SET last_sign_in_at = NEW.last_sign_in_at
  WHERE id = NEW.id;
  RETURN NEW;
END;
$$;

-- Update update_artist_rating function
CREATE OR REPLACE FUNCTION update_artist_rating()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  avg_rating NUMERIC;
  review_count INTEGER;
BEGIN
  SELECT AVG(rating)::NUMERIC(3,2), COUNT(*)
  INTO avg_rating, review_count
  FROM public.reviews
  WHERE artist_id = COALESCE(NEW.artist_id, OLD.artist_id);
  
  UPDATE public."Artist Cards"
  SET 
    rating = COALESCE(avg_rating, 0),
    total_reviews = review_count
  WHERE id = COALESCE(NEW.artist_id, OLD.artist_id);
  
  RETURN COALESCE(NEW, OLD);
END;
$$;

-- Update create_message_notification function
CREATE OR REPLACE FUNCTION create_message_notification()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  recipient_id UUID;
  artist_card_user_id UUID;
BEGIN
  SELECT user_id INTO recipient_id
  FROM public.bookings
  WHERE id = NEW.booking_id;
  
  SELECT user_id INTO artist_card_user_id
  FROM public."Artist Cards"
  WHERE id IN (
    SELECT artist_id FROM public.bookings WHERE id = NEW.booking_id
  );
  
  IF NEW.sender_id = recipient_id THEN
    INSERT INTO public.notifications (user_id, type, title, message, related_id)
    VALUES (
      artist_card_user_id,
      'message',
      'New Message',
      'You have a new message about a booking',
      NEW.booking_id::TEXT
    );
  ELSE
    INSERT INTO public.notifications (user_id, type, title, message, related_id)
    VALUES (
      recipient_id,
      'message',
      'New Message',
      'You have a new message about your booking',
      NEW.booking_id::TEXT
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- Update create_booking_notification function
CREATE OR REPLACE FUNCTION create_booking_notification()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  artist_user_id UUID;
  artist_name TEXT;
BEGIN
  SELECT user_id INTO artist_user_id
  FROM public."Artist Cards"
  WHERE id = NEW.artist_id;
  
  SELECT COALESCE(stage_name, name) INTO artist_name
  FROM public."Artist Cards"
  WHERE id = NEW.artist_id;
  
  INSERT INTO public.notifications (user_id, type, title, message, related_id)
  VALUES (
    artist_user_id,
    'booking',
    'New Booking Request',
    'You have a new booking request from ' || NEW.user_name,
    NEW.id::TEXT
  );
  
  RETURN NEW;
END;
$$;

-- Update update_conversation_timestamp function
CREATE OR REPLACE FUNCTION update_conversation_timestamp()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
BEGIN
  UPDATE public.chat_conversations
  SET updated_at = NOW()
  WHERE id = NEW.conversation_id;
  RETURN NEW;
END;
$$;