/*
  # Fix Admin Message Notification Trigger

  1. Changes
    - Update the notify_admin_message function to use correct notification columns
    - Use type, title, message, related_id instead of non-existent link column
    
  2. Details
    - Notifications table has: user_id, type, title, message, related_id, is_read, created_at
    - Trigger was trying to use 'link' column which doesn't exist
*/

-- Drop existing trigger and function
DROP TRIGGER IF EXISTS notify_admin_message_trigger ON admin_messages;
DROP FUNCTION IF EXISTS notify_admin_message();

-- Recreate function with correct columns
CREATE OR REPLACE FUNCTION notify_admin_message()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  -- Create notification for recipient if they have an account
  IF NEW.recipient_id IS NOT NULL THEN
    INSERT INTO notifications (user_id, type, title, message, related_id)
    VALUES (
      NEW.recipient_id,
      'admin_message',
      'Admin Message',
      'You have a new message from admin: ' || NEW.subject,
      NEW.id
    );
  END IF;
  
  RETURN NEW;
END;
$$;

-- Recreate trigger
CREATE TRIGGER notify_admin_message_trigger
  AFTER INSERT ON admin_messages
  FOR EACH ROW
  EXECUTE FUNCTION notify_admin_message();
