/*
  # Replace Socials JSONB with Individual Social Link Columns

  1. Changes to Tables
    - `Artist Cards`
      - Drop `socials` (jsonb) column
      - Add `youtube_link` (text) - YouTube profile/channel URL
      - Add `instagram_link` (text) - Instagram profile URL
      - Add `facebook_link` (text) - Facebook page URL
      - Add `soundcloud_link` (text) - SoundCloud profile URL
      - Add `mixcloud_link` (text) - Mixcloud profile URL
      - Add `spotify_link` (text) - Spotify artist URL
      - Add `tiktok_link` (text) - TikTok profile URL
  
  2. Notes
    - All social link columns default to empty string for data safety
    - Individual columns provide better type safety and easier querying
*/

-- Remove socials column and add individual social link columns
DO $$
BEGIN
  -- Drop socials column if it exists
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' 
    AND table_name = 'Artist Cards' 
    AND column_name = 'socials'
  ) THEN
    ALTER TABLE "Artist Cards" DROP COLUMN socials;
  END IF;

  -- Add YouTube link column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' 
    AND table_name = 'Artist Cards' 
    AND column_name = 'youtube_link'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN youtube_link text DEFAULT '';
  END IF;

  -- Add Instagram link column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' 
    AND table_name = 'Artist Cards' 
    AND column_name = 'instagram_link'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN instagram_link text DEFAULT '';
  END IF;

  -- Add Facebook link column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' 
    AND table_name = 'Artist Cards' 
    AND column_name = 'facebook_link'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN facebook_link text DEFAULT '';
  END IF;

  -- Add SoundCloud link column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' 
    AND table_name = 'Artist Cards' 
    AND column_name = 'soundcloud_link'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN soundcloud_link text DEFAULT '';
  END IF;

  -- Add Mixcloud link column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' 
    AND table_name = 'Artist Cards' 
    AND column_name = 'mixcloud_link'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN mixcloud_link text DEFAULT '';
  END IF;

  -- Add Spotify link column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' 
    AND table_name = 'Artist Cards' 
    AND column_name = 'spotify_link'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN spotify_link text DEFAULT '';
  END IF;

  -- Add TikTok link column
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' 
    AND table_name = 'Artist Cards' 
    AND column_name = 'tiktok_link'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN tiktok_link text DEFAULT '';
  END IF;
END $$;