/*
  # Fix booking notification trigger UUID casting

  1. Changes
    - Update `create_booking_notification()` function to explicitly cast NEW.id to UUID
    - Ensures related_id is properly typed as UUID

  2. Notes
    - Resolves "column related_id is of type uuid but expression is of type text" error
    - No data changes, only function logic update
*/

CREATE OR REPLACE FUNCTION create_booking_notification()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  artist_user_id uuid;
  artist_name text;
BEGIN
  -- Get the artist's user_id from the Artist Cards table
  SELECT user_id, name INTO artist_user_id, artist_name
  FROM "Artist Cards"
  WHERE id = NEW.artist_id;

  -- Only create notification if we found an artist user_id
  IF artist_user_id IS NOT NULL THEN
    INSERT INTO notifications (user_id, type, title, message, related_id)
    VALUES (
      artist_user_id,
      'new_booking',
      'New Booking Request',
      NEW.user_name || ' has requested a booking for ' || TO_CHAR(NEW.requested_date, 'Mon DD, YYYY'),
      NEW.id::uuid
    );
  END IF;

  RETURN NEW;
END;
$$;