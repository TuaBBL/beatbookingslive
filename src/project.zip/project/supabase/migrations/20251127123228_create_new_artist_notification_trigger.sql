/*
  # Create trigger for new artist notifications

  1. Function
    - Creates a notification whenever a new artist card is created
    - Uses the stage_name or name from the Artist Cards table
  
  2. Trigger
    - Fires AFTER INSERT on Artist Cards table
    - Automatically creates a system notification for new artists
*/

CREATE OR REPLACE FUNCTION notify_new_artist()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  INSERT INTO notifications (type, title, message)
  VALUES (
    'new_artist',
    'New Artist Added!',
    'A new artist has joined the platform: ' || COALESCE(NEW.stage_name, NEW.name)
  );
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_new_artist_notification ON "Artist Cards";

CREATE TRIGGER trg_new_artist_notification
  AFTER INSERT ON "Artist Cards"
  FOR EACH ROW
  EXECUTE FUNCTION notify_new_artist();