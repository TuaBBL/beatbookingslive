/*
  # Create Automatic Email Triggers

  1. Functions Created
    - `send_welcome_email_on_signup()` - Sends welcome email to new artists
    - `send_founder_email_to_first_50()` - Sends founder premium email to first 50 artists

  2. Triggers Created
    - `trigger_welcome_email` - Fires when artist_cards row is inserted
    - `trigger_founder_email` - Fires when artist_cards row is inserted (if first 50)

  3. Purpose
    - Automate welcome emails
    - Automate founder premium emails for first 50 artists
    - No need to manually send emails from frontend

  4. Security
    - Uses SECURITY DEFINER for system-level operations
    - Only fires on insert/signup
*/

-- Enable the http extension if not already enabled
CREATE EXTENSION IF NOT EXISTS http WITH SCHEMA extensions;

-- Function to send welcome email via edge function
CREATE OR REPLACE FUNCTION send_welcome_email_on_signup()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  user_email text;
  artist_name text;
  supabase_url text;
  service_role_key text;
BEGIN
  -- Get Supabase URL and key from environment
  supabase_url := current_setting('app.settings.supabase_url', true);
  service_role_key := current_setting('app.settings.service_role_key', true);

  -- Fallback to hardcoded values if settings don't exist
  IF supabase_url IS NULL THEN
    supabase_url := 'https://your-project.supabase.co';
  END IF;

  -- Get user email from auth.users
  SELECT email INTO user_email
  FROM auth.users
  WHERE id = NEW.user_id;

  -- Use artist name from artist_cards
  artist_name := COALESCE(NEW.name, 'Artist');

  -- Call edge function to send welcome email (async, fire and forget)
  IF user_email IS NOT NULL AND service_role_key IS NOT NULL THEN
    PERFORM
      extensions.http_post(
        url := supabase_url || '/functions/v1/send-welcome-email',
        headers := format('{"Content-Type": "application/json", "Authorization": "Bearer %s"}', service_role_key)::jsonb,
        body := format('{"email": "%s", "name": "%s", "userType": "artist"}', user_email, artist_name)::jsonb
      );
  END IF;

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error but don't fail the insert
    RAISE WARNING 'Failed to send welcome email: %', SQLERRM;
    RETURN NEW;
END;
$$;

-- Function to check if artist is in first 50 and send founder email
CREATE OR REPLACE FUNCTION send_founder_email_to_first_50()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  user_email text;
  artist_name text;
  total_artists integer;
  supabase_url text;
  service_role_key text;
BEGIN
  -- Get Supabase URL and key
  supabase_url := current_setting('app.settings.supabase_url', true);
  service_role_key := current_setting('app.settings.service_role_key', true);

  -- Fallback
  IF supabase_url IS NULL THEN
    supabase_url := 'https://your-project.supabase.co';
  END IF;

  -- Count total artists (including this new one)
  SELECT COUNT(*) INTO total_artists
  FROM artist_cards
  WHERE is_demo = false OR is_demo IS NULL;

  -- Only send if artist is in first 50
  IF total_artists <= 50 THEN
    -- Get user email
    SELECT email INTO user_email
    FROM auth.users
    WHERE id = NEW.user_id;

    artist_name := COALESCE(NEW.name, 'Artist');

    -- Call edge function to send founder premium email
    IF user_email IS NOT NULL AND service_role_key IS NOT NULL THEN
      PERFORM
        extensions.http_post(
          url := supabase_url || '/functions/v1/send-subscription-confirmation',
          headers := format('{"Content-Type": "application/json", "Authorization": "Bearer %s"}', service_role_key)::jsonb,
          body := format('{"email": "%s", "subscription_type": "premium", "is_founder": true}', user_email)::jsonb
        );
    END IF;
  END IF;

  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    -- Log error but don't fail the insert
    RAISE WARNING 'Failed to send founder email: %', SQLERRM;
    RETURN NEW;
END;
$$;

-- Create trigger for welcome email
DROP TRIGGER IF EXISTS trigger_welcome_email ON artist_cards;
CREATE TRIGGER trigger_welcome_email
  AFTER INSERT ON artist_cards
  FOR EACH ROW
  EXECUTE FUNCTION send_welcome_email_on_signup();

-- Create trigger for founder email (runs after welcome email)
DROP TRIGGER IF EXISTS trigger_founder_email ON artist_cards;
CREATE TRIGGER trigger_founder_email
  AFTER INSERT ON artist_cards
  FOR EACH ROW
  EXECUTE FUNCTION send_founder_email_to_first_50();

COMMENT ON FUNCTION send_welcome_email_on_signup IS 'Automatically sends welcome email when new artist signs up';
COMMENT ON FUNCTION send_founder_email_to_first_50 IS 'Sends founder premium email to first 50 artists automatically';
