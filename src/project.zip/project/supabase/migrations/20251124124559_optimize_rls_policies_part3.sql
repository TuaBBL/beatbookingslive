/*
  # Optimize RLS Policies for Performance - Part 3

  1. Changes
    - Replace all `auth.uid()` calls with `(select auth.uid())` in RLS policies
    - This prevents re-evaluation of auth function for each row
    - Significantly improves query performance at scale

  2. Tables Updated
    - booking_messages
    - notifications
    - chat_conversations
    - chat_messages

  3. Security
    - Maintains same security guarantees
    - Optimizes policy evaluation by calling auth functions once per query
*/

-- Booking messages policies
DROP POLICY IF EXISTS "Users can read messages for their bookings" ON booking_messages;
CREATE POLICY "Users can read messages for their bookings"
  ON booking_messages FOR SELECT
  TO authenticated
  USING (
    booking_id IN (
      SELECT id FROM bookings 
      WHERE user_id = (select auth.uid())
      OR artist_id IN (
        SELECT id FROM "Artist Cards" WHERE user_id = (select auth.uid())
      )
    )
  );

DROP POLICY IF EXISTS "Users can send messages for their bookings" ON booking_messages;
CREATE POLICY "Users can send messages for their bookings"
  ON booking_messages FOR INSERT
  TO authenticated
  WITH CHECK (
    sender_id = (select auth.uid())
    AND booking_id IN (
      SELECT id FROM bookings 
      WHERE user_id = (select auth.uid())
      OR artist_id IN (
        SELECT id FROM "Artist Cards" WHERE user_id = (select auth.uid())
      )
    )
  );

-- Notifications policies
DROP POLICY IF EXISTS "Users can view own notifications" ON notifications;
CREATE POLICY "Users can view own notifications"
  ON notifications FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own notifications" ON notifications;
CREATE POLICY "Users can update own notifications"
  ON notifications FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

-- Chat conversations policies
DROP POLICY IF EXISTS "Users can view own conversations" ON chat_conversations;
CREATE POLICY "Users can view own conversations"
  ON chat_conversations FOR SELECT
  TO authenticated
  USING (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can create own conversations" ON chat_conversations;
CREATE POLICY "Users can create own conversations"
  ON chat_conversations FOR INSERT
  TO authenticated
  WITH CHECK (user_id = (select auth.uid()));

DROP POLICY IF EXISTS "Users can update own conversations" ON chat_conversations;
CREATE POLICY "Users can update own conversations"
  ON chat_conversations FOR UPDATE
  TO authenticated
  USING (user_id = (select auth.uid()))
  WITH CHECK (user_id = (select auth.uid()));

-- Chat messages policies
DROP POLICY IF EXISTS "Users can view messages from own conversations" ON chat_messages;
CREATE POLICY "Users can view messages from own conversations"
  ON chat_messages FOR SELECT
  TO authenticated
  USING (
    conversation_id IN (
      SELECT id FROM chat_conversations WHERE user_id = (select auth.uid())
    )
  );

DROP POLICY IF EXISTS "Users can create messages in own conversations" ON chat_messages;
CREATE POLICY "Users can create messages in own conversations"
  ON chat_messages FOR INSERT
  TO authenticated
  WITH CHECK (
    conversation_id IN (
      SELECT id FROM chat_conversations WHERE user_id = (select auth.uid())
    )
  );