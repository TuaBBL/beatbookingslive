/*
  # Add Delete Policy for Admin Messages

  1. Changes
    - Add DELETE policy allowing admins to delete messages
    - Ensures admins have full CRUD control over admin messages

  2. Security
    - Only users with admin role can delete messages
    - Uses JWT role check for authorization
*/

-- Policy: Admins can delete messages
CREATE POLICY "Admins can delete messages"
  ON admin_messages
  FOR DELETE
  TO authenticated
  USING (
    (auth.jwt()->>'role')::text = 'admin'
  );
