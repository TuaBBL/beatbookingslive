/*
  # Add Stripe Integration Columns to Subscriptions Table

  1. Changes to Tables
    - `subscriptions`
      - Add `stripe_subscription_id` (text) - Stripe subscription ID
      - Add `stripe_price_id` (text) - Stripe price ID for mapping to subscription_type
      - Make `plan_type` nullable (not always from Stripe)
      - Make `amount` nullable (not always from Stripe)

  2. Purpose
    - Enable proper sync from Stripe webhook to subscriptions table
    - Track which Stripe subscription is linked to each user subscription
    - Map Stripe price_id to determine standard vs premium subscription

  3. Security
    - Maintain existing RLS policies
    - Add service role policy for webhook to insert/update
*/

-- Add stripe_subscription_id column
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'subscriptions' AND column_name = 'stripe_subscription_id'
  ) THEN
    ALTER TABLE subscriptions ADD COLUMN stripe_subscription_id text;
  END IF;
END $$;

-- Add stripe_price_id column
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'subscriptions' AND column_name = 'stripe_price_id'
  ) THEN
    ALTER TABLE subscriptions ADD COLUMN stripe_price_id text;
  END IF;
END $$;

-- Make plan_type nullable (can be null for Stripe subscriptions)
ALTER TABLE subscriptions ALTER COLUMN plan_type DROP NOT NULL;

-- Make amount nullable (can be null for free or Stripe subscriptions)
ALTER TABLE subscriptions ALTER COLUMN amount DROP NOT NULL;

-- Add unique constraint on stripe_subscription_id
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'subscriptions_stripe_subscription_id_key'
  ) THEN
    ALTER TABLE subscriptions ADD CONSTRAINT subscriptions_stripe_subscription_id_key UNIQUE (stripe_subscription_id);
  END IF;
END $$;

-- Drop existing policy if it exists and recreate
DROP POLICY IF EXISTS "Service role can manage subscriptions" ON subscriptions;

-- Add service role policy to allow webhook to upsert subscriptions
CREATE POLICY "Service role can manage subscriptions"
  ON subscriptions
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Create index for faster lookups
CREATE INDEX IF NOT EXISTS idx_subscriptions_stripe_subscription_id ON subscriptions(stripe_subscription_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_user_id_status ON subscriptions(user_id, status);
