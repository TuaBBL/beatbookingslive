/*
  # Add Manual Featured Artist Update Endpoint

  1. Purpose
    - Provides a way to manually trigger the featured artist calculation
    - Creates a simple helper function that can be called via SQL or API
    - Updates featured artists for the current month based on analytics

  2. Changes
    - No schema changes needed
    - Adds a helper view to see current featured artist status
    - Documents how to manually trigger calculation

  3. Usage
    - Execute: SELECT calculate_featured_artists();
    - This will recalculate featured artists for the current month
*/

-- Create a view to easily see the current featured artist
CREATE OR REPLACE VIEW current_featured_artist AS
SELECT 
  ac.*,
  fa.total_score,
  fa.is_prime_featured,
  aa.view_count,
  aa.booking_request_count
FROM featured_artists fa
INNER JOIN "Artist Cards" ac ON fa.artist_id = ac.id
LEFT JOIN artist_analytics aa ON aa.artist_id = fa.artist_id 
  AND aa.month = date_trunc('month', CURRENT_DATE)
WHERE fa.month = date_trunc('month', CURRENT_DATE)
  AND fa.is_prime_featured = true
ORDER BY fa.total_score DESC
LIMIT 1;

-- Grant access to view
GRANT SELECT ON current_featured_artist TO authenticated, anon;

-- Create a function to increment views when an artist profile is viewed
CREATE OR REPLACE FUNCTION track_artist_view(p_artist_id bigint)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Increment the view count in artist_analytics
  PERFORM increment_artist_views(p_artist_id);
  
  -- Also increment in detailed analytics if the artist is premium
  INSERT INTO artist_analytics_detailed (artist_id, date, profile_views)
  VALUES (p_artist_id, CURRENT_DATE, 1)
  ON CONFLICT (artist_id, date)
  DO UPDATE SET 
    profile_views = artist_analytics_detailed.profile_views + 1,
    updated_at = now();
END;
$$;

-- Create a function to track booking requests
CREATE OR REPLACE FUNCTION track_booking_request(p_artist_id bigint)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Increment booking request count
  PERFORM increment_booking_requests(p_artist_id);
  
  -- Also increment in detailed analytics if the artist is premium
  INSERT INTO artist_analytics_detailed (artist_id, date, booking_button_clicks)
  VALUES (p_artist_id, CURRENT_DATE, 1)
  ON CONFLICT (artist_id, date)
  DO UPDATE SET 
    booking_button_clicks = artist_analytics_detailed.booking_button_clicks + 1,
    updated_at = now();
END;
$$;

-- Add a comment explaining how to manually trigger featured artist calculation
COMMENT ON FUNCTION calculate_featured_artists() IS 
'Calculates and updates featured artists for the current month based on view and booking counts. 
To manually trigger: SELECT calculate_featured_artists();
This is typically run at the start of each month, but can be run anytime to refresh the featured artist.';
