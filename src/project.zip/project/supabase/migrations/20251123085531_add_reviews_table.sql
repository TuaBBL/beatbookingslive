/*
  # Add Reviews Table

  1. New Tables
    - `reviews`
      - `id` (uuid, primary key) - Unique identifier for each review
      - `artist_id` (bigint, foreign key) - References the artist being reviewed
      - `user_id` (uuid, foreign key) - References the user who wrote the review
      - `rating` (integer) - Star rating from 1-5
      - `comment` (text) - Optional review comment
      - `created_at` (timestamptz) - When the review was created
      - `updated_at` (timestamptz) - When the review was last updated

  2. Security
    - Enable RLS on `reviews` table
    - Add policy for anyone to read reviews
    - Add policy for authenticated users to create reviews for artists (one review per artist per user)
    - Add policy for users to update their own reviews
    - Add policy for users to delete their own reviews

  3. Constraints
    - Unique constraint to prevent multiple reviews from same user for same artist
    - Check constraint to ensure rating is between 1 and 5
*/

CREATE TABLE IF NOT EXISTS reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  artist_id bigint NOT NULL REFERENCES "Artist Cards"(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  comment text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now(),
  UNIQUE(artist_id, user_id)
);

ALTER TABLE reviews ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read reviews"
  ON reviews FOR SELECT
  TO authenticated, anon
  USING (true);

CREATE POLICY "Authenticated users can create reviews"
  ON reviews FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own reviews"
  ON reviews FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own reviews"
  ON reviews FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS reviews_artist_id_idx ON reviews(artist_id);
CREATE INDEX IF NOT EXISTS reviews_user_id_idx ON reviews(user_id);