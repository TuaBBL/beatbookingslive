/*
  # Create Bookings Table

  1. New Tables
    - `bookings`
      - `id` (uuid, primary key)
      - `user_id` (uuid, foreign key to auth.users)
      - `artist_id` (bigint, foreign key to Artist Cards)
      - `user_name` (text) - Name of person making booking
      - `user_email` (text) - Email of person making booking
      - `user_phone` (text, optional) - Phone number of person making booking
      - `requested_date` (date) - Date requested for booking
      - `time_from` (time) - Start time for booking
      - `time_to` (time) - End time for booking
      - `location` (text) - Venue/location for booking
      - `comments` (text, optional) - Additional comments/requests
      - `status` (text) - Status: pending, confirmed, cancelled, completed
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on bookings table
    - Users can create their own bookings
    - Users can view their own bookings
    - Artists can view bookings for their artist card
    - Users and artists can update status of their bookings
*/

CREATE TABLE IF NOT EXISTS bookings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  artist_id bigint REFERENCES "Artist Cards"(id) ON DELETE CASCADE NOT NULL,
  user_name text NOT NULL,
  user_email text NOT NULL,
  user_phone text,
  requested_date date NOT NULL,
  time_from time NOT NULL,
  time_to time NOT NULL,
  location text NOT NULL,
  comments text,
  status text DEFAULT 'pending' NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE bookings ENABLE ROW LEVEL SECURITY;

-- Users can create their own bookings
CREATE POLICY "Users can create own bookings"
  ON bookings
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Users can view their own bookings
CREATE POLICY "Users can view own bookings"
  ON bookings
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

-- Artists can view bookings for their artist cards
CREATE POLICY "Artists can view bookings for their cards"
  ON bookings
  FOR SELECT
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM "Artist Cards"
      WHERE "Artist Cards".id = bookings.artist_id
      AND "Artist Cards".user_id = auth.uid()
    )
  );

-- Users can update their own bookings
CREATE POLICY "Users can update own bookings"
  ON bookings
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Artists can update bookings for their artist cards
CREATE POLICY "Artists can update bookings for their cards"
  ON bookings
  FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM "Artist Cards"
      WHERE "Artist Cards".id = bookings.artist_id
      AND "Artist Cards".user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM "Artist Cards"
      WHERE "Artist Cards".id = bookings.artist_id
      AND "Artist Cards".user_id = auth.uid()
    )
  );

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_bookings_user_id ON bookings(user_id);
CREATE INDEX IF NOT EXISTS idx_bookings_artist_id ON bookings(artist_id);
CREATE INDEX IF NOT EXISTS idx_bookings_status ON bookings(status);