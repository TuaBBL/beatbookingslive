-- Fix Storage Bucket Policies
-- Drop and recreate storage policies with correct permissions

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "Artists can upload their own images" ON storage.objects;
DROP POLICY IF EXISTS "Artists can update their own images" ON storage.objects;
DROP POLICY IF EXISTS "Artists can delete their own images" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can view images" ON storage.objects;
DROP POLICY IF EXISTS "Artists can upload their own videos" ON storage.objects;
DROP POLICY IF EXISTS "Artists can update their own videos" ON storage.objects;
DROP POLICY IF EXISTS "Artists can delete their own videos" ON storage.objects;
DROP POLICY IF EXISTS "Anyone can view videos" ON storage.objects;

-- Create new policies for artist-images bucket
CREATE POLICY "Authenticated users can upload images"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'artist-images'
);

CREATE POLICY "Authenticated users can update their own images"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'artist-images' AND
  (storage.foldername(name))[1] = auth.uid()::text
)
WITH CHECK (
  bucket_id = 'artist-images' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Authenticated users can delete their own images"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'artist-images' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Public can view all images"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'artist-images');

-- Create new policies for artist-videos bucket
CREATE POLICY "Authenticated users can upload videos"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'artist-videos'
);

CREATE POLICY "Authenticated users can update their own videos"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'artist-videos' AND
  (storage.foldername(name))[1] = auth.uid()::text
)
WITH CHECK (
  bucket_id = 'artist-videos' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Authenticated users can delete their own videos"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'artist-videos' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Public can view all videos"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'artist-videos');