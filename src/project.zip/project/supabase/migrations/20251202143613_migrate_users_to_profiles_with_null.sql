/*
  # Migrate Existing User Data to Profiles Table with NULL Handling

  1. Data Migration Strategy
    - Copy all existing user profile data from `users` table
    - Convert empty strings or missing values to NULL
    - Force profile completion by ensuring incomplete fields are NULL
    - Every user gets a profile row

  2. Migration Logic
    - NULLIF converts empty strings to NULL
    - COALESCE ensures no missing data becomes empty string
    - Users with incomplete profiles will be forced to complete them

  3. Important Notes
    - Safe migration using INSERT ON CONFLICT
    - Does not delete any data from users table
    - Preserves existing profile data where available
    - Sets NULL for incomplete/missing fields to trigger profile completion flow
*/

-- Migrate existing user profile data to profiles table
-- Convert empty strings and nulls to proper NULL values
INSERT INTO profiles (
  id, 
  full_name, 
  location, 
  state_territory, 
  phone_number, 
  profile_image_url, 
  created_at, 
  updated_at
)
SELECT 
  u.id,
  NULLIF(TRIM(COALESCE(u.full_name, '')), '') AS full_name,
  NULLIF(TRIM(COALESCE(u.location, '')), '') AS location,
  NULLIF(TRIM(COALESCE(u.state_territory, '')), '') AS state_territory,
  NULLIF(TRIM(COALESCE(u.phone_number, '')), '') AS phone_number,
  NULLIF(TRIM(COALESCE(u.profile_image_url, '')), '') AS profile_image_url,
  COALESCE(u.created_at, now()) AS created_at,
  COALESCE(u.updated_at, now()) AS updated_at
FROM users u
ON CONFLICT (id) DO UPDATE SET
  full_name = NULLIF(TRIM(COALESCE(EXCLUDED.full_name, '')), ''),
  location = NULLIF(TRIM(COALESCE(EXCLUDED.location, '')), ''),
  state_territory = NULLIF(TRIM(COALESCE(EXCLUDED.state_territory, '')), ''),
  phone_number = NULLIF(TRIM(COALESCE(EXCLUDED.phone_number, '')), ''),
  profile_image_url = NULLIF(TRIM(COALESCE(EXCLUDED.profile_image_url, '')), ''),
  updated_at = now();