/*
  # Add User Profile Image Support

  1. Changes
    - Add `profile_image_url` column to users table
    - Create `user-profiles` storage bucket for profile images
    - Add storage policies for profile image uploads

  2. Security
    - Users can upload their own profile images
    - Users can view their own profile images
    - Users can update their own profile images
    - Users can delete their own profile images
*/

-- Add profile_image_url column to users table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'users' AND column_name = 'profile_image_url'
  ) THEN
    ALTER TABLE users ADD COLUMN profile_image_url text;
  END IF;
END $$;

-- Create storage bucket for user profile images
INSERT INTO storage.buckets (id, name, public)
VALUES ('user-profiles', 'user-profiles', true)
ON CONFLICT (id) DO NOTHING;

-- Storage policies for user profile images
CREATE POLICY "Users can upload their own profile image"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'user-profiles' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Users can view their own profile image"
ON storage.objects FOR SELECT
TO authenticated
USING (
  bucket_id = 'user-profiles' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Users can update their own profile image"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'user-profiles' AND
  (storage.foldername(name))[1] = auth.uid()::text
)
WITH CHECK (
  bucket_id = 'user-profiles' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Users can delete their own profile image"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'user-profiles' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Public can view all profile images"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'user-profiles');