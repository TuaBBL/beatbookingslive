/*
  # Create System Cleanup Logs Table

  1. New Tables
    - `system_cleanup_logs`
      - `id` (uuid, primary key)
      - `run_at` (timestamptz, default now)
      - `summary` (jsonb, cleanup results)
      - `status` (text, success/error)
      - `error_message` (text, nullable, error details)
      - `admin_email` (text, who ran it)

  2. Security
    - Enable RLS on system_cleanup_logs table
    - Only admins can read logs
    - System can insert logs
*/

CREATE TABLE IF NOT EXISTS system_cleanup_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  run_at timestamptz DEFAULT now(),
  summary jsonb NOT NULL DEFAULT '{}'::jsonb,
  status text NOT NULL,
  error_message text,
  admin_email text,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE system_cleanup_logs ENABLE ROW LEVEL SECURITY;

-- Only admins can view cleanup logs
CREATE POLICY "Admins can read cleanup logs"
  ON system_cleanup_logs
  FOR SELECT
  TO authenticated
  USING (
    COALESCE(
      current_setting('request.jwt.claims', true)::json->>'role',
      ''
    ) = 'admin'
  );

-- Allow authenticated users to insert (the edge function will check admin status)
CREATE POLICY "Authenticated users can insert cleanup logs"
  ON system_cleanup_logs
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Create index for faster queries
CREATE INDEX IF NOT EXISTS idx_system_cleanup_logs_run_at ON system_cleanup_logs(run_at DESC);
CREATE INDEX IF NOT EXISTS idx_system_cleanup_logs_status ON system_cleanup_logs(status);
