/*
  # Add Email Column to Artist Cards
  
  1. Changes
    - Add `email` column to `Artist Cards` table
    - Set default value to empty string
    - Backfill email from users table for artists with user_id
  
  2. Purpose
    - Store artist email directly in Artist Cards for easier access
    - Automatically populate from user account email
    - Enable direct contact with artists for bookings
*/

-- Add email column to Artist Cards if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Artist Cards' AND column_name = 'email'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN email text DEFAULT '';
  END IF;
END $$;

-- Backfill email from users table for artists with user_id
UPDATE "Artist Cards" ac
SET email = u.email
FROM users u
WHERE ac.user_id = u.id
  AND (ac.email IS NULL OR ac.email = '');
