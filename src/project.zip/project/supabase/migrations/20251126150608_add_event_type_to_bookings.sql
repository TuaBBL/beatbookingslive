/*
  # Add event_type column to bookings table

  1. Changes
    - Add `event_type` column to `bookings` table (text, not null with default)
    - Column will store the type of event (Birthday, Wedding, Corporate, School Ball, Private Event, Other)

  2. Notes
    - Default value set to 'Other' for existing records
    - Field will be required for new bookings through the UI
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'bookings' AND column_name = 'event_type'
  ) THEN
    ALTER TABLE bookings ADD COLUMN event_type text NOT NULL DEFAULT 'Other';
  END IF;
END $$;