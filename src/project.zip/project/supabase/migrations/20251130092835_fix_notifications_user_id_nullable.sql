/*
  # Fix notifications table to support system-wide notifications

  1. Schema Changes
    - Make `user_id` column NULLABLE in notifications table
    - This allows for both user-specific notifications (user_id set) and system-wide notifications (user_id NULL)
    - Keep foreign key constraint with CASCADE delete for user-specific notifications
  
  2. Why This Change
    - The notify_new_artist trigger creates system notifications without a specific recipient
    - Current NOT NULL constraint causes "null value in column user_id violates not-null constraint" error
    - Making it nullable enables flexible notification types
  
  3. Impact
    - User-specific notifications: user_id points to specific user
    - System-wide notifications: user_id is NULL (visible to all authenticated users)
    - No data loss: existing notifications already have user_id populated
*/

-- Make user_id nullable to support system-wide notifications
ALTER TABLE notifications 
  ALTER COLUMN user_id DROP NOT NULL;
