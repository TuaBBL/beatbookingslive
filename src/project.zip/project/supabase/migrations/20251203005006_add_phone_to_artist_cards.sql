/*
  # Add phone column to artist_cards table

  1. Changes
    - Add `phone` text column to `artist_cards` table
    - Migrate existing phone numbers from `artist_profiles` to `artist_cards`

  2. Notes
    - Phone is optional for artists
    - Backfills existing phone data from artist_profiles
*/

-- Add phone column if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'artist_cards' AND column_name = 'phone'
  ) THEN
    ALTER TABLE artist_cards ADD COLUMN phone text;
  END IF;
END $$;

-- Migrate phone numbers from artist_profiles to artist_cards
UPDATE artist_cards ac
SET phone = ap.phone
FROM artist_profiles ap
WHERE ac.id = ap.artist_card_id
  AND ap.phone IS NOT NULL
  AND ap.phone != ''
  AND ac.phone IS NULL;
