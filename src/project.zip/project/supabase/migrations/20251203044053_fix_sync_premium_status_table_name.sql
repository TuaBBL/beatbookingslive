/*
  # Fix sync_artist_premium_status Function Table Name

  1. Changes
    - Update function to use correct table name: artist_cards (not "Artist Cards")
  
  2. Purpose
    - Fix the sync function so it actually updates the artist_cards table
    - Ensure premium status syncs correctly when subscriptions change

  3. Security
    - Maintain SECURITY DEFINER for system-level updates
*/

-- Function to sync premium status (fixed table name)
CREATE OR REPLACE FUNCTION sync_artist_premium_status()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Update artist cards based on active premium subscriptions
  UPDATE artist_cards ac
  SET 
    is_premium = CASE 
      WHEN EXISTS (
        SELECT 1 
        FROM subscriptions s
        WHERE s.user_id = ac.user_id 
        AND s.status = 'active'
        AND s.subscription_type = 'premium'
      ) THEN true
      ELSE false
    END,
    subscription_type = COALESCE(
      (SELECT s.subscription_type 
       FROM subscriptions s
       WHERE s.user_id = ac.user_id 
       AND s.status = 'active' 
       ORDER BY s.created_at DESC 
       LIMIT 1),
      'standard'
    );
END;
$$;

-- Run sync now to fix existing records
SELECT sync_artist_premium_status();
