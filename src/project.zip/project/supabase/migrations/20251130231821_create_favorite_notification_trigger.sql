/*
  # Create Favorite Artist Notification Trigger

  1. New Functions
    - `notify_artist_favorited()` - Trigger function that creates a notification when an artist is added to favorites

  2. Changes
    - Creates a trigger on `user_favorites` table
    - Sends notification to artist when they are favorited
    - Includes user information in the notification

  3. Security
    - Function executes with SECURITY DEFINER to allow notification creation
    - Only creates notifications for valid artist-user pairs
*/

-- Create function to notify artist when they are favorited
CREATE OR REPLACE FUNCTION notify_artist_favorited()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
DECLARE
  v_artist_user_id uuid;
  v_user_name text;
BEGIN
  -- Get the artist's user_id from Artist Cards
  SELECT user_id INTO v_artist_user_id
  FROM "Artist Cards"
  WHERE id = NEW.artist_id;

  -- Only create notification if artist has a user_id
  IF v_artist_user_id IS NOT NULL THEN
    -- Get the user's name who favorited
    SELECT full_name INTO v_user_name
    FROM users
    WHERE id = NEW.user_id;

    -- Create notification for the artist
    INSERT INTO notifications (
      user_id,
      type,
      title,
      message,
      related_id,
      is_read,
      created_at
    ) VALUES (
      v_artist_user_id,
      'favorite',
      'New Favorite!',
      COALESCE(v_user_name, 'A user') || ' added you to their favorite artists!',
      NEW.user_id,
      false,
      now()
    );
  END IF;

  RETURN NEW;
END;
$$;

-- Create trigger on user_favorites insert
DROP TRIGGER IF EXISTS trigger_notify_artist_favorited ON user_favorites;

CREATE TRIGGER trigger_notify_artist_favorited
  AFTER INSERT ON user_favorites
  FOR EACH ROW
  EXECUTE FUNCTION notify_artist_favorited();
