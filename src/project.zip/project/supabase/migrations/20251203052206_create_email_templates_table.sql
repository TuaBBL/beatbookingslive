/*
  # Create Email Templates System

  1. New Tables
    - `email_templates`
      - `id` (uuid, primary key)
      - `template_id` (text, unique) - Template identifier (e.g., 'welcome_artist')
      - `subject` (text) - Email subject line
      - `html` (text) - HTML email content
      - `text` (text) - Plain text fallback
      - `variables` (jsonb) - List of available variables
      - `active` (boolean) - Whether template is active
      - `created_at` (timestamptz)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `email_templates` table
    - Allow public read access (for edge functions)
    - Only service role can write

  3. Purpose
    - Centralized email template management
    - Easy template updates without code changes
    - Variable substitution support
    - Version control for email content
*/

-- Create email_templates table
CREATE TABLE IF NOT EXISTS email_templates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  template_id text UNIQUE NOT NULL,
  subject text NOT NULL,
  html text NOT NULL,
  text text NOT NULL,
  variables jsonb DEFAULT '[]'::jsonb,
  active boolean DEFAULT true NOT NULL,
  created_at timestamptz DEFAULT now() NOT NULL,
  updated_at timestamptz DEFAULT now() NOT NULL
);

-- Create index on template_id for fast lookups
CREATE INDEX IF NOT EXISTS idx_email_templates_template_id ON email_templates(template_id);
CREATE INDEX IF NOT EXISTS idx_email_templates_active ON email_templates(active);

-- Enable RLS
ALTER TABLE email_templates ENABLE ROW LEVEL SECURITY;

-- Policy: Service role can do everything
CREATE POLICY "Service role can manage templates"
  ON email_templates
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- Policy: Authenticated users can read active templates
CREATE POLICY "Authenticated users can read active templates"
  ON email_templates
  FOR SELECT
  TO authenticated
  USING (active = true);

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_email_template_timestamp()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

-- Trigger to auto-update timestamp
DROP TRIGGER IF EXISTS update_email_template_timestamp_trigger ON email_templates;
CREATE TRIGGER update_email_template_timestamp_trigger
  BEFORE UPDATE ON email_templates
  FOR EACH ROW
  EXECUTE FUNCTION update_email_template_timestamp();
