/*
  # Auto-assign featured priority to premium artists

  1. New Functions
    - `assign_featured_priority()` - Assigns featured_priority (1-100) to premium artists based on signup order
  
  2. Trigger
    - Automatically assigns featured_priority when artist becomes premium
  
  3. Purpose
    - First 100 premium artists get featured placement
    - Priority assigned based on when they became premium (earlier = lower number = higher priority)
    - Featured priority is automatically managed
  
  4. Behavior
    - When subscription changes to premium, check available featured slots
    - If spots available (< 100 premium artists), assign next priority number
    - If no spots available, featured_priority remains NULL (no featured placement)
*/

-- Function to assign featured priority to premium artists
CREATE OR REPLACE FUNCTION assign_featured_priority()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Assign featured_priority to premium artists who don't have one yet
  -- Only assign to first 100 premium artists based on when they became premium
  WITH ranked_premium AS (
    SELECT 
      ac.id,
      ROW_NUMBER() OVER (ORDER BY ac.premium_start_date ASC NULLS LAST, ac.created_at ASC) as priority_rank
    FROM "Artist Cards" ac
    WHERE ac.is_premium = true
  )
  UPDATE "Artist Cards" ac
  SET featured_priority = CASE 
    WHEN rp.priority_rank <= 100 THEN rp.priority_rank::integer
    ELSE NULL
  END
  FROM ranked_premium rp
  WHERE ac.id = rp.id;
END;
$$;

-- Update the sync function to also set premium dates and trigger priority assignment
CREATE OR REPLACE FUNCTION sync_artist_premium_status()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  -- Update artist cards based on active premium subscriptions
  UPDATE "Artist Cards" ac
  SET 
    is_premium = CASE 
      WHEN EXISTS (
        SELECT 1 
        FROM subscriptions s
        WHERE s.user_id = ac.user_id 
        AND s.status = 'active'
        AND s.subscription_type = 'premium'
      ) THEN true
      ELSE false
    END,
    subscription_type = COALESCE(
      (SELECT s.subscription_type 
       FROM subscriptions s
       WHERE s.user_id = ac.user_id 
       AND s.status = 'active' 
       ORDER BY s.created_at DESC 
       LIMIT 1),
      'standard'
    ),
    premium_start_date = CASE
      WHEN EXISTS (
        SELECT 1 
        FROM subscriptions s
        WHERE s.user_id = ac.user_id 
        AND s.status = 'active'
        AND s.subscription_type = 'premium'
      ) THEN COALESCE(
        ac.premium_start_date,
        (SELECT s.start_date 
         FROM subscriptions s
         WHERE s.user_id = ac.user_id 
         AND s.status = 'active'
         AND s.subscription_type = 'premium'
         ORDER BY s.created_at DESC 
         LIMIT 1)
      )
      ELSE ac.premium_start_date
    END,
    premium_end_date = CASE
      WHEN EXISTS (
        SELECT 1 
        FROM subscriptions s
        WHERE s.user_id = ac.user_id 
        AND s.status = 'active'
        AND s.subscription_type = 'premium'
      ) THEN (
        SELECT s.end_date 
        FROM subscriptions s
        WHERE s.user_id = ac.user_id 
        AND s.status = 'active'
        AND s.subscription_type = 'premium'
        ORDER BY s.created_at DESC 
        LIMIT 1
      )
      ELSE NULL
    END;
  
  -- Assign featured priority to premium artists
  PERFORM assign_featured_priority();
END;
$$;

-- Run initial sync to assign priorities
SELECT sync_artist_premium_status();
