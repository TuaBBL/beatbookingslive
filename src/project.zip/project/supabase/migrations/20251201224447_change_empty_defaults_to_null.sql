/*
  # Change Empty String Defaults to NULL for Profile Detection

  ## Purpose
  Ensures that incomplete profile fields are stored as NULL instead of empty strings,
  allowing the profile setup modal to correctly detect incomplete profiles on signup.

  ## Changes Made
  
  ### artist_cards table
  - Changes default values from empty strings ('') to NULL for:
    - about
    - location
    - category
    - image_url
    - youtube_link, instagram_link, facebook_link, soundcloud_link, mixcloud_link, spotify_link, tiktok_link
    - stage_name
    - genre
    - email
  - Updates existing empty string values to NULL
  - Keeps meaningful defaults: availability ('available'), profile_status ('draft'), profile_theme ('red'), subscription_type ('standard')
  - name field keeps empty string default as it's NOT NULL

  ### artist_profiles table
  - Changes default values from empty strings ('') to NULL for:
    - phone
  - Updates existing empty string values to NULL
  - email field keeps empty string default as it's NOT NULL

  ## Security
  No RLS changes - maintains existing security policies
*/

-- ============================================
-- artist_cards table: Change defaults to NULL
-- ============================================

-- Update default values to NULL for profile fields
ALTER TABLE public.artist_cards 
  ALTER COLUMN about SET DEFAULT NULL,
  ALTER COLUMN location SET DEFAULT NULL,
  ALTER COLUMN category SET DEFAULT NULL,
  ALTER COLUMN image_url SET DEFAULT NULL,
  ALTER COLUMN youtube_link SET DEFAULT NULL,
  ALTER COLUMN instagram_link SET DEFAULT NULL,
  ALTER COLUMN facebook_link SET DEFAULT NULL,
  ALTER COLUMN soundcloud_link SET DEFAULT NULL,
  ALTER COLUMN mixcloud_link SET DEFAULT NULL,
  ALTER COLUMN spotify_link SET DEFAULT NULL,
  ALTER COLUMN tiktok_link SET DEFAULT NULL,
  ALTER COLUMN stage_name SET DEFAULT NULL,
  ALTER COLUMN genre SET DEFAULT NULL,
  ALTER COLUMN email SET DEFAULT NULL;

-- Update existing empty strings to NULL in artist_cards
UPDATE public.artist_cards SET about = NULL WHERE about = '';
UPDATE public.artist_cards SET location = NULL WHERE location = '';
UPDATE public.artist_cards SET category = NULL WHERE category = '';
UPDATE public.artist_cards SET image_url = NULL WHERE image_url = '';
UPDATE public.artist_cards SET youtube_link = NULL WHERE youtube_link = '';
UPDATE public.artist_cards SET instagram_link = NULL WHERE instagram_link = '';
UPDATE public.artist_cards SET facebook_link = NULL WHERE facebook_link = '';
UPDATE public.artist_cards SET soundcloud_link = NULL WHERE soundcloud_link = '';
UPDATE public.artist_cards SET mixcloud_link = NULL WHERE mixcloud_link = '';
UPDATE public.artist_cards SET spotify_link = NULL WHERE spotify_link = '';
UPDATE public.artist_cards SET tiktok_link = NULL WHERE tiktok_link = '';
UPDATE public.artist_cards SET stage_name = NULL WHERE stage_name = '';
UPDATE public.artist_cards SET genre = NULL WHERE genre = '';
UPDATE public.artist_cards SET email = NULL WHERE email = '';

-- ============================================
-- artist_profiles table: Change defaults to NULL
-- ============================================

-- Update default values to NULL for profile fields
ALTER TABLE public.artist_profiles 
  ALTER COLUMN phone SET DEFAULT NULL;

-- Update existing empty strings to NULL in artist_profiles
UPDATE public.artist_profiles SET phone = NULL WHERE phone = '';

-- ============================================
-- users table: Change defaults to NULL
-- ============================================

-- Update default values to NULL for profile fields
ALTER TABLE public.users 
  ALTER COLUMN full_name SET DEFAULT NULL,
  ALTER COLUMN location SET DEFAULT NULL;

-- Update existing empty strings to NULL in users
UPDATE public.users SET full_name = NULL WHERE full_name = '';
UPDATE public.users SET location = NULL WHERE location = '';
