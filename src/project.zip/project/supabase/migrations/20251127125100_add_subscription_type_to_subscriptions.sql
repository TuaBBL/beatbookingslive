/*
  # Add subscription_type to subscriptions table

  1. Changes
    - Add subscription_type column to track standard vs premium
    - Add is_free_forever column to track first 50 artists
  
  2. Purpose
    - Differentiate between standard and premium subscriptions
    - Track free forever subscriptions for first 50 artists
*/

-- Add subscription_type column if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'subscriptions' AND column_name = 'subscription_type'
  ) THEN
    ALTER TABLE subscriptions 
    ADD COLUMN subscription_type text DEFAULT 'standard'
    CHECK (subscription_type IN ('standard', 'premium'));
  END IF;
END $$;

-- Add is_free_forever column if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'subscriptions' AND column_name = 'is_free_forever'
  ) THEN
    ALTER TABLE subscriptions 
    ADD COLUMN is_free_forever boolean DEFAULT false;
  END IF;
END $$;