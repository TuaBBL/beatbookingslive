/*
  # Create Admin Role System

  1. New Columns
    - Add `role` column to `users` table (admin, ambassador, user)
    
  2. Admin RLS Policies
    - Admins and ambassadors can read all profiles
    - Admins and ambassadors can read all artist_cards
    - Admins and ambassadors can read all users
    - Normal users cannot escalate roles
    
  3. Helper Functions
    - Function to check if user is admin or ambassador
*/

-- Add role column to users table
ALTER TABLE users ADD COLUMN IF NOT EXISTS role text DEFAULT 'user';

-- Add constraint
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.constraint_column_usage 
    WHERE table_name = 'users' AND constraint_name = 'users_role_check'
  ) THEN
    ALTER TABLE users ADD CONSTRAINT users_role_check CHECK (role IN ('user', 'ambassador', 'admin'));
  END IF;
END $$;

-- Create index on role for performance
CREATE INDEX IF NOT EXISTS idx_users_role ON users(role);

-- Create function to check if current user is admin or ambassador
CREATE OR REPLACE FUNCTION is_admin_or_ambassador()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM users
    WHERE id = auth.uid()
    AND role IN ('admin', 'ambassador')
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop existing conflicting policies if they exist
DROP POLICY IF EXISTS "Admins and ambassadors can read all profiles" ON profiles;
DROP POLICY IF EXISTS "Admins and ambassadors can read all artist cards" ON artist_cards;
DROP POLICY IF EXISTS "Admins and ambassadors can read all users" ON users;
DROP POLICY IF EXISTS "Users cannot change their own role" ON users;
DROP POLICY IF EXISTS "Admins can update user roles" ON users;

-- Admin read policy for profiles table
CREATE POLICY "Admins and ambassadors can read all profiles"
ON profiles FOR SELECT
TO authenticated
USING (
  is_admin_or_ambassador()
);

-- Admin read policy for artist_cards table
CREATE POLICY "Admins and ambassadors can read all artist cards"
ON artist_cards FOR SELECT
TO authenticated
USING (
  is_admin_or_ambassador()
);

-- Admin read policy for users table
CREATE POLICY "Admins and ambassadors can read all users"
ON users FOR SELECT
TO authenticated
USING (
  is_admin_or_ambassador()
);
