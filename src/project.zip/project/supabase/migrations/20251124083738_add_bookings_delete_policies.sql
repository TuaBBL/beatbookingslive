/*
  # Add DELETE policies for bookings table

  1. Changes
    - Add DELETE policy for users to delete their own bookings
    - Add DELETE policy for artists to delete bookings for their artist cards

  2. Security
    - Users can delete their own booking requests
    - Artists can delete booking requests made to them
*/

-- Users can delete their own bookings
CREATE POLICY "Users can delete own bookings"
  ON bookings
  FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Artists can delete bookings for their artist cards
CREATE POLICY "Artists can delete bookings for their cards"
  ON bookings
  FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM "Artist Cards"
      WHERE "Artist Cards".id = bookings.artist_id
      AND "Artist Cards".user_id = auth.uid()
    )
  );
