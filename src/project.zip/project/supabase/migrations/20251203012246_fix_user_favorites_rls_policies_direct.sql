/*
  # Fix user_favorites RLS Policies - Direct Auth Check

  1. Changes
    - Simplify RLS policies to directly check auth.uid()
    - Remove unnecessary subquery to users table
    - user_favorites.user_id should directly reference auth.users.id
    
  2. Security
    - Users can only manage their own favorites
    - Direct auth.uid() check is more reliable and faster
*/

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view their own favorites" ON user_favorites;
DROP POLICY IF EXISTS "Users can add their own favorites" ON user_favorites;
DROP POLICY IF EXISTS "Users can remove their own favorites" ON user_favorites;

-- Create simplified policies with direct auth.uid() check
CREATE POLICY "Users can view their own favorites"
  ON user_favorites
  FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

CREATE POLICY "Users can add their own favorites"
  ON user_favorites
  FOR INSERT
  TO authenticated
  WITH CHECK (user_id = auth.uid());

CREATE POLICY "Users can remove their own favorites"
  ON user_favorites
  FOR DELETE
  TO authenticated
  USING (user_id = auth.uid());
