/*
  # Create Storage Buckets for Artist Media

  1. Storage Buckets
    - Create `artist-images` bucket for image uploads
    - Create `artist-videos` bucket for video uploads
    - Set appropriate size limits and file type restrictions

  2. Storage Policies
    - Artists can upload files to their own folders
    - Artists can delete their own files
    - Public read access for all files (for displaying on profiles)
    - Authenticated artists can upload images up to 5MB
    - Authenticated artists can upload videos up to 100MB

  3. Security
    - Row Level Security on storage objects
    - File path naming convention: {user_id}/{filename}
*/

-- Create storage buckets
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES 
  (
    'artist-images',
    'artist-images',
    true,
    5242880,
    ARRAY['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp']
  ),
  (
    'artist-videos',
    'artist-videos',
    true,
    104857600,
    ARRAY['video/mp4', 'video/webm', 'video/ogg', 'video/quicktime']
  )
ON CONFLICT (id) DO NOTHING;

-- Storage policies for artist-images bucket
CREATE POLICY "Artists can upload their own images"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'artist-images' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Artists can update their own images"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'artist-images' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Artists can delete their own images"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'artist-images' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Anyone can view images"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'artist-images');

-- Storage policies for artist-videos bucket
CREATE POLICY "Artists can upload their own videos"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'artist-videos' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Artists can update their own videos"
ON storage.objects FOR UPDATE
TO authenticated
USING (
  bucket_id = 'artist-videos' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Artists can delete their own videos"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'artist-videos' AND
  (storage.foldername(name))[1] = auth.uid()::text
);

CREATE POLICY "Anyone can view videos"
ON storage.objects FOR SELECT
TO public
USING (bucket_id = 'artist-videos');