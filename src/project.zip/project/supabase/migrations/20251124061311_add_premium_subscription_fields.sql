/*
  # Add Premium Subscription Fields

  1. Changes to Tables
    - `Artist Cards`
      - Add `is_premium` (boolean) - Indicates if artist has active premium subscription
      - Add `premium_start_date` (timestamptz) - When premium subscription started
      - Add `premium_end_date` (timestamptz) - When premium subscription ends
      - Add `featured_priority` (integer) - Priority ranking for featured section (1-100)
    
  2. Purpose
    - Track which artists have premium subscriptions
    - Enable featured artist section (max 100 artists)
    - Allow premium artists to appear first in searches
    - Maintain priority ordering for featured artists

  3. Security
    - Maintain existing RLS policies
*/

-- Add premium subscription fields to Artist Cards
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Artist Cards' AND column_name = 'is_premium'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN is_premium boolean DEFAULT false;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Artist Cards' AND column_name = 'premium_start_date'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN premium_start_date timestamptz;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Artist Cards' AND column_name = 'premium_end_date'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN premium_end_date timestamptz;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'Artist Cards' AND column_name = 'featured_priority'
  ) THEN
    ALTER TABLE "Artist Cards" ADD COLUMN featured_priority integer;
  END IF;
END $$;

-- Create an index for faster queries on premium status
CREATE INDEX IF NOT EXISTS idx_artist_cards_is_premium ON "Artist Cards"(is_premium);
CREATE INDEX IF NOT EXISTS idx_artist_cards_featured_priority ON "Artist Cards"(featured_priority) WHERE featured_priority IS NOT NULL;