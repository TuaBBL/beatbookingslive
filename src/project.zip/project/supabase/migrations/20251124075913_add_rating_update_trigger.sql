/*
  # Add Rating Update Trigger

  1. Changes
    - Creates a function to calculate average rating from reviews
    - Creates a trigger to automatically update artist card rating when reviews are added, updated, or deleted
    - Ensures artist card ratings always reflect current review averages

  2. Security
    - Function runs with SECURITY DEFINER to ensure it can update ratings regardless of RLS policies
*/

-- Function to update artist card rating based on reviews
CREATE OR REPLACE FUNCTION update_artist_rating()
RETURNS TRIGGER AS $$
BEGIN
  -- Update the artist card rating with the average of all reviews
  UPDATE "Artist Cards"
  SET rating = (
    SELECT COALESCE(AVG(rating), 0)
    FROM reviews
    WHERE artist_id = COALESCE(NEW.artist_id, OLD.artist_id)
  )
  WHERE id = COALESCE(NEW.artist_id, OLD.artist_id);
  
  RETURN COALESCE(NEW, OLD);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Drop trigger if it exists
DROP TRIGGER IF EXISTS trigger_update_artist_rating ON reviews;

-- Create trigger for INSERT, UPDATE, and DELETE on reviews
CREATE TRIGGER trigger_update_artist_rating
AFTER INSERT OR UPDATE OR DELETE ON reviews
FOR EACH ROW
EXECUTE FUNCTION update_artist_rating();