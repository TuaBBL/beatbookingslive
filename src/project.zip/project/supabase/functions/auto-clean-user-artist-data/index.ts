import { createClient } from 'npm:@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface CleanupSummary {
  artists_fixed: number;
  user_rows_deleted: number;
  new_artist_profiles_created: number;
  normal_users_fixed: number;
  missing_user_rows_created: number;
  orphan_artist_profiles_removed: number;
  metadata_roles_fixed: number;
  errors: string[];
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const summary: CleanupSummary = {
      artists_fixed: 0,
      user_rows_deleted: 0,
      new_artist_profiles_created: 0,
      normal_users_fixed: 0,
      missing_user_rows_created: 0,
      orphan_artist_profiles_removed: 0,
      metadata_roles_fixed: 0,
      errors: [],
    };

    // =========================================
    // 1. FETCH ALL AUTH USERS
    // =========================================
    console.log('Step 1: Fetching all auth users...');
    const { data: authResponse, error: authError } = await supabase.auth.admin.listUsers();
    
    if (authError) {
      throw new Error(`Failed to fetch auth users: ${authError.message}`);
    }

    const authUsers = authResponse.users;
    console.log(`Found ${authUsers.length} auth users`);

    // =========================================
    // 2-4. PROCESS EACH USER
    // =========================================
    for (const user of authUsers) {
      try {
        const userId = user.id;
        const userEmail = user.email || '';
        const userRole = user.user_metadata?.role;

        console.log(`\nProcessing user: ${userEmail} (${userId})`);
        console.log(`  Role in metadata: ${userRole || 'none'}`);

        // =========================================
        // 2. DETECT ARTISTS BY ROLE
        // =========================================
        const isArtist = userRole === 'artist';

        if (isArtist) {
          // =========================================
          // 3. CLEAN ARTIST ACCOUNTS
          // =========================================
          console.log(`  → Processing as ARTIST`);

          // Step A: Check if artist profile exists
          const { data: artistProfile, error: artistCheckError } = await supabase
            .from('artist_profiles')
            .select('*')
            .eq('user_id', userId)
            .maybeSingle();

          if (artistCheckError) {
            summary.errors.push(`Error checking artist profile for ${userEmail}: ${artistCheckError.message}`);
            continue;
          }

          if (!artistProfile) {
            console.log(`  → Creating missing artist profile`);
            const { error: insertError } = await supabase
              .from('artist_profiles')
              .insert({
                user_id: userId,
                email: userEmail,
                profile_completed: false,
              });

            if (insertError) {
              summary.errors.push(`Error creating artist profile for ${userEmail}: ${insertError.message}`);
            } else {
              summary.new_artist_profiles_created++;
              summary.artists_fixed++;
            }
          } else {
            console.log(`  → Artist profile exists`);
          }

          // Step B: Check and delete users table row if exists
          const { data: userRow, error: userCheckError } = await supabase
            .from('users')
            .select('*')
            .eq('user_id', userId)
            .maybeSingle();

          if (userCheckError) {
            summary.errors.push(`Error checking users table for ${userEmail}: ${userCheckError.message}`);
            continue;
          }

          if (userRow) {
            console.log(`  → Deleting users table row (artists shouldn't have this)`);
            const { error: deleteError } = await supabase
              .from('users')
              .delete()
              .eq('user_id', userId);

            if (deleteError) {
              summary.errors.push(`Error deleting users row for ${userEmail}: ${deleteError.message}`);
            } else {
              summary.user_rows_deleted++;
              summary.artists_fixed++;
            }
          }

          // Step C: Ensure metadata role is set to artist
          if (userRole !== 'artist') {
            console.log(`  → Fixing metadata role to 'artist'`);
            const { error: metadataError } = await supabase.auth.admin.updateUserById(
              userId,
              {
                user_metadata: { ...user.user_metadata, role: 'artist' },
              }
            );

            if (metadataError) {
              summary.errors.push(`Error updating metadata for ${userEmail}: ${metadataError.message}`);
            } else {
              summary.metadata_roles_fixed++;
              summary.artists_fixed++;
            }
          }

        } else if (userRole === 'user' || userRole === undefined) {
          // =========================================
          // 4. CLEAN NORMAL USERS
          // =========================================
          console.log(`  → Processing as NORMAL USER`);

          // Step A: Check that they have a users profile
          const { data: userProfile, error: userCheckError } = await supabase
            .from('users')
            .select('*')
            .eq('user_id', userId)
            .maybeSingle();

          if (userCheckError) {
            summary.errors.push(`Error checking users profile for ${userEmail}: ${userCheckError.message}`);
            continue;
          }

          if (!userProfile) {
            console.log(`  → Creating missing users profile`);
            const { error: insertError } = await supabase
              .from('users')
              .insert({
                user_id: userId,
                email: userEmail,
                role: 'user',
                profile_completed: false,
              });

            if (insertError) {
              summary.errors.push(`Error creating users profile for ${userEmail}: ${insertError.message}`);
            } else {
              summary.missing_user_rows_created++;
              summary.normal_users_fixed++;
            }
          } else {
            console.log(`  → Users profile exists`);
          }

          // Step B: Ensure they do NOT have an artist profile
          const { data: artistProfile, error: artistCheckError } = await supabase
            .from('artist_profiles')
            .select('*')
            .eq('user_id', userId)
            .maybeSingle();

          if (artistCheckError) {
            summary.errors.push(`Error checking artist profile for ${userEmail}: ${artistCheckError.message}`);
            continue;
          }

          if (artistProfile) {
            console.log(`  → Deleting orphan artist profile (user is not an artist)`);
            const { error: deleteError } = await supabase
              .from('artist_profiles')
              .delete()
              .eq('user_id', userId);

            if (deleteError) {
              summary.errors.push(`Error deleting artist profile for ${userEmail}: ${deleteError.message}`);
            } else {
              summary.orphan_artist_profiles_removed++;
              summary.normal_users_fixed++;
            }
          }
        } else {
          // Unknown role, skip
          console.log(`  → Unknown role '${userRole}', skipping`);
        }

      } catch (userError) {
        summary.errors.push(`Error processing user ${user.email}: ${userError.message}`);
        console.error(`Error processing user ${user.email}:`, userError);
      }
    }

    // =========================================
    // 5. SUMMARY OUTPUT
    // =========================================
    console.log('\n========== CLEANUP SUMMARY ==========');
    console.log(JSON.stringify(summary, null, 2));

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Auto-cleanup completed',
        summary,
      }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );

  } catch (error) {
    console.error('Fatal error in auto-clean function:', error);
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});
