import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from 'npm:@supabase/supabase-js@2.49.1';
import { sendEmail, getEmailTemplate } from "../_shared/email.ts";

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface SubscriptionEmailData {
  email: string;
  subscription_type: string;
  next_billing_date?: string;
  is_founder?: boolean;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const data: SubscriptionEmailData = await req.json();

    if (!data.email || !data.subscription_type) {
      return new Response(
        JSON.stringify({ error: "Email and subscription_type are required" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    let templateId: string;
    let variables: Record<string, string>;

    if (data.is_founder) {
      templateId = 'founder_premium_lifetime';
      variables = {
        artist_name: 'Artist'
      };
    } else {
      templateId = 'subscription_confirmation';
      variables = {
        subscription_type: data.subscription_type.charAt(0).toUpperCase() + data.subscription_type.slice(1),
        next_billing_date: data.next_billing_date || 'N/A'
      };
    }

    const template = await getEmailTemplate(supabase, templateId, variables);

    if (!template) {
      throw new Error(`Email template '${templateId}' not found`);
    }

    const result = await sendEmail({
      to: data.email,
      subject: template.subject,
      html: template.html,
      text: template.text
    });

    if (!result.success) {
      throw new Error(result.error || "Failed to send email");
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: "Subscription confirmation email sent successfully"
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error in subscription confirmation email handler:", error);
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : "An error occurred"
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});