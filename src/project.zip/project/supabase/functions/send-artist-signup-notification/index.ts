import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { sendEmail, createEmailTemplate } from "../_shared/email.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface ArtistData {
  name: string;
  stageName?: string;
  email: string;
  category: string;
  genre?: string;
  location: string;
  phone?: string;
  about: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const artistData: ArtistData = await req.json();

    if (!artistData.name || !artistData.email || !artistData.category) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const adminEmail = Deno.env.get("EMAIL") || "info@beatbookings.com";

    const adminHtml = createEmailTemplate(`
      <h2 style="color: #39ff14;">New Artist Registration</h2>
      <p>A new artist has registered on BeatBookingsLive!</p>

      <div class="info-box">
        <p><strong>Name:</strong> ${artistData.name}</p>
        ${artistData.stageName ? `<p><strong>Stage Name:</strong> ${artistData.stageName}</p>` : ''}
        <p><strong>Email:</strong> ${artistData.email}</p>
        <p><strong>Category:</strong> ${artistData.category}</p>
        ${artistData.genre ? `<p><strong>Genre:</strong> ${artistData.genre}</p>` : ''}
        <p><strong>Location:</strong> ${artistData.location}</p>
        ${artistData.phone ? `<p><strong>Phone:</strong> ${artistData.phone}</p>` : ''}
        <p><strong>About:</strong></p>
        <p>${artistData.about}</p>
      </div>

      <p>Please review and approve this artist profile in the admin dashboard.</p>
    `);

    const welcomeHtml = createEmailTemplate(`
      <h2 style="color: #39ff14;">Welcome to BeatBookingsLive!</h2>
      <p>Hi ${artistData.name},</p>

      <p>Thank you for joining BeatBookingsLive! We're excited to have you as part of our community of talented artists.</p>

      <div class="info-box">
        <h3 style="color: #39ff14; margin-top: 0;">What's Next?</h3>
        <p>✓ Your profile is currently under review</p>
        <p>✓ We'll notify you once your profile is approved and published</p>
        <p>✓ You'll be able to receive booking requests from event planners</p>
        <p>✓ Manage your bookings and profile from your artist dashboard</p>
      </div>

      <p><strong>Profile Features:</strong></p>
      <ul style="color: #cccccc;">
        <li>Upload photos and videos of your performances</li>
        <li>Connect your social media profiles</li>
        <li>Set your availability and pricing</li>
        <li>Receive and respond to booking requests</li>
        <li>Build your reputation with reviews and ratings</li>
      </ul>

      <a href="${Deno.env.get('APP_URL') || 'https://beatbookingslive.com'}" class="button">
        Go to Dashboard
      </a>

      <p>If you have any questions, feel free to reach out to our support team.</p>

      <p>Best regards,<br>The BeatBookingsLive Team</p>
    `);

    const [adminResult, welcomeResult] = await Promise.all([
      sendEmail({
        to: adminEmail,
        subject: `New Artist Registration: ${artistData.stageName || artistData.name}`,
        html: adminHtml,
      }),
      sendEmail({
        to: artistData.email,
        subject: "Welcome to BeatBookingsLive!",
        html: welcomeHtml,
      }),
    ]);

    if (!adminResult.success) {
      console.error("Failed to send admin notification:", adminResult.error);
    }

    if (!welcomeResult.success) {
      console.error("Failed to send welcome email:", welcomeResult.error);
    }

    return new Response(
      JSON.stringify({
        success: true,
        adminEmailSent: adminResult.success,
        welcomeEmailSent: welcomeResult.success,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error in artist signup handler:", error);
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : "An error occurred"
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
