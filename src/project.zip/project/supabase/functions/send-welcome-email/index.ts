import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from 'npm:@supabase/supabase-js@2.49.1';
import { sendEmail, getEmailTemplate } from "../_shared/email.ts";

const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface WelcomeEmailData {
  email: string;
  name?: string;
  userType?: 'artist' | 'planner' | 'user';
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const userData: WelcomeEmailData = await req.json();

    if (!userData.email) {
      return new Response(
        JSON.stringify({ error: "Email is required" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const displayName = userData.name || 'Artist';
    const userType = userData.userType || 'user';

    if (userType === 'artist') {
      const template = await getEmailTemplate(supabase, 'welcome_artist', {
        artist_name: displayName
      });

      if (!template) {
        throw new Error('Welcome email template not found');
      }

      const result = await sendEmail({
        to: userData.email,
        subject: template.subject,
        html: template.html,
        text: template.text
      });

      if (!result.success) {
        throw new Error(result.error || "Failed to send email");
      }

      return new Response(
        JSON.stringify({
          success: true,
          message: "Welcome email sent successfully"
        }),
        {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    return new Response(
      JSON.stringify({
        error: "Only artist welcome emails are supported via template"
      }),
      {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error in welcome email handler:", error);
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : "An error occurred"
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});