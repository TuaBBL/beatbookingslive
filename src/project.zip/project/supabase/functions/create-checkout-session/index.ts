import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
import Stripe from "npm:stripe@14";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      throw new Error("No authorization header");
    }

    const supabaseClient = createClient(
      Deno.env.get("SUPABASE_URL") ?? "",
      Deno.env.get("SUPABASE_ANON_KEY") ?? "",
      {
        global: {
          headers: { Authorization: authHeader },
        },
      }
    );

    const {
      data: { user },
    } = await supabaseClient.auth.getUser();

    if (!user) {
      throw new Error("No user found");
    }

    console.log(`[create-checkout-session] Processing for user: ${user.id}`);

    // Check if user already has is_free_forever = true
    const { data: userData, error: userError } = await supabaseClient
      .from("users")
      .select("is_free_forever")
      .eq("id", user.id)
      .maybeSingle();

    if (userError) {
      console.error(`[create-checkout-session] Error fetching user:`, userError);
      throw userError;
    }

    // If user.is_free_forever = true, return immediately
    if (userData?.is_free_forever === true) {
      console.log(`[create-checkout-session] User has free forever status`);

      return new Response(
        JSON.stringify({
          ok: true,
          status: "free",
          redirect: "/dashboard"
        }),
        {
          headers: {
            ...corsHeaders,
            "Content-Type": "application/json",
          },
          status: 200,
        }
      );
    }

    // User is not free forever - create Stripe checkout session for STANDARD plan
    console.log(`[create-checkout-session] Creating Stripe checkout for standard plan`);

    const { plan, subscriptionType } = await req.json();

    const stripe = new Stripe(Deno.env.get("STRIPE_SECRET_KEY") || "", {
      apiVersion: "2024-11-20.acacia",
    });

    // Create Stripe checkout session for STANDARD subscription
    const session = await stripe.checkout.sessions.create({
      customer_email: user.email,
      line_items: [
        {
          price_data: {
            currency: "aud",
            product_data: {
              name: "Standard Plan",
              description: "Artist profile subscription",
            },
            recurring: {
              interval: "month",
            },
            unit_amount: 2500,
          },
          quantity: 1,
        },
      ],
      mode: "subscription",
      success_url: `${req.headers.get("origin")}/create-artist?success=true`,
      cancel_url: `${req.headers.get("origin")}/?canceled=true`,
      metadata: {
        user_id: user.id,
        plan: plan || "standard",
        subscription_type: "standard",
      },
    });

    return new Response(
      JSON.stringify({ url: session.url }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error: any) {
    console.error("[create-checkout-session] Error:", error);
    return new Response(
      JSON.stringify({ error: error.message || "Internal server error" }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});
