import { createClient } from 'npm:@supabase/supabase-js@2.57.4';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Client-Info, Apikey',
};

interface CleanupSummary {
  artists_fixed: number;
  incorrect_user_rows_deleted: number;
  new_artist_profiles_created: number;
  missing_user_rows_created: number;
  orphan_artist_profiles_removed: number;
  orphan_user_rows_removed: number;
  metadata_roles_fixed: number;
  total_auth_users: number;
  total_artists: number;
  total_regular_users: number;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('No authorization header');
    }

    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: userError } = await supabase.auth.getUser(token);

    if (userError || !user) {
      throw new Error('Unauthorized');
    }

    if (user.email !== 'genetua@gtrax.net') {
      throw new Error('Admin access only');
    }

    const summary: CleanupSummary = {
      artists_fixed: 0,
      incorrect_user_rows_deleted: 0,
      new_artist_profiles_created: 0,
      missing_user_rows_created: 0,
      orphan_artist_profiles_removed: 0,
      orphan_user_rows_removed: 0,
      metadata_roles_fixed: 0,
      total_auth_users: 0,
      total_artists: 0,
      total_regular_users: 0,
    };

    console.log('Starting full auto-clean...');

    const { data: authUsers, error: authError } = await supabase.auth.admin.listUsers();
    if (authError) throw authError;

    summary.total_auth_users = authUsers.users.length;
    console.log(`Found ${authUsers.users.length} auth users`);

    const artistUsers = authUsers.users.filter(u => u.user_metadata?.role === 'artist');
    const regularUsers = authUsers.users.filter(u => u.user_metadata?.role !== 'artist');

    summary.total_artists = artistUsers.length;
    summary.total_regular_users = regularUsers.length;

    console.log(`Artists: ${artistUsers.length}, Regular users: ${regularUsers.length}`);

    // ============================================
    // A. FIX ARTISTS
    // ============================================
    console.log('\n=== FIXING ARTISTS ===');
    for (const authUser of artistUsers) {
      console.log(`Processing artist: ${authUser.email} (${authUser.id})`);

      // Step 1: Check artist_profiles
      const { data: artistProfile } = await supabase
        .from('artist_profiles')
        .select('*')
        .eq('user_id', authUser.id)
        .maybeSingle();

      if (!artistProfile) {
        console.log(`  - Creating missing artist_profile`);
        const { error: insertError } = await supabase
          .from('artist_profiles')
          .insert({
            user_id: authUser.id,
            email: authUser.email,
            profile_completed: false,
          });

        if (!insertError) {
          summary.new_artist_profiles_created++;
          summary.artists_fixed++;
        } else {
          console.error(`  - Error creating artist_profile:`, insertError);
        }
      }

      // Step 2: Check for incorrect users table row
      const { data: userRow } = await supabase
        .from('users')
        .select('id')
        .eq('id', authUser.id)
        .maybeSingle();

      if (userRow) {
        console.log(`  - Deleting incorrect users row`);
        const { error: deleteError } = await supabase
          .from('users')
          .delete()
          .eq('id', authUser.id);

        if (!deleteError) {
          summary.incorrect_user_rows_deleted++;
          summary.artists_fixed++;
        } else {
          console.error(`  - Error deleting users row:`, deleteError);
        }
      }

      // Step 3: Check metadata
      if (authUser.user_metadata?.role !== 'artist') {
        console.log(`  - Fixing role metadata`);
        const { error: updateError } = await supabase.auth.admin.updateUserById(
          authUser.id,
          {
            user_metadata: {
              ...authUser.user_metadata,
              role: 'artist',
            },
          }
        );

        if (!updateError) {
          summary.metadata_roles_fixed++;
          summary.artists_fixed++;
        } else {
          console.error(`  - Error updating metadata:`, updateError);
        }
      }
    }

    // ============================================
    // B. FIX NORMAL USERS
    // ============================================
    console.log('\n=== FIXING REGULAR USERS ===');
    for (const authUser of regularUsers) {
      console.log(`Processing user: ${authUser.email} (${authUser.id})`);

      // Step 1: Check users table
      const { data: userRow } = await supabase
        .from('users')
        .select('*')
        .eq('id', authUser.id)
        .maybeSingle();

      if (!userRow) {
        console.log(`  - Creating missing users row`);
        const { error: insertError } = await supabase
          .from('users')
          .insert({
            id: authUser.id,
            email: authUser.email,
            user_type: 'user',
            profile_completed: false,
          });

        if (!insertError) {
          summary.missing_user_rows_created++;
        } else {
          console.error(`  - Error creating users row:`, insertError);
        }
      }

      // Step 2: Remove bad artist_profiles rows
      const { data: artistProfile } = await supabase
        .from('artist_profiles')
        .select('id')
        .eq('user_id', authUser.id)
        .maybeSingle();

      if (artistProfile) {
        console.log(`  - Deleting incorrect artist_profile`);
        const { error: deleteError } = await supabase
          .from('artist_profiles')
          .delete()
          .eq('user_id', authUser.id);

        if (!deleteError) {
          summary.incorrect_user_rows_deleted++;
        } else {
          console.error(`  - Error deleting artist_profile:`, deleteError);
        }
      }
    }

    // ============================================
    // C. CLEAN UP GHOST & CORRUPT DATA
    // ============================================
    console.log('\n=== CLEANING ORPHANED DATA ===');

    const authUserIds = authUsers.users.map(u => u.id);

    // Remove orphaned users rows
    const { data: allUserRows } = await supabase
      .from('users')
      .select('id');

    if (allUserRows) {
      for (const userRow of allUserRows) {
        if (!authUserIds.includes(userRow.id)) {
          console.log(`  - Removing orphaned users row: ${userRow.id}`);
          const { error } = await supabase
            .from('users')
            .delete()
            .eq('id', userRow.id);

          if (!error) {
            summary.orphan_user_rows_removed++;
          }
        }
      }
    }

    // Remove orphaned artist_profiles
    const { data: allArtistProfiles } = await supabase
      .from('artist_profiles')
      .select('user_id');

    if (allArtistProfiles) {
      for (const profile of allArtistProfiles) {
        if (!authUserIds.includes(profile.user_id)) {
          console.log(`  - Removing orphaned artist_profile: ${profile.user_id}`);
          const { error } = await supabase
            .from('artist_profiles')
            .delete()
            .eq('user_id', profile.user_id);

          if (!error) {
            summary.orphan_artist_profiles_removed++;
          }
        }
      }
    }

    // ============================================
    // D. LOGGING
    // ============================================
    console.log('\n=== SAVING LOG ===');
    const { error: logError } = await supabase
      .from('system_cleanup_logs')
      .insert({
        summary: summary,
        status: 'success',
        admin_email: user.email,
      });

    if (logError) {
      console.error('Error saving log:', logError);
    }

    console.log('\n=== CLEANUP COMPLETE ===');
    console.log(JSON.stringify(summary, null, 2));

    return new Response(
      JSON.stringify({
        success: true,
        summary,
      }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error: any) {
    console.error('Error in full-auto-clean:', error);

    // Try to log the error
    try {
      const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
      const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
      const supabase = createClient(supabaseUrl, supabaseServiceKey);

      await supabase.from('system_cleanup_logs').insert({
        summary: {},
        status: 'error',
        error_message: error.message,
        admin_email: 'unknown',
      });
    } catch (logError) {
      console.error('Failed to log error:', logError);
    }

    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
      }),
      {
        status: error.message === 'Admin access only' ? 403 : 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});