import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { sendEmail, createEmailTemplate } from "../_shared/email.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface ContactFormData {
  name: string;
  email: string;
  message: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const { name, email, message }: ContactFormData = await req.json();

    if (!name || !email || !message) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const adminEmail = Deno.env.get("EMAIL") || "info@beatbookings.com";

    const adminHtml = createEmailTemplate(`
      <h2 style="color: #39ff14;">New Contact Form Submission</h2>
      <p>You have received a new message from the BeatBookingsLive contact form.</p>

      <div class="info-box">
        <p><strong>Name:</strong> ${name}</p>
        <p><strong>Email:</strong> ${email}</p>
        <p><strong>Message:</strong></p>
        <p>${message.replace(/\n/g, '<br>')}</p>
      </div>

      <p>You can reply directly to this person at: <a href="mailto:${email}" style="color: #39ff14;">${email}</a></p>
    `);

    const result = await sendEmail({
      to: adminEmail,
      subject: `New Contact Form: ${name}`,
      html: adminHtml,
    });

    if (!result.success) {
      throw new Error(result.error || "Failed to send email");
    }

    return new Response(
      JSON.stringify({ success: true, message: "Contact form submitted successfully" }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error in contact form handler:", error);
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : "An error occurred"
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
