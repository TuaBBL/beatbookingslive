import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface BookingNotification {
  artistEmail: string;
  artistName: string;
  userName: string;
  userEmail: string;
  userPhone?: string;
  eventType: string;
  requestedDate: string;
  timeFrom: string;
  timeTo: string;
  location: string;
  comments?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const booking: BookingNotification = await req.json();

    console.log('Received booking data:', booking);

    if (!booking.artistEmail) {
      throw new Error('Artist email is required');
    }

    if (!booking.artistName) {
      throw new Error('Artist name is required');
    }

    if (!booking.userName) {
      throw new Error('User name is required');
    }

    if (!booking.userEmail) {
      throw new Error('User email is required');
    }

    const emailHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(135deg, #39ff14 0%, #ff0000 100%); color: white; padding: 20px; border-radius: 8px 8px 0 0; }
            .content { background: #f9f9f9; padding: 20px; border: 1px solid #ddd; border-top: none; border-radius: 0 0 8px 8px; }
            .info-row { margin: 10px 0; padding: 10px; background: white; border-left: 4px solid #39ff14; }
            .label { font-weight: bold; color: #555; }
            .footer { margin-top: 20px; padding-top: 20px; border-top: 1px solid #ddd; font-size: 12px; color: #777; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <h1 style="margin: 0;">New Booking Request</h1>
            </div>
            <div class="content">
              <p>Hi ${booking.artistName},</p>
              <p>You have received a new booking request from <strong>${booking.userName}</strong>.</p>
              
              <h3 style="color: #39ff14; margin-top: 20px;">Booking Details:</h3>

              <div class="info-row">
                <span class="label">Event Type:</span> ${booking.eventType}
              </div>

              <div class="info-row">
                <span class="label">Date:</span> ${booking.requestedDate}
              </div>

              <div class="info-row">
                <span class="label">Time:</span> ${booking.timeFrom} - ${booking.timeTo}
              </div>

              <div class="info-row">
                <span class="label">Location:</span> ${booking.location}
              </div>
              
              <h3 style="color: #39ff14; margin-top: 20px;">Client Information:</h3>
              
              <div class="info-row">
                <span class="label">Name:</span> ${booking.userName}
              </div>
              
              <div class="info-row">
                <span class="label">Email:</span> <a href="mailto:${booking.userEmail}">${booking.userEmail}</a>
              </div>
              
              ${booking.userPhone ? `
              <div class="info-row">
                <span class="label">Phone:</span> ${booking.userPhone}
              </div>
              ` : ''}
              
              ${booking.comments ? `
              <h3 style="color: #39ff14; margin-top: 20px;">Additional Comments:</h3>
              <div class="info-row">
                ${booking.comments}
              </div>
              ` : ''}
              
              <p style="margin-top: 20px;">
                Please respond to the client directly at <a href="mailto:${booking.userEmail}">${booking.userEmail}</a> to confirm availability and discuss further details.
              </p>
              
              <div class="footer">
                <p>This is an automated notification from Beat Bookings.</p>
              </div>
            </div>
          </div>
        </body>
      </html>
    `;

    const emailText = `
New Booking Request

Hi ${booking.artistName},

You have received a new booking request from ${booking.userName}.

Booking Details:
- Event Type: ${booking.eventType}
- Date: ${booking.requestedDate}
- Time: ${booking.timeFrom} - ${booking.timeTo}
- Location: ${booking.location}

Client Information:
- Name: ${booking.userName}
- Email: ${booking.userEmail}
${booking.userPhone ? `- Phone: ${booking.userPhone}` : ''}

${booking.comments ? `Additional Comments:\n${booking.comments}\n` : ''}
Please respond to the client directly at ${booking.userEmail} to confirm availability and discuss further details.

This is an automated notification from Beat Bookings.
    `;

    const RESEND_API_KEY = Deno.env.get('RESEND_API_KEY');
    
    if (!RESEND_API_KEY) {
      console.error('RESEND_API_KEY not configured');
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'Booking created but email notification not sent (email service not configured)' 
        }),
        {
          status: 200,
          headers: {
            ...corsHeaders,
            'Content-Type': 'application/json',
          },
        }
      );
    }

    const emailPayload = {
      from: 'Beat Bookings <bookings@resend.dev>',
      to: [booking.artistEmail],
      subject: `New Booking Request from ${booking.userName}`,
      html: emailHtml,
      text: emailText,
    };

    console.log('Sending email with payload:', JSON.stringify(emailPayload, null, 2));

    const emailResponse = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${RESEND_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(emailPayload),
    });

    if (!emailResponse.ok) {
      const errorText = await emailResponse.text();
      console.error('Failed to send email:', errorText);

      let errorData;
      try {
        errorData = JSON.parse(errorText);
      } catch {
        errorData = { message: errorText };
      }

      if (errorData.statusCode === 403 && errorData.name === 'validation_error') {
        return new Response(
          JSON.stringify({
            success: true,
            warning: 'Email service is in test mode. Emails can only be sent to verified addresses. Please use the in-app messaging feature to communicate with the artist.',
            testMode: true
          }),
          {
            status: 200,
            headers: {
              ...corsHeaders,
              'Content-Type': 'application/json',
            },
          }
        );
      }

      throw new Error(`Failed to send email: ${errorText}`);
    }

    const emailData = await emailResponse.json();

    return new Response(
      JSON.stringify({ success: true, emailId: emailData.id }),
      {
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});
