interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

interface EmailResponse {
  success: boolean;
  error?: string;
}

const SENDER_NAME = 'BeatBookingsLive Team';
const SENDER_EMAIL = Deno.env.get('EMAIL') || 'info@beatbookings.com';

export async function sendEmail(options: EmailOptions): Promise<EmailResponse> {
  if (!SENDER_EMAIL) {
    console.error('EMAIL environment variable is not set');
    return { success: false, error: 'Email service not configured' };
  }

  try {
    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${Deno.env.get('RESEND_API_KEY')}`,
      },
      body: JSON.stringify({
        from: `${SENDER_NAME} <${SENDER_EMAIL}>`,
        to: options.to,
        subject: options.subject,
        html: options.html,
        text: options.text || stripHtml(options.html),
      }),
    });

    if (!response.ok) {
      const error = await response.text();
      console.error('Email send failed:', error);
      return { success: false, error: `Failed to send email: ${error}` };
    }

    const result = await response.json();
    console.log('Email sent successfully:', result);
    return { success: true };
  } catch (error) {
    console.error('Email error:', error);
    return { success: false, error: error instanceof Error ? error.message : 'Unknown error' };
  }
}

function stripHtml(html: string): string {
  return html
    .replace(/<style[^>]*>.*?<\/style>/gi, '')
    .replace(/<script[^>]*>.*?<\/script>/gi, '')
    .replace(/<[^>]+>/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

export function createEmailTemplate(content: string): string {
  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>BeatBookingsLive</title>
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
      background-color: #000000;
      color: #ffffff;
    }
    .container {
      max-width: 600px;
      margin: 0 auto;
      background-color: #1a1a1a;
      border: 2px solid #39ff14;
      border-radius: 8px;
      overflow: hidden;
    }
    .header {
      background: linear-gradient(135deg, #000000 0%, #1a1a1a 100%);
      padding: 30px 20px;
      text-align: center;
      border-bottom: 3px solid #39ff14;
    }
    .logo {
      font-size: 32px;
      font-weight: bold;
      color: #39ff14;
      text-shadow: 0 0 10px rgba(57, 255, 20, 0.5);
      margin: 0;
    }
    .content {
      padding: 40px 30px;
      line-height: 1.6;
    }
    .content p {
      margin: 0 0 15px 0;
      color: #cccccc;
    }
    .button {
      display: inline-block;
      padding: 12px 30px;
      background-color: #39ff14;
      color: #000000;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
      margin: 20px 0;
      text-align: center;
    }
    .footer {
      background-color: #0a0a0a;
      padding: 20px;
      text-align: center;
      font-size: 12px;
      color: #666666;
      border-top: 1px solid #333333;
    }
    .info-box {
      background-color: #2a2a2a;
      border: 1px solid #39ff14;
      border-radius: 5px;
      padding: 15px;
      margin: 20px 0;
    }
    .info-box strong {
      color: #39ff14;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1 class="logo">BeatBookingsLive</h1>
    </div>
    <div class="content">
      ${content}
    </div>
    <div class="footer">
      <p>&copy; ${new Date().getFullYear()} BeatBookingsLive. All rights reserved.</p>
      <p>This email was sent from info@beatbookings.com</p>
    </div>
  </div>
</body>
</html>
  `.trim();
}