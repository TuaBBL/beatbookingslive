import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { sendEmail, createEmailTemplate } from "./email.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface BookingData {
  artistName: string;
  artistEmail: string;
  userName: string;
  userEmail: string;
  userPhone?: string;
  userProfileImageUrl?: string;
  eventType: string;
  requestedDate: string;
  timeFrom: string;
  timeTo: string;
  location: string;
  comments?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const bookingData: BookingData = await req.json();

    if (!bookingData.artistName || !bookingData.userName || !bookingData.userEmail) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const adminEmail = Deno.env.get("EMAIL") || "info@beatbookings.com";

    const formattedDate = new Date(bookingData.requestedDate).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });

    const adminHtml = createEmailTemplate(`
      <h2 style="color: #39ff14;">New Booking Request</h2>
      <p>A new booking request has been submitted on BeatBookingsLive.</p>

      <div class="info-box">
        <h3 style="color: #39ff14; margin-top: 0;">Artist Information</h3>
        <p><strong>Artist:</strong> ${bookingData.artistName}</p>
        ${bookingData.artistEmail ? `<p><strong>Artist Email:</strong> ${bookingData.artistEmail}</p>` : ''}
      </div>

      <div class="info-box">
        <h3 style="color: #39ff14; margin-top: 0;">Client Information</h3>
        ${bookingData.userProfileImageUrl ? `
          <div style="text-align: center; margin-bottom: 15px;">
            <img src="${bookingData.userProfileImageUrl}" alt="${bookingData.userName}" style="width: 80px; height: 80px; border-radius: 50%; object-fit: cover; border: 3px solid #39ff14;" />
          </div>
        ` : ''}
        <p><strong>Name:</strong> ${bookingData.userName}</p>
        <p><strong>Email:</strong> ${bookingData.userEmail}</p>
        ${bookingData.userPhone ? `<p><strong>Phone:</strong> ${bookingData.userPhone}</p>` : ''}
      </div>

      <div class="info-box">
        <h3 style="color: #39ff14; margin-top: 0;">Event Details</h3>
        <p><strong>Event Type:</strong> ${bookingData.eventType}</p>
        <p><strong>Date:</strong> ${formattedDate}</p>
        <p><strong>Time:</strong> ${bookingData.timeFrom} - ${bookingData.timeTo}</p>
        <p><strong>Location:</strong> ${bookingData.location}</p>
        ${bookingData.comments ? `<p><strong>Additional Comments:</strong><br>${bookingData.comments.replace(/\n/g, '<br>')}</p>` : ''}
      </div>

      <p>The artist has been notified and can respond through their dashboard.</p>
    `);

    const userHtml = createEmailTemplate(`
      <h2 style="color: #39ff14;">Booking Request Confirmed</h2>
      <p>Hi ${bookingData.userName},</p>

      <p>Thank you for your booking request! We've received your inquiry and have notified <strong>${bookingData.artistName}</strong>.</p>

      <div class="info-box">
        <h3 style="color: #39ff14; margin-top: 0;">Your Booking Details</h3>
        <p><strong>Artist:</strong> ${bookingData.artistName}</p>
        <p><strong>Event Type:</strong> ${bookingData.eventType}</p>
        <p><strong>Date:</strong> ${formattedDate}</p>
        <p><strong>Time:</strong> ${bookingData.timeFrom} - ${bookingData.timeTo}</p>
        <p><strong>Location:</strong> ${bookingData.location}</p>
      </div>

      <p><strong>What happens next?</strong></p>
      <ul style="color: #cccccc;">
        <li>The artist will review your request</li>
        <li>You'll receive a notification when they respond</li>
        <li>You can message the artist directly through your dashboard</li>
        <li>Track your booking status in your account</li>
      </ul>

      <a href="${Deno.env.get('APP_URL') || 'https://beatbookingslive.com'}/dashboard" class="button">
        View My Bookings
      </a>

      <p>If you have any questions or need to modify your request, please contact us or reach out to the artist directly.</p>

      <p>Best regards,<br>The BeatBookingsLive Team</p>
    `);

    const [adminResult, userResult] = await Promise.all([
      sendEmail({
        to: adminEmail,
        subject: `New Booking: ${bookingData.artistName} - ${formattedDate}`,
        html: adminHtml,
      }),
      sendEmail({
        to: bookingData.userEmail,
        subject: `Booking Request Confirmed - ${bookingData.artistName}`,
        html: userHtml,
      }),
    ]);

    if (!adminResult.success) {
      console.error("Failed to send admin notification:", adminResult.error);
    }

    if (!userResult.success) {
      console.error("Failed to send user confirmation:", userResult.error);
    }

    return new Response(
      JSON.stringify({
        success: true,
        adminEmailSent: adminResult.success,
        userEmailSent: userResult.success,
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error in booking notification handler:", error);
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : "An error occurred"
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});