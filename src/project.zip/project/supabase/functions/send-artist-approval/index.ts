import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { sendEmail, createEmailTemplate } from "../_shared/email.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface ArtistApprovalData {
  artistName: string;
  artistEmail: string;
  stageName?: string;
  category: string;
  profileUrl?: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const approvalData: ArtistApprovalData = await req.json();

    if (!approvalData.artistName || !approvalData.artistEmail) {
      return new Response(
        JSON.stringify({ error: "Missing required fields" }),
        {
          status: 400,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const displayName = approvalData.stageName || approvalData.artistName;
    const appUrl = Deno.env.get('APP_URL') || 'https://beatbookingslive.com';

    const approvalHtml = createEmailTemplate(`
      <h2 style="color: #39ff14;">🎉 Your Profile is Live!</h2>
      <p>Hi ${displayName},</p>

      <p>Great news! Your artist profile on BeatBookingsLive has been approved and is now <strong>published and live</strong>!</p>

      <div class="info-box">
        <h3 style="color: #39ff14; margin-top: 0;">Your Profile is Now:</h3>
        <p style="margin: 8px 0;">✓ <strong>Visible</strong> to event planners searching for artists</p>
        <p style="margin: 8px 0;">✓ <strong>Featured</strong> in the ${approvalData.category} category</p>
        <p style="margin: 8px 0;">✓ <strong>Ready</strong> to receive booking requests</p>
        <p style="margin: 8px 0;">✓ <strong>Searchable</strong> by location and genre</p>
      </div>

      <p><strong>What you can do now:</strong></p>
      <ul style="color: #cccccc;">
        <li>Start receiving and managing booking requests</li>
        <li>Respond to client inquiries through the messaging system</li>
        <li>Update your profile photos and videos anytime</li>
        <li>Set your availability calendar</li>
        <li>Build your reputation with client reviews</li>
        <li>Track your profile analytics</li>
      </ul>

      ${approvalData.profileUrl ? `
        <a href="${approvalData.profileUrl}" class="button">
          View Your Live Profile
        </a>
      ` : `
        <a href="${appUrl}/artist-profile" class="button">
          Go to Artist Dashboard
        </a>
      `}

      <div class="info-box" style="margin-top: 30px; background-color: #1a3a1a;">
        <h3 style="color: #39ff14; margin-top: 0;">💡 Pro Tip</h3>
        <p>Consider upgrading to <strong>Premium</strong> to unlock:</p>
        <ul style="color: #cccccc; margin: 10px 0;">
          <li>Featured placement in search results</li>
          <li>Unlimited photo and video uploads</li>
          <li>Advanced analytics and insights</li>
          <li>Verified artist badge</li>
          <li>Priority booking notifications</li>
          <li>Custom profile themes</li>
        </ul>
        <a href="${appUrl}/subscription" style="color: #39ff14; text-decoration: underline;">
          Learn More About Premium
        </a>
      </div>

      <p>We're excited to have you as part of the BeatBookingsLive community. If you have any questions or need support, don't hesitate to reach out!</p>

      <p>Best of luck with your bookings,<br>The BeatBookingsLive Team</p>
    `);

    const result = await sendEmail({
      to: approvalData.artistEmail,
      subject: "🎉 Your Artist Profile is Approved & Live!",
      html: approvalHtml,
    });

    if (!result.success) {
      throw new Error(result.error || "Failed to send email");
    }

    return new Response(
      JSON.stringify({
        success: true,
        message: "Approval email sent successfully"
      }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error) {
    console.error("Error in artist approval handler:", error);
    return new Response(
      JSON.stringify({
        error: error instanceof Error ? error.message : "An error occurred"
      }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
