/*
  # Complete User Data Cleanup Script

  Purpose: Remove ALL data for user: djtua75@gmail.com

  This script will:
  1. Look up the user's UUID from auth.users
  2. Delete all related records in correct order (respecting foreign keys)
  3. Finally delete the auth.users record

  Tables affected:
  - admin_messages (as sender, recipient, admin)
  - chat_messages (via conversations)
  - chat_conversations
  - notifications
  - booking_messages (via bookings)
  - bookings
  - user_favorites
  - artist_analytics_detailed (via artist_cards)
  - artist_analytics (via artist_cards)
  - featured_artists (via artist_cards)
  - reviews (as user and for their artist)
  - artist_profiles
  - artist_cards
  - subscriptions
  - stripe_customers
  - profiles
  - users
  - auth.users
*/

-- Step 1: Get the user's UUID
DO $$
DECLARE
  target_user_id uuid;
  target_email text := 'djtua75@gmail.com';
  artist_card_id bigint;
BEGIN
  -- Get user ID
  SELECT id INTO target_user_id
  FROM auth.users
  WHERE email = target_email;

  IF target_user_id IS NULL THEN
    RAISE NOTICE 'User with email % not found', target_email;
    RETURN;
  END IF;

  RAISE NOTICE 'Found user ID: %', target_user_id;

  -- Get artist card ID if exists
  SELECT id INTO artist_card_id
  FROM artist_cards
  WHERE user_id = target_user_id;

  IF artist_card_id IS NOT NULL THEN
    RAISE NOTICE 'Found artist card ID: %', artist_card_id;
  END IF;

  -- Step 2: Delete chat messages (via conversations)
  RAISE NOTICE 'Deleting chat messages...';
  DELETE FROM chat_messages
  WHERE conversation_id IN (
    SELECT id FROM chat_conversations WHERE user_id = target_user_id
  );

  -- Step 3: Delete chat conversations
  RAISE NOTICE 'Deleting chat conversations...';
  DELETE FROM chat_conversations
  WHERE user_id = target_user_id;

  -- Step 4: Delete booking messages (via bookings)
  RAISE NOTICE 'Deleting booking messages...';
  DELETE FROM booking_messages
  WHERE booking_id IN (
    SELECT id FROM bookings WHERE user_id = target_user_id
  );

  -- Also delete messages where user was sender
  DELETE FROM booking_messages
  WHERE sender_id = target_user_id;

  -- Step 5: Delete bookings (as user requesting)
  RAISE NOTICE 'Deleting bookings as requester...';
  DELETE FROM bookings
  WHERE user_id = target_user_id;

  -- Delete bookings for their artist card
  IF artist_card_id IS NOT NULL THEN
    RAISE NOTICE 'Deleting bookings for artist...';
    DELETE FROM bookings
    WHERE artist_id = artist_card_id;
  END IF;

  -- Step 6: Delete notifications
  RAISE NOTICE 'Deleting notifications...';
  DELETE FROM notifications
  WHERE user_id = target_user_id;

  -- Step 7: Delete admin messages (as sender, recipient, or admin)
  RAISE NOTICE 'Deleting admin messages...';
  DELETE FROM admin_messages
  WHERE admin_id = target_user_id
     OR recipient_id = target_user_id
     OR sender_id = target_user_id;

  -- Step 8: Delete user favorites
  RAISE NOTICE 'Deleting user favorites...';
  DELETE FROM user_favorites
  WHERE user_id = target_user_id;

  -- Step 9: Delete artist analytics (if artist)
  IF artist_card_id IS NOT NULL THEN
    RAISE NOTICE 'Deleting artist analytics detailed...';
    DELETE FROM artist_analytics_detailed
    WHERE artist_id = artist_card_id;

    RAISE NOTICE 'Deleting artist analytics...';
    DELETE FROM artist_analytics
    WHERE artist_id = artist_card_id;

    RAISE NOTICE 'Deleting featured artists...';
    DELETE FROM featured_artists
    WHERE artist_id = artist_card_id;
  END IF;

  -- Step 10: Delete reviews (as reviewer and for their artist)
  RAISE NOTICE 'Deleting reviews as reviewer...';
  DELETE FROM reviews
  WHERE user_id = target_user_id;

  IF artist_card_id IS NOT NULL THEN
    RAISE NOTICE 'Deleting reviews for artist...';
    DELETE FROM reviews
    WHERE artist_id = artist_card_id;
  END IF;

  -- Step 11: Delete artist profile
  RAISE NOTICE 'Deleting artist profile...';
  DELETE FROM artist_profiles
  WHERE user_id = target_user_id;

  -- Step 12: Delete artist card
  IF artist_card_id IS NOT NULL THEN
    RAISE NOTICE 'Deleting artist card...';
    DELETE FROM artist_cards
    WHERE id = artist_card_id;
  END IF;

  -- Step 13: Delete subscriptions
  RAISE NOTICE 'Deleting subscriptions...';
  DELETE FROM subscriptions
  WHERE user_id = target_user_id;

  -- Step 14: Delete stripe customers
  RAISE NOTICE 'Deleting stripe customers...';
  DELETE FROM stripe_customers
  WHERE user_id = target_user_id;

  -- Step 15: Delete profiles
  RAISE NOTICE 'Deleting profiles...';
  DELETE FROM profiles
  WHERE id = target_user_id;

  -- Step 16: Delete users table
  RAISE NOTICE 'Deleting users table entry...';
  DELETE FROM users
  WHERE id = target_user_id;

  -- Step 17: Finally delete from auth.users
  RAISE NOTICE 'Deleting auth.users entry...';
  DELETE FROM auth.users
  WHERE id = target_user_id;

  RAISE NOTICE 'Successfully deleted all data for user: %', target_email;
  RAISE NOTICE 'Cleanup complete!';

EXCEPTION
  WHEN OTHERS THEN
    RAISE NOTICE 'Error occurred: %', SQLERRM;
    RAISE EXCEPTION 'Cleanup failed: %', SQLERRM;
END $$;
